"""Keep the Plex sign-in token unreadable for anyone but you (Windows DPAPI).

On Windows, ``protect()`` encrypts a text with the Windows Data Protection API (``CryptProtectData``
in crypt32.dll, called through ctypes, so no extra package) for the Windows user who is signed in:
only that user, on that PC, can decrypt it again. The result is ``"dpapi:" + base64``. Windows never
shows a dialog for it (``CRYPTPROTECT_UI_FORBIDDEN``).

On Linux and macOS, ``protect()`` returns the text unchanged: those systems keep the token as before,
in settings.json, which only its owner may read (the file is chmod 600 already).

``unprotect()`` undoes ``protect()``. Plain text (e.g. from an older settings.json) passes through
unchanged. A ``dpapi:`` value that can't be decrypted raises ``SecretError``: it was saved by another
Windows user or on another PC (for example in a portable data folder copied to another computer),
it is damaged, or this isn't Windows.

Tests swap the backend: ``mock.patch.object(secret, "backend", FakeBackend())``, or ``None`` to act
like Linux/macOS. A backend has ``protect(bytes) -> bytes`` and ``unprotect(bytes) -> bytes`` and
raises ``OSError`` when it can't.
"""

from __future__ import annotations

import base64
import sys
from typing import Any, Optional

PREFIX = "dpapi:"
# Extra input DPAPI mixes into the encryption, so a generic "decrypt everything of this user" call
# without it fails. Never change it: values saved with the old one would stop decrypting.
ENTROPY = b"AniBox settings.json"
DESCRIPTION = "AniBox Plex sign-in"  # stored inside the encrypted data, readable only after decrypting
CRYPTPROTECT_UI_FORBIDDEN = 0x1  # fail instead of showing a dialog


class SecretError(OSError):
    """A protected value that can't be used on this computer, or a value Windows couldn't encrypt.

    An ``OSError``, so code that already handles "couldn't read or write the settings file"
    handles this too.
    """


class DpapiBackend:
    """Windows DPAPI for the current Windows user, through ctypes (Windows only)."""

    def __init__(self) -> None:
        import ctypes
        from ctypes import wintypes

        class Blob(ctypes.Structure):  # DATA_BLOB
            _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]

        self._ct = ctypes
        self._Blob = Blob
        # Own DLL handles, so the argtypes set here can't clash with other code using ctypes.windll.
        crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        blob_p = ctypes.POINTER(Blob)
        self._encrypt = crypt32.CryptProtectData
        self._encrypt.argtypes = [blob_p, wintypes.LPCWSTR, blob_p, ctypes.c_void_p, ctypes.c_void_p,
                                  wintypes.DWORD, blob_p]
        self._encrypt.restype = wintypes.BOOL
        self._decrypt = crypt32.CryptUnprotectData
        self._decrypt.argtypes = [blob_p, ctypes.c_void_p, blob_p, ctypes.c_void_p, ctypes.c_void_p,
                                  wintypes.DWORD, blob_p]
        self._decrypt.restype = wintypes.BOOL
        self._local_free = kernel32.LocalFree
        self._local_free.argtypes = [ctypes.c_void_p]
        self._local_free.restype = ctypes.c_void_p

    def _blob(self, data: bytes) -> Any:
        """A DATA_BLOB pointing at a copy of ``data`` (the buffer is kept alive on the blob)."""
        ct = self._ct
        buf = ct.create_string_buffer(data, len(data))
        blob = self._Blob(len(data), ct.cast(buf, ct.POINTER(ct.c_char)))
        blob._keep = buf
        return blob

    def _call(self, func: Any, data: bytes, description: Optional[str]) -> bytes:
        ct = self._ct
        source, entropy, out = self._blob(data), self._blob(ENTROPY), self._Blob()
        if not func(ct.byref(source), description, ct.byref(entropy), None, None,
                    CRYPTPROTECT_UI_FORBIDDEN, ct.byref(out)):
            raise ct.WinError(ct.get_last_error())
        try:
            return ct.string_at(out.pbData, out.cbData)
        finally:
            if out.pbData:
                self._local_free(ct.cast(out.pbData, ct.c_void_p))  # DPAPI allocated it with LocalAlloc

    def protect(self, data: bytes) -> bytes:
        return self._call(self._encrypt, data, DESCRIPTION)

    def unprotect(self, data: bytes) -> bytes:
        return self._call(self._decrypt, data, None)  # None: don't hand back the description


_AUTO = object()
backend: Any = _AUTO  # _AUTO: DPAPI on Windows, nothing elsewhere. Tests put a fake (or None) here.
_dpapi: Optional[DpapiBackend] = None


def _active() -> Any:
    """The backend in use, or None where values are kept as they are (Linux/macOS)."""
    global _dpapi
    if backend is not _AUTO:
        return backend
    if not sys.platform.startswith("win"):
        return None
    if _dpapi is None:
        _dpapi = DpapiBackend()
    return _dpapi


def available() -> bool:
    """True where ``protect()`` really encrypts (Windows)."""
    try:
        return _active() is not None
    except (OSError, AttributeError):
        return False


def is_protected(value: Any) -> bool:
    """Was this value made by ``protect()`` (``"dpapi:..."``)?"""
    return isinstance(value, str) and value.startswith(PREFIX)


def protect(text: str) -> str:
    """``"dpapi:" + base64`` of ``text`` encrypted for this Windows user; elsewhere ``text`` unchanged.

    Empty and already protected values come back as they are. Raises ``SecretError`` if Windows
    can't encrypt (then nothing should be written).
    """
    if not isinstance(text, str):
        raise TypeError("protect() takes a str")
    if not text or is_protected(text):
        return text
    try:
        engine = _active()
        if engine is None:
            return text
        blob = engine.protect(text.encode("utf-8"))
    except (OSError, AttributeError) as exc:  # AttributeError: no WinDLL (not really Windows)
        raise SecretError(f"Windows couldn't encrypt it: {exc}") from exc  # callers put it in brackets
    return PREFIX + base64.b64encode(blob).decode("ascii")


def unprotect(value: str) -> str:
    """The text ``protect()`` was given. Plain text passes through; raises ``SecretError`` if it can't."""
    if not is_protected(value):
        return value
    try:
        engine = _active()
    except (OSError, AttributeError) as exc:
        raise SecretError(f"Windows couldn't decrypt it ({exc}).") from exc
    if engine is None:
        raise SecretError("It was encrypted on Windows, and only the same Windows user on the same PC "
                          "can decrypt it.")
    try:
        blob = base64.b64decode(value[len(PREFIX):].encode("ascii"), validate=True)
    except ValueError as exc:  # binascii.Error and UnicodeEncodeError are ValueErrors
        raise SecretError("It is damaged (not valid encrypted data).") from exc
    if not blob:
        raise SecretError("It is damaged (not valid encrypted data).")
    try:
        data = engine.unprotect(blob)
    except (OSError, ValueError) as exc:
        raise SecretError("It can't be decrypted here: it was saved by another Windows user or on another "
                          "PC (for example in a portable data folder copied from another computer).") from exc
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise SecretError("It is damaged (not valid encrypted data).") from exc
