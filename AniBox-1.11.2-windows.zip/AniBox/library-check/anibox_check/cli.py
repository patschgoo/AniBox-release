"""Command line entry point: ``python -m anibox_check`` (for developers; users get the same reports on AniBox's Missing page)."""

from __future__ import annotations

import argparse
import getpass
import json
import logging
import os
import sys
import threading
import uuid
import webbrowser
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Set, Tuple

from . import __version__
from .analyze import Analyzer
from .datasets import default_data_dir, ensure_datasets
from .home import home_dir, home_file, legacy_dirs
from .folders import TitleMatcher, folder_items, group_videos, read_listing, walk_folders
from . import ignore, secret
from .plex import PlexAuthError, PlexError, PlexReader, Section, normalize_server_url
from .plextv import PLEX_TV, PinExpired, PlexTv, PlexTvError, find_working_address
from .report import write_csv, write_html

log = logging.getLogger(__name__)

# The fields in settings.json that are secrets: only the Plex server's access token. The rest stays
# readable: "server" (address), "client_id" (the device id Plex lists under Authorized Devices; sent
# openly with every request, not a password) and "server_info" (the server's name, from the app).
SECRET_FIELDS = ("token",)
_settings_lock = threading.RLock()  # one writer at a time in this process (the app has threads)
_warned: Set[Tuple[str, str, str]] = set()


def settings_path() -> Path:
    """Plex sign-in and choices, in AniBox's data folder (see home.py)."""
    return home_file("settings.json")


def ignored_path() -> Path:
    """The list of items hidden from "Not found in the anime lists" (next to settings.json)."""
    settings = settings_path()
    if settings.parent == home_dir():
        return home_file("ignored.txt")
    return settings.parent / "ignored.txt"


def load_settings() -> dict:
    """settings.json, with the secret fields decrypted (see secret.py).

    A secret that can't be decrypted here (saved by another Windows user or on another PC) is left
    out of the result, so the user is simply asked to sign in again; a warning is logged once and
    the file stays as it is. A plain-text token from an older version works as before and is
    encrypted in the file right away (``_protect_in_file``).
    """
    p = settings_path()
    try:
        raw = p.read_text(encoding="utf-8")
        data = json.loads(raw)
    except (OSError, ValueError):
        return {}
    if not isinstance(data, dict):
        return {}
    plain = dropped = False
    for key in SECRET_FIELDS:
        value = data.get(key)
        if not isinstance(value, str) or not value:
            continue
        if not secret.is_protected(value):
            plain = True
            continue
        try:
            data[key] = secret.unprotect(value)
        except secret.SecretError as exc:
            del data[key]
            dropped = True
            if (str(p), key, value) not in _warned:
                _warned.add((str(p), key, value))
                log.warning("Can't use the saved Plex sign-in in %s: %s Sign in again to save a new one.", p, exc)
    if plain and not dropped:  # rewriting now would also lose the value that only its owner can read
        _protect_in_file(p, raw, data)
    return data


def _write_settings(p: Path, data: dict) -> None:
    out = dict(data)  # the caller keeps its plain values
    for key in SECRET_FIELDS:
        value = out.get(key)
        if isinstance(value, str) and value:
            out[key] = secret.protect(value)  # before anything is written: no plain token on disk if this fails
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(out, indent=2), encoding="utf-8")
    try:
        os.chmod(p, 0o600)
    except OSError:
        pass


def _protect_in_file(p: Path, raw: str, data: dict) -> None:
    """Encrypt a plain-text token from an older version now, not only at the next sign-in (which may
    never come while the old one keeps working).

    Only where it's safe: this system encrypts (Windows), the file isn't the old ``%APPDATA%``
    copy that versions up to 1.0 still read (home.py never changes those), and the file is still
    exactly what was read (nothing else saved meanwhile). If anything goes wrong the file stays as
    it was and the token keeps working.
    """
    if not secret.available() or p.parent in legacy_dirs():
        return
    with _settings_lock:
        try:
            if p.read_text(encoding="utf-8") != raw:
                return
            _write_settings(p, data)
        except (OSError, ValueError) as exc:  # SecretError is an OSError
            log.info("Couldn't encrypt the saved Plex sign-in in %s yet (%s); it keeps working as it is.", p, exc)
            return
    log.info("Encrypted the saved Plex sign-in in %s for this Windows user.", p)


def save_settings(data: dict) -> Path:
    """Write settings.json; secret fields are encrypted for this Windows user first (secret.py).

    Raises ``OSError`` if the file can't be written, or ``secret.SecretError`` (an ``OSError``) if
    Windows can't encrypt the token; then nothing is written.
    """
    p = settings_path()
    with _settings_lock:
        _write_settings(p, data)
    return p


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="anibox-check",
        description="Read-only report of missing anime seasons, OVAs, specials and movies in a Plex library.",
    )
    p.add_argument("--server", help="Plex address, e.g. 192.168.178.50 or http://192.168.178.50:32400 (env: PLEX_URL)")
    p.add_argument("--token", help="Your X-Plex-Token (env: PLEX_TOKEN)")
    p.add_argument("--login", action="store_true", help="Sign in again with a code at plex.tv/link")
    p.add_argument("--folders", nargs="+", metavar="FOLDER",
                   help="Check these folders directly instead of Plex (a drive, share or library folder; read-only)")
    p.add_argument("--listing", nargs="+", metavar="FILE",
                   help="Check folders from file lists instead of Plex (one full path per line, e.g. 'dir /s /b' output)")
    p.add_argument("--library", action="append", default=[], help="Library name to check (repeatable). Default: ask, or all.")
    p.add_argument("--out", default=".", help="Folder for the report files (default: current folder)")
    p.add_argument("--posters", action="store_true", help="Show small posters in the report (loaded from MAL's image server)")
    p.add_argument("--csv-delimiter", choices=[";", ","], default=";",
                   help="Column separator in the CSV (default ';', which German Excel expects)")
    p.add_argument("--refresh-data", action="store_true", help="Download the anime lists again even if the copy is fresh")
    p.add_argument("--offline", action="store_true", help="Use only the already downloaded anime lists")
    p.add_argument("--data-dir", help="Where to keep the downloaded anime lists")
    p.add_argument("--no-open", action="store_true", help="Don't open the report in the browser")
    p.add_argument("--save", action="store_true", help="Remember server and token for next time without asking")
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    return p


def _ask(prompt: str, default: str = "") -> str:
    suffix = f" [{default}]" if default else ""
    try:
        answer = input(f"{prompt}{suffix}: ").strip()
    except EOFError:
        answer = ""
    return answer or default


def _probe(uri: str, token: str) -> bool:
    try:
        PlexReader(uri, token, timeout=6, attempts=1).identity()
        return True
    except (PlexError, ValueError):
        return False


def sign_in_with_code(settings: dict, interactive: bool, plex_tv: str = PLEX_TV) -> Tuple[str, str]:
    """Sign in at plex.tv/link and return (server address, server token)."""
    client_id = settings.get("client_id") or str(uuid.uuid4())
    settings["client_id"] = client_id
    tv = PlexTv(client_id, base=plex_tv)
    pin = tv.create_pin()
    print("\nSign in to Plex:")
    print("  1. Open  https://plex.tv/link  (on any device, signed in to your Plex account)")
    print(f"  2. Enter this code:  {pin.code}")
    print("Waiting for you to enter the code (it's valid for about 15 minutes) ...")
    if interactive:
        try:
            webbrowser.open("https://plex.tv/link")
        except Exception:
            pass
    token = tv.wait_for_token(pin)
    print("Signed in. Looking for your Plex server ...")
    servers = tv.servers(token)
    if not servers:
        raise PlexTvError("No Plex server found on this Plex account.")
    server = servers[0]
    if len(servers) > 1 and interactive:
        print("\nServers on this account:")
        for i, s in enumerate(servers, 1):
            print(f"  {i}. {s.name}{'' if s.owned else ' (shared with you)'}")
        answer = _ask("Which one?", "1")
        if answer.isdigit() and 1 <= int(answer) <= len(servers):
            server = servers[int(answer) - 1]
    address = find_working_address(server, _probe)
    if not address:
        raise PlexTvError(f"Found '{server.name}', but couldn't reach it from this computer. Is it on and awake?")
    print(f"Using '{server.name}' at {address}")
    return address, server.access_token


class UseFolders(Exception):
    """The user chose to check folders instead of Plex."""

    def __init__(self, paths: List[str]):
        super().__init__("folders")
        self.paths = paths


def ask_folder_paths() -> List[str]:
    print("\nPaste a folder to check, e.g. the share with your anime or a library folder like ...\\Anime.")
    print("A .txt file with a list of paths (from 'dir /s /b') works too. Press Enter on an empty line when done.")
    paths = []
    while True:
        answer = _ask(f"Folder {len(paths) + 1}").strip().strip('"')
        if not answer:
            return paths
        paths.append(answer)


def ask_connection(settings: dict, interactive: bool, force_code: bool = False,
                   offer_folders: bool = False) -> Tuple[str, str]:
    """Get a server address and token from the user (or raise UseFolders)."""
    if not force_code:
        print("\nHow should AniBox connect to Plex?")
        print("  1. Sign in with a code at plex.tv/link (easiest). AniBox then shows up in your Plex")
        print("     account under 'Authorized Devices', where you can remove it any time.")
        print("  2. Type the server address and an X-Plex-Token yourself (see README.md).")
        if offer_folders:
            print("  3. Don't use Plex: check the anime folders on your drives directly (no sign-in).")
        choice = _ask("Choose " + ("1, 2 or 3" if offer_folders else "1 or 2"), "1")
        if offer_folders and choice == "3":
            raise UseFolders(ask_folder_paths())
        force_code = choice != "2"
    if force_code:
        return sign_in_with_code(settings, interactive)
    print("Plex address: the Shield's IP address on your network, e.g. 192.168.178.50")
    server = _ask("Plex address")
    print("Plex token: see library-check/README.md, section 'Finding your Plex token'.")
    token = getpass.getpass("X-Plex-Token (input hidden): ").strip()
    return server, token


def choose_sections(sections: List[Section], wanted: List[str], interactive: bool) -> List[Section]:
    if wanted:
        lower = {w.lower() for w in wanted}
        chosen = [s for s in sections if s.title.lower() in lower]
        missing = lower - {s.title.lower() for s in chosen}
        if missing:
            names = ", ".join(s.title for s in sections)
            raise SystemExit(f"Library not found: {', '.join(sorted(missing))}. Available: {names}")
        return chosen
    if not interactive or len(sections) <= 1:
        return sections
    print("\nLibraries on this server:")
    for i, s in enumerate(sections, 1):
        print(f"  {i}. {s.title} ({'TV shows' if s.type == 'show' else 'Movies'})")
    answer = _ask("Which ones should be checked? Numbers separated by commas, or Enter for all")
    if not answer:
        return sections
    picked = []
    for part in answer.replace(" ", "").split(","):
        if part.isdigit() and 1 <= int(part) <= len(sections):
            picked.append(sections[int(part) - 1])
    return picked or sections


def _write_reports(report, server_name: str, args, folder_mode: bool = False) -> int:
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y-%m-%d")
    html_path = out_dir / f"AniBox-Report-{stamp}.html"
    csv_path = out_dir / f"AniBox-Report-{stamp}.csv"
    keys = ignore.load(ignored_path())
    ignore.apply(report, keys)

    def write() -> None:
        write_html(report, html_path, server_name, posters=args.posters, folder_mode=folder_mode)
        write_csv(report, csv_path, delimiter=args.csv_delimiter)

    write()
    missing = sum(1 for f in report.franchises for e in f.entries if e.status == "missing" and not e.short)
    what = "folders" if folder_mode else "items"
    print(f"\nDone. {report.identified} of {report.scanned} {what} identified, {missing} entries missing.")
    print(f"Report: {html_path.resolve()}")
    print(f"Spreadsheet: {csv_path.resolve()}")
    interactive = sys.stdin.isatty()
    if not args.no_open and interactive:
        try:
            webbrowser.open(html_path.resolve().as_uri())
        except Exception:
            pass
    if interactive and (report.unidentified or report.ignored):
        ask_ignore(report, keys, write)
    return 0


def _print_not_found(report) -> None:
    items = ignore.numbered(report)
    shown = len(report.unidentified)
    for n, item in enumerate(items, 1):
        mark = "  [ignored]" if n > shown else ""
        print(f"  {n:3}. {item.title}  ({item.section}){mark}")


def ask_ignore(report, keys: List[str], write) -> List[str]:
    """Let the user hide items from the 'Not found' list (saved in ignored.txt for later runs)."""
    print(f"\n'Not found in the anime lists': {len(report.unidentified)} shown, {len(report.ignored)} ignored.")
    _print_not_found(report)
    print("To hide items from that list from now on, type their numbers (e.g. 3,7 or 10-12).")
    print("Typing the number of an ignored item shows it again. Press Enter to finish.")
    while True:
        answer = _ask("Numbers")
        if not answer:
            return keys
        numbers = ignore.parse_numbers(answer)
        keys, bad = ignore.toggle(keys, ignore.numbered(report), [n for n in numbers if n > 0])
        if bad or any(n <= 0 for n in numbers):
            print(f"Skipped: {', '.join(bad) or answer} (not a number from the list).")
        ignore.save(ignored_path(), keys)
        ignore.apply(report, keys)
        write()
        print(f"Saved. Now {len(report.unidentified)} shown, {len(report.ignored)} ignored. "
              "Press F5 in the browser to see the updated report.")
        _print_not_found(report)


def run_folder_check(args, folders: List[str], listings: List[str], interactive: bool) -> int:
    """Check anime folders directly (read-only), without Plex."""
    files: List[str] = []
    for f in listings:
        try:
            files.extend(read_listing(f))
        except OSError as exc:
            print(f"Error: can't read {f} ({exc})", file=sys.stderr)
            return 1
        print(f"Read {f}")
    for d in folders:
        if not os.path.isdir(d):
            print(f"Error: folder not found or not reachable: {d}", file=sys.stderr)
            return 1
        print(f"Reading folders in {d} (this can take a minute on a network share) ...")
        files.extend(walk_folders(d))
    shows = group_videos(files)
    if not shows:
        print("No video files found there.", file=sys.stderr)
        return 1
    counts: dict = {}
    for library, _ in shows:
        counts[library] = counts.get(library, 0) + 1
    libraries = sorted(counts)
    if args.library:
        lower = {w.lower() for w in args.library}
        chosen = [lib for lib in libraries if lib.lower() in lower]
        unknown = lower - {lib.lower() for lib in chosen}
        if unknown:
            raise SystemExit(f"Folder not found: {', '.join(sorted(unknown))}. Found: {', '.join(libraries)}")
    elif interactive and len(libraries) > 1:
        print("\nFolders with shows in them:")
        for i, lib in enumerate(libraries, 1):
            print(f"  {i}. {lib} ({counts[lib]} folders)")
        answer = _ask("Which ones hold anime? Numbers separated by commas, or Enter for all")
        picked = [libraries[int(p) - 1] for p in answer.replace(" ", "").split(",")
                  if p.isdigit() and 1 <= int(p) <= len(libraries)]
        chosen = picked or libraries
    else:
        chosen = libraries

    data_dir = Path(args.data_dir) if args.data_dir else default_data_dir()
    try:
        ds = ensure_datasets(data_dir, refresh=args.refresh_data, offline=args.offline)
    except (OSError, RuntimeError, ValueError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    print("Matching folder names to MyAnimeList titles ...")
    selected = {k: v for k, v in shows.items() if k[0] in chosen}
    items = folder_items(selected, TitleMatcher(ds.titles))
    report = Analyzer(ds).analyze(items, [], folder_mode=True)
    return _write_reports(report, "Folder check: " + ", ".join(chosen), args, folder_mode=True)


def _connect(server: str, token: str) -> Tuple[PlexReader, dict, List[Section]]:
    plex = PlexReader(server, token)
    print(f"Connecting to {plex.base_url} ...")
    return plex, plex.identity(), plex.sections()


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    interactive = sys.stdin.isatty()
    settings = load_settings()

    if args.folders or args.listing:
        return run_folder_check(args, args.folders or [], args.listing or [], interactive)

    server = args.server or os.environ.get("PLEX_URL") or settings.get("server")
    token = args.token or os.environ.get("PLEX_TOKEN") or settings.get("token")
    asked = False
    try:
        if args.login:
            server, token = sign_in_with_code(settings, interactive)
            asked = True
        elif (not server or not token) and interactive:
            server, token = ask_connection(settings, interactive, offer_folders=True)
            asked = True
    except UseFolders as choice:
        paths = choice.paths
        listings = [p for p in paths if p.lower().endswith(".txt") and os.path.isfile(p)]
        return run_folder_check(args, [p for p in paths if p not in listings], listings, interactive)
    except (PlexTvError, PinExpired) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    if not server or not token:
        print("Need --server and --token (or PLEX_URL / PLEX_TOKEN), or run it in a window to sign in.", file=sys.stderr)
        return 2

    for attempt in range(2):
        try:
            plex, ident, sections = _connect(server, token)
            break
        except ValueError as exc:
            print(f"Error: that Plex address doesn't look right ({exc}).", file=sys.stderr)
            return 1
        except PlexAuthError as exc:
            if attempt == 0 and interactive and not args.token:
                print(f"\n{exc}")
                print("Let's sign in again.")
                try:
                    server, token = ask_connection(settings, interactive)
                except (PlexTvError, PinExpired) as exc2:
                    print(f"Error: {exc2}", file=sys.stderr)
                    return 1
                asked = True
                continue
            hint = "" if args.token else f" Sign in again with --login, or fix/delete {settings_path()}."
            print(f"Error: {exc}{hint}", file=sys.stderr)
            return 1
        except PlexError as exc:
            print(f"Error: {exc}", file=sys.stderr)
            return 1
    server_name = ident.get("friendlyName") or plex.base_url

    if args.save or (asked and interactive and _ask("Remember this sign-in for next time? (y/n)", "y").lower().startswith("y")):
        settings.update({"server": normalize_server_url(server), "token": token})
        try:
            print(f"Saved to {save_settings(settings)}")
        except OSError as exc:  # incl. secret.SecretError: Windows couldn't encrypt it
            print(f"Couldn't save the sign-in ({exc}). You'll be asked again next time.", file=sys.stderr)

    if not sections:
        print("No TV or movie libraries found.", file=sys.stderr)
        return 1
    chosen = choose_sections(sections, args.library, interactive)

    data_dir = Path(args.data_dir) if args.data_dir else default_data_dir()
    try:
        ds = ensure_datasets(data_dir, refresh=args.refresh_data, offline=args.offline)
    except (OSError, RuntimeError, ValueError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    shows, movies, orderings = [], [], {}
    try:
        for s in chosen:
            print(f"Reading '{s.title}' ...")
            items = plex.items(s)
            if s.type == "show":
                orderings[s.key] = plex.section_ordering(s)
                shows.extend(items)
            else:
                movies.extend(items)
    except PlexError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    print("Comparing with the anime lists ...")
    report = Analyzer(ds).analyze(shows, movies, orderings)
    return _write_reports(report, server_name, args)
