"""Sign in to Plex with a short code (plex.tv/link) and find the user's Plex servers.

This is the same flow Plex's own TV apps use:

1. Ask plex.tv for a 4-character code.
2. The user opens plex.tv/link and enters it.
3. Poll until plex.tv hands out a token.
4. List the account's servers with their own access tokens and addresses, and keep the first
   address that answers.

Signing in adds "AniBox Library Check" to the Plex account under Authorized Devices, where it
can be removed at any time. Only the server's address and token are kept afterwards.
"""

from __future__ import annotations

import json
import platform
import socket
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from typing import Callable, List, Optional

from . import __version__

PLEX_TV = "https://plex.tv"
PRODUCT = "AniBox Library Check"
POLL_SECONDS = 1.5
MAX_NETWORK_ERRORS = 6


class PlexTvError(Exception):
    pass


class PinExpired(PlexTvError):
    pass


@dataclass
class Pin:
    id: int
    code: str
    expires_in: int


@dataclass
class Server:
    name: str
    access_token: str
    owned: bool = True
    connections: List[dict] = field(default_factory=list)


class PlexTv:
    def __init__(self, client_id: str, base: str = PLEX_TV, timeout: float = 20.0):
        self.client_id = client_id
        self.base = base.rstrip("/")
        self.timeout = timeout

    def _request(self, method: str, path: str, params: Optional[dict] = None, token: Optional[str] = None):
        url = self.base + path + ("?" + urllib.parse.urlencode(params) if params else "")
        req = urllib.request.Request(url, method=method, data=b"" if method == "POST" else None)
        req.add_header("Accept", "application/json")
        req.add_header("X-Plex-Product", PRODUCT)
        req.add_header("X-Plex-Version", __version__)
        req.add_header("X-Plex-Client-Identifier", self.client_id)
        req.add_header("X-Plex-Device-Name", PRODUCT)
        req.add_header("X-Plex-Platform", platform.system() or "Unknown")
        if token:
            req.add_header("X-Plex-Token", token)
        with urllib.request.urlopen(req, timeout=self.timeout) as resp:
            body = resp.read()
        try:
            return json.loads(body.decode("utf-8")) if body else {}
        except ValueError as exc:
            raise PlexTvError(f"plex.tv sent an unexpected answer for {path}") from exc

    def create_pin(self) -> Pin:
        try:
            data = self._request("POST", "/api/v2/pins", {"strong": "false"})
        except (urllib.error.URLError, socket.timeout, ConnectionError) as exc:
            raise PlexTvError(f"Could not reach plex.tv ({exc})") from exc
        try:
            return Pin(int(data["id"]), str(data["code"]), int(data.get("expiresIn") or 900))
        except (KeyError, TypeError, ValueError) as exc:
            raise PlexTvError("plex.tv didn't send a sign-in code") from exc

    def check_pin(self, pin: Pin) -> Optional[str]:
        """The token once the code was entered, else None. Raises PinExpired."""
        try:
            data = self._request("GET", f"/api/v2/pins/{pin.id}", {"code": pin.code})
        except urllib.error.HTTPError as exc:
            if exc.code == 404:
                raise PinExpired("The code expired. Start the sign-in again.") from exc
            raise
        token = data.get("authToken") if isinstance(data, dict) else None
        return str(token) if token else None

    def wait_for_token(
        self,
        pin: Pin,
        sleep: Optional[Callable[[float], None]] = None,
        clock: Optional[Callable[[], float]] = None,
    ) -> str:
        sleep = sleep or time.sleep
        clock = clock or time.monotonic
        deadline = clock() + pin.expires_in
        errors = 0
        while clock() < deadline:
            try:
                token = self.check_pin(pin)
                errors = 0
            except PinExpired:
                raise
            except (urllib.error.URLError, socket.timeout, ConnectionError, PlexTvError) as exc:
                errors += 1
                if errors > MAX_NETWORK_ERRORS:
                    raise PlexTvError(f"Lost the connection to plex.tv ({exc})") from exc
                token = None
            if token:
                return token
            sleep(POLL_SECONDS)
        raise PinExpired("The code expired. Start the sign-in again.")

    def servers(self, token: str) -> List[Server]:
        try:
            data = self._request(
                "GET", "/api/v2/resources", {"includeHttps": 1, "includeRelay": 1, "includeIPv6": 1}, token=token
            )
        except urllib.error.HTTPError as exc:
            raise PlexTvError(f"plex.tv refused the server list (HTTP {exc.code})") from exc
        except (urllib.error.URLError, socket.timeout, ConnectionError) as exc:
            raise PlexTvError(f"Could not reach plex.tv ({exc})") from exc
        out: List[Server] = []
        for d in data if isinstance(data, list) else []:
            if "server" not in str(d.get("provides") or "") and "Media Server" not in str(d.get("product") or ""):
                continue
            if not d.get("accessToken"):
                continue
            out.append(Server(
                name=str(d.get("name") or "Plex Media Server"),
                access_token=str(d["accessToken"]),
                owned=bool(d.get("owned", True)),
                connections=[c for c in d.get("connections") or [] if isinstance(c, dict)],
            ))
        out.sort(key=lambda s: (not s.owned, s.name.lower()))
        return out


def connection_order(server: Server) -> List[str]:
    """Addresses to try: local http, local https (plex.direct), remote, relay. IPv6 is skipped."""
    def rank(c: dict) -> int:
        if c.get("relay"):
            return 3
        if c.get("local"):
            return 0 if c.get("protocol") == "http" else 1
        return 2
    usable = [c for c in server.connections if c.get("uri") and not c.get("IPv6")]
    return [c["uri"] for c in sorted(usable, key=rank)]


def find_working_address(server: Server, probe: Callable[[str, str], bool]) -> Optional[str]:
    for uri in connection_order(server):
        if probe(uri, server.access_token):
            return uri
    return None
