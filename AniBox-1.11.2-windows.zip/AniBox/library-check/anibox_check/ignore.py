"""Items the user chose to hide from the "Not found in the anime lists" list.

They're kept in a small text file (``ignored.txt`` next to AniBox's settings), one per line as
``<library>\\<name>``, so the choice applies to every later report. Hidden items aren't
deleted from anything: the report lists them in a folded-away "Ignored" section, and they can
be shown again at any time.
"""

from __future__ import annotations

from pathlib import Path
from typing import Iterable, List, Tuple

HEADER = (
    "# AniBox Library Check: items hidden from the 'Not found in the anime lists' list.\n"
    "# One per line as <library>\\<name>. Delete a line to show that item again.\n"
)


def item_key(item) -> str:
    return f"{item.section}\\{item.title}"


def _fold(key: str) -> str:
    return " ".join(key.casefold().split())


def load(path: Path) -> List[str]:
    try:
        text = path.read_text(encoding="utf-8-sig")
    except OSError:
        return []
    keys: List[str] = []
    seen = set()
    for line in text.splitlines():
        line = line.strip()
        if line and not line.startswith("#") and _fold(line) not in seen:
            seen.add(_fold(line))
            keys.append(line)
    return keys


def save(path: Path, keys: Iterable[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(HEADER + "".join(f"{k}\n" for k in keys), encoding="utf-8")


def apply(report, keys: Iterable[str]) -> None:
    """Move ignored items from ``report.unidentified`` to ``report.ignored`` (and back)."""
    folded = {_fold(k) for k in keys}
    everything = list(report.unidentified) + list(getattr(report, "ignored", []))
    report.unidentified = [i for i in everything if _fold(item_key(i)) not in folded]
    report.ignored = [i for i in everything if _fold(item_key(i)) in folded]


def numbered(report) -> List:
    """The order the report numbers them in: shown items first, then ignored ones."""
    return list(report.unidentified) + list(report.ignored)


def toggle(keys: List[str], items: List, numbers: Iterable[int]) -> Tuple[List[str], List[str]]:
    """Ignore the given (1-based) items, or show them again if they're ignored already.
    Returns the new key list and the numbers that didn't exist."""
    keys = list(keys)
    bad: List[str] = []
    for n in numbers:
        if not 1 <= n <= len(items):
            bad.append(str(n))
            continue
        key = item_key(items[n - 1])
        match = [k for k in keys if _fold(k) == _fold(key)]
        if match:
            keys = [k for k in keys if _fold(k) != _fold(key)]
        else:
            keys.append(key)
    return keys, bad


def parse_numbers(answer: str) -> List[int]:
    """'3, 7, 10-12' -> [3, 7, 10, 11, 12]"""
    out: List[int] = []
    for part in answer.replace(" ", "").split(","):
        if "-" in part:
            a, _, b = part.partition("-")
            if a.isdigit() and b.isdigit() and int(a) <= int(b) <= int(a) + 500:
                out.extend(range(int(a), int(b) + 1))
                continue
        if part.isdigit():
            out.append(int(part))
        elif part:
            out.append(-1)  # reported as not a valid number
    return out
