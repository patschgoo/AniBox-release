"""Work out which anime entries (by MyAnimeList ID) the library has, and which are missing.

How it works:

1. Every Plex show/movie carries external IDs from its existing match (TVDB, TMDB, IMDb,
   or AniDB/MAL/AniList from older or custom agents). Nothing is re-matched.
2. The anime-lists mapping says which MyAnimeList entries live inside that TVDB/TMDB show,
   and where: season N, or Specials (season 0) starting after a given episode offset.
   TVDB and TMDB often number the same anime differently, so the numbering the library
   actually uses (its "episode ordering") decides which of the two applies.
3. Comparing that with the episodes Plex actually has gives owned / partial / missing.
   When the data can't say for sure, the entry is marked "unsure" (shown as "Check")
   instead of guessing.
4. Franchise groups (related MAL entries) then reveal sequels, OVAs, specials and movies
   that are not in the library at all.
"""

from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Set, Tuple

from .datasets import Datasets
from .ids import ANIDB, ANILIST, IMDB, MAL, MODE_DVD, TMDB, TMDB_MOVIE, TVDB
from .plex import PlexItem

# Statuses, best first.
OWNED = "owned"
PARTIAL = "partial"
UNSURE = "unsure"
MISSING = "missing"
UPCOMING = "upcoming"

STATUS_RANK = {OWNED: 0, PARTIAL: 1, UNSURE: 2, MISSING: 3, UPCOMING: 4}

SHORT_SECONDS = 5 * 60  # clips shorter than this are usually promos, CMs, music videos
CLIP_TYPES = {"SPECIAL", "ONA", "MUSIC"}
SOURCE_LABEL = {"tvdb": "TVDB", "tmdb": "TMDB"}


@dataclass
class EntryResult:
    mal_id: str
    title: str
    type: str
    episodes: Optional[int]
    year: Optional[int]
    status: str
    detail: str  # where it is / where it would go
    plex_title: str = ""  # Plex item it was found in
    have: Optional[int] = None  # episodes present, for partial
    anidb_id: Optional[str] = None
    thumbnail: Optional[str] = None
    short: bool = False
    airing: str = ""

    @property
    def mal_url(self) -> str:
        return f"https://myanimelist.net/anime/{self.mal_id}"

    @property
    def anidb_url(self) -> Optional[str]:
        return f"https://anidb.net/anime/{self.anidb_id}" if self.anidb_id else None


@dataclass
class Franchise:
    name: str
    entries: List[EntryResult] = field(default_factory=list)

    def count(self, *statuses: str, include_short: bool = False) -> int:
        return sum(1 for e in self.entries if e.status in statuses and (include_short or not e.short))


@dataclass
class Report:
    franchises: List[Franchise]
    unidentified: List[PlexItem]
    scanned: int
    identified: int
    titles_meta: dict = field(default_factory=dict)
    ignored: List[PlexItem] = field(default_factory=list)  # hidden from "not found" by the user


@dataclass
class _Slot:
    """Where a MAL entry sits inside a TVDB or TMDB show."""

    kind: str  # "season", "all" (the whole show) or "noseason" (belongs here, numbering unknown)
    source: str  # "tvdb" or "tmdb"
    show_id: str
    season: Optional[int] = None
    offset: Optional[int] = None  # None for season 0 means "somewhere in Specials"

    def same_place(self, other: "_Slot") -> bool:
        return (self.kind, self.season, self.offset) == (other.kind, other.season, other.offset)


def _slot_offset(season: int, offset) -> Optional[int]:
    """anime-lists leaves out offset 0. For a real season that means "starts at episode 1";
    for Specials it means the exact numbers aren't known."""
    if offset is not None:
        return int(offset)
    return 0 if season >= 1 else None


def _as_list(value) -> list:
    if value is None:
        return []
    return value if isinstance(value, list) else [value]


def _show_id(entry: dict, source: str):
    if source == "tvdb":
        return entry.get("tvdb_id")
    return (entry.get("themoviedb_id") or {}).get("tv")


def _entry_slot(entry: dict, source: str, show_id: Optional[str] = None) -> Optional[_Slot]:
    sid = _show_id(entry, source)
    if sid is None or (show_id is not None and str(sid) != show_id):
        return None
    season_map = entry.get("season") or {}
    if season_map.get(source) is not None:
        season = int(season_map[source])
        offset = (entry.get("episode_offset") or {}).get(source)
        return _Slot("season", source, str(sid), season, _slot_offset(season, offset))
    if not season_map:
        return _Slot("all", source, str(sid))
    return _Slot("noseason", source, str(sid))


class _Index:
    def __init__(self, ds: Datasets):
        self.by_mal: Dict[str, dict] = {}
        self.by_anidb: Dict[str, List[dict]] = {}
        self.by_anilist: Dict[str, List[dict]] = {}
        self.by_tvdb: Dict[str, List[dict]] = {}
        self.by_tmdb_tv: Dict[str, List[dict]] = {}
        self.by_tmdb_movie: Dict[str, List[dict]] = {}
        self.by_imdb: Dict[str, List[dict]] = {}
        # How many MAL entries claim the same place (show, season, offset): those can't be told apart.
        self.slot_count: Counter = Counter()
        for e in ds.mapping:
            if e.get("mal_id") is not None:
                self.by_mal[str(e["mal_id"])] = e
            if e.get("anidb_id") is not None:
                self.by_anidb.setdefault(str(e["anidb_id"]), []).append(e)
            if e.get("anilist_id") is not None:
                self.by_anilist.setdefault(str(e["anilist_id"]), []).append(e)
            if e.get("tvdb_id") is not None:
                self.by_tvdb.setdefault(str(e["tvdb_id"]), []).append(e)
            tmdb = e.get("themoviedb_id") or {}
            if tmdb.get("tv") is not None:
                self.by_tmdb_tv.setdefault(str(tmdb["tv"]), []).append(e)
            for mid in _as_list(tmdb.get("movie")):
                self.by_tmdb_movie.setdefault(str(mid), []).append(e)
            for imdb in _as_list(e.get("imdb_id")):
                self.by_imdb.setdefault(str(imdb), []).append(e)
            if e.get("mal_id") is not None:
                for source in ("tvdb", "tmdb"):
                    slot = _entry_slot(e, source)
                    if slot and slot.kind == "season":
                        self.slot_count[(source, slot.show_id, slot.season, slot.offset)] += 1


# -- franchise graph -----------------------------------------------------------------------------

_CROSSOVER_RE = re.compile(r"(\S+)\s+[x×]\s+(\S+)", re.IGNORECASE)


def _looks_crossover(title: Optional[str]) -> bool:
    """Titles shaped like 'A x B' ("Naruto x Ninkuu", but also "Spy x Family"); not 'Hunter x Hunter'."""
    if not title:
        return False
    m = _CROSSOVER_RE.search(title)
    if not m or m.group(1).endswith(":"):  # "Caoyuan Dou Si: X Jiong Tegong" is a subtitle, not "A x B"
        return False
    return m.group(1).strip(":!?,.").lower() != m.group(2).strip(":!?,.").lower()


def _is_clip(info: Optional[dict]) -> bool:
    """Short promo-like entries (CMs, PVs, music videos). Never a TV series: short-format
    shows such as Teekyuu are real content."""
    if not info:
        return False
    duration = info.get("duration")
    if not duration or duration >= SHORT_SECONDS or info.get("type") == "TV":
        return False
    return info.get("type") in CLIP_TYPES or (info.get("episodes") or 1) <= 1


class _UnionFind:
    def __init__(self):
        self.parent: Dict[str, str] = {}

    def find(self, x: str) -> str:
        self.parent.setdefault(x, x)
        root = x
        while self.parent[root] != root:
            root = self.parent[root]
        while self.parent[x] != root:
            self.parent[x], x = root, self.parent[x]
        return root

    def union(self, a: str, b: str) -> None:
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.parent[rb] = ra


class FranchiseGraph:
    """Franchises built from the "related anime" links in the offline database.

    - Only links listed in both directions count, which drops one-sided noise.
    - Short clips (CMs, PVs, music videos) never connect two entries. Otherwise a single
      shared commercial merges unrelated films into one "franchise".
    - An "A x B" title only stops connecting things when it really bridges two franchises
      that are otherwise separate ("Naruto x Ninkuu"). Series like "Spy x Family" or
      "Kiss x Sis" stay normal members of their own franchise.
    - Clips and crossovers still show up next to the entries they belong to.
    - Some old franchises are tied together by crossovers (Lupin III / Detective Conan,
      Fujiko F. Fujio, Tezuka). For groups bigger than BIG_GROUP only entries within
      NEAR_HOPS links of something you own are listed.
    """

    BIG_GROUP = 100
    NEAR_HOPS = 3

    def __init__(self, titles: Dict[str, dict]):
        self.titles = titles
        self.adj: Dict[str, Set[str]] = {}
        for a, info in titles.items():
            for b in info.get("rel") or ():
                b = str(b)
                other = titles.get(b)
                if other is not None and a in {str(x) for x in other.get("rel") or ()}:
                    self.adj.setdefault(a, set()).add(b)
                    self.adj.setdefault(b, set()).add(a)

        clips = {m for m, info in titles.items() if _is_clip(info)}
        candidates = {m for m, info in titles.items() if m not in clips and _looks_crossover(info.get("title"))}
        base = set(titles) - clips - candidates
        uf = _UnionFind()
        for a in base:
            uf.find(a)
            for b in self.adj.get(a, ()):
                if b in base:
                    uf.union(a, b)

        # Attach each "A x B" entry to the one franchise it touches; if it touches two or more,
        # it's a crossover bridge and becomes a leaf.
        bridges: Set[str] = set()
        settled = set(base)
        pending = set(candidates)
        changed = True
        while changed and pending:
            changed = False
            for c in sorted(pending):
                roots = {uf.find(n) for n in self.adj.get(c, ()) if n in settled}
                if len(roots) >= 2:
                    bridges.add(c)
                elif len(roots) == 1:
                    uf.union(next(iter(roots)), c)
                    settled.add(c)
                else:
                    continue
                pending.discard(c)
                changed = True
        # Whatever is left only links to other "A x B" entries: a franchise of its own (e.g. Spy x Family).
        for c in pending:
            uf.find(c)
            for n in self.adj.get(c, ()):
                if n in pending:
                    uf.union(c, n)

        self.leaves = clips | bridges
        groups: Dict[str, List[str]] = {}
        for m in titles:
            if m not in self.leaves:
                groups.setdefault(uf.find(m), []).append(m)
        self.comps: List[List[str]] = list(groups.values())
        self.comp_of: Dict[str, int] = {m: i for i, comp in enumerate(self.comps) for m in comp}

    def _core_neighbors_comp(self, mal_id: str) -> Set[int]:
        return {self.comp_of[n] for n in self.adj.get(mal_id, ()) if n in self.comp_of}

    def _near(self, comp: List[str], starts: Set[str]) -> Set[str]:
        allowed = set(comp)
        seen = {s for s in starts if s in allowed}
        frontier = set(seen)
        for _ in range(self.NEAR_HOPS):
            frontier = {y for x in frontier for y in self.adj.get(x, ()) if y in allowed and y not in seen}
            seen |= frontier
        return seen

    def franchises_for(self, have: Set[str]) -> List[List[str]]:
        """Group the given MAL IDs into franchises and add every related entry."""
        by_comp: Dict[int, Set[str]] = {}
        loose: List[str] = []
        for m in have:
            if m in self.comp_of:
                by_comp.setdefault(self.comp_of[m], set()).add(m)
            else:
                comps = self._core_neighbors_comp(m) if m in self.leaves else set()
                if comps:
                    for c in comps:
                        by_comp.setdefault(c, set()).add(m)
                else:
                    loose.append(m)
        out: List[List[str]] = []
        for c, starts in by_comp.items():
            comp = self.comps[c]
            members = set(comp) if len(comp) <= self.BIG_GROUP else self._near(comp, starts)
            members |= starts
            # Clips and crossovers hang off the entries they relate to.
            members |= {y for x in list(members) for y in self.adj.get(x, ()) if y in self.leaves}
            out.append(sorted(members))
        out.extend([m] for m in loose)
        return out

    def name_for(self, members: List[str], results: Dict[str, "EntryResult"]) -> str:
        """Name a franchise after the earliest TV series you have or that is directly related to
        one you have; fall back to the earliest entry."""
        def key(m):
            info = self.titles.get(m, {})
            return (info.get("year") or 9999, int(m) if m.isdigit() else 0)
        have = [m for m in members if m in results]
        near = set(have) | {y for x in have for y in self.adj.get(x, ()) if y not in self.leaves}
        tv_near = [m for m in members if m in near and self.titles.get(m, {}).get("type") == "TV"]
        tv = [m for m in members if self.titles.get(m, {}).get("type") == "TV" and m not in self.leaves]
        pick = min(tv_near or tv or have or members, key=key)
        info = self.titles.get(pick)
        if info and info.get("title"):
            return info["title"]
        r = results.get(pick)
        return r.title if r else f"MAL #{pick}"


# -- numbering ----------------------------------------------------------------------------------


def numbering_for(item: PlexItem, library_ordering: str) -> str:
    """How this show's seasons are numbered: 'tvdb', 'tmdb', 'absolute', 'dvd' or 'unknown'."""
    if any(m.startswith("hama:tvdb") for m in item.modes):
        return "absolute"  # HAMA's tvdb2-tvdb9 modes don't use plain TVDB seasons
    if MODE_DVD in item.modes:
        return "dvd"
    ordering = (item.ordering or library_ordering or "").lower()
    if ordering:
        if "absolute" in ordering:
            return "absolute"
        if "tmdb" in ordering:
            return "tmdb"
        if "dvd" in ordering:
            return "dvd"
        if "tvdb" in ordering or "aired" in ordering:
            return "tvdb"
    has_tvdb, has_tmdb = TVDB in item.ids, TMDB in item.ids
    if has_tvdb and not has_tmdb:
        return "tvdb"
    if has_tmdb and not has_tvdb:
        return "tmdb"
    return "unknown"


def _span(season: int, start: int, n_eps: int) -> str:
    return f"S{season:02d}E{start:02d}" + (f"–E{start + n_eps - 1:02d}" if n_eps > 1 else "")


class Analyzer:
    def __init__(self, ds: Datasets):
        self.ds = ds
        self.idx = _Index(ds)
        self.graph = FranchiseGraph(ds.titles)

    # -- helpers -------------------------------------------------------------------------------

    def _info(self, mal_id: str) -> dict:
        return self.ds.titles.get(mal_id) or {}

    def _entry_for_mal(self, mal_id: str) -> Optional[dict]:
        if mal_id in self.idx.by_mal:
            return self.idx.by_mal[mal_id]
        if mal_id in self.ds.titles:
            return {"mal_id": mal_id}  # known title, just not in the ID mapping
        return None

    def _result(self, entry: dict, status: str, detail: str, plex_title: str = "", have=None) -> Optional[EntryResult]:
        if entry.get("mal_id") is None:
            return None
        mal_id = str(entry["mal_id"])
        info = self._info(mal_id)
        anidb = entry.get("anidb_id") or info.get("anidb")
        result = EntryResult(
            mal_id=mal_id,
            title=info.get("title") or f"MAL #{mal_id}",
            type=info.get("type") or entry.get("type") or "UNKNOWN",
            episodes=info.get("episodes"),
            year=info.get("year"),
            status=status,
            detail=detail,
            plex_title=plex_title,
            have=have,
            anidb_id=str(anidb) if anidb else None,
            thumbnail=info.get("thumbnail"),
            short=_is_clip(info),
            airing=info.get("status") or "",
        )
        if status == MISSING and info.get("status") == "UPCOMING":
            result.status = UPCOMING
        return result

    def _n_eps(self, entry: dict) -> int:
        return int(self._info(str(entry.get("mal_id"))).get("episodes") or 0)

    # -- placing an entry inside a show --------------------------------------------------------

    def _eval_whole_show(self, item: PlexItem, entry: dict, label: str) -> Optional[EntryResult]:
        regular = len(item.regular_episodes)
        n = self._n_eps(entry)
        if not regular:
            return self._result(entry, MISSING, f"{label}: no episodes yet", item.title, have=0)
        if n and regular < n:
            return self._result(entry, PARTIAL, f"{label}: {regular} of {n} episodes", item.title, have=regular)
        return self._result(entry, OWNED, label, item.title, have=regular)

    def _eval_slot(self, item: PlexItem, entry: dict, slot: _Slot) -> Optional[EntryResult]:
        title = item.title
        if slot.kind == "all":
            return self._eval_whole_show(item, entry, "Whole show")
        if slot.kind == "noseason":
            other = "TMDB" if slot.source == "tvdb" else "TVDB"
            return self._result(
                entry, UNSURE, f"Only numbered on {other}; this show uses {SOURCE_LABEL[slot.source]} order. Check", title
            )

        season, offset = int(slot.season), slot.offset
        present = item.season_episodes(season)
        where = "Specials" if season == 0 else f"Season {season}"
        n = self._n_eps(entry)
        shared = self.idx.slot_count[(slot.source, slot.show_id, season, offset)] - 1

        if offset is None:
            # Somewhere in Specials, exact numbers unknown. If it's the only entry there,
            # anime-lists left out offset 0, so it probably starts at S00E01.
            if shared > 0:
                if present:
                    return self._result(
                        entry, UNSURE, f"Specials (Season 0): you have {len(present)} special(s); check which", title
                    )
                return self._result(entry, MISSING, "Would go in Specials (Season 0)", title)
            if n:
                span = _span(0, 1, n)
                wanted = set(range(1, n + 1))
                if wanted <= present:
                    return self._result(entry, OWNED, f"Specials ({span}, probably)", title, have=n)
                if present:
                    return self._result(
                        entry, UNSURE, f"Specials, probably {span}; you have {len(present)} special(s). Check", title
                    )
                return self._result(entry, MISSING, f"Would go in Specials (probably {span})", title, have=0)
            if present:
                return self._result(entry, UNSURE, f"Specials: you have {len(present)} special(s); check which", title)
            return self._result(entry, MISSING, "Would go in Specials (Season 0)", title)

        start = offset + 1
        if n:
            wanted = set(range(start, start + n))
            have = len(wanted & present)
            span = _span(season, start, n)
            if shared > 0 and have:
                others = "entry" if shared == 1 else "entries"
                return self._result(
                    entry, UNSURE, f"{where} ({span}) is shared with {shared} other {others}; check", title, have=have
                )
            if have == len(wanted):
                return self._result(entry, OWNED, f"{where} ({span})", title, have=have)
            if have:
                return self._result(entry, PARTIAL, f"{where} ({span}): {have} of {n} episodes", title, have=have)
            return self._result(entry, MISSING, f"Would go in {where} ({span})", title, have=0)
        # Episode count unknown (often still airing): any episode from the start counts.
        if any(e >= start for e in present):
            if shared > 0:
                return self._result(entry, UNSURE, f"{where} (from E{start:02d}) is shared with other entries; check", title)
            return self._result(entry, OWNED, f"{where} (from E{start:02d})", title)
        return self._result(entry, MISSING, f"Would go in {where} (from E{start:02d})", title)

    def _place(self, item: PlexItem, entry: dict, numbering: str) -> Optional[EntryResult]:
        """Status of one mapping entry inside one Plex show, or None if it isn't part of this show."""
        slots = {}
        for source in ("tvdb", "tmdb"):
            for sid in item.ids.get(TVDB if source == "tvdb" else TMDB, ()):
                slot = _entry_slot(entry, source, sid)
                if slot:
                    slots[source] = slot
                    break

        if numbering in ("tvdb", "tmdb"):
            slot = slots.get(numbering)
            return self._eval_slot(item, entry, slot) if slot else None

        if numbering == "unknown":
            evaluated = {s: self._eval_slot(item, entry, sl) for s, sl in slots.items()}
            evaluated = {s: r for s, r in evaluated.items() if r is not None}
            if not evaluated:
                return None
            if len(evaluated) == 1 or slots["tvdb"].same_place(slots["tmdb"]):
                return next(iter(evaluated.values()))
            found = [r for r in evaluated.values() if r.status in (OWNED, PARTIAL)]
            if found:
                # The episodes are where one of the two numberings says: that's the one in use.
                return min(found, key=lambda r: STATUS_RANK[r.status])
            if all(r.status == MISSING for r in evaluated.values()):
                tv, tm = evaluated.get("tvdb"), evaluated.get("tmdb")
                detail = " / ".join(
                    f"{r.detail} ({SOURCE_LABEL[s]} order)" for s, r in (("tvdb", tv), ("tmdb", tm)) if r
                )
                return self._result(entry, MISSING, detail, item.title, have=0)
            return min(evaluated.values(), key=lambda r: STATUS_RANK[r.status])

        slot = slots.get("tvdb") or slots.get("tmdb")
        if slot is None:
            return None
        if slot.kind == "all":
            return self._eval_whole_show(item, entry, "Whole show")
        if numbering == "absolute" and slot.kind == "season" and slot.season == 0:
            return self._eval_slot(item, entry, slot)  # Specials keep their numbers
        label = "absolute numbering" if numbering == "absolute" else "DVD order"
        if not item.regular_episodes:
            return self._result(entry, MISSING, f"Would be in this show ({label})", item.title, have=0)
        return self._result(
            entry, UNSURE, f"This show uses {label}: can't tell which episodes belong to this entry. Check", item.title
        )

    # -- matching a show ------------------------------------------------------------------------

    def _direct_entries(self, item: PlexItem) -> List[dict]:
        """Entries named directly by the match (old MAL/AniDB/AniList agents, HAMA movie IDs)."""
        out: List[dict] = []
        seen: Set[int] = set()

        def add(entries: Iterable[Optional[dict]]):
            for e in entries:
                if e is not None and id(e) not in seen:
                    seen.add(id(e))
                    out.append(e)

        for mid in item.ids.get(MAL, ()):
            add([self._entry_for_mal(mid)])
        for aid in item.ids.get(ANIDB, ()):
            add(self.idx.by_anidb.get(aid, []))
        for lid in item.ids.get(ANILIST, ()):
            add(self.idx.by_anilist.get(lid, []))
        for tid in item.ids.get(TMDB_MOVIE, ()):
            add(self.idx.by_tmdb_movie.get(tid, []))
        return out

    def _show_results(self, show: PlexItem, numbering: str) -> Tuple[List[EntryResult], str]:
        """Results for one show, plus a note if nothing could be matched."""
        direct = self._direct_entries(show)
        if direct:
            results = []
            for e in direct:
                if e.get("type") == "MOVIE" and not e.get("tvdb_id") and TMDB_MOVIE in show.ids:
                    status = OWNED if show.episode_count else MISSING
                    results.append(self._result(e, status, "This show (a movie)", show.title))
                else:
                    results.append(self._eval_whole_show(show, e, "This folder" if show.source == "folder" else "This show"))
            merged = [m for m in show.modes if m.startswith("hama:anidb")]
            if merged:
                # HAMA's anidb2+ modes put several AniDB entries into one Plex show.
                direct_ids = {id(e) for e in direct}
                tvdb_ids = {str(e["tvdb_id"]) for e in direct if e.get("tvdb_id") is not None}
                for tid in tvdb_ids:
                    for e in self.idx.by_tvdb.get(tid, []):
                        if id(e) not in direct_ids:
                            results.append(self._result(
                                e, UNSURE, f"May be inside this show (HAMA {merged[0][5:]} numbering); check", show.title
                            ))
            results = [r for r in results if r is not None]
            return results, "" if results else "Matched to an AniDB/AniList entry that has no MyAnimeList ID"

        candidates: List[dict] = []
        seen: Set[int] = set()
        for tid in show.ids.get(TVDB, ()):
            for e in self.idx.by_tvdb.get(tid, []):
                if id(e) not in seen:
                    seen.add(id(e))
                    candidates.append(e)
        for tid in show.ids.get(TMDB, ()):
            for e in self.idx.by_tmdb_tv.get(tid, []):
                if id(e) not in seen:
                    seen.add(id(e))
                    candidates.append(e)
        if candidates:
            results = [self._place(show, e, numbering) for e in candidates]
            results = [r for r in results if r is not None]
            return results, "" if results else "In the anime lists, but no MyAnimeList entry fits this show's numbering"

        imdb = [e for iid in show.ids.get(IMDB, ()) for e in self.idx.by_imdb.get(iid, [])
                if e.get("type") in ("TV", "ONA", "OVA")]
        if len(imdb) == 1:
            r = self._eval_whole_show(show, imdb[0], "This show (matched by IMDb)")
            return ([r] if r else []), ""
        if imdb:
            results = [self._result(e, UNSURE, "Matched only by IMDb; check", show.title) for e in imdb]
            return [r for r in results if r], ""
        return [], "Not in the anime lists (not anime, or matched without TVDB/TMDB/IMDb ID)"

    def _movie_results(self, movie: PlexItem) -> Tuple[List[EntryResult], str]:
        entries: List[dict] = list(self._direct_entries(movie))
        for tid in movie.ids.get(TMDB, ()):
            entries.extend(self.idx.by_tmdb_movie.get(tid, []))
        if not entries:
            for iid in movie.ids.get(IMDB, ()):
                entries.extend(e for e in self.idx.by_imdb.get(iid, []) if e.get("type") == "MOVIE")
        if not entries:
            return [], "Not in the anime lists"
        results = [self._result(e, OWNED, "Movie library", movie.title) for e in entries]
        results = [r for r in results if r is not None]
        return results, "" if results else "In the anime lists, but without a MyAnimeList ID"

    # -- main ----------------------------------------------------------------------------------

    def analyze(
        self,
        shows: List[PlexItem],
        movies: List[PlexItem],
        orderings: Optional[Dict[str, str]] = None,
        folder_mode: bool = False,
    ) -> Report:
        """``orderings`` maps a library's id (section key) to its episode ordering.
        ``folder_mode``: the items come from folders on the drives, not from Plex."""
        orderings = orderings or {}
        results: Dict[str, EntryResult] = {}
        unidentified: List[PlexItem] = []
        identified = 0
        numbering_of: Dict[str, str] = {}

        def keep(r: Optional[EntryResult]):
            if r is None:
                return
            old = results.get(r.mal_id)
            if old is None or STATUS_RANK[r.status] < STATUS_RANK[old.status]:
                results[r.mal_id] = r

        for show in shows:
            numbering = numbering_for(show, orderings.get(show.section_key, ""))
            numbering_of[show.rating_key] = numbering
            found, note = self._show_results(show, numbering)
            if not found:
                show.note = show.note or note  # keep the folder check's own reason
                unidentified.append(show)
                continue
            identified += 1
            for r in found:
                keep(r)

        for movie in movies:
            found, note = self._movie_results(movie)
            if not found:
                movie.note = note
                unidentified.append(movie)
                continue
            identified += 1
            for r in found:
                keep(r)

        # Franchises: everything related to what you have.
        owned_shows = self._owned_show_ids(shows, numbering_of)
        all_fr: List[Franchise] = []
        for members in self.graph.franchises_for(set(results)):
            fr = Franchise(self.graph.name_for(members, results))
            for mid in members:
                if mid in results:
                    fr.entries.append(results[mid])
                    continue
                entry = self._entry_for_mal(mid) or {"mal_id": mid}
                where = "Not on your drives" if folder_mode else self._suggest_place(entry, owned_shows)
                r = self._result(entry, MISSING, where)
                if r:
                    fr.entries.append(r)
            all_fr.append(fr)

        for fr in all_fr:
            fr.entries.sort(key=lambda e: (e.year or 9999, e.title.lower()))
        all_fr.sort(key=lambda f: f.name.lower())
        return Report(
            franchises=all_fr,
            unidentified=sorted(unidentified, key=lambda i: (i.type, i.title.lower())),
            scanned=len(shows) + len(movies),
            identified=identified,
            titles_meta=self.ds.titles_meta,
        )

    # -- suggestions for missing entries -------------------------------------------------------

    def _owned_show_ids(self, shows: List[PlexItem], numbering_of: Dict[str, str]) -> Dict[str, Tuple[str, str]]:
        out: Dict[str, Tuple[str, str]] = {}
        for s in shows:
            numbering = numbering_of.get(s.rating_key, "unknown")
            for kind in (TVDB, TMDB):
                for i in s.ids.get(kind, ()):
                    out[f"{kind}:{i}"] = (s.title, numbering)
        return out

    def _where(self, entry: dict, source: str) -> str:
        slot = _entry_slot(entry, source)
        if slot is None or slot.kind != "season":
            return ""
        n = self._n_eps(entry)
        if slot.season == 0 and slot.offset is None:
            return "Specials"
        where = "Specials" if slot.season == 0 else f"Season {slot.season}"
        return f"{where} ({_span(slot.season, slot.offset + 1, n)})" if n else where

    def _suggest_place(self, entry: dict, owned: Dict[str, Tuple[str, str]]) -> str:
        """Where a missing entry would show up in Plex with the built-in agents."""
        library_numbering = ""
        for source, kind in (("tvdb", TVDB), ("tmdb", TMDB)):
            sid = _show_id(entry, source)
            key = f"{kind}:{sid}" if sid is not None else None
            if key and key in owned:
                show_title, numbering = owned[key]
                if numbering in (source, "unknown") or (numbering in ("absolute", "dvd") and source == "tvdb"):
                    where = self._where(entry, source)
                    return f"Would go in {show_title}" + (f" → {where}" if where else "")
                library_numbering = numbering  # this show counts the other way; the entry lives elsewhere there
        order = ["tmdb", "tvdb"] if library_numbering == "tmdb" else ["tvdb", "tmdb"]
        for source in order:
            sid = _show_id(entry, source)
            if sid is not None:
                where = self._where(entry, source)
                return f"Separate show on {SOURCE_LABEL[source]} ({sid})" + (f", {where}" if where else "")
        tmdb = entry.get("themoviedb_id") or {}
        if tmdb.get("movie"):
            return f"Movie on TMDB ({_as_list(tmdb['movie'])[0]}): add to a movie library"
        return "No TVDB/TMDB link known: Plex's built-in agents may not find it"
