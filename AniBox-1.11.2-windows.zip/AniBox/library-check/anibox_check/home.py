"""The one folder where AniBox keeps everything (Library Check and the app share it).

- Portable mode: a folder named ``data`` next to ``AniBox.bat`` (the top of the AniBox download).
- Otherwise ``%LOCALAPPDATA%\\AniBox`` on Windows and ``~/.local/share/anibox`` elsewhere.
- ``ANIBOX_HOME`` overrides both (used by the tests).

Older versions kept ``settings.json`` and ``ignored.txt`` in ``%APPDATA%\\AniBox`` (Roaming). They are
*copied* over the first time they're needed; the old files stay where they are.
"""

from __future__ import annotations

import os
import shutil
import sys
from pathlib import Path
from typing import List

PROGRAM_DIR = Path(__file__).resolve().parents[2]  # the folder with AniBox.bat
PORTABLE_DIR = PROGRAM_DIR / "data"


def is_portable() -> bool:
    return not os.environ.get("ANIBOX_HOME") and PORTABLE_DIR.is_dir()


def home_dir() -> Path:
    override = os.environ.get("ANIBOX_HOME")
    if override:
        return Path(override)
    if PORTABLE_DIR.is_dir():
        return PORTABLE_DIR
    if sys.platform.startswith("win"):
        base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
        return Path(base) / "AniBox"
    base = os.environ.get("XDG_DATA_HOME") or str(Path.home() / ".local" / "share")
    return Path(base) / "anibox"


def legacy_dirs() -> List[Path]:
    """Where versions up to 1.0 kept settings.json and ignored.txt."""
    if os.environ.get("ANIBOX_HOME"):
        return []
    if sys.platform.startswith("win"):
        base = os.environ.get("APPDATA") or str(Path.home() / "AppData" / "Roaming")
        return [Path(base) / "AniBox"]
    base = os.environ.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")
    return [Path(base) / "anibox"]


def home_file(name: str) -> Path:
    """``<home>/<name>``; copied once from the old place if it only exists there."""
    path = home_dir() / name
    if not path.exists():
        for old in legacy_dirs():
            src = old / name
            if src.is_file():
                try:
                    path.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(src, path)
                except OSError:
                    return src  # can't copy: keep using the old file
                break
    return path
