"""Turn Plex GUID strings into external IDs (TVDB, TMDB, IMDb, AniDB, MyAnimeList, AniList).

Plex stores the match of every item as a GUID. Depending on which agent matched it,
the GUID looks very different:

- Modern Plex agents: ``plex://show/5d9c...`` plus a ``Guid`` list such as
  ``tvdb://78857``, ``tmdb://46260``, ``imdb://tt0409591``.
- Legacy agents: ``com.plexapp.agents.thetvdb://78857?lang=en`` (``thetvdbdvd`` = DVD order),
  ``com.plexapp.agents.themoviedb://46260?lang=en``, ``com.plexapp.agents.imdb://tt0409591``.
- HAMA: ``com.plexapp.agents.hama://anidb-239?lang=en``. The prefix also says how episodes are
  numbered: ``anidb2``-``anidb9`` and ``tvdb2``-``tvdb9`` are HAMA's special numbering modes
  (absolute numbering, merged seasons, arcs as seasons). ``tsdb-`` is a TMDB *series* ID,
  ``tmdb-`` a TMDB *movie* ID, ``imdb-`` an IMDb ID.
- Fribb's MyAnimeList.bundle: ``net.fribbtastic.coding.plex.myanimelist://20?lang=en``.
- Custom metadata providers (PMS 1.43+): ``tv.plex.agents.custom.<name>.<source>://show/78874``.
  Only the last part of the scheme names the source.
"""

from __future__ import annotations

import re
from typing import Dict, Iterable, NamedTuple, Optional, Set, Tuple

# Kinds of IDs.
MAL = "mal"
ANIDB = "anidb"
ANILIST = "anilist"
TVDB = "tvdb"
TMDB = "tmdb"  # TV show in show libraries, movie in movie libraries
TMDB_MOVIE = "tmdb_movie"  # always a movie (HAMA "tmdb-")
IMDB = "imdb"

# Numbering modes (stored next to the IDs).
MODE_DVD = "dvd"


class ParsedGuid(NamedTuple):
    kind: str
    ident: str
    mode: str = ""  # e.g. "hama:tvdb3", "hama:anidb2", "dvd"


_IMDB_RE = re.compile(r"(tt\d+)")
_DIGITS_RE = re.compile(r"(\d+)")
_HAMA_PREFIX_RE = re.compile(r"^(anidb|tvdb|tmdb|tsdb|imdb)(\d*)$")


def _kind_from_word(word: str) -> Optional[str]:
    word = word.lower()
    if "myanimelist" in word or word == "mal":
        return MAL
    if word == "anilist":
        return ANILIST
    if re.fullmatch(r"anidb\d*", word):
        return ANIDB
    if word in ("thetvdb", "tvdb", "thetvdbdvd") or re.fullmatch(r"tvdb\d*", word):
        return TVDB
    if word in ("themoviedb", "tmdb", "tsdb") or re.fullmatch(r"tmdb\d*", word):
        return TMDB
    if word == "imdb":
        return IMDB
    return None


def _extract_id(kind: str, value: str) -> Optional[str]:
    if kind == IMDB:
        m = _IMDB_RE.search(value)
        return m.group(1) if m else None
    m = _DIGITS_RE.search(value)
    return m.group(1) if m else None


def _parse_hama(value: str) -> Optional[ParsedGuid]:
    prefix, sep, rest = value.partition("-")
    m = _HAMA_PREFIX_RE.match(prefix.lower()) if sep else None
    if not m:
        return None
    source, number = m.group(1), m.group(2)
    mode = f"hama:{source}{number}" if number else ""
    if source == "anidb":
        kind = ANIDB
    elif source == "tvdb":
        kind = TVDB
    elif source == "tsdb":
        kind = TMDB
    elif source == "tmdb":
        kind = TMDB_MOVIE
    else:
        kind = IMDB
    ident = _extract_id(kind, rest)
    return ParsedGuid(kind, ident, mode) if ident else None


def parse_guid(guid: str) -> Optional[ParsedGuid]:
    """Return the external ID in a Plex GUID, or ``None`` if it carries no usable one."""
    if not guid or "://" not in guid:
        return None
    scheme, rest = guid.split("://", 1)
    rest = rest.split("?", 1)[0].strip("/")
    if not rest:
        return None
    scheme_l = scheme.lower()
    if scheme_l in ("plex", "local", "file") or "shoko" in scheme_l:
        return None

    if scheme_l.endswith(".hama") or scheme_l == "hama":
        return _parse_hama(rest.split("/")[0])

    if scheme_l.startswith("tv.plex.agents.custom."):
        # The last path segment holds the ID ("show/78874", "movie/tmdb-movie-19934").
        segment = rest.split("/")[-1]
        kind = _kind_from_word(scheme_l.rsplit(".", 1)[-1])
        prefix, sep, value = segment.partition("-")
        if sep and _kind_from_word(prefix):
            kind, segment = _kind_from_word(prefix), value
        if kind is None:
            return None
        ident = _extract_id(kind, segment)
        return ParsedGuid(kind, ident) if ident else None

    # Legacy agents: the last part of the scheme names the source.
    last = scheme_l.rsplit(".", 1)[-1]
    kind = _kind_from_word(last)
    if kind is None and "myanimelist" in scheme_l:
        kind = MAL
    if kind is None:
        return None
    ident = _extract_id(kind, rest.split("/")[0])
    if not ident:
        return None
    return ParsedGuid(kind, ident, MODE_DVD if last == "thetvdbdvd" else "")


def external_ids(guids: Iterable[str]) -> Tuple[Dict[str, Set[str]], Set[str]]:
    """Collect every external ID from a list of GUID strings.

    Returns ``({kind: set(ids)}, set(modes))``.
    """
    found: Dict[str, Set[str]] = {}
    modes: Set[str] = set()
    for g in guids:
        parsed = parse_guid(g)
        if parsed:
            found.setdefault(parsed.kind, set()).add(parsed.ident)
            if parsed.mode:
                modes.add(parsed.mode)
    return found, modes
