"""A deliberately read-only Plex Media Server client.

Only HTTP GET requests are ever sent, so the report cannot change matches, metadata,
watch states or settings on the server.
"""

from __future__ import annotations

import http.client
import json
import socket
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple

from . import __version__
from .ids import external_ids

PAGE_SIZE = 500
DEFAULT_PORT = 32400
RETRY_STATUS = (502, 503, 504)  # Plex answers 503 while it is starting (e.g. a waking Shield)

# Plex item type numbers used by /library/sections/{id}/all?type=N
TYPE_MOVIE = 1
TYPE_SHOW = 2
TYPE_EPISODE = 4


class PlexError(Exception):
    pass


class PlexAuthError(PlexError):
    """The server refused the token (HTTP 401/403)."""


@dataclass
class Section:
    key: str
    title: str
    type: str  # "show" or "movie"
    agent: str = ""


@dataclass
class PlexItem:
    rating_key: str
    title: str
    year: Optional[int]
    type: str  # "show" or "movie"
    section: str  # library title, for display
    section_key: str = ""  # library id
    guid: str = ""
    ids: Dict[str, Set[str]] = field(default_factory=dict)
    modes: Set[str] = field(default_factory=set)  # numbering hints from the GUIDs, e.g. "hama:tvdb3"
    ordering: str = ""  # per-show override of the episode ordering
    episodes: Set[Tuple[int, int]] = field(default_factory=set)  # (season, episode)
    note: str = ""  # why it's listed under "not found"
    source: str = "plex"  # "plex" or "folder" (folder check without Plex)

    def season_episodes(self, season: int) -> Set[int]:
        return {e for s, e in self.episodes if s == season}

    @property
    def regular_episodes(self) -> Set[Tuple[int, int]]:
        return {(s, e) for s, e in self.episodes if s >= 1}

    @property
    def episode_count(self) -> int:
        return len(self.episodes)


def normalize_server_url(address: str) -> str:
    """Turn whatever the user pasted into ``scheme://host:port``.

    Accepts ``192.168.178.50``, ``192.168.178.50:32400/web/index.html#!/``, ``https://host``,
    ``[fe80::1]``, ``fe80::1`` ... Paths, queries and fragments are dropped; the port defaults to 32400.
    """
    text = (address or "").strip()
    if not text:
        raise ValueError("empty server address")
    if "://" not in text:
        text = "http://" + text
    scheme, rest = text.split("://", 1)
    scheme = scheme.lower() if scheme.lower() in ("http", "https") else "http"
    netloc = rest.split("/", 1)[0].split("?", 1)[0].split("#", 1)[0]
    netloc = netloc.rsplit("@", 1)[-1]  # drop user:password@
    host, port = netloc, None
    if netloc.startswith("["):
        end = netloc.find("]")
        host = netloc[1:end] if end > 0 else netloc.strip("[]")
        tail = netloc[end + 1:] if end > 0 else ""
        if tail.startswith(":") and tail[1:].isdigit():
            port = int(tail[1:])
    elif netloc.count(":") == 1:
        h, p = netloc.split(":")
        host = h
        if p.isdigit():
            port = int(p)
    # else: no colon (plain host) or several colons (bare IPv6 without brackets)
    if not host:
        raise ValueError(f"no host in {address!r}")
    if ":" in host:
        host = f"[{host}]"
    return f"{scheme}://{host}:{port or DEFAULT_PORT}"


class PlexReader:
    def __init__(self, base_url: str, token: str, timeout: float = 30.0, attempts: int = 4):
        self.base_url = normalize_server_url(base_url)
        self.token = token
        self.timeout = timeout
        self.attempts = attempts

    # -- low level ---------------------------------------------------------------------------

    def _get(self, path: str, params: Optional[dict] = None, headers: Optional[dict] = None) -> dict:
        url = self.base_url + path
        if params:
            url += "?" + urllib.parse.urlencode(params)
        req = urllib.request.Request(url, method="GET")
        req.add_header("Accept", "application/json")
        req.add_header("X-Plex-Token", self.token)
        req.add_header("X-Plex-Product", "AniBox Library Check")
        req.add_header("X-Plex-Version", __version__)
        req.add_header("X-Plex-Client-Identifier", "anibox-library-check")
        for k, v in (headers or {}).items():
            req.add_header(k, v)
        last_error = ""
        for attempt in range(self.attempts):
            if attempt:
                # A sleeping Shield can take a while to answer; wait a bit longer each time.
                time.sleep(3 * attempt)
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                    body = resp.read()
            except urllib.error.HTTPError as exc:
                if exc.code in (401, 403):
                    raise PlexAuthError(
                        "Plex rejected the sign-in (HTTP %d). The token is wrong or no longer valid." % exc.code
                    ) from exc
                if exc.code in RETRY_STATUS:
                    last_error = f"HTTP {exc.code}, Plex is probably still starting"
                    continue
                raise PlexError(f"Plex answered HTTP {exc.code} for {path}") from exc
            except (urllib.error.URLError, socket.timeout, ConnectionError, http.client.HTTPException) as exc:
                last_error = str(getattr(exc, "reason", None) or exc) or type(exc).__name__
                continue
            if not body:
                return {}
            try:
                data = json.loads(body.decode("utf-8"))
            except ValueError as exc:
                raise PlexError(
                    f"Plex sent something that isn't JSON for {path}. Is {self.base_url} really a Plex server?"
                ) from exc
            if not isinstance(data, dict):
                raise PlexError(f"Unexpected answer from Plex for {path}")
            return data
        raise PlexError(
            f"Could not reach Plex at {self.base_url} ({last_error}). "
            "Is the Shield awake and on the same network? Try opening "
            f"{self.base_url}/web in a browser."
        )

    def _paged(self, path: str, params: dict) -> List[dict]:
        items: List[dict] = []
        start = 0
        while True:
            data = self._get(
                path,
                params,
                headers={"X-Plex-Container-Start": str(start), "X-Plex-Container-Size": str(PAGE_SIZE)},
            )
            mc = data.get("MediaContainer", {}) or {}
            page = mc.get("Metadata", []) or []
            items.extend(page)
            total = mc.get("totalSize")
            start += len(page)
            if not page or total is None or start >= int(total):
                break
        return items

    # -- library -------------------------------------------------------------------------------

    def identity(self) -> dict:
        return self._get("/identity").get("MediaContainer", {}) or {}

    def sections(self) -> List[Section]:
        data = self._get("/library/sections")
        out = []
        for d in (data.get("MediaContainer", {}) or {}).get("Directory", []) or []:
            if d.get("type") in ("show", "movie"):
                out.append(Section(key=str(d["key"]), title=d.get("title", ""), type=d["type"], agent=d.get("agent", "")))
        return out

    def section_ordering(self, section: Section) -> str:
        """The library's episode ordering ("" when Plex doesn't say)."""
        if section.type != "show":
            return ""
        try:
            data = self._get(f"/library/sections/{section.key}/prefs")
        except PlexAuthError:
            raise
        except PlexError:
            return ""
        for s in (data.get("MediaContainer", {}) or {}).get("Setting", []) or []:
            if s.get("id") == "showOrdering":
                return str(s.get("value") or s.get("default") or "")
        return ""

    def items(self, section: Section) -> List[PlexItem]:
        type_num = TYPE_SHOW if section.type == "show" else TYPE_MOVIE
        raw = self._paged(f"/library/sections/{section.key}/all", {"type": type_num, "includeGuids": 1})
        items: List[PlexItem] = []
        by_key: Dict[str, PlexItem] = {}
        for m in raw:
            guids = [m.get("guid", "")] + [g.get("id", "") for g in (m.get("Guid") or [])]
            ids, modes = external_ids(guids)
            year = m.get("year")
            item = PlexItem(
                rating_key=str(m.get("ratingKey")),
                title=m.get("title", ""),
                year=int(year) if isinstance(year, (int, str)) and str(year).isdigit() else None,
                type=section.type,
                section=section.title,
                section_key=section.key,
                guid=m.get("guid", ""),
                ids=ids,
                modes=modes,
                ordering=str(m.get("showOrdering") or ""),
            )
            items.append(item)
            by_key[item.rating_key] = item
        if section.type == "show":
            for ep in self._paged(f"/library/sections/{section.key}/all", {"type": TYPE_EPISODE}):
                show = by_key.get(str(ep.get("grandparentRatingKey")))
                season, number = ep.get("parentIndex"), ep.get("index")
                if show is not None and season is not None and number is not None:
                    try:
                        show.episodes.add((int(season), int(number)))
                    except (TypeError, ValueError):
                        continue
        return items
