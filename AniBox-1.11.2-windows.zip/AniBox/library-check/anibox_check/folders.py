"""Check anime folders directly, without Plex.

Works when the drives are organised the MyAnimeList way: one folder per MAL entry, named
after its title, with the episodes inside (``Anime\\Sousou no Frieren\\Sousou no Frieren 01.mkv``).
That also catches files Plex can't see (for example when a library's scanner is broken).

Two ways to get the file list, both read-only:

- ``walk_folders``: list folders directly (a drive, a network share or a library folder).
- ``read_listing``: read a text file with one full path per line, such as the output of
  ``dir /s /b`` on Windows.

The folder that directly holds the videos is the "show folder" (season folders like
``Season 01`` are skipped upwards, extras folders are ignored), and the folder above it is
the "library folder" (``Anime``, ``OVA's`` ...).
"""

from __future__ import annotations

import os
import re
import unicodedata
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Set, Tuple

from .ids import MAL
from .plex import PlexItem

VIDEO_EXTENSIONS = {".mkv", ".mp4", ".avi", ".ts", ".m4v", ".divx", ".mov", ".wmv", ".webm", ".mpg", ".mpeg", ".ogm", ".ogv", ".m2ts"}
SEASON_DIR_RE = re.compile(r"^(season|staffel|series|s)\s*\d{1,3}$|^specials?$", re.IGNORECASE)
# "<Show> - Season 1", "Show.S02", "Show Staffel 3": a season folder only right inside the folder "<Show>".
_NAMED_SEASON_RE = re.compile(r"^(?P<show>.+?)[\s._\-]*\b(?:season|staffel|series|s)[\s._\-]*(?P<n>\d{1,3})$", re.IGNORECASE)


def _plain(text: str) -> str:
    return re.sub(r"[^0-9a-z]+", "", text.casefold())


def is_season_dir(name: str, parent: str = "") -> bool:
    """Is the folder ``name`` (inside the folder ``parent``) a season of the show ``parent``?

    "Season 01", "Staffel 2", "S3" and "Specials" always are. "<Show> - Season 1" is too, but only
    right inside a folder with the same show name ("Rick and Morty\\Rick and Morty - Season 1"). An
    anime folder that is its own MyAnimeList entry ("Anime\\Shingeki no Kyojin Season 3") stays a show.
    """
    name = name.strip()
    if SEASON_DIR_RE.match(name):
        return True
    m = _NAMED_SEASON_RE.match(name)
    return bool(m and parent and _plain(m.group("show")) and _plain(m.group("show")) == _plain(parent))


def looks_like_season_dir(name: str) -> bool:
    """Shape only, for a folder the grouping already accepted as a season ("Season 1", "Show - Season 1")."""
    name = name.strip()
    return bool(SEASON_DIR_RE.match(name) or _NAMED_SEASON_RE.match(name))


def season_number(name: str) -> int:
    """The season of a season folder: its number at the end; "Specials" = 0."""
    m = re.search(r"(\d{1,3})\s*$", name.strip())
    return int(m.group(1)) if m else 0
EXTRA_DIRS = {
    "extras", "featurettes", "behind the scenes", "deleted scenes", "interviews", "scenes", "shorts",
    "trailers", "other", "sample", "samples", "bonus", "nc", "ncop", "nced", "menu", "menus",
}


# -- reading file lists --------------------------------------------------------------------------


def _decode(data: bytes) -> str:
    """dir /s /b output can be UTF-8, UTF-16 (PowerShell) or the old DOS code page (cmd.exe)."""
    if data.startswith((b"\xff\xfe", b"\xfe\xff")):
        return data.decode("utf-16")
    try:
        return data.decode("utf-8-sig")
    except UnicodeDecodeError:
        return data.decode("cp850", errors="replace")


def read_listing(path: str) -> List[str]:
    with open(path, "rb") as fh:
        text = _decode(fh.read())
    return [line.strip() for line in text.splitlines() if line.strip()]


def walk_folders(root: str) -> List[str]:
    """All file paths below ``root``. Only lists folders; nothing is opened or changed."""
    out: List[str] = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if not d.startswith(".")]
        out.extend(os.path.join(dirpath, f) for f in filenames)
    return out


# -- grouping videos into show folders -----------------------------------------------------------


@dataclass
class ShowFolder:
    library: str  # e.g. "Anime"
    name: str  # e.g. "Sousou no Frieren"
    files: List[str] = field(default_factory=list)  # video file names ("Season 02\\name.mkv" inside season folders)

    @property
    def rel_path(self) -> str:
        return f"{self.library}\\{self.name}"


def _split(path: str) -> List[str]:
    return [p for p in re.split(r"[\\/]+", path) if p]


def group_videos(paths: Iterable[str]) -> Dict[Tuple[str, str], ShowFolder]:
    """Group video files by (library folder, show folder)."""
    shows: Dict[Tuple[str, str], ShowFolder] = {}
    for path in paths:
        parts = _split(path)
        if len(parts) < 3:
            continue
        name = parts[-1]
        if os.path.splitext(name)[1].lower() not in VIDEO_EXTENSIONS:
            continue
        folders = parts[:-1]
        if any(f.lower() in EXTRA_DIRS for f in folders[-2:]):
            continue  # extras, trailers, samples ...
        season_dir = ""
        while len(folders) >= 3 and is_season_dir(folders[-1], folders[-2]):
            season_dir = season_dir or folders[-1].strip()
            folders = folders[:-1]  # "Show\Season 01\file" -> the show is "Show"
        show, library = folders[-1], folders[-2]
        key = (library, show)
        entry = f"{season_dir}\\{name}" if season_dir else name
        shows.setdefault(key, ShowFolder(library, show)).files.append(entry)
    return shows


# -- episode numbers from file names -------------------------------------------------------------

_TAGS_RE = re.compile(r"\[[^\]]*\]|\{[^}]*\}|\((?:19|20)\d\d\)")
_SXXEYY_RE = re.compile(r"\bS(\d{1,3})\s?E(\d{1,4})\b", re.IGNORECASE)
_DASH_NUM_RE = re.compile(r"\s-\s*(\d{1,4})(?:v\d)?\b")
_LEADING_RE = re.compile(r"^(\d{1,4})(?:v\d)?(?:\s|$|\.|_|-)")
_E_RE = re.compile(r"(?:^|[\s_.\-])(?:E|EP|Ep|Episode|Folge)\s?\.?(\d{1,4})\b", re.IGNORECASE)
_TRAILING_RE = re.compile(r"(?:^|[\s_.\-])(\d{1,4})(?:v\d)?$")
_ANY_RE = re.compile(r"(?<![\dx])(\d{2,4})(?![\dp])")  # only "01"-style numbers, not "Movie 3"


def episode_number(file_name: str, title: str = "") -> Optional[Tuple[int, int]]:
    """(season, episode) from a file name, or None if it has no episode number.

    Handles ``Show 01.mkv``, ``Show - 01.ts``, ``E01.mkv``, ``001  Title .mp4``,
    ``Show S01E05.mkv``, ``Show 01v2.mkv``, ``Show 01.English.mp4``. If the file name starts
    with the show's ``title`` (the folder name), that part is skipped first, so numbers inside
    titles ("3-gatsu no Lion 05", "86 Part 2 03") aren't taken for the episode.
    """
    stem = os.path.splitext(file_name)[0]
    if title and stem.casefold().startswith(title.casefold()) and len(stem) > len(title):
        stem = stem[len(title):]
    stem = re.sub(r"(\.[A-Za-z]{2,12})+$", "", stem)  # language suffixes like ".English"
    stem = _TAGS_RE.sub(" ", stem)
    stem = re.sub(r"\b\d{3,4}p\b|\b[xh]\.?26[45]\b|\bHEVC\b|\b10.?bit\b|\bv\d\b", " ", stem, flags=re.IGNORECASE)
    stem = " ".join(stem.split())
    m = _SXXEYY_RE.search(stem)
    if m:
        return int(m.group(1)), int(m.group(2))
    for rx in (_DASH_NUM_RE, _LEADING_RE, _E_RE, _TRAILING_RE):
        m = rx.search(stem)
        if m:
            return 1, int(m.group(1))
    m = _ANY_RE.search(stem)
    if m and not (1900 <= int(m.group(1)) <= 2099):
        return 1, int(m.group(1))
    return None


def folder_episodes(files: List[str], title: str = "") -> Set[Tuple[int, int]]:
    """Distinct episodes in a show folder. Copies of the same episode count once.
    Files without a number count one each; a folder with a single file is episode 1."""
    numbers = []
    for f in files:
        folder, _, name = f.rpartition("\\")
        ep = episode_number(name, title)
        if ep is not None and folder:
            # Inside "Season 55" (or "Specials"), numbers often start again at 01.
            season = season_number(folder)
            if ep[0] == 1:
                ep = (season, ep[1])
        numbers.append(ep)
    found = {n for n in numbers if n is not None}
    if len(found) == 1 and len(files) >= 3:
        # Every file "has" the same number: it's part of the title, not an episode number.
        numbers = [None] * len(files)
    episodes: Set[Tuple[int, int]] = set()
    unnumbered = 0
    for ep in numbers:
        if ep is None:
            unnumbered += 1
        else:
            episodes.add(ep)
    if not episodes and unnumbered:
        return {(1, i) for i in range(1, unnumbered + 1)}
    top = max((e for _, e in episodes), default=0)
    for i in range(unnumbered):
        episodes.add((1, top + 1 + i))
    return episodes


# -- matching folder names to MyAnimeList entries ------------------------------------------------


def _fold(text: str) -> str:
    text = unicodedata.normalize("NFKD", text)
    text = "".join(c for c in text if not unicodedata.combining(c))
    return text.lower().replace("&", " and ")


def exact_key(text: str) -> str:
    return " ".join(unicodedata.normalize("NFKC", text).casefold().split())


def spaced_key(text: str) -> str:
    return " ".join(re.sub(r"[\W_]+", " ", _fold(text)).split())


def compact_key(text: str) -> str:
    return re.sub(r"[\W_]+", "", _fold(text))


_YEAR_RE = re.compile(r"\((19\d\d|20\d\d)\)")
LIBRARY_TYPE_HINTS = (
    ("movie", {"MOVIE"}),
    ("film", {"MOVIE"}),
    ("ova", {"OVA", "SPECIAL", "ONA"}),
    ("special", {"SPECIAL", "OVA", "ONA"}),
)


class TitleMatcher:
    """Find the MyAnimeList entry for a folder name (main titles first, then alternative titles)."""

    def __init__(self, titles: Dict[str, dict]):
        self.titles = titles
        # From strict to loose: exact title, exact alternative title, then the same with
        # punctuation ignored ("Yuru Yuri" must not become "Yuru Yuri♪♪").
        self.levels = [(exact_key, 0), (exact_key, 1), (spaced_key, 0), (spaced_key, 1), (compact_key, 0), (compact_key, 1)]
        self.indexes: List[Dict[str, Set[str]]] = [{} for _ in self.levels]
        for mal_id, info in titles.items():
            names = ([info.get("title") or ""], list(info.get("syn") or ()))
            for index, (key_fn, which) in zip(self.indexes, self.levels):
                for n in names[which]:
                    key = key_fn(n) if n else ""
                    if key:
                        index.setdefault(key, set()).add(mal_id)

    def _lookup(self, name: str) -> Set[str]:
        for index, (key_fn, _) in zip(self.indexes, self.levels):
            key = key_fn(name)
            if key and key in index:
                return set(index[key])
        return set()

    def match(self, folder: str, library: str = "", n_files: int = 0) -> Tuple[Optional[str], str]:
        """Return (mal_id, "") or (None, reason)."""
        name = re.sub(r"\[[^\]]*\]|\{[^}]*\}", " ", folder).strip()
        year_m = _YEAR_RE.search(name)
        year = int(year_m.group(1)) if year_m else None
        candidates = self._lookup(name)
        if not candidates and year:
            candidates = self._lookup(_YEAR_RE.sub(" ", name))
        if not candidates and re.search(r"\s\(?TV\)?$", name):
            candidates = self._lookup(re.sub(r"\s\(?TV\)?$", "", name))  # "Hinamatsuri TV" -> "Hinamatsuri"
        if not candidates:
            return None, "No MyAnimeList title matches this folder name"
        if len(candidates) == 1:
            return next(iter(candidates)), ""

        # Several entries share this title: decide by year, episode count, then library type.
        def info(m):
            return self.titles.get(m, {})
        narrowed = candidates
        if year:
            narrowed = {m for m in narrowed if info(m).get("year") == year} or narrowed
        if len(narrowed) > 1 and n_files:
            by_count = {m for m in narrowed if info(m).get("episodes") == n_files}
            narrowed = by_count or narrowed
        if len(narrowed) > 1:
            lib = library.lower()
            types = next((t for word, t in LIBRARY_TYPE_HINTS if word in lib), {"TV"})
            by_type = {m for m in narrowed if info(m).get("type") in types}
            narrowed = by_type or narrowed
        if len(narrowed) == 1:
            return next(iter(narrowed)), ""
        options = ", ".join(
            f"{info(m).get('title')} ({info(m).get('type')}, {info(m).get('year')})"
            for m in sorted(narrowed, key=lambda m: (info(m).get("year") or 0, m))[:4]
        )
        return None, f"Several MyAnimeList entries fit this name; add the year to the folder name to pick one: {options}"


def folder_items(shows: Dict[Tuple[str, str], ShowFolder], matcher: TitleMatcher) -> List[PlexItem]:
    """Turn show folders into items the analyzer understands (matched directly by MAL ID)."""
    items: List[PlexItem] = []
    for (library, name), show in sorted(shows.items()):
        episodes = folder_episodes(show.files, name)
        mal_id, reason = matcher.match(name, library, len(episodes))
        year_m = _YEAR_RE.search(name)
        items.append(PlexItem(
            rating_key=show.rel_path,
            title=name,
            year=int(year_m.group(1)) if year_m else None,
            type="show",
            section=library,
            section_key=library,
            guid=show.rel_path,
            ids={MAL: {mal_id}} if mal_id else {},
            episodes=episodes,
            note=reason,
            source="folder",
        ))
    return items
