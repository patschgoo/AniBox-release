# AniBox

A private player for the anime on your own drives. AniBox shows your anime folders as a library
(matched to MyAnimeList), plays them with mpv, remembers where you stopped, and tells you which
seasons, OVAs, specials and movies you're missing. The look and many features come from
**Frostbox**, Martin's archive.org player (used with his permission).

AniBox only reads your video folders. It never renames, moves or deletes a video. The only things
it can write onto your drives are small `.nfo` info files, and only when you click **Write** under
Settings → Info files (see below), and the files you download from the Internet Archive, into the
download folder you choose (it never replaces a file that's already there). It never changes
anything in Plex. It can also add subtitle files (`.srt`, `.ass`) next to new or unlocked episodes,
only when you click **Add** or **Download** on a show's page (see "Subtitles for the TV" below).

## Start it (Windows)

Two ways to get AniBox onto the PC:

- **Ready package, no Python needed:** `AniBox-<version>-windows.zip` brings its own Python (the
  official "embeddable" Python from python.org, in the `python` folder). Unpack it anywhere, e.g.
  `Documents\AniBox`, and double-click **`AniBox.bat`** in the `AniBox` folder. For now the
  package is built from this repository with `python tools/build_windows.py` (it ends up in
  `dist/`, see [tools/](tools/)); later it will come from a release repository.
- **From the source, with Python installed:** install **Python 3.9 or newer** from
  [python.org](https://www.python.org/downloads/) (tick "Add python.exe to PATH"), download this
  repository (green **Code** button → **Download ZIP**), unpack it anywhere and double-click
  **`AniBox.bat`**.

Windows may warn once because the files come from the internet. To avoid that, right-click the
ZIP before unpacking → **Properties** → tick **Unblock** → **OK**.

Then, either way:

1. AniBox opens in its own window (Microsoft Edge in app mode).
   **Settings → Your data → Add to desktop** puts an AniBox icon on your desktop.
2. **Settings → Folders**: **Browse …** or paste any folder with videos (a Shield drive such as
   `\\SHIELD\External USB drive-1234abcd\NVIDIA_SHIELD`, a NAS, a USB disk, a folder on the PC),
   then **Scan now**. Later scans only read the folders that changed, so they're quick even on
   the Shield; **Full rescan** reads everything again (use it if a new episode doesn't show up).
3. **Settings → Player**: **Download mpv** once (about 34 MB, checked against a fixed checksum).
   Windows 11 unpacks it by itself; on older Windows install [7-Zip](https://7-zip.org) first.

Closing the window stops AniBox after about two minutes. Starting it again opens the same window.

On Linux or macOS: install `python3` and `mpv`, then run `./AniBox.sh`.

**New versions** are published in a public release repository (Settings → Updates; default
`patschgoo/AniBox-release`). Once a day AniBox reads its `latest.json`; when there's a newer
version, Home says so and **Download** fetches the zip into your Downloads folder and checks it (size
and SHA-256). Then **Update now** installs it. Nothing is downloaded or installed without a click.

**Updating (from 1.6.0 on):** put the new `AniBox-<version>-windows.zip` in your **Downloads**
folder, don't unpack it. AniBox shows **AniBox x.y is in your Downloads · Update now** on Home (and
under Settings → Updates). Click it: AniBox closes, a small helper puts the new version in place
and starts it, and AniBox opens again by itself. If the new version doesn't start, the helper puts
the old one back and AniBox says so. Your library, watch progress and settings are in a separate
folder (see "Your data") and are never touched; the old program files stay in `.previous-update`
inside the AniBox folder until the next update. The helper's log is `app\logs\update.log`.

By hand (and for versions before 1.6.0): close AniBox (it stops about two minutes after its window
closes), unpack the new ZIP over the old folder and start it again. If the repository is public,
AniBox tells you when a new version is out.

## What it does

- **Home**: Continue watching (with the next episode) and Recently added.
- **Library**: every show as a poster card, in sections **Anime** (with Series, Movies, OVAs,
  Specials, ONAs), **Series** and **Movies** (your non-anime folders) and **Everything**, with search
  and filters. AniBox guesses what each library folder holds; Settings → Libraries to show lets you
  set it (Auto / Anime / Series / Movies). **Franchises** groups the
  seasons, OVAs and movies of one franchise into one card, with a page that lists everything in
  that franchise (what you have and what's missing).
- **Show page**: episodes with progress, the franchise entries you don't have yet, and (with a
  MyAnimeList Client ID) the description, score, genres and studio. **Wrong match? / Match by
  hand** picks the right MyAnimeList entry for a folder; AniBox remembers it, the folder stays
  as it is.
- **Missing**: what's missing per franchise, which folders are incomplete, and which folders
  weren't recognized. Unrecognized folders can be matched by hand or hidden. Two tabs:
  **Your folders** (from your scanned folders, no Plex needed) and **Your Plex library** (reads the
  Plex libraries you pick and says where each missing entry would go in Plex's numbering, e.g.
  "Would go in Specials (S00E12)"). **Save as web page** / **Save as spreadsheet** export either
  one (the spreadsheet uses `;` for German Excel). This replaces the separate Library Check
  program (`run-check.bat`) of earlier versions.
- **Playing** (from Frostbox): resume where you stopped (10 s back), "watched" at 95 %, next
  episode after a short countdown, "Still watching?" after a few episodes in a row, sleep timer.
- **Plays inside the AniBox window** (Windows): a big player, a small one in the corner while you
  keep browsing (it switches to small when you open another page), **Fill the window** and **Full
  screen** (buttons above the video, `F`/`Esc`, or double-click / `F` in the video). mpv still does the
  playing, so every file and subtitle that worked before still works. Dialogs (audio/subtitles,
  "Still watching?") hide the video while they're open, because nothing can be drawn on top of it.
  If AniBox can't place the video in its window, it opens in its own window as before; Settings →
  Player → **Play inside the AniBox window** switches this off.
- **Audio and subtitles**: preferred languages (e.g. Japanese audio, German subtitles), a track
  picker in the playing bar and on the phone, and AniBox remembers your choice per show.
- **Skip opening / ending**: when the file has chapters called "Opening"/"OP" or
  "Ending"/"ED" (most fansub and Blu-ray releases), a **Skip** button appears, or AniBox skips by
  itself if you choose that.
  **Files without chapters:** on a show's page, **Find opening and ending** compares the sound of
  the show's episodes (the way Plex finds intros and credits) and remembers where the opening and the
  ending are; the same Skip button, auto-skip and the phone's Skip then work for them. It needs ffmpeg
  (Settings → Player), reads only the first 6 and the last 5 minutes of each file, one show at a time,
  and changes nothing in your folders: the times are kept in AniBox's data folder
  (`skip-markers.json`). The show's page lists what was found per episode; **Edit** corrects a time
  or says "no opening here", and **Turn off for this show** goes back to chapters only. Chapters in
  a file always win. Settings → *Openings and endings without chapters* has **Check every show** and
  "Find openings when a show is opened" (off at first; never while that show is playing). The first
  episode (often without an opening) and a different finale are no problem, because each episode is
  compared with several others.
- **Phone remote** (from Frostbox): switch it on in Settings and scan the QR code (same Wi-Fi).
  Play/pause, seek, skip, next episode, audio/subtitles, volume, sleep timer and the episode list.
  Windows asks once whether to allow AniBox in your network: allow **private networks** only.
- **Play on TV**: send an episode, an Internet Archive video or a series playlist to CastApp TV on
  the Shield, another DLNA TV or a Chromecast in your home network (see below).
- **Watch history from Plex**: copies which episodes you watched in Plex into AniBox
  (read-only in Plex).
- **Plex's details, copied**: what your Plex libraries already know about your shows (titles,
  descriptions, the MyAnimeList match from the old agent, episode titles, posters) is copied into
  AniBox and shown on each show page. A backup in case the Shield's SD card fails (see below).
- **Episode titles and pictures**: titles you typed into your file names come first; otherwise
  AniBox gets titles, air dates and pictures from Kitsu (free, no account) and, for One Piece,
  pictures from the One Piece Wiki. They're only shown in AniBox; your files are never renamed.
- **Sub/dub badges**: each show says whether it's Japanese, a German or English dub, and which
  subtitles it has ("DUB DE", "JA", "SUB DE·EN"). AniBox guesses from folder and file names, reads
  the track list at the start of an MKV/MP4 file when you open a show, and learns from the player;
  you can correct it by hand. Filter the library by Japanese, German dub, English dub, German subs or English subs, and by subtitle type: burned in, styled (ASS), plain text (SRT), image (PGS/VobSub), or "may not show on the TV" (styled or picture subtitles that the Plex app on the Shield and many TVs can't show as they are). The language editor explains which type works where.
- **Locked old episodes**: everything that was already in your folders is locked, new episodes
  are open. AniBox writes nothing for locked episodes (no info files) until you click **Unlock
  this show** on a show's page.
- **Subtitles for the TV and "Plays on the TV?"**: plain `.srt` copies of styled subtitles, subtitles
  from Jimaku or OpenSubtitles, and a check per show whether Plex on the Shield or CastApp TV plays it
  directly (see below).
- **Internet Archive**: search archive.org's free films, cartoons and TV recordings, open an item,
  tick the files you want and download them into a folder you choose; AniBox can add them to your
  library. Or watch them straight from archive.org, also as series playlists in the order they aired
  (see below).

In the mpv window: `N` / `P` next / previous episode, `Shift+S` skip the opening, `#` switch
audio, `j` switch subtitles, `v` subtitles on/off, `Q` close.

### Add new videos (from Downloads into your library)

**Library → Add new videos** (the number shows how many are waiting) looks in your Downloads folder
(or another folder you pick) for finished video downloads, recognizes them (release names like
`[Group] Title - 05 (1080p).mkv` or `Title.S01E05.mkv`), matches them to MyAnimeList and suggests:

- **where they go**: into the show's existing folder if you already have it (new episodes follow the
  names already there), otherwise a new folder named after the MyAnimeList title in the library that
  already holds most entries of that kind (series → `Anime`, movies → `Anime Movies`, OVAs → `OVA's`,
  German dubs → `Anime [ger dub]`; an empty folder of the same name on another drive is never used);
- **what they're called**: `<Title> 01.mkv`, `<Title> 02.mkv` … (movies `<Title> 01.mkv` too), like your
  library; subtitle files next to a video (`.ass`, `.srt`) go with it and get the same name.

Two options above the list do the rest in one go: **write info files (.nfo)** for the new episodes
(for a Plex NFO library), and **ask Plex to scan** the library you pick there (only libraries with a
modern agent are offered; the old MyAnimeList libraries are never scanned). AniBox maps its folder
(`\\SHIELD\…\NVIDIA_SHIELD\Anime\Show`) to Plex's own path (`/storage/…/NVIDIA_SHIELD/Anime/Show`) and
asks Plex to scan just that folder, like clicking "Scan Library Files".

Change any title (**Change title**), folder or file name, untick what you don't want (episodes that
are already in the folder start unticked), choose **Move** or **Copy**, check the list and confirm.
AniBox never overwrites a file; a move to another drive is copied, checked and only then removed from
Downloads. **Undo** puts the last batch back. The new episodes are "new" (not locked), so AniBox shows
their MyAnimeList details and episode titles right away, and **Settings → Info files → Write** gives
them info files for a Plex NFO library.

**Watching for new videos** (Settings → Watching for new videos), only while AniBox is open:

- **New videos in the inbox** (on): every 30 seconds AniBox looks at the "Add new videos" folder. Once a
  download is finished (at least 1 MB, unchanged for 20 seconds, no `.part`/`.crdownload` next to it),
  Home and the Library page say "3 new videos in Downloads → Add them". **Not now** hides those until
  others come. It only looks: nothing moves until you click Add. Folders are listed again only when
  they changed, so this is light.
- **Rescan the library by itself** (off): a quick rescan of your library folders every N minutes (at
  least 5), never while something plays (it waits until playback stops). Unchanged folders on the
  Shield's shares are skipped through the scan cache. New episodes it finds are "new", as with every scan.

### New episodes, statistics, watch order

- **New episodes** (on Home): for the shows you're watching and the ones still airing, AniBox says
  "Episode 7 is out (2 days ago) · not on your drives", or "… waiting in Downloads → Add new videos"
  when a matching download is there, and when the next one comes ("Next: Episode 8 on Sat 29 Nov at
  17:30", your PC's time). Air dates come from [AniList](https://anilist.co)'s free public API, no
  account; AniBox only sends the MyAnimeList numbers of those shows, at most every 2 hours (**Check
  now** asks again) and keeps the answers in `app\airing.json`. Episodes before the first one in a
  folder don't count. Offline: nothing is shown. **Settings → New episodes** switches it off.
- **Statistics** (Library → Statistics): hours and episodes watched, the last 12 months, anime /
  series / movies, MyAnimeList types, genres (from the MyAnimeList details AniBox has loaded), the
  most watched shows, what you finished this year and your streak of days in a row. It counts
  episodes marked as watched on the day they were marked (also by hand or copied from Plex); when
  AniBox doesn't know an episode's length it uses the show's usual one ("about").
- **Watch order** (on a franchise's page): its series, movies, OVAs and specials in release order,
  each marked watched, partly watched, not started, not on your drives or not out yet; OVAs and
  specials are optional, short clips are hidden. When you finish a show, its page shows **Next in
  this franchise** (the main story before optional parts).

### Banners, characters and trailers (AniList)

An anime's page gets a wide **banner** above its title, its **genres and main tags** (tags that give
away the story stay hidden until you click **Show spoilers**), AniList's score, season and studio,
links to the official site and where it streams, a **Trailer** button, the **characters with their
voice actors** (switch between the Japanese, German and English cast; the first one follows your
audio languages) and the **main staff** (original creator, director, series composition, music,
character design). A franchise's page shows the banner of its first show.

It all comes from [AniList](https://anilist.co)'s free public API, no account. AniBox only sends the
show's AniList number, when you open its page, and keeps the answer for 14 days in `app\anilist\`.
The pictures load from AniList's picture server. The trailer opens on YouTube or Dailymotion like the
MyAnimeList link does: nothing of theirs is loaded inside AniBox until you click. **Settings → AniList
extras** switches it all off, picks the cast language, and has **Load all**, which fills in every anime
in your library slowly in the background (about 15 a minute, with Cancel); smart collections need it
for genres and tags.

### Your own collections

**Library → Collections**: your own groups of shows, shown as a grid of covers.

- **Hand-picked**: you choose the shows (from any library, and Internet Archive series playlists) and
  their order (drag, or ↑ and ↓ under **Arrange …**). On a show's page, **Add to collection …** puts it
  in one, or starts a new one with it; the page also says which collections it's in.
- **Smart**: a saved filter that keeps itself up to date: section, anime type, library, watched or not,
  language, year range, words in the title, and genres and tags from AniList (only for shows whose
  AniList extras are on this PC; the page says how many are still missing). Sorted by title, year,
  recently added or recently watched.
- **Edit …** renames it, changes the description and the cover (the first show's poster, or any of its
  shows' posters or AniList banners). **Pin to Home** shows it as a row on Home.
- **Delete** only deletes the list: never a show, a file or watch progress. Collections are kept in
  `app\collections.json` (a damaged file is copied aside as `collections.damaged.json`). A show that
  isn't in your library right now (a drive that isn't connected) stays in the list with its name and a
  **Remove** button; a show moved to another library under the same folder name is found again.

### Watch again, start again from here

On a show's page or a series playlist, watched episodes have a **Watch again** button (it shows when
you point at the episode). **Just this episode** plays it once: afterwards nothing starts by itself,
and Continue stays where you were. (For Internet Archive videos there's also **… and keep it**.)
**Start again from here** makes this episode and every later one count as not watched again (the
earlier ones stay watched) and Continue starts there; it asks first, and you can undo it right
after or later on the History page. Your MyAnimeList/AniList lists don't change: AniBox never
lowers progress there.

### Profiles

Several people in the house can use the same AniBox, each with a **profile** (like Plex Home).
**Settings → Profiles → Add a profile**: a name, a colour and an emoji (or the first letter), and an
optional **PIN** (4 to 8 digits). With two or more profiles AniBox asks **Who's watching?** when it
starts; the avatar at the top right switches later.

- **Each profile has its own** watched marks and resume points, Continue watching, statistics,
  "Watch again"/"Start again from here", the audio/subtitle choice per show, and these settings:
  audio and subtitle languages, subtitles on/off, skipping openings and endings, next episode
  automatically and "Still watching?" (marked with the profile's name on the Settings page).
- **Shared:** the library, the other settings, locks and unlocks, matches by hand, the languages found
  in the files, the Internet Archive downloads and playlists, info files and your video files.
- One profile is active at a time (it's one PC and one player). Switching stops nothing: an episode
  that's playing keeps saving to the profile it was started in. The phone remote works for the
  active profile.
- The first profile ("Me", rename it as you like) holds everything you watched before profiles
  existed. It can't be deleted. Deleting another profile removes its watch progress (AniBox asks
  first).
- **Your MyAnimeList/AniList connection** belongs to the profile that was active when you connected
  it (an older connection belongs to the first profile). Only that profile's watching is ever sent
  there; "Sync now" is worked out from that profile's progress too.
- **Kids profile** (switch it on when you add or edit a profile; never for the first profile): it
  only sees the libraries you tick (none ticked = all), adult anime are hidden, and the Internet
  Archive tab is hidden unless you allow it. It can't open Settings, Add new videos, History, Check my
  library or Your lists, can't change matches, locks or languages, and can only switch to another
  profile with the **PIN of a grown-up profile**, so give your own profile a PIN (Settings → Profiles
  reminds you). AniBox itself refuses all of this for a kids profile; it isn't only hidden.
  "Adult anime" are entries the anime lists tag Hentai or Erotica, and ones MyAnimeList rates Rx
  (once their details are on this PC). Folders AniBox couldn't match can't be checked, so
  "Only these libraries" is the sure way.
- PINs are only kept as a salted hash (PBKDF2), never as the digits; a backup holds the hash too.
  After five wrong PINs AniBox waits a minute.
- When you first start a version with profiles, AniBox copies the database to
  `app\backups\before-profiles-<date>.db`, then moves your watch progress into the first profile in
  one step (all or nothing). An older AniBox can't use the moved database; to go back, copy that
  file over `app\anibox.db`.

### Open folder, Move or rename

- **Open folder** on a show's page opens it in File Explorer; the folder icon on an episode shows that
  file in its folder.
- **Move or rename …** moves a show to another library folder and/or renames its folder and episode
  files (`<Folder> 01` …), with a preview first and Undo afterwards. Watch progress follows. It only
  works for shows that are new or that you **unlocked**: what was already there stays as it is. Shows
  in the old Plex libraries are flagged, because their old scanner can't pick moved files up again.

### Check my library, Move plan, History

**Library → Check my library** looks through AniBox's list of your files (from the last scan) and lists:

- **Same episode twice**: two files with the same number in one folder (another version or language), and
  the same show in two folders (e.g. one in `Anime2` and one in `Anime`), with the episodes that are in
  both and the ones that are only in one. A German dub next to the Japanese version counts as "another
  language", not as a copy.
- **Missing episodes**: numbers missing in the middle (1–5 and 7–12 but no 6). Where MyAnimeList knows the
  episode count, also at the start and, for finished shows, at the end; shows that are still airing aren't
  counted at the end. A show in two folders is counted over both.
- **Empty or broken files**, only when you tick **Check the files too**: AniBox opens every video and reads
  its first few KB (a few files at a time) to see whether it's empty, much smaller than the other episodes,
  doesn't start like a video file (an error page saved as `.mkv`, a renamed archive) or can't be read. On
  the Shield this takes a while; **Stop** keeps what was read so far.
- **Odd names**: files without a number among numbered ones, numbers that don't fit (101 in a 12-episode
  show), leftover download names (`[Group]`, `1080p`).
- **Not recognized**: how many folders no MyAnimeList entry fits (they're on the Missing page).

Each entry links to its show and has **Open folder** / **Show file**; **Save as web page** / **Save as
spreadsheet** export the list. Nothing on your drives changes. The last result is kept in `app\health.json`.

**Move plan** (the second tab) prepares moving `Anime2` into `Anime` (and `Anime [ger dub] 2` into
`Anime [ger dub]`, or any two libraries you pick): for each show folder, old path → new path, into the
show's folder in the target if it already has one (same MyAnimeList entry), named like the files there,
otherwise into a new folder of the same name in the target's fullest folder. It flags episodes that are
already in the target, files on another drive (copied, not just renamed) and locked shows. It's only a list,
with no button that moves anything; the page says when moving would be safe (only after a new Plex library
with working matching covers the target folder, because the old library doesn't see moved files; watched
marks in Plex don't follow the files). It can be saved as a web page or spreadsheet too.

**History** (Library → History, or Settings → History of changes) lists everything AniBox changed, newest
first: videos added, moved or renamed (one entry per batch), info files written, what Tidy up removed
(noted in `app\tidy-log.jsonl`), updates, and matches by hand. **Undo** works for file batches (the last
one, and an older one as long as no later change touched the same files and none of its files changed
since; watch progress follows the files back) and for the info files written since the last undo. AniBox
asks first every time. What Tidy up removed, updates and matches can't be undone there (matches are
changed on the show's page).

### Check my setup

**Settings → Check my setup** (or the small link at the bottom of Home) tests every part of AniBox on
this PC and writes a short report to send when something doesn't work. Nothing runs until you click
**Run the check**; it takes a few seconds. Each check says ✓ (fine), ! (works, but note this), ✗ (a
problem) or – (not checked), in one line, with a fix where there is one:

- **AniBox and system**: version, package or developer copy, Windows and Python version, the data folder
  (free space, a quick database check, log size) and whether **Update now** can replace this folder.
- **Player**: mpv's version and a real start (idle, over its named pipe, one second of its own test
  picture without picture or sound), playing inside the window (what happened last time), ffmpeg.
- **The window**: browser and version, whether it's AniBox's own app window, scale and size.
- **Library folders**: for each folder its kind (local drive, mapped network drive, `\\server\share`),
  whether it answers and how long listing its top level takes, whether quick rescans reuse folders
  there, and the last scan's numbers. A share that hangs gets its own time limit and doesn't hold up the
  rest.
- **Plex** (if signed in; only questions, never changes): reachable and how (home network, remote,
  relay), the server version, its libraries and which use an old agent, whether the NFO agent and
  custom metadata providers are there.
- **TVs**: a search (how many TVs, CastApp TVs, other makers), whether remembered TVs answer, CastApp
  TV's capabilities (Hi10P, HEVC 10-bit, AV1, ASS subtitles …), pairing, and whether each TV is in the
  same network as the PC.
- **Internet**: one small request each to archive.org, the release repository, AniList and Kitsu, and to
  MyAnimeList, TMDB, Jimaku and OpenSubtitles only if their key is set (each key only goes to its own
  service).
- **Internet Archive cache**: the folder can be written, free space, the limit, whether the drive can hold
  sparse files (a small test file, deleted right away), kept files.
- **Phone remote** (on, or its port free; Tailscale running or not) and the **last warnings and errors**
  from AniBox's log.

The report leaves out everything personal: the user and computer names (`%USERPROFILE%`, `<PC>`), share
and drive names (`\\<server>\<share 1>`, `<drive 1>`; the same drive gets the same number as Plex's
`/storage/…` path), addresses (`<home network address>`, `<Tailscale address>`, `<internet address>`),
e-mail and MAC addresses, keys and tokens (`<hidden>`), Plex server, account and TV names, and show
names. The page shows the exact text; **Save report** puts it into Downloads as
`AniBox setup check <date>.txt` (never over an older one) and **Copy report** copies it. The last report
is kept in `app\setup-check.json`. The check only reads: the one file it writes is that test file in its
own cache folder.

### Optional: descriptions and scores from MyAnimeList

AniBox works without any account. For descriptions, scores, genres and studios on the show pages,
create a free Client ID on myanimelist.net (Profile → Account settings → API → Create ID, app
type "other") and paste it under **Settings → MyAnimeList**. It's only used to read public
information; answers are kept for 30 days. MyAnimeList has no episode titles, so episodes stay
"Episode 1, 2, …".

### Optional: your MyAnimeList / AniList list

**Settings → Your anime lists**: type your MyAnimeList and/or AniList user name. AniBox then reads
your public list (MyAnimeList with the Client ID above, AniList with nothing else), keeps a copy for
an hour, and shows it:

- a small badge on every card ("MAL · Watching 5/12") and a line on each show page;
- **Library → Your lists** with three parts: *On your list but not on your drives* (watching, plan
  to watch, completed), *Watched on your list but not in AniBox* (with **Mark these as watched in
  AniBox**: shows exactly which episodes first, and only ever marks), and *In AniBox but not on
  your list*. A switch picks MyAnimeList or AniList.

**Sending what you watch to your list** (off until you turn it on, per account):

1. Connect the account. MyAnimeList: on myanimelist.net → Account settings → API, edit the app
   whose Client ID AniBox uses: App Type **other** (it has no Client Secret, none is needed) and
   App Redirect URL exactly `http://127.0.0.1:43210/oauth/mal`. AniList: anilist.co → Settings →
   Developer → Create New Client with the Redirect URL `http://127.0.0.1:43210/oauth/anilist`, and
   put its ID under Client ID. Then **Connect …** → **Open MyAnimeList/AniList** → Allow. (The
   Settings page shows the exact addresses; they contain the port AniBox runs on.)
2. **Turn on …** shows every change it would make now (from → to), and nothing is written before
   you click OK. **Sync now …** does the same later.
3. From then on, when you finish an episode (95 %, in AniBox or on a TV), AniBox updates that show
   on your list in the background (with retries): progress = the highest episode you watched,
   Plan to watch → Watching, Completed at the last episode. It never lowers progress, never
   removes entries and never changes scores. Completed entries are left alone unless you turn on
   "When I watch a finished show again: count it as a rewatch". Settings lists the last changes
   per account.

The sign-ins are kept in `app\lists\accounts.json`, encrypted for your Windows user (on Linux/macOS
in a file only you can read). **Disconnect** forgets them.

### Optional: series and movie info from TMDB

Anime gets its info from MyAnimeList. For your **series and movies** (libraries that count as
"Series" or "Movies" under Settings → Libraries to show), AniBox can show posters, descriptions,
genres, the year and episode titles from [TMDB](https://www.themoviedb.org), a free movie and TV
database. It needs a free key of your own: make an account on themoviedb.org, open Settings → API,
ask for an API key for personal use, and paste the **API Read Access Token** (or the shorter API
Key) under **Settings → Series and movie info (TMDB)**.

- AniBox searches TMDB by folder name ("Title (2019)" or "Title.2019…" give the year) and picks the
  same title first, then the same year, then the most popular one. **Wrong match?** on a show's
  page lets you search and pick another one, or mark it as not on TMDB.
- TMDB only learns your folder names. Answers and posters are kept in `app\tmdb` for 30 days; the
  window never talks to TMDB itself. Without a key AniBox never asks TMDB anything.
- Episode titles: the ones in your file names come first, then Plex's, then TMDB's
  (`S01E05` or a `Season 1` folder tells AniBox which episode it is).

### Optional: watch history from Plex

**Settings → Your Plex library → Sign in with a code** (the same code sign-in as the Library
Check; it adds "AniBox Library Check" to your Plex account under Authorized Devices, where you can
remove it). **Import watched episodes** then marks what you watched in Plex as watched in AniBox
and takes over resume points. Plex itself is only read. AniBox never un-marks anything.

### Copy Plex's details into AniBox

Five of the Plex libraries were matched by the old MyAnimeList agent, which no longer works. Their
titles, descriptions and MyAnimeList IDs can't be downloaded again; they only live in Plex's
database on the Shield's SD card. **Settings → Your Plex library → Copy now** reads them (Plex is
only read) and keeps a copy in AniBox's data folder (`app\plex-details.json`, posters in
`app\plexposters`), linked to your folders by file name, not by title.

- Each show page then has a **From your Plex library** box. For locked shows it stays exactly as
  copied; copying again later only adds what's new.
- Episode titles: the ones in your file names come first, then Plex's, then Kitsu's.
- Where Plex's old MyAnimeList match differs from AniBox's, the show page offers **Use Plex's
  match**, and Settings lists all of them.

### Info files for Plex and Jellyfin (NFO)

Plex Media Server 1.43 added a "Plex NFO Series" agent that reads Kodi-style `.nfo` files next to
the videos; Jellyfin and Kodi read the same files. AniBox can write such files with the
MyAnimeList title, description, genres and IDs, so a Plex library can show MyAnimeList data
again without an always-on server.

- Check first that your Plex server offers it: Plex Web → Settings → your server → Metadata
  Agents. Try it in a **new test library** with a copy of a few folders, never on an existing
  library.
- **Settings → Info files**: pick the libraries, click **Preview** (lists every file that would be
  written), then **Write**. Episodes that were already there are locked and skipped; only new
  episodes (and shows you unlocked) get files; One Piece follows the same rule. AniBox only adds `tvshow.nfo` and one `.nfo` per episode; it never
  replaces a file it didn't write itself, and folders on your protected list
  are never touched. **Undo** removes exactly the files AniBox wrote.

### Away from home (Tailscale)

Plex already works away from home (your router forwards Plex's port). For AniBox's phone remote and
anything else that should reach your PC or the Shield from outside without opening ports, install
[Tailscale](https://tailscale.com) (free for personal use) on the PC and the phone and sign in to the
same account. Settings → Phone remote then also shows a **Tailscale** link that works from anywhere.
Never open the file-sharing port (445) on the router.

### Play on TV

**Play on TV** (show page or playing bar) finds TVs in your home network: CastApp TV on the
Shield, smart TVs and Kodi with DLNA. AniBox then streams the episode from your PC to the TV and
keeps resume points and watched marks as usual; the playing bar and the phone remote control the
TV. If CastApp TV only accepts paired devices, AniBox asks for the 4-digit code shown on the TV.
The playing bar's TV button continues the current episode on a TV. The first time, Windows asks
whether to allow AniBox in your network; allow private networks. Keep AniBox open while the TV
plays (the file streams from your PC).

**Internet Archive videos and series playlists** go to the TV too: **On TV** next to a video's Play
button, **Play on TV** / **Continue on TV** on a series playlist's page, the TV button on a
"Continue watching" card, or the playing bar's TV button while one plays on this PC. AniBox picks the
way for each video:

- completely on this PC (kept, or fully loaded in the cache): served from there, like an episode;
- the cache on (Settings → Internet Archive streaming): the TV reads through AniBox's cache, so it
  gets the parallel loading, loading ahead and quick jumps mpv gets;
- the cache off: CastApp TV loads it straight from archive.org; other TVs get it passed on by this PC
  over plain http (many TVs can't do https).

A file the TV can't play (CastApp TV: WMV/ASF, Ogg video, Blu-ray .m2ts; for other TVs AniBox prefers
MP4 with H.264) is swapped for archive.org's MP4 copy of the same episode; without one AniBox says so.
Resume points, watched marks and the next episode follow the item or playlist you started from, and the
cache loads the next episodes ahead.

CastApp TV also learns your subtitle and audio languages (Settings → Player, and the languages you
last picked for the show). When the file is on this PC, AniBox reads its subtitle tracks and names
the exact one: a full track in your first language (one without "SDH" first), a "Signs & Songs" or
forced track only when there's nothing else, then your next language. A subtitle file next to the
video goes along instead (CastApp TV 3 gets ASS files with their styling, other TVs get SRT). With
subtitles switched off it shows none. If a video can't play, CastApp TV 3 says why (for example
"10-bit H.264 (High 10)") and AniBox shows that. If CastApp TV doesn't appear in the list, open CastApp
on the TV once so it says "Ready to cast", or type the TV's address (shown on the TV) instead.

**Chromecasts** and TVs with Google Cast (the Shield has its own Cast receiver too) appear in the same
list, marked "Chromecast". Their player takes MP4 or WebM with H.264 (HEVC and VP9 on newer models) and
WebVTT subtitles, so AniBox decides for each file: an MP4 that fits goes as it is; an MKV whose picture
fits is repackaged on the fly (the picture copied, the sound converted to AAC if needed: light work);
a picture the device can't decode (10-bit "Hi10P", HEVC on an older Chromecast) is converted while you
watch, which uses this PC's processor (or its graphics chip) and says so in the playing bar; a TV copy
made earlier goes instead when there is one. A jump in a repackaged or converted video starts it again
at the new place, which takes a moment. Subtitle files next to the video and the text subtitles inside
an MKV go along as WebVTT (without the ASS styling); pick or hide them with the playing bar's track
button. Picture subtitles (PGS, VobSub) can't go to a Chromecast. Repackaging and converting need
ffmpeg (see below). To add one by hand, type its address with `:8009` (for example
`192.168.1.60:8009`). **Settings → Player → Chromecasts in Play on TV** switches them off. Not tried
with a real Chromecast or the Shield's Cast receiver yet: what each model decodes comes from Google's
specifications, and whether Windows lets the search answers (multicast DNS) in is still to be seen.

### Subtitles for the TV, subtitles online, "Plays on the TV?"

Each show page has an **On the TV** box. Some parts need **ffmpeg**: **Settings → Player → Download
ffmpeg** (once, about 114 MB: the FFmpeg 9.1 "essentials" build for Windows by Gyan Doshi, checked
against a fixed checksum; only `ffmpeg.exe` and `ffprobe.exe` are kept, in the `ffmpeg` folder of your
data folder). On Linux/macOS install `ffmpeg` with your package manager.

- **Plays on the TV?** reads the first and a middle episode (only their start) and says for **Plex on
  the Shield** and **CastApp TV** whether they play directly or need converting, and why (for example
  "10-bit H.264 (Hi10P): the Shield's hardware can't decode it; Plex converts it, which is slow on
  the Shield"). CastApp TV is asked what it can decode when AniBox knows it (Play on TV → Search);
  everything else comes from a built-in table, marked "probably" where it hasn't been tried on your
  Shield yet. Without ffmpeg AniBox reads only MKV/MP4 files, a bit less exactly.
  **Settings → Check every show** checks the whole library; **Library → May need converting** then
  lists the shows that won't play directly.
- **Make TV-friendly subtitles**: Plex on the Shield and many TVs can't show styled subtitles (ASS, the
  usual fansub format) and convert the whole video to burn them in, or show them plain. AniBox adds a
  plain `<video name>.<language>.srt` next to each episode (signs-only tracks as `.<language>.forced.srt`),
  taken from the MKV or from an `.ass` file next to it. The `.srt` keeps the text but loses colours,
  fonts and positions. Picture subtitles (PGS, VobSub) can't become text without OCR, so AniBox offers
  nothing for them. You see a preview first ("3 files would be added"); only episodes that aren't
  locked get files; nothing is ever replaced; **Undo added subtitles** removes exactly the files AniBox
  added (a file you changed since stays).
- **Find subtitles online**, per episode, from **Jimaku** (Japanese subtitles for anime) or
  **OpenSubtitles** (many languages). Each needs your own free key under **Settings → Subtitles online
  and the TV check**:
  - Jimaku: sign up on [jimaku.cc](https://jimaku.cc), open your account page, create an API key.
  - OpenSubtitles: sign up on [opensubtitles.com](https://www.opensubtitles.com), open
    [opensubtitles.com/consumers](https://www.opensubtitles.com/consumers), add a consumer (any name)
    and copy its API key. Downloads also need your OpenSubtitles username and password (free accounts
    get a few downloads a day).

  Without a key nothing is sent. With one, only the title (or the AniList/IMDb number), the episode
  number and, for OpenSubtitles, a short fingerprint of the video file (its size and a checksum of its
  first and last 64 KB) are sent. The keys are kept encrypted for your Windows user in
  `app\subtitle-accounts.json`, never shown in the window and never in a backup. The chosen file is
  saved next to the video as `<video name>.<language>.srt` (or `.ass`), only for new or unlocked
  episodes, never over an existing file, and Undo removes it again.

Files: `app\media-info.json` (what AniBox read from each file, by size and date), `app\media-checks.json`
(the results for the library filter), `app\subtitle-log.jsonl` (every subtitle file AniBox added, for
Undo).

### TV copies (Hi10P and other videos the TV can't play)

Many older anime releases are 10-bit H.264 ("Hi10P"). Neither the Shield's hardware nor phones decode
it: Plex on the Shield converts it slowly, and CastApp TV can't play it at all. Like Plex's "Optimized
versions", AniBox can make a copy the TV plays directly, on the PC, with ffmpeg:

- When **Plays on the TV?** says **Needs converting**, click **Make TV copies …**. The preview lists the
  episodes that need one (all of the show's episodes are read, only their start), the encoder, the
  estimated size and time and where the copies go. Tick what you want and confirm.
- **The copy**: 8-bit H.264 (High, `yuv420p`), at most 1920×1080 (smaller videos keep their size).
  Sound the TV plays (AAC, AC3, E-AC3, MP3, FLAC, Opus) is copied as it is; DTS, TrueHD and rarer formats
  become Dolby Digital (AC3, 640k for 5.1, 256k for stereo) or, as an option, AAC stereo. Every audio
  track keeps its language; every subtitle track is copied as it is (styled ASS stays styled, PGS stays
  PGS), plus subtitle files next to the original (`.ass`, `.srt`, `.vtt`, `.sup`); fonts inside the file,
  chapters and titles too. Always MKV.
- **Encoder**: Automatic uses the graphics card when ffmpeg has an encoder for it that works on this
  PC (NVIDIA NVENC, Intel Quick Sync, AMD AMF; tested once with a 1-second test encode), otherwise the
  processor (x264, `veryfast`, quality 20). You can pick one in **Settings → TV copies**.
- **Never next to your videos.** A second video in a show folder would be a duplicate episode in AniBox
  and Plex. Copies go into their own folder (standard: `app\tv-copies` in AniBox's data folder; change
  it in **Settings → TV copies**, ideally to a big drive), named like the original:
  `<copies folder>\<library>\<show>\<same name>.mkv`. A folder inside your library folders or the "Add
  new videos" folder is refused.
- **Safe**: ffmpeg writes `<name>.mkv.part`, AniBox checks the copy is as long as the original (±2 s)
  and only then renames it; nothing is ever replaced (a name that's taken gets " (2)"). One file at a
  time, at low priority, with progress, speed and time left; **Pause** and **Cancel** (Cancel deletes
  only the unfinished `.part`). A free-space check comes first; when the drive is too full the queue
  pauses. AniBox stays open while copies are being made; if you quit, the unfinished one is dropped
  and the rest wait (paused) for next time.
- **Play on TV** sends the copy instead of the original when there is an up-to-date one; the TV check
  says "TV copy ready". When the original changes, its copy counts as outdated and isn't used.
- **Undo**: **Remove** next to a copy (show page → TV copies), the History page (one entry per "Make TV
  copies"), or **Settings → TV copies → Remove all TV copies**. Only files AniBox made and lists in
  `app\tv-copies.json` are ever deleted; anything else in the folder stays, and a copy you changed is kept.
- **Plex too (optional, your step)**: choose a copies folder on one of the Shield's drives, outside the
  folders AniBox reads, and add `<copies folder>\Anime` (the library's name inside it) in Plex as a new
  TV library. Plex then plays the copies without converting. AniBox does nothing in Plex here.

Files: `app\tv-copies.json` (the copies, with the original's size and date), `app\tvcopy-log.jsonl`
(every copy made or removed, for the History page).

### Internet Archive

The **Internet Archive** tab searches archive.org (no account needed). Search by title, subject
or maker, or paste an archive.org link; **Videos** / **Everything** and the sort order narrow it
down. Open an item to see its description and files: videos and subtitles are listed, the
original files are ticked already ("Copy by archive.org" are smaller versions archive.org made);
**Show all files** lists pictures and info files too. **Download selected** puts the ticked files
in the list under **Downloads**.

- **Where they go:** your Downloads folder → `AniBox Internet Archive` → one folder per item,
  named after its title. **Change …** picks another folder. AniBox only ever adds new files there:
  a file that's already there is never replaced (the new one gets " (2)"), and **Cancel** deletes
  only the unfinished `.part` file of that download.
- **Add to my AniBox library** (on by default, remembered): when an item's videos are done, AniBox
  adds the download folder to Settings → Folders (unless one of your folders already contains it)
  and scans. It reads it like a library folder, `<download folder>\<item>\<files>`, so each item
  becomes a show in the library "AniBox Internet Archive".
- Two files download at the same time; **Pause** and **Resume** go on where they stopped, also
  after a restart. Files are checked against archive.org's checksum when it has one. When
  archive.org is busy, AniBox waits and tries again by itself. If you close the AniBox window,
  AniBox finishes the downloads first and then closes.
- Every request carries only `AniBox/<version>` as its name; item pictures are fetched by AniBox
  and kept in `app\ia-thumbs`, the download list in `app\ia-downloads.json`.
- **Watch without downloading:** every video in an item has a **Play** button next to its tick box.
  AniBox's player then plays it from archive.org, like Frostbox does (through the cache below, or
  straight from archive.org with the cache off). Resume, "watched at 95 %", the playing bar and the phone remote work as for your own
  episodes; next and previous are the item's other videos of the same kind (originals, or
  archive.org's copies in the same format), and subtitle files with the video's name come along.
  Before you've played anything of an item, AniBox takes archive.org's MP4 copy (it starts and jumps
  quickly), unless archive.org says the original is sharper (e.g. a 1080p MKV and a 480p copy).
  **Continue watching** on the Internet Archive tab (and on Home) lists the items you started.
  Progress is kept under keys like `ia:<item>/<file>`, the item list in `app\ia-streams.json`.
- **Series playlists** (the **Series playlists** tab, or **Make a series playlist** on an item page;
  the idea comes from Frostbox): give it a name and paste one or more archive.org links. AniBox reads
  the items and groups their videos by series, the part of the file name before a date or S01E01
  (`Made.Up.Show.2008.01.07.mp4` → "Made Up Show"). Tick the series you want and give each a short
  name if you like; series you don't tick never slip in later. Pick the order, with a preview: by
  **air date** (from the file name), **season & episode**, **file name** (2 before 10), **added**, or
  **manual** (drag the episodes or use ↑ ↓; new episodes then go to the end, marked "new"). Episodes
  without a date or number go to the end, marked. Per episode AniBox plays archive.org's MP4 copy,
  unless the original is sharper. On a playlist's page: **Play/Continue**, find by name or date,
  **Hide watched**, hide single episodes, **Refresh** (finds new files; files that are gone stay
  greyed as "No longer online"), **Series and items …** (tick other series, add more items),
  **Rename** and **Delete** (only the list goes). Next and previous follow the playlist, and what you
  watched counts everywhere: in the item, in every playlist that has the episode, and in Continue
  watching, where a playlist you're watching has its own card. The playlists, with each file's size,
  length and checksum, are kept in `app\ia-playlists.json`; a damaged file is copied aside as
  `ia-playlists.damaged.json` and AniBox starts a new list.
- **Cache, loading ahead and Keep** (Settings → Internet Archive streaming; Frostbox's design): a
  video you play first loads into a cache on this PC (`app\ia-cache` unless you pick another
  folder), with 8 connections at once, the start first, and mpv plays it from there, so it doesn't
  stop to buffer; when you jump ahead, that part loads first. The next 2 episodes load ahead. If
  loading gets stuck, AniBox tries 5 times with longer waits, then shows "Paused" with **Try again**
  and **Start over**; without internet it waits and goes on by itself; a finished file is checked
  against archive.org's checksum. The cache never grows over its size (20 GB): watched episodes go
  first, then the ones loaded furthest ahead, and only files the cache made itself (listed in
  `app\ia-cache.json`) are ever deleted. **Keep** next to a video loads it fully, checks it and moves
  it to the folder `AniBox Keep` (next to the Internet Archive download folder, so the library doesn't list it as a show) as `<title> – <file name>` (never over another file); it then plays
  from there and doesn't count toward the cache size. Each video shows its state: Loading 63 %,
  Preloaded, Loaded, Kept, Paused, Waiting for internet, No longer online, Broken.

## Library layout it expects

`<library folder>\<show folder>\<episodes>`, the way the Shield drives are organized:

```
NVIDIA_SHIELD\
  Anime\
    Sousou no Frieren\
      Sousou no Frieren 01.mkv
  One Piece\
    One Piece\
      Season 01\One Piece 001.mkv
  Anime Movies\
    Mononoke Hime\Mononoke Hime.mkv
```

The folder holding the videos is the show and the folder above it the library. `Season NN`
folders are kept as seasons, and so are folders named after the show inside the show's folder
(`Rick and Morty\Rick and Morty - Season 1`); folders such as `Extras` or `Featurettes` are skipped.
An anime folder whose name ends in "Season 3" but sits directly in a library (`Anime\Shingeki no
Kyojin Season 3`) stays its own show, because it's its own MyAnimeList entry. Show
folders are matched to MyAnimeList by their name (MAL titles and alternative titles). After a
scan, AniBox picks the libraries where most folders are anime; you can change the choice in
Settings.

## Your data

Everything AniBox keeps is in **one folder**: `%LOCALAPPDATA%\AniBox` on Windows
(`~/.local/share/anibox` elsewhere). **Settings → Your data → Open data folder** shows it.

- `app\`: settings and watch progress (`anibox.db`), the library cache (`library.json`, plus
  `scan-cache.json` with the folder listings that make rescans quick), the copy of Plex's details,
  your collections (`collections.json`), AniList extras (`anilist\`), posters, TV copies (`tv-copies\`, unless you chose another folder), logs
  (`app\logs\anibox.log`, send this file when something goes wrong), daily copies of the watch
  progress (`app\backups`, last 7 days).
- `data\`: the anime lists (shared with the Library Check, refreshed weekly).
- `mpv\`: the downloaded player.
- `settings.json` and `ignored.txt`: the Plex sign-in (on Windows encrypted for your user account, so a copy on another PC asks you to sign in again) and hidden items.

It's separate from the program folder so that a new version can replace the program folder
without losing anything. Versions up to 1.0 kept `settings.json`/`ignored.txt` in
`%APPDATA%\AniBox`; they are copied over once and the old folder can be deleted afterwards.

- **Back up watch progress** saves one file (to your Downloads) that **Restore a backup** reads
  back; for each episode the newer entry wins and nothing is deleted. It holds every profile; a
  backup from before profiles goes into the first profile.
- **Tidy up** lists AniBox's own leftovers that aren't needed anymore (the old `run-check.bat`, the
  previous version kept after an update, update zips in Downloads you've already installed, the
  settings folder of AniBox 1.0) and removes each one only when you click **Remove**.
- **Portable mode**: if a folder named `data` sits next to `AniBox.bat`, AniBox keeps everything
  there instead (e.g. on a USB stick). **Copy to the program folder** sets this up; when you
  update, copy the `data` folder into the new version.

## Other parts of this repository

- **[library-check/](library-check/)**: the engine behind the Missing page (matching folders and
  Plex items to MyAnimeList, franchises, the HTML/CSV reports). Its command-line version still runs
  for developers; see its README.
- **[CLAUDE.md](CLAUDE.md)**: background research and decisions (Plex vs. Jellyfin, metadata
  agents, the Jikan shutdown, Shoko, remote access).

## For developers

Python 3.9+, standard library only. The app is a small local web server
(`app/anibox/server.py`) with the window as a web page (`app/anibox/web/`); mpv is controlled over
its JSON IPC.

```
cd app && python -m unittest discover -s tests -t .
cd library-check && python -m unittest discover -s tests -t .
```

The player tests need `mpv` and `ffmpeg` and are skipped without them.

`python tools/build_windows.py` builds the Windows package with Python's embeddable distribution inside
(pinned version and checksum; see `tools/README.md`); `python -m unittest tools/test_build_windows.py` tests it.

## Credits

- **Frostbox** by Martin: the design (colors, Sora/Inter typography, cards, the glow), the playing
  features and the phone remote page. Used and adapted with permission.
- [Fribb/anime-lists](https://github.com/Fribb/anime-lists): MyAnimeList ↔ AniDB/TVDB/TMDB mapping.
- [anime-offline-database](https://github.com/cedya77/anime-offline-database) (ODbL): titles,
  related entries and poster links.
- [MyAnimeList API](https://myanimelist.net/apiconfig/references/api/v2) (optional, your own Client ID).
- [AniList API](https://docs.anilist.co) (public, no account): air dates for the new-episode notices.
- [TMDB](https://www.themoviedb.org) (optional, your own key): series and movie info and posters.
  This product uses the TMDB API but is not endorsed or certified by TMDB.
- [mpv](https://mpv.io) (GPL/LGPL), Windows build by
  [shinchiro](https://github.com/shinchiro/mpv-winbuild-cmake); downloaded on request, not included.
- [FFmpeg](https://ffmpeg.org) (GPL), Windows build by [Gyan Doshi](https://www.gyan.dev/ffmpeg/builds/)
  ([GyanD/codexffmpeg](https://github.com/GyanD/codexffmpeg)); downloaded on request, not included.
- [Jimaku](https://jimaku.cc) and [OpenSubtitles](https://www.opensubtitles.com) (optional, your own keys).
- Fonts [Sora](https://github.com/sora-xor/sora-font) and [Inter](https://rsms.me/inter/),
  SIL Open Font License (`app/anibox/web/fonts/`).
- [qrcode-generator](https://github.com/kazuhikoarase/qrcode-generator) by Kazuhiko Arase, MIT.
