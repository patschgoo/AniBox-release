@echo off
rem AniBox: double-click to start.
rem The ready package brings its own Python (the "python" folder next to this file).
rem Otherwise AniBox needs Python 3.9 or newer from python.org.
cd /d "%~dp0app"
if exist "%~dp0python\pythonw.exe" (
  start "" "%~dp0python\pythonw.exe" -m anibox %*
  exit /b 0
)
where pyw >nul 2>nul
if %errorlevel%==0 (
  start "" pyw -3 -m anibox %*
  exit /b 0
)
where pythonw >nul 2>nul
if %errorlevel%==0 (
  start "" pythonw -m anibox %*
  exit /b 0
)
echo AniBox needs Python 3.9 or newer: https://www.python.org/downloads/
echo During setup, tick "Add python.exe to PATH".
echo.
pause
