"""Find subtitles online: Jimaku (Japanese subtitles for anime) and OpenSubtitles.

Both are optional and need the user's own free key, typed in under Settings. Nothing is sent
anywhere until the user clicks Search on a show page; then only the show's title or AniList /
IMDb number, the episode number and (OpenSubtitles) a short fingerprint of the video file (its size
and a checksum of its first and last 64 KB, OpenSubtitles' "movie hash") go out. Every request
names itself only as ``AniBox``.

- **Jimaku** (jimaku.cc, API docs at jimaku.cc/api/docs): ``Authorization: <API key>``;
  ``GET /api/entries/search?anime=true&anilist_id=N`` (or ``query=``), then
  ``GET /api/entries/{id}/files?episode=N``; every file has a download ``url``. The key is on the
  account page after signing up (free).
- **OpenSubtitles** (REST API v1, api.opensubtitles.com): header ``Api-Key`` (a free "consumer" key
  from opensubtitles.com/consumers) and ``User-Agent: AniBox v<version>``. Searching works with the
  key alone (``GET /subtitles``, parameters sorted and lower-case); downloading needs a free user
  account too: ``POST /login`` gives a token (and, for VIP users, another server) that goes along
  as ``Authorization: Bearer`` with ``POST /download {file_id}``, which answers a temporary link.
  Free accounts get a few downloads a day.

The keys and the password are kept in ``subtitle-accounts.json`` in AniBox's data folder, encrypted
for your Windows user (DPAPI, the same as the Plex sign-in); they never go to the window or into a
backup.
"""

from __future__ import annotations

import json
import logging
import os
import re
import struct
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Dict, List, Optional

from anibox_check import secret

from . import __version__

log = logging.getLogger("anibox.subsearch")

JIMAKU_BASE = "https://jimaku.cc"
OPENSUBTITLES_BASE = "https://api.opensubtitles.com/api/v1"
TIMEOUT = 15
MAX_ANSWER = 4_000_000
MAX_FILE = 8_000_000
SUB_EXTS = (".srt", ".ass", ".ssa", ".vtt")
ARCHIVE_EXTS = (".zip", ".rar", ".7z", ".tar", ".gz")
FIELDS = ("jimaku_key", "opensubtitles_key", "opensubtitles_user", "opensubtitles_password")
SECRET_FIELDS = ("jimaku_key", "opensubtitles_key", "opensubtitles_password")

HOW_TO = {
    "jimaku": "Jimaku needs a free API key: sign up on jimaku.cc, open your account page and create an API key. "
              "Paste it under Settings → Subtitles online.",
    "opensubtitles": "OpenSubtitles needs a free API key: sign up on opensubtitles.com, open opensubtitles.com/consumers, "
                     "add a new consumer (any name, e.g. AniBox) and copy its API key into Settings → Subtitles online. "
                     "For downloads, also enter your OpenSubtitles username and password there.",
}


class SubtitleError(Exception):
    """A problem with a message the user can read as it is. ``reason``: no_key, login, limit, busy,
    nothing, offline, server."""

    def __init__(self, message: str, reason: str = "server"):
        super().__init__(message)
        self.reason = reason


# -- the keys ------------------------------------------------------------------------------------

class Accounts:
    """``subtitle-accounts.json``: the keys (encrypted on Windows). Never sent to the window."""

    def __init__(self, path: Path):
        self.path = Path(path)
        self._lock = threading.Lock()

    def _read(self) -> dict:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}
        return data if isinstance(data, dict) else {}

    def get(self) -> Dict[str, str]:
        raw = self._read()
        out = {}
        for k in FIELDS:
            v = raw.get(k)
            if not isinstance(v, str):
                v = ""
            try:
                out[k] = secret.unprotect(v) if k in SECRET_FIELDS else v
            except secret.SecretError:
                out[k] = ""  # saved by another Windows user or PC: type it in again
        return out

    def update(self, changes: dict) -> Dict[str, str]:
        """Set the given fields (empty string = remove). Fields that aren't given stay."""
        with self._lock:
            current = self.get()
            for k in FIELDS:
                if k in changes and changes[k] is not None:
                    current[k] = str(changes[k]).strip()
            stored = {k: (secret.protect(v) if k in SECRET_FIELDS else v) for k, v in current.items() if v}
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".part")
            tmp.write_text(json.dumps(stored, indent=1), encoding="utf-8")
            try:
                os.chmod(tmp, 0o600)
            except OSError:
                pass
            os.replace(tmp, self.path)
        return current

    def public(self) -> dict:
        """What the window may know: which keys are there (not the keys)."""
        a = self.get()
        return {"jimaku": bool(a["jimaku_key"]), "opensubtitles": bool(a["opensubtitles_key"]),
                "opensubtitlesUser": a["opensubtitles_user"],
                "opensubtitlesLogin": bool(a["opensubtitles_user"] and a["opensubtitles_password"]),
                "encrypted": secret.available()}


# -- HTTP ----------------------------------------------------------------------------------------

def _request(method: str, url: str, headers: dict, body: Optional[dict] = None, limit: int = MAX_ANSWER,
             timeout: float = TIMEOUT):
    data = json.dumps(body).encode("utf-8") if body is not None else None
    h = dict(headers)
    if data is not None:
        h["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, method=method, headers=h)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read(limit + 1)
            status = resp.status
            resp_headers = dict(resp.headers)
    except urllib.error.HTTPError as exc:
        raw = exc.read(limit + 1) if exc.fp else b""
        status = exc.code
        resp_headers = dict(exc.headers or {})
    except (urllib.error.URLError, OSError) as exc:
        raise SubtitleError("Couldn't reach the subtitle site. Check the internet connection.", "offline") from exc
    if len(raw) > limit:
        raise SubtitleError("The answer was too big.", "server")
    return status, raw, resp_headers


def _json(raw: bytes):
    try:
        return json.loads(raw.decode("utf-8") or "null")
    except (UnicodeDecodeError, ValueError):
        return None


def _ext(name: str) -> str:
    return os.path.splitext(name or "")[1].lower()


def movie_hash(path: str) -> Optional[str]:
    """OpenSubtitles' fingerprint: file size plus the 64-bit sums of the first and last 64 KB."""
    try:
        size = os.path.getsize(path)
        if size < 131072:
            return None
        total = size
        with open(path, "rb") as f:
            for offset in (0, size - 65536):
                f.seek(offset)
                chunk = f.read(65536)
                total += sum(struct.unpack("<8192Q", chunk))
        return "%016x" % (total & 0xFFFFFFFFFFFFFFFF)
    except (OSError, struct.error):
        return None


# -- Jimaku ----------------------------------------------------------------------------------------

class Jimaku:
    name = "Jimaku"

    def __init__(self, key: str, base: str = JIMAKU_BASE, timeout: float = TIMEOUT):
        if not key:
            raise SubtitleError(HOW_TO["jimaku"], "no_key")
        self.key = key.strip()
        self.base = base.rstrip("/")
        self.timeout = timeout

    def _headers(self) -> dict:
        return {"Authorization": self.key, "User-Agent": f"AniBox/{__version__}", "Accept": "application/json"}

    def _get(self, path: str, params: dict):
        url = f"{self.base}{path}?{urllib.parse.urlencode(params)}"
        status, raw, headers = _request("GET", url, self._headers(), timeout=self.timeout)
        obj = _json(raw)
        if status == 200:
            return obj
        msg = obj.get("error") if isinstance(obj, dict) else ""
        if status == 401:
            raise SubtitleError("Jimaku didn't accept the API key. Check it under Settings → Subtitles online.", "no_key")
        if status == 429:
            wait = headers.get("x-ratelimit-reset-after") or headers.get("X-RateLimit-Reset-After") or ""
            raise SubtitleError("Jimaku is busy. Try again in a moment" + (f" ({wait} s)." if wait else "."), "busy")
        if status == 404:
            return None
        raise SubtitleError(f"Jimaku answered with an error ({status})" + (f": {msg}" if msg else "."), "server")

    def search(self, anilist_id: Optional[int] = None, query: str = "", episode: Optional[int] = None) -> List[dict]:
        entries = []
        if anilist_id:
            entries = self._get("/api/entries/search", {"anime": "true", "anilist_id": int(anilist_id)}) or []
        if not entries and query:
            entries = self._get("/api/entries/search", {"anime": "true", "query": query}) or []
        if not isinstance(entries, list) or not entries:
            raise SubtitleError("Jimaku has nothing for this show.", "nothing")
        results = []
        for entry in entries[:3]:
            if not isinstance(entry, dict) or not isinstance(entry.get("id"), int):
                continue
            params = {"episode": int(episode)} if episode is not None else {}
            files = self._get(f"/api/entries/{entry['id']}/files", params) or []
            title = entry.get("english_name") or entry.get("name") or ""
            for f in files if isinstance(files, list) else []:
                if not isinstance(f, dict) or not isinstance(f.get("url"), str) or not isinstance(f.get("name"), str):
                    continue
                ext = _ext(f["name"])
                ok = ext in SUB_EXTS and self._own_url(f["url"])
                results.append({"provider": "jimaku", "name": f["name"], "release": f["name"], "lang": "ja",
                                "format": ext.lstrip(".") or "?", "size": int(f.get("size") or 0), "downloads": None,
                                "title": title, "hashMatch": False, "url": f["url"], "downloadable": ok,
                                "note": "" if ok else ("an archive: open it on jimaku.cc" if ext in ARCHIVE_EXTS
                                                       else "not on jimaku.cc" if ext in SUB_EXTS
                                                       else "not a subtitle file AniBox can use")})
            if results:
                break
        if not results:
            raise SubtitleError("Jimaku has no files for this episode.", "nothing")
        return results

    def _own_url(self, url: str) -> bool:
        u, b = urllib.parse.urlsplit(url), urllib.parse.urlsplit(self.base)
        return u.scheme in ("https", b.scheme) and u.netloc == b.netloc

    def fetch(self, result: dict) -> bytes:
        url = result.get("url") or ""
        if not self._own_url(url):
            raise SubtitleError("That download isn't on jimaku.cc.", "server")
        status, raw, _ = _request("GET", url, self._headers(), limit=MAX_FILE, timeout=self.timeout)
        if status != 200:
            raise SubtitleError(f"The download from Jimaku failed ({status}).", "server")
        return raw


# -- OpenSubtitles -------------------------------------------------------------------------------

_TOKENS: Dict[tuple, tuple] = {}  # (base, user) -> (token, base_url, time); in memory only
TOKEN_HOURS = 20


class OpenSubtitles:
    name = "OpenSubtitles"

    def __init__(self, key: str, user: str = "", password: str = "", base: str = OPENSUBTITLES_BASE,
                 timeout: float = TIMEOUT):
        if not key:
            raise SubtitleError(HOW_TO["opensubtitles"], "no_key")
        self.key = key.strip()
        self.user = user.strip()
        self.password = password
        self.base = base.rstrip("/")
        self.timeout = timeout

    def _headers(self, token: str = "") -> dict:
        h = {"Api-Key": self.key, "User-Agent": f"AniBox v{__version__}", "Accept": "application/json"}
        if token:
            h["Authorization"] = f"Bearer {token}"
        return h

    def _call(self, method: str, url: str, body: Optional[dict] = None, token: str = "", login: bool = False,
              download: bool = False):
        status, raw, _ = _request(method, url, self._headers(token), body, timeout=self.timeout)
        obj = _json(raw)
        if 200 <= status < 300 and isinstance(obj, dict):
            return obj
        msg = ""
        if isinstance(obj, dict):
            msg = str(obj.get("message") or " ".join(str(e) for e in obj.get("errors") or []) or "").strip()
        if download and (status == 406 or (isinstance(obj, dict) and isinstance(obj.get("remaining"), int) and obj["remaining"] < 0)):
            raise SubtitleError("You reached today's OpenSubtitles download limit. " + (msg or "Try again tomorrow."), "limit")
        if status == 401 and login:
            raise SubtitleError("OpenSubtitles didn't accept the username or password.", "login")
        if status == 401:
            _TOKENS.pop((self.base, self.user), None)
            raise SubtitleError("OpenSubtitles wants you to sign in again. Check the username and password under "
                                "Settings → Subtitles online.", "login")
        if status == 403:
            raise SubtitleError("OpenSubtitles didn't accept the API key. Check it under Settings → Subtitles online.", "no_key")
        if status == 429:
            raise SubtitleError("OpenSubtitles is busy. Try again in a moment.", "busy")
        if status == 404:
            raise SubtitleError("OpenSubtitles found nothing.", "nothing")
        raise SubtitleError(f"OpenSubtitles answered with an error ({status})" + (f": {msg}" if msg else "."), "server")

    def login(self) -> tuple:
        if not (self.user and self.password):
            raise SubtitleError("Downloading from OpenSubtitles needs your free OpenSubtitles account: enter its username and "
                                "password under Settings → Subtitles online.", "login")
        hit = _TOKENS.get((self.base, self.user))
        if hit and time.time() - hit[2] < TOKEN_HOURS * 3600:
            return hit[0], hit[1]
        obj = self._call("POST", f"{self.base}/login", {"username": self.user, "password": self.password}, login=True)
        token = obj.get("token")
        if not isinstance(token, str) or not token:
            raise SubtitleError("OpenSubtitles didn't sign you in.", "login")
        base = self.base
        host = str(obj.get("base_url") or "").strip().rstrip("/")
        if host and re.fullmatch(r"(https://)?[a-z0-9.-]+\.opensubtitles\.(com|org)(/api/v1)?", host):
            base = (host if host.startswith("https://") else "https://" + host)
            base = base if base.endswith("/api/v1") else base + "/api/v1"
        _TOKENS[(self.base, self.user)] = (token, base, time.time())
        return token, base

    def _search_url(self, params: dict) -> str:
        # Sorted and lower-case, as the API asks (otherwise it answers with a redirect).
        items = sorted((k.lower(), str(v).lower()) for k, v in params.items() if v not in (None, ""))
        return f"{self.base}/subtitles?" + urllib.parse.urlencode(items)

    def search(self, query: str = "", episode: Optional[int] = None, season: Optional[int] = None,
               languages: Optional[List[str]] = None, moviehash: Optional[str] = None,
               parent_imdb: Optional[int] = None) -> List[dict]:
        langs = ",".join(sorted({l.strip().lower() for l in languages or [] if l.strip()}))
        searches = []
        if moviehash:
            searches.append({"moviehash": moviehash, "languages": langs})
        if parent_imdb:
            searches.append({"parent_imdb_id": int(parent_imdb), "episode_number": episode, "season_number": season,
                             "languages": langs})
        if query:
            searches.append({"query": query, "episode_number": episode, "languages": langs, "type": "episode" if episode else ""})
        found: Dict[int, dict] = {}
        for params in searches:
            try:
                obj = self._call("GET", self._search_url(params))
            except SubtitleError as exc:
                if exc.reason == "nothing":
                    continue
                raise
            for r in self._results(obj):
                found.setdefault(r["fileId"], r)
            if len(found) >= 40:
                break
        if not found:
            raise SubtitleError("OpenSubtitles has nothing for this episode in these languages.", "nothing")
        out = sorted(found.values(), key=lambda r: (not r["hashMatch"], -(r["downloads"] or 0)))
        return out[:60]

    @staticmethod
    def _results(obj: dict) -> List[dict]:
        out = []
        for item in obj.get("data") or []:
            a = (item or {}).get("attributes") if isinstance(item, dict) else None
            if not isinstance(a, dict):
                continue
            files = a.get("files") or []
            f = files[0] if files and isinstance(files[0], dict) else {}
            fid = f.get("file_id")
            if not isinstance(fid, int) or fid <= 0:
                continue
            feat = a.get("feature_details") or {}
            notes = []
            if a.get("machine_translated") or a.get("ai_translated"):
                notes.append("machine translated")
            if a.get("hearing_impaired"):
                notes.append("for the hearing impaired")
            if a.get("foreign_parts_only"):
                notes.append("foreign parts only")
            out.append({"provider": "opensubtitles", "fileId": fid, "name": str(f.get("file_name") or ""),
                        "release": str(a.get("release") or f.get("file_name") or ""),
                        "lang": str(a.get("language") or "").lower(), "format": "srt", "size": 0,
                        "downloads": int(a.get("download_count") or 0),
                        "title": str(feat.get("title") or feat.get("movie_name") or ""),
                        "hashMatch": bool(a.get("moviehash_match")), "downloadable": True, "note": ", ".join(notes)})
        return out

    def _link_ok(self, link: str) -> bool:
        """Download links only from OpenSubtitles' own servers (or the server AniBox talks to)."""
        u = urllib.parse.urlsplit(link)
        host = (u.hostname or "").lower()
        if u.netloc and u.netloc == urllib.parse.urlsplit(self.base).netloc and u.scheme in ("https", "http"):
            return True
        return u.scheme == "https" and (host in ("opensubtitles.com", "opensubtitles.org")
                                        or host.endswith((".opensubtitles.com", ".opensubtitles.org")))

    def fetch(self, result: dict) -> bytes:
        token, base = self.login()
        obj = self._call("POST", f"{base}/download", {"file_id": int(result["fileId"]), "sub_format": "srt"},
                         token=token, download=True)
        link = obj.get("link")
        if not isinstance(link, str) or not self._link_ok(link):
            raise SubtitleError(str(obj.get("message") or "OpenSubtitles gave no download."), "server")
        status, raw, _ = _request("GET", link, {"User-Agent": f"AniBox v{__version__}"}, limit=MAX_FILE, timeout=self.timeout)
        if status != 200:
            raise SubtitleError(f"The download from OpenSubtitles failed ({status}).", "server")
        log.info("OpenSubtitles download: %s left today", obj.get("remaining"))
        return raw
