"""Check my setup: test every part of AniBox on this PC and write a short report that can be shared.

The user clicks **Check my setup** (Settings, or the small link on Home) and AniBox tests the parts that
can go wrong on a real PC: its own folder and data, mpv (a real start over its named pipe), playing
inside the window, ffmpeg, the window itself, every library folder, Plex, TVs, the internet services,
the Internet Archive cache, the phone remote, and the last warnings in its log. Each check says ✓ (fine),
! (works, but note this) or ✗ (a problem), in one plain line, with a fix where there is one.

Rules:

- Everything only *reads*. The one exception is a small test file AniBox makes in its own cache folder
  (to see whether the drive can hold sparse files) and deletes right away. Nothing is written into the
  library folders, nothing is sent to Plex except GET requests, nothing to a TV except reading its
  description and CastApp TV's capabilities.
- Each check runs on its own thread with its own time limit (``run_checks``), so a hung network share or
  a sleeping Shield can't hold up the others.
- The report goes through ``Scrubber`` before anyone sees it: user and computer names, profile paths,
  share and drive names, addresses, e-mail addresses, keys and tokens, Plex server and account names, TV
  names and show names are replaced (``<PC>``, ``%USERPROFILE%``, ``\\\\<server>\\<share 1>``,
  ``<drive 1>``, ``<home network address>``, ``<hidden>`` ...). The page shows exactly that text before
  it's saved or copied.
- The internet checks send one small request each, with ``User-Agent: AniBox/<version>`` and nothing
  about the user; a key only ever goes to the service it belongs to, and only if it's set.
"""

from __future__ import annotations

import getpass
import http.client
import ipaddress
import json
import logging
import ntpath
import os
import platform
import re
import secrets
import shutil
import socket
import sqlite3
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import Counter
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Optional, Sequence, Tuple

from . import __version__

log = logging.getLogger("anibox.setupcheck")

IS_WINDOWS = os.name == "nt"
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
USER_AGENT = f"AniBox/{__version__}"

STATES = ("ok", "note", "problem", "skip")
MARKS = {"ok": "✓", "note": "!", "problem": "✗", "skip": "–", "waiting": "·", "running": "…"}
GROUPS = ("AniBox and system", "Player", "The window", "Library folders", "Plex", "TVs", "Internet",
          "Internet Archive cache", "Phone remote", "Recent problems")
PARALLEL = 6  # checks at the same time
LOG_LINES = 20  # warnings and errors from the log in the report
SPARSE_TEST_SIZE = 16 << 20  # the test file's size; with sparse files it takes (almost) nothing
LOG_RE = re.compile(r"^(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d),\d+ (DEBUG|INFO|WARNING|ERROR|CRITICAL) ([\w.]+): (.*)$")


# -- results ---------------------------------------------------------------------------------------

def result(status: str, line: str, *details: str, fix: str = "") -> dict:
    return {"status": status, "line": line, "details": [d for d in details if d], "fix": fix}


def ok(line: str, *details: str, fix: str = "") -> dict:
    return result("ok", line, *details, fix=fix)


def note(line: str, *details: str, fix: str = "") -> dict:
    return result("note", line, *details, fix=fix)


def problem(line: str, *details: str, fix: str = "") -> dict:
    return result("problem", line, *details, fix=fix)


def skip(line: str, *details: str, fix: str = "") -> dict:
    return result("skip", line, *details, fix=fix)


def worst(*states: str) -> str:
    order = {"problem": 3, "note": 2, "ok": 1, "skip": 0}
    return max(states, key=lambda s: order.get(s, 0)) if states else "ok"


def size_text(n: Optional[float]) -> str:
    if n is None:
        return "?"
    n = float(n)
    for unit in ("bytes", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{int(n)} bytes" if unit == "bytes" else f"{n:.1f} {unit}".replace(".0 ", " ")
        n /= 1024
    return f"{n:.1f} TB"


def secs_text(s: float) -> str:
    return f"{s * 1000:.0f} ms" if s < 1 else f"{s:.1f} s"


# -- the scrubber ----------------------------------------------------------------------------------

_TAILSCALE4 = ipaddress.ip_network("100.64.0.0/10")
_TAILSCALE6 = ipaddress.ip_network("fd7a:115c:a1e0::/48")
_COMMON_USERS = {"root", "user", "users", "admin", "administrator", "default", "public", "guest", "owner"}


def address_kind(text: str) -> Optional[str]:
    """"home network", "Tailscale" or "internet" for an IP address; "" for harmless ones (this PC,
    multicast) that stay as they are; None if it isn't an address."""
    try:
        a = ipaddress.ip_address(text.strip("[]").split("%")[0])
    except ValueError:
        return None
    mapped = getattr(a, "ipv4_mapped", None)
    if mapped:
        a = mapped
    if a.is_loopback or a.is_unspecified or a.is_multicast:
        return ""
    if (a.version == 4 and a in _TAILSCALE4) or (a.version == 6 and a in _TAILSCALE6):
        return "Tailscale"
    if a.is_private or a.is_link_local:
        return "home network"
    return "internet"


def _placeholder(kind: str) -> str:
    return f"<{kind} address>"


def _trie(words: Iterable[str], case: bool = False) -> str:
    """A regex for any of these words, built as a tree of their letters (quick with thousands of show names;
    the longest name wins)."""
    root: dict = {}
    for w in words:
        node = root
        for ch in (w if case else w.casefold()):
            node = node.setdefault(ch, {})
        node[""] = {}

    def build(node: dict) -> str:
        end = "" in node
        alts = [re.escape(ch) + build(sub) for ch, sub in sorted(node.items()) if ch]
        if not alts:
            return ""
        body = alts[0] if len(alts) == 1 else "(?:" + "|".join(alts) + ")"
        return "(?:" + body + ")?" if end else body
    return build(root)


def _words(names: Iterable[str], min_len: int = 2, whole: bool = True, case: bool = False) -> Optional["re.Pattern"]:
    """One pattern for these names; ``whole``: only as whole words; ``case``: only in the same letter case."""
    uniq = {n.strip() for n in names if n and len(n.strip()) >= min_len}
    if not uniq:
        return None
    body = _trie(uniq, case)
    return re.compile(r"(?<![\w])" + body + r"(?![\w])" if whole else body, 0 if case else re.I)


_SECRET_KV = re.compile(
    r"(?i)(?<![\w-])(x-plex-token|x-castapp-token|x-mal-client-id|api-key|api_key|apikey|access_token|refresh_token|"
    r"client_secret|client_id|code_verifier|password|passwd|secret|token|key)"
    r"([\"']?\s*[:=]\s*[\"']?)(?:bearer\s+|basic\s+)?([^\s\"'&,;<>\]})]+)")
_AUTH = re.compile(r"(?i)(authorization[\"']?\s*[:=]\s*[\"']?)(?:(bearer|basic|token)\s+)?([^\s\"',;]+)")
_DPAPI = re.compile(r"(?i)\bdpapi:[A-Za-z0-9+/=]+")
_REMOTE_LINK = re.compile(r"(/r/)([A-Za-z0-9_-]{6,})(?=/|\b)")
_EMAIL = re.compile(r"(?<![\w.+-])[\w.+-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+")
_PROFILE_WIN = re.compile(r"(?i)(?<![\w])[A-Z]:(?:\\{1,2}|/)Users(?:\\{1,2}|/)"
                          r"(?:[^\\/'\"<>|:*?\r\n]+(?=[\\/])|[^\\/\s'\"<>|:*?]+)")  # "Max Mustermann\" or "Erika"
_PROFILE_NIX = re.compile(r"(?<![\w/.])/(?:home|Users)/[^/\s'\"<>]+")
_USB_SHARE = re.compile(r"(?i)External USB drive-?\s?([0-9A-F]{4})-?([0-9A-F]{4})(?![0-9A-F])")
_STORAGE = re.compile(r"(?i)(/storage/|/mnt/media_rw/|/mnt/usb/)([0-9A-F]{4})-([0-9A-F]{4})(?![0-9A-F])")
_SERIAL = re.compile(r"(?i)(serial number is |serial number: |serial[ :=]+)([0-9A-F]{4})-?([0-9A-F]{4})(?![0-9A-F])")
_BARE_DRIVE = re.compile(r"(?<![\w-])([0-9A-Fa-f]{4})-([0-9A-Fa-f]{4})(?![\w-])")
_GUID = re.compile(r"\{?(?<![0-9A-Fa-f])[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}(?![0-9A-Fa-f])\}?")
_SID = re.compile(r"\bS-1-\d+(?:-\d+){1,14}\b")
_UNC = re.compile(
    r"(?<![\w\\])(?P<sep>\\{1,2})(?P=sep)(?:\?(?P=sep)UNC(?P=sep))?"
    r"(?P<host>[^\\/\s'\"<>|:*?,;()\[\]]+)(?P=sep)"
    r"(?P<share><drive \d+>|[^\\/\r\n'\"<>|*?:,;()\[\]]+)(?P<after>(?P=sep)?)")
_SMB = re.compile(r"(?i)\bsmb://([^/\s'\"<>]+)/([^/\s'\"<>]+)")
_PLEX_DIRECT = re.compile(r"(?i)\b(\d{1,3})-(\d{1,3})-(\d{1,3})-(\d{1,3})\.[0-9a-f]{8,}\.plex\.direct\b")
_MAC = re.compile(r"(?<![\w:-])(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}(?![\w:-])")
_IPV4 = re.compile(r"(?<![\w.])(\d{1,3}(?:\.\d{1,3}){3})(?!\w|\.\d)")
_IPV6 = re.compile(r"\[((?:[0-9A-Fa-f]{0,4}:){2,7}[0-9A-Fa-f]{0,4})(%[\w.]+)?\]"
                   r"|(?<![\w:.\[])((?:[0-9A-Fa-f]{0,4}:){2,7}[0-9A-Fa-f]{0,4})(%[\w.]+)?(?![\w:])")
_VERSIONISH = re.compile(r"(?i)(?:[a-z]/|\bv|version\s|python\s|edge\s|chrome\s|mpv\s|ffmpeg\s|build\s)$")
_VIDEO_TAIL = r"\.(?:mp4|mkv|avi|ogv|m4v|webm|mpe?g|wmv|mov|flv|ts|m2ts|3gp|divx|srt|vtt|ass|ssa)\b"
_IA_PATH = re.compile(r"(?i)(archive\.org/(?:download|details|metadata|serve|services/img)/)([^/\s?#\"'<>]+)"
                      r"(/(?:[^?#\"'<>\r\n]*?" + _VIDEO_TAIL + r"|[^\s?#\"'<>]*))?")
_IA_KEY = re.compile(r"\bia:(@?)([^\s/\"'<>]+)(/(?:[^\"'<>\r\n]*?" + _VIDEO_TAIL + r"|[^\s\"'<>]+))?", re.I)
_LONG_HEX = re.compile(r"(?<![0-9A-Za-z])[0-9A-Fa-f]{24,}(?![0-9A-Za-z])")
_TOKENISH = re.compile(r"(?<![\w+=-])[A-Za-z0-9_+=-]{20,}(?![\w+=-])")


def _looks_secret(s: str) -> bool:
    """A long run of letters and digits mixed the way keys and tokens are (not words or file names)."""
    digits = sum(c.isdigit() for c in s)
    letters = sum(c.isalpha() for c in s)
    if digits < 3 or letters < 3:
        return False
    mixed = sum(1 for a, b in zip(s, s[1:]) if (a.isdigit() and b.isalpha()) or (a.isalpha() and b.isdigit()))
    cases = any(c.islower() for c in s) and any(c.isupper() for c in s)
    return mixed >= 4 or (cases and digits >= 4 and mixed >= 3)


class Scrubber:
    """Takes everything personal out of a text. One per report: the same share, drive or server gets the
    same number everywhere in it.

    ``user``/``home``/``computer``: this PC's facts (``None`` = read them from the system; tests pass
    made-up ones). ``secrets``: exact values to hide (keys, tokens). ``names``: ``(text, label)`` pairs
    such as ``("Living room", "<TV name>")``. ``shows``: show folder names and titles (``<show>``).
    ``known``: folders whose shares/drives get the first numbers, in this order.
    """

    def __init__(self, user: Optional[Sequence[str]] = None, home: Optional[Sequence[str]] = None,
                 computer: Optional[Sequence[str]] = None, secrets: Iterable[str] = (),
                 names: Iterable[Tuple[str, str]] = (), shows: Iterable[str] = (), known: Iterable[str] = ()):
        self.users = [u for u in (user if user is not None else _system_users()) if u]
        self.homes = [h for h in (home if home is not None else _system_homes()) if h and len(h) > 3]
        self.computers = [c for c in (computer if computer is not None else _system_computers())
                          if c and len(c) >= 2 and c.lower() not in ("localhost",)]
        self.secrets: set = set()
        self.names: List[Tuple[str, str]] = []
        self.shows: set = set()
        self._drives: Dict[str, int] = {}
        self._shares: Dict[Tuple[str, str], str] = {}
        self._servers: Dict[str, int] = {}
        self._known: List[Tuple[str, str]] = []  # (host, share) of the user's own folders
        self._compiled: Optional[dict] = None
        self._lock = threading.RLock()
        self.add_secrets(secrets)
        self.add_names(names)
        self.add_shows(shows)
        for folder in known:  # the user's folders get the first numbers, their share names exactly
            m = re.match(r"^\\\\(?:\?\\UNC\\)?([^\\/]+)\\([^\\/]+)", str(folder).replace("/", "\\"))
            if m and not _USB_SHARE.match(m.group(2)):
                self._known.append((m.group(1).casefold(), m.group(2).strip()))
            self.scrub(folder)

    # -- what to hide

    def add_secrets(self, values: Iterable[str]) -> None:
        with self._lock:
            new = {str(v or "").strip() for v in values} - self.secrets
            new = {v for v in new if len(v) >= 6}
            if new:
                self.secrets |= new
                self._compiled = None

    def add_names(self, pairs: Iterable[Tuple[str, str]]) -> None:
        with self._lock:
            for text, label in pairs:
                text = str(text or "").strip()
                if len(text) >= 3 and (text, label) not in self.names:
                    self.names.append((text, label))
                    self._compiled = None

    def add_shows(self, names: Iterable[str]) -> None:
        with self._lock:
            new = {str(n).strip() for n in names if n and len(str(n).strip()) >= 4} - self.shows
            if new:
                self.shows |= new
                self._compiled = None

    # -- numbering

    def drive(self, a: str, b: str) -> str:
        ident = (a + b).upper()
        with self._lock:
            n = self._drives.setdefault(ident, len(self._drives) + 1)
        return f"<drive {n}>"

    def _share(self, host: str, share: str) -> str:
        if share.startswith("<drive "):
            return share
        key = (host.casefold(), share.casefold())
        with self._lock:
            if key not in self._shares:
                self._shares[key] = f"<share {sum(1 for v in self._shares.values() if v.startswith('<share')) + 1}>"
            return self._shares[key]

    def _server(self, host: str) -> str:
        with self._lock:
            n = self._servers.setdefault(host.casefold(), len(self._servers) + 1)
        return "<server>" if n == 1 else f"<server {n}>"

    # -- the rules

    def _patterns(self) -> dict:
        with self._lock:
            if self._compiled is None:
                homes = set()
                for h in self.homes:
                    h = h.rstrip("\\/")
                    homes |= {h, h.replace("\\", "\\\\"), h.replace("\\", "/")}
                users = [u for u in self.users if u.lower() not in _COMMON_USERS and len(u) >= 2]
                by_label: Dict[str, List[str]] = {}
                for text, label in self.names:
                    by_label.setdefault(label, []).append(text)
                secret_values = set(self.secrets)
                secret_values |= {urllib.parse.quote(s, safe="") for s in self.secrets}
                self._compiled = {
                    "secrets": _words(secret_values, 6, whole=False) if secret_values else None,
                    "homes": re.compile("(?:" + "|".join(re.escape(h) for h in sorted(homes, key=len, reverse=True)) +
                                        r")(?![\w.-])", re.I) if homes else None,
                    "computers": _words(self.computers),
                    "users": _words(users),
                    "names": [(label, _words(texts, 3)) for label, texts in by_label.items()],
                    "shows": _words(self.shows, 4, case=True),  # as written: a show "Another" isn't the word "another"
                }
            return self._compiled

    def scrub(self, text: str) -> str:
        if not text:
            return text or ""
        p = self._patterns()
        t = str(text)
        # 1. keys and tokens
        if p["secrets"]:
            t = p["secrets"].sub("<hidden>", t)
        t = _DPAPI.sub("<hidden>", t)
        t = _AUTH.sub(lambda m: m.group(1) + (m.group(2) + " " if m.group(2) else "") + "<hidden>", t)
        t = _SECRET_KV.sub(lambda m: m.group(1) + m.group(2) + "<hidden>", t)
        t = _REMOTE_LINK.sub(r"\1<hidden>", t)
        # 2. e-mail addresses (before names: they often hold the user name)
        t = _EMAIL.sub("<e-mail>", t)
        # 3. the user's profile folder
        if p["homes"]:
            t = p["homes"].sub("%USERPROFILE%", t)
        t = _PROFILE_WIN.sub("%USERPROFILE%", t)
        t = _PROFILE_NIX.sub("%USERPROFILE%", t)
        # 4. drives: the Shield's share names and Plex's /storage paths, serial numbers, volume ids
        t = _USB_SHARE.sub(lambda m: self.drive(m.group(1), m.group(2)), t)
        t = _STORAGE.sub(lambda m: m.group(1) + self.drive(m.group(2), m.group(3)), t)
        t = _SERIAL.sub(lambda m: m.group(1) + self.drive(m.group(2), m.group(3)), t)
        t = _GUID.sub("<id>", t)
        t = _SID.sub("<id>", t)
        t = _BARE_DRIVE.sub(lambda m: self.drive(m.group(1), m.group(2))
                            if re.search(r"[A-Fa-f]", m.group(0)) else m.group(0), t)
        # 5. network shares: \\host\share -> \\<server>\<share 1>
        t = _UNC.sub(self._unc, t)
        t = _SMB.sub(lambda m: f"smb://{self._server(m.group(1))}/{self._share(m.group(1), m.group(2))}", t)
        # 6. addresses
        t = _PLEX_DIRECT.sub(self._plex_direct, t)
        t = _MAC.sub("<MAC>", t)
        t = _IPV4.sub(self._ip, t)
        t = _IPV6.sub(self._ip6, t)
        # 7. names: this PC, the user, Plex servers, accounts, TVs, shows
        if p["computers"]:
            t = p["computers"].sub("<PC>", t)
        if p["users"]:
            t = p["users"].sub("<user>", t)
        for label, pat in p["names"]:
            if pat:
                t = pat.sub(label, t)
        t = _IA_PATH.sub(lambda m: m.group(1) + "<item>" + ("/<file>" if m.group(3) and len(m.group(3)) > 1 else ""), t)
        t = _IA_KEY.sub(lambda m: "ia:" + m.group(1) + "<item>" + ("/<file>" if m.group(3) else ""), t)
        if p["shows"]:
            t = p["shows"].sub("<show>", t)
        # 8. anything else that looks like a key
        t = _LONG_HEX.sub("<hidden>", t)
        t = _TOKENISH.sub(lambda m: "<hidden>" if _looks_secret(m.group(0)) else m.group(0), t)
        return t

    __call__ = scrub

    def _unc(self, m: "re.Match") -> str:
        sep, host, share, after = m.group("sep"), m.group("host"), m.group("share"), m.group("after")
        rest = ""
        full = share.rstrip()
        known = [s for h, s in self._known if h == host.casefold() and full.casefold().startswith(s.casefold())
                 and (len(full) == len(s) or not full[len(s)].isalnum())]
        if not after and known:  # one of the user's own shares: its exact name, spaces and all
            s = max(known, key=len)
            rest, share = share[len(s):], share[:len(s)]
        elif not after and not share.startswith("<drive ") and re.search(r"\s", share.strip()):
            # The share is the end of the path: a space after it is probably the sentence going on
            first, _, tail = share.strip().partition(" ")
            rest = share[share.index(first) + len(first):]
            share = first
        else:
            stripped = share.rstrip()
            rest, share = share[len(stripped):], stripped
        return sep * 2 + self._server(host) + sep + self._share(host, share) + rest + after

    def _plex_direct(self, m: "re.Match") -> str:
        kind = address_kind(".".join(m.groups()))
        return (_placeholder(kind) if kind else "<address>") + ".plex.direct"

    def _ip(self, m: "re.Match") -> str:
        ip = m.group(1)
        if _VERSIONISH.search(m.string[max(0, m.start() - 10):m.start()]):
            return ip
        kind = address_kind(ip)
        return m.group(0) if not kind else _placeholder(kind)

    def _ip6(self, m: "re.Match") -> str:
        kind = address_kind(m.group(1) or m.group(3))
        return m.group(0) if not kind else _placeholder(kind)


def _system_users() -> List[str]:
    out = []
    for v in (os.environ.get("USERNAME"), os.environ.get("USER")):
        if v:
            out.append(v)
    try:
        out.append(getpass.getuser())
    except Exception:
        pass
    try:
        out.append(Path.home().name)
    except Exception:
        pass
    return list(dict.fromkeys(out))


def _system_homes() -> List[str]:
    out = []
    for v in (os.environ.get("USERPROFILE"), os.environ.get("HOME")):
        if v:
            out.append(v)
    try:
        out.append(str(Path.home()))
    except Exception:
        pass
    return list(dict.fromkeys(out))


def _system_computers() -> List[str]:
    out = []
    for v in (os.environ.get("COMPUTERNAME"), socket.gethostname(), platform.node()):
        if v:
            out.append(v)
            out.append(v.split(".")[0])
    return list(dict.fromkeys(out))


def scrub(text: str, **kwargs) -> str:
    """``Scrubber(**kwargs).scrub(text)``: with this PC's user and computer names unless given."""
    return Scrubber(**kwargs).scrub(text)


# -- running the checks ----------------------------------------------------------------------------

class Check:
    def __init__(self, id: str, group: str, title: str, fn: Callable[["Context"], dict], timeout: float = 20.0,
                 after: Sequence[str] = (), timeout_text: str = "", timeout_fix: str = ""):
        self.id, self.group, self.title, self.fn = id, group, title, fn
        self.timeout = timeout
        self.after = tuple(after)
        self.timeout_text = timeout_text
        self.timeout_fix = timeout_fix


class Context:
    """What the checks share: the App, the window's own facts, results for later checks, names found."""

    def __init__(self, app=None, window: Optional[dict] = None):
        self.app = app
        self.window = window or {}
        self.shared: Dict[str, object] = {}
        self.names: List[Tuple[str, str]] = []  # found while checking (Plex server, TVs): the scrubber hides them
        self.secrets: List[str] = []
        self.ssdp_targets = None  # tests: search these (host, port) by unicast instead of the whole network
        self.discover_timeout = 3.0
        self.lock = threading.Lock()

    def hide(self, text: str, label: str) -> None:
        with self.lock:
            self.names.append((text, label))

    def hide_secret(self, text: str) -> None:
        with self.lock:
            self.secrets.append(text)


def _normal(res) -> dict:
    if not isinstance(res, dict) or res.get("status") not in STATES:
        return problem("The check didn't give an answer AniBox understands.")
    return {"status": res["status"], "line": str(res.get("line") or ""),
            "details": [str(d) for d in res.get("details") or [] if d], "fix": str(res.get("fix") or "")}


def run_checks(checks: Sequence[Check], ctx: Context, on_change: Optional[Callable[[List[dict]], None]] = None,
               parallel: int = PARALLEL, poll: float = 0.05) -> List[dict]:
    """Run the checks (up to ``parallel`` at once, each after the ones in its ``after``), each with its own
    time limit. A check that doesn't finish in time is marked ✗ and left behind (its thread is a daemon
    and can't hold the others up). Returns one row per check, in the given order."""
    rows = {c.id: {"id": c.id, "group": c.group, "title": c.title, "status": "waiting", "line": "", "details": [],
                   "fix": "", "seconds": None} for c in checks}
    ids = {c.id for c in checks}
    pending = list(checks)
    running: Dict[str, tuple] = {}
    finished: set = set()

    def changed() -> None:
        if on_change:
            try:
                on_change([dict(rows[c.id]) for c in checks])
            except Exception:
                log.exception("Setup check: the progress update failed")

    def one(c: Check, box: dict) -> None:
        started = time.monotonic()
        try:
            res = _normal(c.fn(ctx))
        except Exception as exc:
            log.warning("Setup check %s failed", c.id, exc_info=True)
            res = problem(f"The check itself failed: {exc.__class__.__name__}: {exc}")
        res["seconds"] = round(time.monotonic() - started, 2)
        box["result"] = res

    changed()
    while pending or running:
        moved = False
        for c in list(pending):
            if len(running) >= parallel:
                break
            if any(a in ids and a not in finished for a in c.after):
                continue
            pending.remove(c)
            box: dict = {}
            t = threading.Thread(target=one, args=(c, box), daemon=True, name=f"anibox-check-{c.id}")
            rows[c.id]["status"] = "running"
            running[c.id] = (c, box, time.monotonic())
            t.start()
            moved = True
        for cid, (c, box, started) in list(running.items()):
            if "result" in box:
                rows[cid].update(box["result"])
            elif time.monotonic() - started > c.timeout:
                rows[cid].update(problem(c.timeout_text or f"Didn't finish within {c.timeout:.0f} s.",
                                         fix=c.timeout_fix), seconds=round(c.timeout, 1))
                log.info("Setup check %s didn't finish within %.0f s", cid, c.timeout)
            else:
                continue
            del running[cid]
            finished.add(cid)
            moved = True
        if moved:
            changed()
        elif pending and not running:  # waiting for checks that don't exist (can't happen): run them anyway
            for c in pending:
                c.after = ()
        else:
            time.sleep(poll)
    return [dict(rows[c.id]) for c in checks]


# -- small helpers -----------------------------------------------------------------------------------

def first_line(cmd: List[str], timeout: float = 10.0) -> str:
    """The first line a program prints (``mpv --version``), or "" if it doesn't start."""
    try:
        r = subprocess.run(cmd, stdin=subprocess.DEVNULL, capture_output=True, timeout=timeout, creationflags=NO_WINDOW)
    except (OSError, subprocess.TimeoutExpired, ValueError):
        return ""
    text = (r.stdout or r.stderr or b"").decode("utf-8", "replace").strip()
    return text.splitlines()[0].strip() if text else ""


def http_probe(url: str, method: str = "GET", headers: Optional[dict] = None, body: Optional[bytes] = None,
               timeout: float = 10.0, limit: int = 200_000) -> dict:
    """One request: ``{"status", "seconds", "body", "error"}`` (status 0 = no answer). Redirects are followed;
    the error text never holds the address (it may carry a key)."""
    h = {"User-Agent": USER_AGENT, "Accept": "application/json", **(headers or {})}
    req = urllib.request.Request(url, data=body, method=method, headers=h)
    started = time.monotonic()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = r.read(limit)
            return {"status": r.status, "seconds": time.monotonic() - started, "body": data, "error": ""}
    except urllib.error.HTTPError as exc:
        try:
            data = exc.read(limit)
        except Exception:
            data = b""
        return {"status": exc.code, "seconds": time.monotonic() - started, "body": data, "error": f"HTTP {exc.code}"}
    except (urllib.error.URLError, OSError, http.client.HTTPException, ValueError) as exc:
        reason = getattr(exc, "reason", None) or exc
        return {"status": 0, "seconds": time.monotonic() - started, "body": b"",
                "error": f"{reason.__class__.__name__ if isinstance(reason, Exception) else ''} {reason}".strip()}


def windows_text() -> str:
    if not IS_WINDOWS:
        return f"{platform.system()} {platform.release()} ({platform.machine()}): not Windows"
    try:
        v = sys.getwindowsversion()
        name = "Windows 11" if v.major == 10 and v.build >= 22000 else f"Windows {platform.release()}"
        edition = platform.win32_edition() if hasattr(platform, "win32_edition") else ""
        return f"{name}{' ' + edition if edition else ''} (build {v.build}), {platform.machine()}"
    except Exception:
        return platform.platform()


def program_kind(program_dir: Path) -> str:
    if (program_dir / ".git").exists():
        return "a developer copy (a git folder)"
    if (program_dir / "python").is_dir():
        return "the Windows package with its own Python"
    if (program_dir / "AniBox.bat").is_file():
        return "an AniBox folder that uses a Python installed on this PC"
    return "not in its usual program folder"


def bundled_python(program_dir: Path) -> bool:
    try:
        return (program_dir / "python").resolve() in Path(sys.executable).resolve().parents
    except OSError:
        return False


def folder_bytes(folder: Path) -> Tuple[int, int]:
    total = count = 0
    try:
        for p in folder.iterdir():
            if p.is_file():
                total += p.stat().st_size
                count += 1
    except OSError:
        pass
    return total, count


def quick_check(db: Path, timeout: float = 5.0) -> Tuple[bool, str]:
    """SQLite's ``PRAGMA quick_check`` on a read-only connection of its own."""
    try:
        con = sqlite3.connect(Path(db).resolve().as_uri() + "?mode=ro", uri=True, timeout=timeout)
    except sqlite3.Error as exc:
        return False, f"couldn't open it ({exc})"
    try:
        rows = [r[0] for r in con.execute("PRAGMA quick_check").fetchall()]
    except sqlite3.Error as exc:
        return False, str(exc)
    finally:
        con.close()
    if rows == ["ok"]:
        return True, "ok"
    return False, "; ".join(str(r) for r in rows[:3])


def drive_type(path: str) -> str:
    """"network share", "mapped network drive", "local drive", "removable drive" ... (Windows), or
    "network share (mounted)" / "local folder" elsewhere."""
    p = path.replace("/", "\\") if IS_WINDOWS or path.startswith("\\\\") else path
    if p[:8].upper() == "\\\\?\\UNC\\" or (p.startswith("\\\\") and not p.startswith(("\\\\?\\", "\\\\.\\"))):
        return "network share (a UNC address)"
    if IS_WINDOWS:
        drive = ntpath.splitdrive(p.replace("\\\\?\\", ""))[0]
        try:
            import ctypes
            kind = ctypes.windll.kernel32.GetDriveTypeW(drive + "\\")
        except Exception:
            kind = 0
        return {2: "removable drive (USB stick or disk)", 3: "local drive", 4: "mapped network drive",
                5: "CD/DVD drive", 6: "RAM disk"}.get(kind, "drive of an unknown kind")
    fs = _mount_type(path)
    if fs in ("cifs", "smb3", "smbfs", "nfs", "nfs4", "fuse.sshfs", "9p"):
        return f"network share (mounted, {fs})"
    return "local folder"


def _mount_type(path: str) -> str:
    try:
        lines = Path("/proc/mounts").read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return ""
    best, kind = "", ""
    real = os.path.realpath(path)
    for line in lines:
        parts = line.split()
        if len(parts) >= 3:
            mnt = parts[1].replace("\\040", " ")
            if (real == mnt or real.startswith(mnt.rstrip("/") + "/")) and len(mnt) > len(best):
                best, kind = mnt, parts[2]
    return kind


def list_top(folder: str) -> Tuple[float, int, int, int]:
    """(seconds, subfolders, video files, other files) of one folder's top level. Only lists it."""
    from anibox_check.folders import VIDEO_EXTENSIONS
    started = time.monotonic()
    dirs = videos = other = 0
    with os.scandir(folder) as it:
        for e in it:
            try:
                if e.is_dir(follow_symlinks=False):
                    dirs += 1
                elif os.path.splitext(e.name)[1].lower() in VIDEO_EXTENSIONS:
                    videos += 1
                else:
                    other += 1
            except OSError:
                other += 1
    return time.monotonic() - started, dirs, videos, other


def same_24(a: str, b: str) -> Optional[bool]:
    try:
        x, y = ipaddress.ip_address(a), ipaddress.ip_address(b)
    except ValueError:
        return None
    if x.version != 4 or y.version != 4:
        return None
    return ipaddress.ip_network(f"{a}/24", strict=False) == ipaddress.ip_network(f"{b}/24", strict=False)


def maker(dev: dict) -> str:
    """"CastApp TV", "LG", "Samsung" ...: the first word of the manufacturer."""
    if dev.get("castapp"):
        return "CastApp TV"
    m = str(dev.get("manufacturer") or "").strip()
    word = re.split(r"[\s,]+", m)[0] if m else ""
    return word or "unknown maker"


# -- the log -----------------------------------------------------------------------------------------

def log_records(logs: Path, names: Sequence[str] = ("anibox.log",), per_file: int = 2_000_000) -> List[dict]:
    """AniBox's log records, oldest first: ``{"time", "level", "name", "message", "extra"}`` (``extra``: the
    lines after it, e.g. a traceback). Reads the rotated copies (``.3`` … ``.1``) too."""
    files: List[Path] = []
    for name in names:
        for n in (3, 2, 1):
            files.append(logs / f"{name}.{n}")
        files.append(logs / name)
    out: List[dict] = []
    for f in files:
        try:
            with open(f, "rb") as fh:
                size = fh.seek(0, os.SEEK_END)
                fh.seek(max(0, size - per_file))
                text = fh.read().decode("utf-8", "replace")
        except OSError:
            continue
        for line in text.splitlines():
            m = LOG_RE.match(line)
            if m:
                out.append({"time": m.group(1), "level": m.group(2), "name": m.group(3), "message": m.group(4),
                            "extra": []})
            elif out and line.strip():
                out[-1]["extra"].append(line.rstrip())
    return out


def problems_from_log(records: List[dict], limit: int = LOG_LINES) -> List[str]:
    bad = [r for r in records if r["level"] in ("WARNING", "ERROR", "CRITICAL")][-limit:]
    lines = []
    for r in bad:
        text = f"{r['time']} {r['level']} {r['name']}: {r['message']}"[:400]
        exc = next((x.strip() for x in reversed(r["extra"]) if x.strip() and not x.startswith(" ")), "")
        if exc and exc != r["message"]:
            text += f"  → {exc[:300]}"
        lines.append(text)
    return lines


def last_record(records: List[dict], needle: str) -> Optional[dict]:
    for r in reversed(records):
        if needle in r["message"]:
            return r
    return None


# -- mpv -----------------------------------------------------------------------------------------------

def mpv_start_test(exe: str, limit: float = 15.0) -> dict:
    """Start mpv like AniBox does (idle, with its control connection), ask it something, play one second
    of mpv's own test picture without picture or sound, and quit. Nothing is shown on the screen."""
    from .player import MpvGone, _Ipc
    tag = f"anibox-check-{os.getpid()}-{secrets.token_hex(3)}"
    address = rf"\\.\pipe\{tag}" if IS_WINDOWS else os.path.join(tempfile.gettempdir(), tag + ".sock")
    args = [exe, "--idle=yes", "--force-window=no", "--vo=null", "--ao=null", "--no-terminal", "--keep-open=no",
            "--load-scripts=no", "--osc=no", "--ytdl=no", "--input-default-bindings=no", f"--input-ipc-server={address}"]
    out = {"via": "named pipe" if IS_WINDOWS else "socket", "ready": None, "version": "", "played": False,
           "play_error": "", "error": "", "exit": None}
    started = time.monotonic()
    try:
        proc = subprocess.Popen(args, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                creationflags=NO_WINDOW)
    except OSError as exc:
        out["error"] = f"couldn't start mpv ({exc})"
        return out
    killer = threading.Timer(limit, proc.kill)  # a pipe read can't time out on Windows: this ends it
    killer.daemon = True
    killer.start()
    ipc = None
    try:
        while time.monotonic() - started < min(10.0, limit - 1):
            if proc.poll() is not None:
                out["error"] = f"mpv closed right after starting (exit code {proc.returncode})"
                return out
            try:
                ipc = _Ipc(address)
                break
            except OSError:
                time.sleep(0.1)
        if ipc is None:
            out["error"] = "mpv didn't open its control connection within 10 s"
            return out
        out["ready"] = time.monotonic() - started
        out["version"] = str(ipc.request(["get_property", "mpv-version"]).get("data") or "")
        r = ipc.request(["loadfile", "av://lavfi:testsrc=duration=1:size=64x48:rate=10"])
        if r.get("error") not in (None, "success"):
            out["play_error"] = str(r.get("error"))
        deadline = time.monotonic() + 8
        loaded = False
        while not out["play_error"] and time.monotonic() < deadline:
            ipc.request(["get_property", "idle-active"])
            for ev in ipc.events:
                if ev.get("event") == "file-loaded":
                    loaded = True
                elif ev.get("event") == "end-file":
                    reason = ev.get("reason")
                    if reason == "eof" and loaded:
                        out["played"] = True
                    elif reason not in ("eof", "stop", "quit", "redirect"):
                        out["play_error"] = str(ev.get("file_error") or reason or "error")
                    elif not loaded:
                        out["play_error"] = str(ev.get("file_error") or "it ended before it started")
            ipc.events.clear()
            if out["played"]:
                break
            time.sleep(0.1)
        else:
            if not out["played"] and not out["play_error"]:
                out["play_error"] = "it didn't finish within 8 s"
        try:
            ipc.request(["quit"])
        except MpvGone:
            pass
        try:
            out["exit"] = proc.wait(5)
        except subprocess.TimeoutExpired:
            proc.kill()
    except MpvGone as exc:
        out["error"] = out["error"] or f"mpv stopped answering ({exc})"
    finally:
        killer.cancel()
        if ipc is not None:
            ipc.close()
        if proc.poll() is None:
            proc.kill()
        if not IS_WINDOWS:
            try:
                os.unlink(address)
            except OSError:
                pass
    return out


# -- sparse files -------------------------------------------------------------------------------------

def sparse_test(folder: Path, size: int = SPARSE_TEST_SIZE) -> dict:
    """Make a test file in ``folder`` (AniBox's own cache folder), mark it sparse (Windows), write its first
    and last byte, measure what it takes on the disk, delete it. ``{"writable", "sparse", "allocated", "error"}``."""
    from . import iacache
    path = Path(folder) / f".anibox-setup-check-{secrets.token_hex(4)}.tmp"
    out = {"writable": False, "sparse": None, "allocated": None, "error": ""}
    try:
        with open(path, "xb") as fh:
            out["writable"] = True
            iacache._set_sparse(fh)
            fh.write(b"\0")
            fh.seek(size - 1)
            fh.write(b"\0")
            fh.flush()
            os.fsync(fh.fileno())
        out["allocated"] = iacache.allocated(path)
        out["sparse"] = out["allocated"] < size // 4
    except OSError as exc:
        out["error"] = f"{exc.__class__.__name__}: {exc.strerror or exc}"
    finally:
        try:
            path.unlink()
        except FileNotFoundError:
            pass
        except OSError as exc:
            out["error"] = out["error"] or f"the test file couldn't be deleted ({exc})"
    return out


# -- the checks ------------------------------------------------------------------------------------------

def check_anibox(ctx: Context) -> dict:
    from .paths import PROGRAM_DIR
    kind = program_kind(PROGRAM_DIR)
    bundled = bundled_python(PROGRAM_DIR)
    py = (f"Python {platform.python_version()} ({platform.architecture()[0].replace('bit', '-bit')}), "
          + ("the one in AniBox's python folder" if bundled else f"installed on this PC: {sys.executable}"))
    details = [windows_text(), py]
    if not IS_WINDOWS:
        return note(f"AniBox {__version__}, {kind}.", *details,
                    "Not on Windows: the named pipe, playing inside the window, drive types and sparse files can't be checked here.")
    if sys.version_info < (3, 9):
        return problem(f"AniBox {__version__}, {kind}.", *details, fix="AniBox needs Python 3.9 or newer.")
    return ok(f"AniBox {__version__}, {kind}.", *details)


def check_data(ctx: Context) -> dict:
    from .paths import home_dir, is_portable
    app = ctx.app
    home = app.data_dir.parent
    portable = is_portable() and home == home_dir()
    details, state, fix = [], "ok", ""
    try:
        usage = shutil.disk_usage(str(home))
        free = usage.free
    except OSError:
        free = None
    where = f"{'Portable: the data folder next to AniBox.bat' if portable else 'In the usual place'} ({home})"
    if free is not None:
        details.append(f"{size_text(free)} free on that drive")
        if free < 500 << 20:
            state, fix = "problem", "The drive with AniBox's data is almost full: free some space there."
        elif free < 5 << 30:
            state = "note"
    good, text = quick_check(app.store.path)
    db_size = app.store.path.stat().st_size if app.store.path.is_file() else 0
    details.append(f"Database: {'fine' if good else 'damaged: ' + text} (quick check, {size_text(db_size)})")
    if not good:
        state = "problem"
        fix = ("Close AniBox and restore a daily copy: Settings → Your data → Show them (the backups), "
               "or send this report.")
    logs, count = folder_bytes(app.data_dir / "logs")
    details.append(f"Logs: {size_text(logs)} in {count} file{'s' if count != 1 else ''}")
    if logs > 50 << 20:
        state = worst(state, "note")
        details.append("The logs are big: Settings → Player → Detailed player log can be switched off when nothing needs hunting.")
    backups = sorted(app.backup_dir.glob("anibox-*.db")) if app.backup_dir.is_dir() else []
    details.append(f"Daily copies of the watch progress: {len(backups)}" + (f", newest {backups[-1].stem[7:]}" if backups else ""))
    return result(state, f"{where}.", *details, fix=fix)


def check_update(ctx: Context) -> dict:
    from .selfupdate import downloads_dir, find_update
    app = ctx.app
    why = app.selfupdate.why_not()
    dl = downloads_dir()
    details = [f"Downloads folder: {dl}" + ("" if dl.is_dir() else " (not there)")]
    try:
        found = find_update(dl)
        if found["found"]:
            details.append(f"Waiting in Downloads: {found['found']['name']} (Update now installs it)")
    except Exception:
        pass
    info = app.updates.info()
    if info.get("checked"):
        details.append(f"Last look for a new version: newest {info.get('latest') or '?'}" +
                       (f" ({info['error']})" if info.get("error") else ""))
    upd = last_record(log_records(app.data_dir / "logs"), "Last update:")
    if upd:
        details.append(f"Last update ({upd['time'][:10]}): {upd['message'].split('Last update:', 1)[1].strip()}")
    if not why:
        return ok("Update now can replace this AniBox folder.", *details)
    if "developer copy" in why:
        return note(why, *details)
    return problem(why, *details, fix="Put the AniBox folder somewhere you may change (e.g. in your user folder), "
                                     "or start AniBox from the folder the zip was unpacked into.")


def check_mpv(ctx: Context) -> dict:
    app = ctx.app
    exe = app.player.mpv_path()
    if not exe:
        return problem("mpv isn't there yet, so nothing can play.", fix="Settings → Player → Download mpv (about 34 MB).")
    ctx.shared["mpv"] = exe
    own = str(app.data_dir.parent / "mpv")
    setting = app.store.settings().get("mpv_path") or ""
    where = ("AniBox's own copy" if os.path.normcase(exe).startswith(os.path.normcase(own))
             else "the program set in Settings" if setting and os.path.normcase(setting) == os.path.normcase(exe)
             else f"found on this PC ({exe})")
    version = first_line([exe, "--version"], 15)
    if not version:
        return problem(f"mpv is there ({where}) but doesn't start.", fix="Settings → Player → Download mpv again.")
    return ok(f"{version.split(' Copyright')[0]}, {where}.")


def check_mpv_start(ctx: Context) -> dict:
    exe = ctx.shared.get("mpv")
    if not exe:
        return skip("No mpv to start.")
    r = mpv_start_test(str(exe))
    if r["error"]:
        return problem(f"mpv didn't work: {r['error']}.",
                       fix="Settings → Player → Download mpv again; if it stays like this, switch on the detailed player log, "
                           "play an episode and send this report.")
    line = f"mpv started in {secs_text(r['ready'])} and answered over its {r['via']}"
    details = [f"It says it is {r['version']}"] if r["version"] else []
    if r["played"]:
        return ok(line + ", then played 1 s of its test picture (no window, no sound).", *details)
    return note(line + f", but its test picture didn't play ({r['play_error']}).", *details,
                "Normal videos may still play; this test needs mpv's built-in test source.")


def check_embed(ctx: Context) -> dict:
    app = ctx.app
    on = bool(app.store.settings().get("embed_player", True))
    e = app.embed
    records = log_records(app.data_dir / "logs")
    inside = last_record(records, "Player goes inside the AniBox window")
    outside = last_record(records, "Player stays in its own window")
    failed = last_record(records, "Couldn't put the player into the AniBox window")
    area = last_record(records, "Video area:")
    details = []
    if area:
        details.append(f"Last placement ({area['time']}): {area['message'].split('Video area:', 1)[1].strip()}")
    if e.reason and e.available:
        details.append(f"Right now: {e.reason}")
    if not on:
        return note("Off (Settings → Player): videos open in a window of their own.", *details)
    if not e.available:
        return skip("Playing inside the window works on Windows only.", *details)
    if e.attached:
        return ok("On; the player's place in this window is ready" + (" and showing." if e.visible else "."), *details)
    last = max((r for r in (inside, outside, failed) if r), key=lambda r: r["time"], default=None)
    if last is None:
        return note("On, not tried yet: AniBox puts the player into the window when a video starts.", *details,
                    fix="Play any episode for a few seconds, close it, then run the check again.")
    if last is inside:
        return ok(f"On; last time ({inside['time']}) the video played inside the AniBox window.", *details)
    return problem(f"On, but last time ({last['time']}) AniBox didn't find its window, so the video opened in its own window.",
                   *details, fix="Start AniBox with AniBox.bat or its desktop shortcut, so it opens in its own app window "
                                 "(not a browser tab), then play an episode and run the check again.")


def check_ffmpeg(ctx: Context) -> dict:
    from .ffmpegsetup import find_tools
    app = ctx.app
    tools = find_tools(app.data_dir, app.store.settings().get("ffmpeg_path") or "")
    details, missing = [], []
    for name in ("ffmpeg", "ffprobe"):
        path = tools.get(name)
        if not path:
            missing.append(name)
            continue
        version = first_line([path, "-hide_banner", "-version"], 15)
        details.append(f"{name}: {version.split(' Copyright')[0] if version else 'there, but it does not start'}")
        if not version:
            missing.append(name)
    if not missing:
        return ok("Both are there.", *details)
    return note(f"{' and '.join(missing)} {'is' if len(missing) == 1 else 'are'} missing or don't start.", *details,
                fix="Only needed for TV-friendly subtitles and the exact TV check: Settings → Player → Download ffmpeg.")


def browser_of(w: dict) -> Tuple[str, str]:
    for brand in w.get("brands") or []:
        for name, label in (("Microsoft Edge ", "Edge"), ("Google Chrome ", "Chrome")):
            if str(brand).startswith(name):
                return label, str(brand)[len(name):]
    ua = str(w.get("ua") or "")
    for pat, label in ((r"Edg/([\d.]+)", "Edge"), (r"OPR/([\d.]+)", "Opera"), (r"Firefox/([\d.]+)", "Firefox"),
                       (r"Chrome/([\d.]+)", "Chrome"), (r"Version/([\d.]+).*Safari", "Safari")):
        m = re.search(pat, ua)
        if m:
            return label, m.group(1)
    return "an unknown browser", ""


def check_window(ctx: Context) -> dict:
    w = ctx.window
    if not w:
        return skip("The window didn't send its details.")
    name, version = browser_of(w)
    app_window = bool(w.get("standalone")) or w.get("locationbar") is False
    try:
        dpr = float(w.get("dpr") or 1)
    except (TypeError, ValueError):
        dpr = 1.0
    details = [f"Window {w.get('ow', '?')}×{w.get('oh', '?')}, page {w.get('iw', '?')}×{w.get('ih', '?')}, "
               f"scale {round(dpr * 100)} %, screen {w.get('sw', '?')}×{w.get('sh', '?')}"]
    pv = str(w.get("platformVersion") or "")
    if pv and pv.split(".")[0].isdigit():
        details.append("The browser says: " + ("Windows 11" if int(pv.split(".")[0]) >= 13 else "Windows 10 or older"))
    line = f"{name} {version}".strip() + (", as AniBox's own app window." if app_window else ", in a normal browser tab or window.")
    if name not in ("Edge", "Chrome"):
        return note(line, *details, fix="AniBox's window works best in Microsoft Edge (it's part of Windows).")
    if not app_window:
        return note(line, *details, fix="Playing inside the window needs AniBox's own window: start AniBox with AniBox.bat "
                                         "or the desktop shortcut instead of opening the address in a browser tab.")
    return ok(line, *details)


def _folder_shows(shows: List[dict], folder: str) -> List[dict]:
    base = os.path.normcase(os.path.normpath(folder)).rstrip("\\/")
    out = []
    for sh in shows:
        eps = sh.get("episodes") or []
        if eps:
            p = os.path.normcase(os.path.normpath(eps[0]["path"]))
            if p.startswith(base + os.sep) or p.startswith(base + "\\") or p.startswith(base + "/"):
                out.append(sh)
    return out


_READ_RE = re.compile(r"^Read (?P<folder>.+?): (?P<files>\d+) video files in (?P<secs>[\d.]+) s \((?P<listed>\d+) folders "
                      r"listed, (?P<reused>\d+) unchanged ones reused(?:, (?P<bad>\d+) couldn't be read)?\)$")


def check_folder(folder: str) -> Callable[[Context], dict]:
    def run(ctx: Context) -> dict:
        from .library import listing_times_trusted
        app = ctx.app
        details = [f"Kind: {drive_type(folder)}",
                   "Quick rescans reuse unchanged folders here." if listing_times_trusted(folder) else
                   "Every folder is listed again on each scan here (a local NTFS drive's folder times can't be "
                   "trusted, and listing is quick there)."]
        shows = _folder_shows(app.library.shows(all_libraries=True), folder)
        if shows:
            files = sum(len(s["episodes"]) for s in shows)
            matched = sum(1 for s in shows if s.get("mal_id"))
            libs = len({s["library"] for s in shows})
            details.append(f"Last scan: {libs} librar{'ies' if libs != 1 else 'y'}, {len(shows)} show folders, "
                           f"{files} files, {matched} matched to MyAnimeList")
        last = next((m for r in reversed(log_records(app.data_dir / "logs")) if r["message"].startswith("Read ")
                     for m in [_READ_RE.match(r["message"])] if m and m.group("folder") == folder), None)
        if last:
            bad = f", {last.group('bad')} couldn't be read" if last.group("bad") else ""
            details.append(f"Its last scan took {last.group('secs')} s ({last.group('listed')} folders listed, "
                           f"{last.group('reused')} reused{bad})")
        if not os.path.isdir(folder):
            return problem("Not reachable (or not there).", *details,
                           fix="Open the folder in File Explorer once (that also wakes a sleeping Shield), then Run again. "
                               "If it moved, change it in Settings → Folders.")
        try:
            seconds, dirs, videos, other = list_top(folder)
        except OSError as exc:
            return problem(f"Reachable, but it can't be listed ({exc.strerror or exc}).", *details,
                           fix="Check that this Windows user may read the share (open it in File Explorer).")
        details.insert(1, f"Top level: {dirs} folder{'s' if dirs != 1 else ''}, {videos} video{'s' if videos != 1 else ''}, "
                          f"{other} other file{'s' if other != 1 else ''}; listed in {secs_text(seconds)}")
        state = "note" if seconds > 3 or (last and last.group("bad")) else "ok"
        line = f"Reachable; the top level was listed in {secs_text(seconds)}."
        if seconds > 3:
            line = f"Reachable, but slow: the top level took {secs_text(seconds)} to list."
        if not dirs and not videos:
            state, line = "note", "Reachable, but empty."
        return result(state, line, *details)
    return run


def check_scan(ctx: Context) -> dict:
    lib = ctx.app.library
    st = lib.status or {}
    shows = lib.shows(all_libraries=True)
    records = log_records(ctx.app.data_dir / "logs")
    done = last_record(records, "Scan done in ")
    started = last_record(records, "Scan started:")
    details = []
    if shows:
        details.append(f"{len(lib.libraries())} libraries, {len(shows)} show folders, "
                       f"{sum(len(s['episodes']) for s in shows)} files, {sum(1 for s in shows if s.get('mal_id'))} matched")
    if done:
        details.append(f"{done['time']}: {done['message']}" + (" (a full rescan)" if started and "full rescan" in started["message"]
                                                                and started["time"] <= done["time"] else ""))
    if st.get("state") == "running":
        return note("A scan is running right now.", *details)
    if st.get("state") == "error":
        return problem(f"The last scan failed: {st.get('message')}", *details,
                       fix="Check the folders above, then Settings → Scan now.")
    if not lib.scanned_at:
        return note("Not scanned yet.", *details, fix="Settings → Folders → Scan now.")
    age = time.time() - lib.scanned_at
    when = time.strftime("%Y-%m-%d %H:%M", time.localtime(lib.scanned_at))
    return ok(f"Finished {when} ({'today' if age < 86400 else f'{int(age // 86400)} days ago'}).", *details)


# -- Plex (GET only) ---

def _plex_creds():
    from . import plexhistory
    return plexhistory.saved_credentials()


def plex_route(url: str) -> str:
    u = urllib.parse.urlsplit(url)
    host, port = u.hostname or "", u.port
    m = _PLEX_DIRECT.match(host)
    ip = ".".join(m.groups()) if m else host
    kind = address_kind(ip)
    secure = " (https)" if u.scheme == "https" else ""
    if kind is None:
        return f"by name{secure}"
    if kind == "":
        return "on this PC"
    if kind == "home network":
        return f"local, in the home network{secure}"
    if kind == "Tailscale":
        return f"over Tailscale{secure}"
    return "through Plex's relay (slow)" if port == 8443 else f"remote, over the internet{secure}"


def check_plex_server(ctx: Context) -> dict:
    from anibox_check import cli as check_cli
    from anibox_check.plex import PlexAuthError, PlexError
    from . import plexhistory
    creds = _plex_creds()
    if not creds:
        ctx.shared["plex_why"] = "Not signed in to Plex."
        return skip("Not signed in to Plex (Settings → Your Plex library), so there's nothing to check.")
    server, token, client = creds
    ctx.hide_secret(token)
    ctx.hide_secret(client)
    info = (check_cli.load_settings().get(plexhistory.SERVER_INFO_KEY) or {})
    if info.get("name"):
        ctx.hide(str(info["name"]), "<Plex server>")
    reader = plexhistory._Reader(server, token, client, timeout=10, attempts=2)
    started = time.monotonic()
    try:
        ident = reader.identity()
    except PlexAuthError:
        return problem("Plex didn't accept the saved sign-in.", fix="Settings → Your Plex library → Sign in again.")
    except (PlexError, OSError, ValueError) as exc:
        return problem(f"Plex doesn't answer ({plex_route(server)}).", str(exc),
                       fix="Is the Shield awake? Open Plex on the TV once, then Run again. "
                           "If the Shield's address changed, sign in to Plex again.")
    seconds = time.monotonic() - started
    machine = str(ident.get("machineIdentifier") or "")
    if machine:
        ctx.hide(machine, "<id>")
    version = str(ident.get("version") or "?")
    ctx.shared["plex"] = reader
    details = [f"Plex Media Server {version}"]
    try:
        newer = tuple(int(x) for x in version.split("-")[0].split(".")[:2]) >= (1, 43)
        details.append("New enough for custom metadata providers (1.43+)" if newer else
                       "Older than 1.43: no custom metadata providers yet")
    except ValueError:
        pass
    return ok(f"Plex answered in {secs_text(seconds)}, {plex_route(server)}.", *details)


def check_plex_libraries(ctx: Context) -> dict:
    from .plexdetails import is_legacy_agent
    reader = ctx.shared.get("plex")
    if reader is None:
        return skip(str(ctx.shared.get("plex_why") or "Plex didn't answer above."))
    sections = reader.sections()
    tv = [s for s in sections if s.type == "show"]
    movies = [s for s in sections if s.type == "movie"]
    legacy = [s for s in sections if is_legacy_agent(s.agent)]
    details = [f"Old agent: {', '.join(s.title for s in legacy)}" if legacy else "No library uses an old agent"]
    agents = Counter(s.agent or "(none)" for s in sections)
    details.append("Agents: " + ", ".join(f"{a} ×{n}" for a, n in agents.most_common()))
    line = f"{len(sections)} libraries: {len(tv)} TV, {len(movies)} movie."
    if legacy:
        return note(line + f" {len(legacy)} use{'s' if len(legacy) == 1 else ''} an old agent that stopped working on the "
                           "Shield in 2024 (new files aren't added there).", *details)
    return ok(line, *details)


def check_plex_agents(ctx: Context) -> dict:
    if ctx.shared.get("plex") is None:
        return skip(str(ctx.shared.get("plex_why") or "Plex didn't answer above."))
    found = ctx.app._plex_agents()
    na, npr = len(found["agents"]), len(found["providers"])
    details = [f"{na} agent{'s' if na != 1 else ''}, {npr} metadata provider{'s' if npr != 1 else ''}"]
    details += [f"Couldn't read {e.split(':', 1)[0]}" for e in found.get("errors") or []]
    line = ("The “Plex NFO” agent is there" if found["nfo"] else "No “Plex NFO” agent found") + "; " + \
           ("custom metadata providers are there." if found["custom"] else "no custom metadata providers.")
    if found["nfo"]:
        return ok(line, *details)
    return note(line, *details, fix="Look under Plex Web → Settings → Metadata Agents; the NFO library plan needs "
                                    "the “Plex NFO Series” agent.")


# -- TVs ---

def _tv_label(ctx: Context, dev: dict) -> str:
    """"CastApp TV 1", "LG TV 2": the TV's own name is hidden in the report."""
    with ctx.lock:
        labels = ctx.shared.setdefault("tv_labels", {})
        if dev["id"] not in labels:
            labels[dev["id"]] = f"{maker(dev) if dev.get('castapp') else maker(dev) + ' TV'} {len(labels) + 1}"
        name = str(dev.get("name") or "").strip()
        plain = {"castapp tv", "tv", str(dev.get("manufacturer") or "").casefold(), str(dev.get("model") or "").casefold()}
        if len(name) >= 3 and name.casefold() not in plain:
            ctx.names.append((name, "<TV name>"))
        return labels[dev["id"]]


def _tv_host(dev: dict) -> str:
    return urllib.parse.urlsplit(str(dev.get("location") or dev.get("avtransport") or "")).hostname or ""


def _same_net_text(dev: dict) -> str:
    from . import tv
    host = _tv_host(dev)
    same = same_24(tv.lan_ip_for(host), host) if host else None
    return {True: "same network as this PC: yes", False: "same network as this PC: no",
            None: "same network as this PC: can't tell"}[same]


def check_tv_search(ctx: Context) -> dict:
    from . import tv
    found = sorted(tv.discover(ctx.discover_timeout, ctx.ssdp_targets),
                   key=lambda d: (not d.get("castapp"), str(d.get("name") or "").casefold()))  # CastApp TVs first
    ctx.shared["tv_found"] = found
    if not found:
        return note("No TV answered the search.",
                    fix="Switch the TV or Shield on. For CastApp TV: open CastApp once on the Shield after installing it "
                        "(its home screen shows its address; Play on TV → add a TV by its address). Windows may also "
                        "block the answers: allow Python for private networks when Windows asks.")
    kinds = Counter(maker(d) for d in found)
    details = [f"{_tv_label(ctx, d)}{'' if d.get('castapp') else ' (' + (d.get('model') or 'no model name') + ')'}: "
               f"{_same_net_text(d)}" for d in found]
    summary = ", ".join(f"{n} {k}" for k, n in sorted(kinds.items(), key=lambda kv: (-kv[1], kv[0] != "CastApp TV", kv[0])))
    return ok(f"{len(found)} TV{'s' if len(found) != 1 else ''} answered: {summary}.", *details)


def check_tv_remembered(ctx: Context) -> dict:
    from . import tv
    saved = ctx.app.store.meta("tv_devices") or {}
    found = {d["id"]: d for d in ctx.shared.get("tv_found") or []}
    if not saved:
        return skip("No TV remembered yet (AniBox remembers a TV once something played on it).")
    answering, details = {}, []
    for dev_id, dev in saved.items():
        if not isinstance(dev, dict):
            continue
        dev = dict(dev, id=dev_id)
        label = _tv_label(ctx, dev)
        if dev_id in found:
            answering[dev_id] = found[dev_id]
            details.append(f"{label}: answered the search")
            continue
        try:
            answering[dev_id] = tv.describe(str(dev.get("location") or ""), timeout=3.0)
            details.append(f"{label}: its description answers at the remembered address")
        except tv.TvError as exc:
            details.append(f"{label}: doesn't answer ({exc.reason})")
    ctx.shared["tv_answering"] = answering
    missing = len(saved) - len(answering)
    if missing:
        return note(f"{len(answering)} of {len(saved)} remembered TVs answer.", *details,
                    fix="A TV that's off or asleep doesn't answer; switch it on and Run again.")
    return ok(f"All {len(saved)} remembered TV{'s answer' if len(saved) != 1 else ' answers'}.", *details)


CAP_KEYS = ("h264_10bit", "hevc_10bit", "av1", "av1_sw", "sub_ass")


def check_castapp(ctx: Context) -> dict:
    from . import tv
    devices = {d["id"]: d for d in ctx.shared.get("tv_found") or [] if d.get("castapp")}
    for dev_id, d in (ctx.shared.get("tv_answering") or {}).items():
        if d.get("castapp"):
            devices.setdefault(dev_id, d)
    if not devices:
        return note("No CastApp TV answered.",
                    fix="On the Shield: open CastApp once after installing it (Android only lets an app start by itself "
                        "after that). Its home screen shows “Address: …:49595”; add that under Play on TV → Add a TV by "
                        "its address.")
    tokens = ctx.app.store.meta("tv_tokens") or {}
    details, state = [], "ok"
    for dev_id, dev in devices.items():
        label = _tv_label(ctx, dev)
        token = tokens.get(dev_id, "")
        if token:
            ctx.hide_secret(token)
        try:
            base = tv.Renderer(dev, token=token).base
        except tv.TvError as exc:
            details.append(f"{label}: {exc}")
            state = worst(state, "note")
            continue
        headers = {"X-CastApp-Name": "AniBox", "Accept": "application/json"}
        if token:
            headers["X-CastApp-Token"] = token
        r = http_probe(base + "/castapp/capabilities", headers=headers, timeout=5)
        details.append(f"{label}: {_same_net_text(dev)}")
        pairing = ("AniBox is paired with it (it has the TV's pairing code saved)" if token else
                   "AniBox isn't paired with it (only needed when the TV is set to “Only paired devices”; "
                   "the TV then shows a code the first time you play)")
        if r["status"] == 200:
            try:
                caps = json.loads(r["body"].decode("utf-8"))
            except ValueError:
                caps = None
            if isinstance(caps, dict):
                main = ", ".join(f"{k} {_yes_no(caps.get(k))}" for k in CAP_KEYS)
                others = ", ".join(f"{k} {_yes_no(v)}" for k, v in sorted(caps.items()) if k not in CAP_KEYS + ("version",))
                details.append(f"{label} can play (capabilities version {caps.get('version', '?')}): {main}")
                if others:
                    details.append(f"{label}, everything it lists: {others}")
            else:
                state = worst(state, "note")
                details.append(f"{label}: its capabilities answer isn't readable")
        elif r["status"] in (401, 403):
            pairing = "the TV wants AniBox paired first (it answered “code required”)"
            state = worst(state, "note")
        elif r["status"] == 404:
            details.append(f"{label}: an older CastApp TV without the capabilities list")
            state = worst(state, "note")
        else:
            details.append(f"{label}: the capabilities didn't answer ({r['error'] or r['status']})")
            state = worst(state, "note")
        details.append(f"{label}: {pairing}")
    return result(state, f"{len(devices)} CastApp TV{'s' if len(devices) != 1 else ''} found.", *details)


def _yes_no(v) -> str:
    if v is True:
        return "yes"
    if v is False:
        return "no"
    if v is None:
        return "not listed"
    return str(v)


# -- the internet ---

def _net_result(name: str, r: dict, ok_text: str = "", key_name: str = "") -> dict:
    took = secs_text(r["seconds"])
    if 200 <= r["status"] < 300:
        return ok(f"{name} answered in {took}{ok_text}.")
    if r["status"] in (401, 403) and key_name:
        return problem(f"{name} answered, but didn't accept the {key_name}.",
                       fix=f"Check the {key_name} in Settings.")
    if r["status"] == 429 or r["status"] >= 500:
        return note(f"{name} answered but is busy right now (HTTP {r['status']}, {took}).")
    if r["status"]:
        return note(f"{name} answered with HTTP {r['status']} ({took}).")
    return problem(f"{name} isn't reachable ({r['error'] or 'no answer'}).",
                   fix="Is the internet working? A firewall, VPN or proxy can block AniBox (Python).")


def check_archive(ctx: Context) -> dict:
    base = ctx.app.ia_client.base
    q = urllib.parse.urlencode({"q": "identifier:nasa", "fl[]": "identifier", "rows": "1", "output": "json"})
    return _net_result("archive.org", http_probe(f"{base}/advancedsearch.php?{q}"))


def check_release(ctx: Context) -> dict:
    up = ctx.app.updates
    r = http_probe(up._base() + "latest.json")
    if r["status"] == 404:
        return note(f"The release repository has no latest.json ({up.repo} isn't there or isn't public).",
                    fix="Settings → Updates: check the release repository's name.")
    res = _net_result("GitHub (the release repository)", r)
    if r["status"] == 200:
        try:
            latest = str(json.loads(r["body"].decode("utf-8")).get("version") or "?")
            res["line"] = res["line"][:-1] + f": the newest AniBox is {latest} (this is {__version__})."
        except (ValueError, AttributeError):
            return note("The release repository's latest.json isn't readable.")
    return res


def check_anilist(ctx: Context) -> dict:
    from .airing import ANILIST
    base = getattr(ctx.app, "anilist_url", ANILIST)
    body = json.dumps({"query": "{ Media(id: 1) { id } }"}).encode("utf-8")
    return _net_result("AniList", http_probe(base, "POST", {"Content-Type": "application/json"}, body))


def check_kitsu(ctx: Context) -> dict:
    base = ctx.app.episodes.kitsu
    return _net_result("Kitsu", http_probe(f"{base}/anime/1?fields%5Banime%5D=slug",
                                           headers={"Accept": "application/vnd.api+json"}))


def check_mal(ctx: Context) -> dict:
    cid = str(ctx.app.store.settings().get("mal_client_id") or "").strip()
    if not cid:
        return skip("No MyAnimeList Client ID set, so nothing goes to MyAnimeList's API.")
    ctx.hide_secret(cid)
    r = http_probe(f"{ctx.app.mal.base}/anime/1?fields=id", headers={"X-MAL-CLIENT-ID": cid})
    return _net_result("MyAnimeList", r, " and took the Client ID", "Client ID")


def check_tmdb(ctx: Context) -> dict:
    from . import tmdb
    key = tmdb.clean_key(ctx.app.store.settings().get("tmdb_api_key") or "")
    if not key:
        return skip("No TMDB key set, so nothing goes to TMDB.")
    ctx.hide_secret(key)
    url, headers = f"{ctx.app.tmdb.api}/authentication", {}
    if tmdb.key_kind(key) == "v3":
        url += "?" + urllib.parse.urlencode({"api_key": key})
    else:
        headers["Authorization"] = "Bearer " + key
    return _net_result("TMDB", http_probe(url, headers=headers), " and took the key", "TMDB key")


def _subtitle_accounts(ctx: Context) -> Tuple[dict, dict]:
    st = ctx.app._media()
    acc = st["accounts"].get()
    for k in ("jimaku_key", "opensubtitles_key", "opensubtitles_password"):
        if acc.get(k):
            ctx.hide_secret(acc[k])
    if acc.get("opensubtitles_user"):
        ctx.hide(acc["opensubtitles_user"], "<account>")
    return acc, st["bases"]


def check_jimaku(ctx: Context) -> dict:
    acc, bases = _subtitle_accounts(ctx)
    key = acc.get("jimaku_key") or ""
    if not key:
        return skip("No Jimaku key set, so nothing goes to Jimaku.")
    url = f"{bases['jimaku'].rstrip('/')}/api/entries/search?" + urllib.parse.urlencode({"anime": "true", "anilist_id": 21})
    return _net_result("Jimaku", http_probe(url, headers={"Authorization": key}), " and took the key", "Jimaku key")


def check_opensubtitles(ctx: Context) -> dict:
    acc, bases = _subtitle_accounts(ctx)
    key = acc.get("opensubtitles_key") or ""
    if not key:
        return skip("No OpenSubtitles key set, so nothing goes to OpenSubtitles.")
    r = http_probe(f"{bases['opensubtitles'].rstrip('/')}/infos/formats", headers={"Api-Key": key})
    res = _net_result("OpenSubtitles", r, " and took the key", "OpenSubtitles key")
    if not (acc.get("opensubtitles_user") and acc.get("opensubtitles_password")):
        res["details"].append("No OpenSubtitles username and password saved: searching works, downloading doesn't.")
    return res


# -- Internet Archive cache, phone remote, log ---

def check_iacache(ctx: Context) -> dict:
    app = ctx.app
    info = app.iacache.info()
    folder = Path(info["dir"])
    default = not info.get("dirSetting")
    details = [f"Folder: {folder}" + (" (the usual one)" if default else ""),
               f"Limit {info['gb']} GB; {size_text(info['used'])} used by {info['files']} files"]
    state, fix = "ok", ""
    test_in = folder
    if not folder.is_dir():
        if not default:
            return problem("The cache folder isn't there or can't be reached.", *details,
                           fix="Settings → Internet Archive streaming → pick a different cache folder.")
        test_in = app.data_dir  # AniBox makes its usual cache folder the first time it loads a video
        details.append("The folder doesn't exist yet; AniBox makes it the first time it loads a video (tested in its data folder)")
    r = sparse_test(test_in)
    if not r["writable"]:
        return problem(f"AniBox can't write into the cache folder ({r['error']}).", *details,
                       fix="Settings → Internet Archive streaming → pick a cache folder this Windows user may change.")
    if r["error"]:
        state = worst(state, "note")
        details.append(f"Test file: {r['error']}")
    if r["sparse"]:
        details.append(f"Sparse files work (a {size_text(SPARSE_TEST_SIZE)} test file took {size_text(r['allocated'])} on the disk)")
    else:
        state = worst(state, "note")
        details.append(f"Sparse files don't work on that drive (the test file took {size_text(r['allocated'])}): "
                       "a jump far into a video that isn't loaded yet takes longer")
        fix = "Pick a cache folder on an NTFS drive (most internal drives), not a FAT32/exFAT USB stick."
    free = info.get("free")
    if free is not None:
        details.append(f"{size_text(free)} free on that drive")
        if free < info["limit"]:
            state = worst(state, "note")
            details.append("Less free space than the limit: the cache pauses when the drive is full")
    details.append(f"Kept files: {info['kept']}" + (f" ({size_text(info['keptBytes'])}) in {info['keepDir']}" if info["kept"] else ""))
    line = ("On; the folder can be written." if info["enabled"] else
            "Off: Internet Archive videos stream straight from archive.org (the folder was still tested).")
    return result(state if info["enabled"] else worst(state, "note"), line, *details, fix=fix)


def check_remote(ctx: Context) -> dict:
    from .server import lan_address, tailscale_address
    app = ctx.app
    s = app.store.settings()
    if s.get("remote_key"):
        ctx.hide_secret(str(s["remote_key"]))
    port = int(s.get("remote_port") or 43211)
    lan = lan_address()
    kind = address_kind(lan)
    details = ["This PC's home network address: " + ("found" if kind == "home network" else
                                                       "not found (only this PC)" if kind == "" else f"a {kind} address"),
               "Tailscale: " + ("running" if tailscale_address() else "not running")]
    if app.remote:
        return ok(f"On, on port {app.remote.server_address[1]}.", *details)
    if s.get("remote_enabled"):
        return problem(app.remote_error or "On in Settings, but it isn't running.", *details,
                       fix="Pick a different port for the phone remote, or close the program that uses this one.")
    free = True
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.bind(("0.0.0.0", port))  # only bound for a moment, never listening
    except OSError:
        free = False
    if free:
        return ok(f"Off; its port {port} is free for when you switch it on.", *details)
    return note(f"Off, and its port {port} is used by a different program.", *details,
                fix="Switching the remote on would fail: close that program, or change the remote's port.")


def check_logs(ctx: Context) -> dict:
    logs = ctx.app.data_dir / "logs"
    if not (logs / "anibox.log").is_file():
        return skip("No log file yet.")
    lines = problems_from_log(log_records(logs))
    if not lines:
        return ok("No warnings or errors in AniBox's log.")
    n = len(lines)
    return note(f"{n} recent warning{'s' if n != 1 else ''} or error{'s' if n != 1 else ''} in AniBox's log (newest last):",
                *lines)


def build_checks(app, ctx: Context) -> List[Check]:
    hung = "didn't answer within {s} s (the share hangs, or the Shield is asleep)."
    out = [
        Check("system.anibox", "AniBox and system", "AniBox", check_anibox, 10),
        Check("system.data", "AniBox and system", "Data folder", check_data, 20),
        Check("system.update", "AniBox and system", "Update now", check_update, 20),
        Check("player.mpv", "Player", "mpv", check_mpv, 20),
        Check("player.start", "Player", "mpv start test", check_mpv_start, 25, after=["player.mpv"],
              timeout_text="mpv didn't finish the test within 25 s.",
              timeout_fix="Settings → Player → Download mpv again; an antivirus program can also hold mpv up."),
        Check("player.embed", "Player", "Playing inside the window", check_embed, 10),
        Check("player.ffmpeg", "Player", "ffmpeg and ffprobe", check_ffmpeg, 25),
        Check("window", "The window", "The AniBox window", check_window, 5),
    ]
    folders = list(app.store.settings().get("folders") or [])
    if not folders:
        out.append(Check("folders.none", "Library folders", "Folders",
                         lambda c: note("No folders yet.", fix="Settings → Folders → add your anime folders."), 5))
    for i, folder in enumerate(folders, 1):
        out.append(Check(f"folders.{i}", "Library folders", f"Folder {i}: {folder}", check_folder(folder), 15,
                         timeout_text="It " + hung.format(s=15),
                         timeout_fix="Open it in File Explorer once to wake the drive, then Run again."))
    out += [
        Check("folders.scan", "Library folders", "Last scan", check_scan, 10),
        Check("plex.server", "Plex", "Plex server", check_plex_server, 40,
              timeout_text="Plex didn't answer within 40 s.", timeout_fix="Is the Shield awake? Open Plex on the TV once, then Run again."),
        Check("plex.libraries", "Plex", "Plex libraries", check_plex_libraries, 30, after=["plex.server"]),
        Check("plex.agents", "Plex", "Plex metadata agents", check_plex_agents, 40, after=["plex.server"]),
        Check("tv.search", "TVs", "TV search", check_tv_search, 15),
        Check("tv.remembered", "TVs", "Remembered TVs", check_tv_remembered, 20, after=["tv.search"]),
        Check("tv.castapp", "TVs", "CastApp TV", check_castapp, 20, after=["tv.remembered"]),
        Check("net.archive", "Internet", "archive.org", check_archive, 15),
        Check("net.release", "Internet", "Release repository", check_release, 15),
        Check("net.anilist", "Internet", "AniList", check_anilist, 15),
        Check("net.kitsu", "Internet", "Kitsu", check_kitsu, 15),
        Check("net.mal", "Internet", "MyAnimeList", check_mal, 15),
        Check("net.tmdb", "Internet", "TMDB", check_tmdb, 15),
        Check("net.jimaku", "Internet", "Jimaku", check_jimaku, 15),
        Check("net.opensubtitles", "Internet", "OpenSubtitles", check_opensubtitles, 15),
        Check("iacache", "Internet Archive cache", "Cache folder", check_iacache, 20),
        Check("remote", "Phone remote", "Phone remote", check_remote, 10),
        Check("logs", "Recent problems", "AniBox's log", check_logs, 10),
    ]
    return out


# -- the report ----------------------------------------------------------------------------------------

def summary(rows: List[dict]) -> Dict[str, int]:
    c = Counter(r["status"] for r in rows)
    return {k: c.get(k, 0) for k in STATES}


def summary_text(rows: List[dict]) -> str:
    s = summary(rows)
    parts = [f"{s['ok']} fine", f"{s['note']} to note", f"{s['problem']} problem{'s' if s['problem'] != 1 else ''}"]
    if s["skip"]:
        parts.append(f"{s['skip']} not checked")
    return ", ".join(parts)


def report_text(rows: List[dict], meta: dict) -> str:
    """The report as plain text (Markdown headings). Not scrubbed yet: the caller scrubs the whole text."""
    lines = ["AniBox setup check", "==================",
             f"{meta.get('date', '')} · AniBox {meta.get('version', __version__)}",
             f"Result: {summary_text(rows)} ({len(rows)} checks in {meta.get('seconds', 0):.0f} s).",
             "Left out on purpose: names, addresses, keys and show names (replaced by <…> or %USERPROFILE%).", ""]
    for group in GROUPS:
        mine = [r for r in rows if r["group"] == group]
        if not mine:
            continue
        lines.append(f"## {group}")
        for r in mine:
            mark = MARKS.get(r["status"], "?")
            lines.append(f"{mark} {r['title']}: {r['line']}".rstrip())
            for d in r.get("details") or []:
                lines.append(f"    {d}")
            if r.get("fix"):
                lines.append(f"    Fix: {r['fix']}")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def save_report(text: str, folder: Path, day: Optional[str] = None) -> Path:
    """Write the report into ``folder`` as "AniBox setup check <date>.txt", never over another file
    (" (2)", " (3)" ...)."""
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    stem = f"AniBox setup check {day or time.strftime('%Y-%m-%d')}"
    for n in range(1, 1000):
        path = folder / (stem + (f" ({n})" if n > 1 else "") + ".txt")
        try:
            with open(path, "x", encoding="utf-8-sig", newline="\r\n" if IS_WINDOWS else "\n") as fh:
                fh.write(text)
            return path
        except FileExistsError:
            continue
    raise OSError("There are already 999 reports with today's date in that folder.")
