"""The Missing page: what's missing per franchise, from your folders or from a Plex library.

This used to be the separate "Library Check" program (``run-check.bat``). Its engine still lives in
``library-check/anibox_check``; AniBox now runs both checks itself and exports the same HTML/CSV
reports.

- *Your folders*: ``library.report()``, built from the scanned folders (no Plex needed).
- *Your Plex library*: reads the chosen Plex libraries (GET only, the saved sign-in) and compares
  each show with the anime lists in the numbering the library uses ("Would go in X → Season 1").
  The result is kept in ``plex-check.json`` so it's there after a restart.

Part of the App class (see server.py); the methods use the App's attributes.
"""

from __future__ import annotations

import dataclasses
import json
import logging
import os
import tempfile
import threading
import time
from pathlib import Path
from typing import Optional, Tuple

import anibox
from anibox_check import ignore as ignore_list
from anibox_check.analyze import Analyzer, EntryResult, Franchise, Report
from anibox_check.cli import ignored_path
from anibox_check.plex import PlexAuthError, PlexError, PlexItem, PlexReader
from anibox_check.report import write_csv, write_html

from . import plexhistory
from .apierror import ApiError
from .library import entry_json

log = logging.getLogger("anibox")

SIGN_IN_FIRST = "Sign in to Plex first (Settings → Your Plex library)."


# -- saving a report -------------------------------------------------------------------------------

def _item_json(i: PlexItem) -> dict:
    d = dataclasses.asdict(i)
    d["ids"] = {k: sorted(v) for k, v in i.ids.items()}
    d["modes"] = sorted(i.modes)
    d["episodes"] = sorted([s, e] for s, e in i.episodes)
    return d


def _item_from(d: dict) -> PlexItem:
    names = {f.name for f in dataclasses.fields(PlexItem)}
    d = {k: v for k, v in d.items() if k in names}
    d["ids"] = {k: set(v) for k, v in (d.get("ids") or {}).items()}
    d["modes"] = set(d.get("modes") or ())
    d["episodes"] = {(int(s), int(e)) for s, e in d.get("episodes") or ()}
    return PlexItem(**d)


def report_to_json(report: Report) -> dict:
    return {
        "franchises": [{"name": f.name, "entries": [dataclasses.asdict(e) for e in f.entries]} for f in report.franchises],
        "items": [_item_json(i) for i in list(report.unidentified) + list(report.ignored)],
        "scanned": report.scanned, "identified": report.identified, "titles_meta": report.titles_meta,
    }


def report_from_json(d: dict) -> Report:
    names = {f.name for f in dataclasses.fields(EntryResult)}
    return Report(
        franchises=[Franchise(f["name"], [EntryResult(**{k: v for k, v in e.items() if k in names}) for e in f["entries"]])
                    for f in d.get("franchises") or []],
        unidentified=[_item_from(i) for i in d.get("items") or []],
        scanned=int(d.get("scanned") or 0), identified=int(d.get("identified") or 0),
        titles_meta=d.get("titles_meta") or {},
    )


def missing_json(report: Report) -> dict:
    """The report as the Missing page shows it."""
    gaps, complete = [], 0
    for fr in report.franchises:
        entries = [entry_json(e) for e in fr.entries]
        if any(e["status"] in ("missing", "partial", "unsure") for e in entries):
            gaps.append({"name": fr.name, "entries": entries, "have": fr.count("owned", include_short=True),
                         "total": len(entries), "missing": fr.count("missing")})
        else:
            complete += 1

    def item(i):
        return {"key": ignore_list.item_key(i), "title": i.title, "library": i.section, "note": i.note}

    return {
        "gaps": gaps,
        "complete": complete,
        "stats": {
            "folders": report.scanned, "identified": report.identified,
            "have": sum(f.count("owned", include_short=True) for f in report.franchises),
            "missing": sum(f.count("missing") for f in report.franchises),
            "incomplete": sum(f.count("partial") for f in report.franchises),
            "check": sum(f.count("unsure") for f in report.franchises),
        },
        "notFound": [item(i) for i in report.unidentified],
        "ignored": [item(i) for i in report.ignored],
        "titlesUpdated": report.titles_meta.get("lastUpdate"),
    }


class RoutesMissingMixin:
    # -- the page ----------------------------------------------------------------------------------

    def _missing(self, source: str = "folders") -> dict:
        if source != "plex":
            return {"source": "folders", **missing_json(self.library.report())}
        report, meta = self._plex_report_loaded()
        out = {"source": "plex", "check": self.plex_check, "signedIn": bool(plexhistory.saved_credentials())}
        if report is None:
            return {**out, "empty": True}
        return {**out, **missing_json(report), "server": meta.get("server", ""), "fetched": meta.get("fetched"),
                "sections": meta.get("sections") or []}

    def _ignore(self, key: str, ignore: bool) -> dict:
        if not key:
            raise ApiError("Missing key")
        keys = ignore_list.load(ignored_path())
        folded = [k for k in keys if k.casefold() != key.casefold()]
        keys = folded + ([key] if ignore else [])
        ignore_list.save(ignored_path(), keys)
        self.library.forget_report()
        if self._plex_report is not None:
            ignore_list.apply(self._plex_report, keys)
        return {"ok": True}

    # -- the Plex check ------------------------------------------------------------------------------

    def _plex_report_loaded(self) -> Tuple[Optional[Report], dict]:
        if self._plex_report is None and self.plex_check_path.is_file():
            try:
                saved = json.loads(self.plex_check_path.read_text(encoding="utf-8"))
                report = report_from_json(saved["report"])
                ignore_list.apply(report, ignore_list.load(ignored_path()))
                self._plex_report, self._plex_report_meta = report, saved.get("meta") or {}
            except Exception as exc:  # damaged or from another version: check again
                log.warning("Couldn't read %s (%s); the Plex check has to run again", self.plex_check_path, exc)
        return self._plex_report, self._plex_report_meta or {}

    def _plex_sections(self) -> dict:
        """The Plex server's TV and movie libraries, and which ones the check reads."""
        creds = plexhistory.saved_credentials()
        if not creds:
            raise ApiError(SIGN_IN_FIRST)
        try:
            sections = PlexReader(creds[0], creds[1]).sections()
        except PlexAuthError:
            raise ApiError("Plex didn't accept the saved sign-in. Sign in again under Settings → Your Plex library.")
        except (PlexError, OSError, ValueError) as exc:
            raise ApiError(f"Couldn't reach Plex: {exc}")
        chosen = self.store.settings().get("plex_check_sections") or []
        return {"sections": [{"key": s.key, "title": s.title, "type": s.type, "agent": s.agent,
                              "chosen": not chosen or s.key in chosen} for s in sections]}

    def _plex_check_start(self, body: dict) -> dict:
        if self.plex_check.get("state") == "running":
            return self.plex_check
        creds = plexhistory.saved_credentials()
        if not creds:
            raise ApiError(SIGN_IN_FIRST)
        if isinstance(body.get("sections"), list):
            self.store.update_settings({"plex_check_sections": [str(k) for k in body["sections"]]})
        wanted = set(self.store.settings().get("plex_check_sections") or [])
        started = self.plex_check = {"state": "running", "message": "Connecting to Plex (a sleeping Shield can take a minute) …"}

        def say(message: str) -> None:
            self.plex_check["message"] = message

        def run():
            try:
                reader = PlexReader(creds[0], creds[1])
                name = (reader.identity() or {}).get("friendlyName") or reader.base_url
                chosen = [s for s in reader.sections() if not wanted or s.key in wanted]
                if not chosen:
                    raise ApiError("None of the chosen Plex libraries exist any more. Pick the libraries again.")
                shows, movies, orderings = [], [], {}
                for s in chosen:
                    say(f"Reading “{s.title}” …")
                    items = reader.items(s)
                    if s.type == "show":
                        orderings[s.key] = reader.section_ordering(s)
                        shows.extend(items)
                    else:
                        movies.extend(items)
                say("Comparing with the anime lists …")
                report = Analyzer(self.library.datasets()).analyze(shows, movies, orderings)
                meta = {"server": name, "fetched": time.time(), "sections": [s.title for s in chosen],
                        "version": anibox.__version__}
                tmp = self.plex_check_path.with_suffix(".part")
                tmp.write_text(json.dumps({"meta": meta, "report": report_to_json(report)}, ensure_ascii=False),
                               encoding="utf-8")
                os.replace(tmp, self.plex_check_path)
                ignore_list.apply(report, ignore_list.load(ignored_path()))
                self._plex_report, self._plex_report_meta = report, meta
                missing = sum(f.count("missing") for f in report.franchises)
                self.plex_check = {"state": "done", "fetched": meta["fetched"]}
                log.info("Plex check: %d of %d items identified, %d entries missing (%s)", report.identified,
                         report.scanned, missing, ", ".join(meta["sections"]))
            except PlexAuthError:
                self.plex_check = {"state": "error", "message": "Plex didn't accept the saved sign-in. "
                                                                "Sign in again under Settings → Your Plex library."}
            except Exception as exc:  # shown on the page
                log.exception("Plex check failed")
                self.plex_check = {"state": "error", "message": str(exc) or exc.__class__.__name__}

        threading.Thread(target=run, daemon=True, name="anibox-plex-check").start()
        return started  # not self.plex_check: a quick error may already have replaced it

    # -- export --------------------------------------------------------------------------------------

    def _missing_export(self, source: str, fmt: str) -> Tuple[bytes, str, str]:
        """(file bytes, file name, content type) of the report as a web page or a spreadsheet."""
        if fmt not in ("html", "csv"):
            raise ApiError("Unknown format")
        if source == "plex":
            report, meta = self._plex_report_loaded()
            if report is None:
                raise ApiError("Check your Plex library first.")
            label, folder_mode, what = meta.get("server") or "Plex", False, "Plex"
        else:
            report, label, folder_mode, what = self.library.report(), "your folders", True, "Folders"
        name = time.strftime(f"AniBox-Missing-{what}-%Y-%m-%d.{fmt}")
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / name
            if fmt == "csv":
                write_csv(report, path)
            else:
                write_html(report, path, label, posters=True, folder_mode=folder_mode,
                           made_by=f"AniBox {anibox.__version__}")
            data = path.read_bytes()
        return data, name, "text/csv; charset=utf-8" if fmt == "csv" else "text/html; charset=utf-8"
