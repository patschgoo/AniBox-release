"""What's inside a video file, whether it plays directly on the TV, and plain subtitle files for the TV.

Three parts:

1. **Reading a file** (:func:`probe`): with ffprobe when it's there (exact: codec, profile, bit
   depth, every audio and subtitle track), otherwise AniBox's own reading of the start of an MKV/MP4
   file (codec, size, and for H.264/H.265/AV1 the profile and bit depth from the codec header). Only
   reads; results are cached per file (size + modified time) in :class:`InfoCache`.
2. **"Plays on the TV?"** (:func:`check`): compares a file with what the target plays directly:
   Plex on the Shield (a built-in table, ``probably`` where it isn't verified) or CastApp TV (its
   ``/castapp/capabilities`` answer, see ``tv.Renderer.capabilities``, plus a built-in table).
3. **TV-friendly subtitles** (:func:`plan_subtitles`, :func:`write_subtitles`, :func:`undo`): a plain
   ``<video name>.<language>.srt`` next to an episode whose subtitles are styled (ASS/SSA, inside the
   MKV or as a ``.ass`` file next to it). The rules:

   - preview first, write only what the preview listed, after you confirm;
   - only for episodes that aren't locked (new episodes, or shows you unlocked), never in protected
     folders;
   - never overwrite: a file that exists is skipped, and the new file is created with "fail if it
     exists" (``O_EXCL``), so nothing can be replaced even if it appears in between;
   - every written file goes into ``subtitle-log.jsonl`` (path, checksum); :func:`undo` removes
     only files that are still exactly what AniBox wrote, and only subtitle files.

   Picture subtitles (PGS from Blu-rays, VobSub from DVDs) can't become text without OCR
   (recognizing letters in pictures), so AniBox offers nothing for them.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import secrets
import shutil
import struct
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path
from typing import Callable, Dict, List, Optional, Sequence, Tuple

from . import languages

log = logging.getLogger("anibox.media")

IS_WINDOWS = sys.platform.startswith("win")
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
CACHE_VERSION = 1
PROBE_TIMEOUT = 60  # ffprobe on a network drive
EXTRACT_TIMEOUT = 900  # taking a track out reads the whole file (1-2 GB over the network)
MAX_SUBTITLE = 20_000_000
SUBTITLE_EXTS = (".srt", ".ass", ".ssa", ".vtt", ".sub", ".sup", ".idx")  # what undo may ever remove

# -- names for people ------------------------------------------------------------------------------

VIDEO_NAMES = {"h264": "H.264", "hevc": "H.265 (HEVC)", "av1": "AV1", "vp9": "VP9", "vp8": "VP8",
               "mpeg2video": "MPEG-2", "mpeg1video": "MPEG-1", "mpeg4": "MPEG-4 (Xvid/DivX)",
               "msmpeg4v3": "DivX 3", "msmpeg4v2": "MS MPEG-4", "vc1": "VC-1", "wmv3": "WMV 9", "wmv2": "WMV 8",
               "theora": "Theora", "rv40": "RealVideo", "rv30": "RealVideo", "prores": "ProRes", "ffv1": "FFV1",
               "vfw": "an old AVI codec", "h263": "H.263", "flv1": "Flash video", "mjpeg": "Motion JPEG"}
AUDIO_NAMES = {"aac": "AAC", "ac3": "Dolby Digital (AC3)", "eac3": "Dolby Digital Plus (E-AC3)", "dts": "DTS",
               "truehd": "Dolby TrueHD", "flac": "FLAC", "opus": "Opus", "vorbis": "Vorbis", "mp3": "MP3",
               "mp2": "MP2", "pcm": "PCM", "alac": "ALAC", "wmav2": "WMA", "wmapro": "WMA Pro", "mlp": "MLP",
               "cook": "RealAudio"}


def _pcm(codec: str) -> str:
    return "pcm" if codec.startswith("pcm_") else codec


def video_text(v: Optional[dict]) -> str:
    """"H.264 10-bit (Hi10P) · 1920×1080"."""
    if not v:
        return "no picture found"
    name = VIDEO_NAMES.get(v.get("codec") or "", (v.get("codec") or "?").upper())
    bits = v.get("bits")
    profile = (v.get("profile") or "").strip()
    text = name
    if bits and bits > 8:
        text += f" {bits}-bit"
    if v.get("codec") == "h264" and is_hi10p(v):
        text += " (Hi10P)"
    elif profile and profile.lower() not in ("main", "high", "lc", "constrained baseline", "baseline"):
        text += f" ({profile})"
    if v.get("width") and v.get("height"):
        text += f" · {v['width']}×{v['height']}"
    return text


def audio_text(a: dict) -> str:
    name = AUDIO_NAMES.get(_pcm(a.get("codec") or ""), (a.get("codec") or "?").upper())
    profile = (a.get("profile") or "").strip()
    if profile and a.get("codec") == "dts" and profile.upper() != "DTS":
        name = profile  # "DTS-HD MA"
    ch = a.get("channels")
    if ch:
        name += " " + {1: "1.0", 2: "2.0", 6: "5.1", 8: "7.1"}.get(ch, f"{ch} ch")
    return name + (f" ({a['lang']})" if a.get("lang") else "")


def sub_text(s: dict) -> str:
    name = languages.SUBTYPE_NAMES.get(s.get("type") or "", (s.get("codec") or "?").upper())
    extra = [x for x in (s.get("lang"), "forced" if s.get("forced") else "", "file next to it" if s.get("external") else "") if x]
    return name + (f" ({', '.join(extra)})" if extra else "")


def is_hi10p(v: dict) -> bool:
    return v.get("codec") == "h264" and ((v.get("bits") or 8) > 8 or "10" in (v.get("profile") or ""))


# -- 1. reading a file -----------------------------------------------------------------------------

def _bits_from_pix_fmt(pix: str) -> Optional[int]:
    if not pix:
        return None
    m = re.search(r"p(\d{2})(?:le|be)?$", pix) or re.search(r"(\d{2})(?:le|be)$", pix)
    if m:
        return int(m.group(1))
    if pix in ("p010le", "p010be", "p010"):
        return 10
    return 8


def parse_ffprobe(obj: dict) -> dict:
    """ffprobe's JSON (``-show_streams -show_format``) -> AniBox's info dict (see :func:`probe`)."""
    video, audio, subs = None, [], []
    sub_n = 0
    for s in obj.get("streams") or []:
        kind = s.get("codec_type")
        tags = {str(k).lower(): v for k, v in (s.get("tags") or {}).items()}
        disp = s.get("disposition") or {}
        codec = str(s.get("codec_name") or "").lower()
        if kind == "video":
            if disp.get("attached_pic"):
                continue  # a cover picture, not the video
            if video is None:
                bits = None
                raw = str(s.get("bits_per_raw_sample") or "")
                if raw.isdigit() and int(raw) > 0:
                    bits = int(raw)
                bits = bits or _bits_from_pix_fmt(str(s.get("pix_fmt") or ""))
                video = {"codec": codec, "profile": str(s.get("profile") or ""), "bits": bits,
                         "width": int(s.get("width") or 0), "height": int(s.get("height") or 0)}
        elif kind == "audio":
            audio.append({"codec": _pcm(codec), "profile": str(s.get("profile") or ""),
                          "channels": int(s.get("channels") or 0), "lang": languages.lang(str(tags.get("language") or "")),
                          "title": str(tags.get("title") or ""), "default": bool(disp.get("default"))})
        elif kind == "subtitle":
            subs.append({"n": sub_n, "codec": codec, "type": languages.subtype(codec),
                         "lang": languages.lang(str(tags.get("language") or "")), "title": str(tags.get("title") or ""),
                         "forced": bool(disp.get("forced")), "default": bool(disp.get("default"))})
            sub_n += 1
    fmt = obj.get("format") or {}
    return {"source": "ffprobe", "container": str(fmt.get("format_name") or ""), "video": video, "audio": audio,
            "subs": subs, "exact": True}


def probe_ffprobe(path: str, ffprobe: str) -> Optional[dict]:
    try:
        r = subprocess.run([ffprobe, "-v", "error", "-print_format", "json", "-show_streams", "-show_format", "-i", path],
                           stdin=subprocess.DEVNULL, capture_output=True, timeout=PROBE_TIMEOUT, creationflags=NO_WINDOW)
    except (OSError, subprocess.TimeoutExpired) as exc:
        log.info("ffprobe couldn't read %s: %s", path, exc)
        return None
    if r.returncode != 0:
        log.info("ffprobe couldn't read %s: %s", path, (r.stderr or b"").decode("utf-8", "replace").strip()[:200])
        return None
    try:
        return parse_ffprobe(json.loads(r.stdout.decode("utf-8", "replace") or "{}"))
    except ValueError:
        return None


# Without ffprobe: the codec header at the start of an MKV/MP4 file.

_MKV_VIDEO = {"V_MPEG4/ISO/AVC": "h264", "V_MPEGH/ISO/HEVC": "hevc", "V_AV1": "av1", "V_VP9": "vp9", "V_VP8": "vp8",
              "V_MPEG2": "mpeg2video", "V_MPEG1": "mpeg1video", "V_MPEG4/ISO/ASP": "mpeg4", "V_MPEG4/ISO/SP": "mpeg4",
              "V_MPEG4/ISO/AP": "mpeg4", "V_MPEG4/MS/V3": "msmpeg4v3", "V_THEORA": "theora", "V_REAL/RV40": "rv40",
              "V_REAL/RV30": "rv30", "V_MS/VFW/FOURCC": "vfw", "V_PRORES": "prores", "V_FFV1": "ffv1"}
_MKV_AUDIO = (("A_AAC", "aac"), ("A_EAC3", "eac3"), ("A_AC3", "ac3"), ("A_DTS", "dts"), ("A_TRUEHD", "truehd"),
              ("A_FLAC", "flac"), ("A_OPUS", "opus"), ("A_VORBIS", "vorbis"), ("A_MPEG/L3", "mp3"), ("A_MPEG/L2", "mp2"),
              ("A_PCM", "pcm"), ("A_ALAC", "alac"), ("A_MLP", "mlp"), ("A_REAL", "cook"))
_MP4_VIDEO = {"avc1": "h264", "avc3": "h264", "hvc1": "hevc", "hev1": "hevc", "av01": "av1", "vp09": "vp9",
              "vp08": "vp8", "mp4v": "mpeg4", "dvh1": "hevc", "dvhe": "hevc", "mp2v": "mpeg2video"}
_MP4_AUDIO = {"mp4a": "aac", "ac-3": "ac3", "ec-3": "eac3", "dtsc": "dts", "dtsh": "dts", "dtsl": "dts", "dtse": "dts",
              "opus": "opus", "fLaC": "flac", "alac": "alac", ".mp3": "mp3", "lpcm": "pcm", "sowt": "pcm", "twos": "pcm"}
_H264_PROFILES = {66: "Baseline", 77: "Main", 88: "Extended", 100: "High", 110: "High 10", 122: "High 4:2:2",
                  244: "High 4:4:4 Predictive", 44: "CAVLC 4:4:4"}
_HEVC_PROFILES = {1: "Main", 2: "Main 10", 3: "Main Still Picture", 4: "Rext"}


def _avcc(data: bytes) -> Tuple[str, Optional[int]]:
    """H.264 codec header (avcC) -> (profile, bit depth or None)."""
    if len(data) < 7 or data[0] != 1:
        return "", None
    profile_idc = data[1]
    profile = _H264_PROFILES.get(profile_idc, "")
    bits = None
    try:  # the extension after the parameter sets (High profiles) carries the bit depth
        pos = 5
        n_sps = data[pos] & 0x1F
        pos += 1
        for _ in range(n_sps):
            size = struct.unpack(">H", data[pos:pos + 2])[0]
            pos += 2 + size
        n_pps = data[pos]
        pos += 1
        for _ in range(n_pps):
            size = struct.unpack(">H", data[pos:pos + 2])[0]
            pos += 2 + size
        if profile_idc in (100, 110, 122, 144, 244) and pos + 3 <= len(data):
            bits = (data[pos + 1] & 0x07) + 8
    except (IndexError, struct.error):
        pass
    if bits is None:
        bits = 10 if profile_idc == 110 else (8 if profile_idc in (66, 77, 88, 100) else None)
    return profile, bits


def _hvcc(data: bytes) -> Tuple[str, Optional[int]]:
    if len(data) < 23:
        return "", None
    profile = _HEVC_PROFILES.get(data[1] & 0x1F, "")
    return profile, (data[17] & 0x07) + 8


def _av1c(data: bytes) -> Tuple[str, Optional[int]]:
    if len(data) < 3:
        return "", None
    profile = {0: "Main", 1: "High", 2: "Professional"}.get(data[1] >> 5, "")
    high, twelve = bool(data[2] & 0x40), bool(data[2] & 0x20)
    return profile, 12 if twelve else (10 if high else 8)


def _codec_private(codec: str, data: bytes) -> Tuple[str, Optional[int]]:
    if codec == "h264":
        return _avcc(data)
    if codec == "hevc":
        return _hvcc(data)
    if codec == "av1":
        return _av1c(data[4:] if data[:4] == b"av1C" else data)
    return "", None


def _mkv_tracks_area(path: str) -> Optional[bytes]:
    """The contents of an MKV file's Tracks element (same way of finding it as languages.probe_mkv)."""
    E = languages
    with open(path, "rb") as f:
        buf = f.read(E.READ_FIRST)
        if len(buf) < 8 or E._vint(buf, 0, True)[0] != E._EBML:
            return None
        pos = None
        for eid, a, b in E._elements(buf, 0, len(buf)):
            if eid == E._SEGMENT:
                pos = a
                break
        if pos is None:
            return None
        seek_tracks = None
        for eid, a, b in E._elements(buf, pos, len(buf)):
            if eid == E._TRACKS:
                if b <= len(buf):
                    return buf[a:b]
                f.seek(a)
                return f.read(min(b - a, 8 * E.READ_FIRST))
            if eid == E._SEEKHEAD:
                for sid, x, y in E._elements(buf, a, b):
                    if sid != E._SEEK:
                        continue
                    target, where = None, None
                    for cid, u, w in E._elements(buf, x, y):
                        if cid == E._SEEKID:
                            target = E._uint(buf[u:w])
                        elif cid == E._SEEKPOS:
                            where = E._uint(buf[u:w])
                    if target == E._TRACKS and where is not None:
                        seek_tracks = pos + where
            if eid == E._CLUSTER:
                break
        if seek_tracks is None:
            return None
        f.seek(max(0, seek_tracks))
        more = f.read(E.READ_FIRST)
    for eid, a, b in E._elements(more, 0, len(more)):
        if eid == E._TRACKS:
            return more[a:b]
    return None


def probe_mkv_info(path: str) -> Optional[dict]:
    E = languages
    area = _mkv_tracks_area(path)
    if area is None:
        return None
    video, audio, subs = None, [], []
    for eid, a, b in E._elements(area, 0, len(area)):
        if eid != E._TRACKENTRY:
            continue
        t = {"type": 0, "codec": "", "private": b"", "lang": "eng", "bcp47": "", "name": "", "default": True,
             "forced": False, "width": 0, "height": 0, "bits": None, "channels": 0}
        for cid, x, y in E._elements(area, a, b):
            v = area[x:y]
            if cid == E._TRACKTYPE:
                t["type"] = E._uint(v)
            elif cid == E._CODEC:
                t["codec"] = v.decode("ascii", "replace").strip("\0")
            elif cid == 0x63A2:  # CodecPrivate
                t["private"] = v[:4096]
            elif cid == E._LANGUAGE:
                t["lang"] = v.decode("ascii", "replace").strip("\0")
            elif cid == E._LANG_BCP47:
                t["bcp47"] = v.decode("ascii", "replace").strip("\0")
            elif cid == E._NAME:
                t["name"] = v.decode("utf-8", "replace").strip("\0")
            elif cid == E._DEFAULT:
                t["default"] = bool(E._uint(v))
            elif cid == E._FORCED:
                t["forced"] = bool(E._uint(v))
            elif cid == 0xE0:  # Video
                for vid, p, q in E._elements(area, x, y):
                    if vid == 0xB0:
                        t["width"] = E._uint(area[p:q])
                    elif vid == 0xBA:
                        t["height"] = E._uint(area[p:q])
                    elif vid == 0x55B0:  # Colour
                        for cc, r, s in E._elements(area, p, q):
                            if cc == 0x55B2:
                                t["bits"] = E._uint(area[r:s]) or None
            elif cid == 0xE1:  # Audio
                for aid, p, q in E._elements(area, x, y):
                    if aid == 0x9F:
                        t["channels"] = E._uint(area[p:q])
        lang = languages.lang(t["bcp47"] or t["lang"])
        codec = t["codec"].upper()
        if t["type"] == 1 and video is None:
            c = _MKV_VIDEO.get(codec, codec.lower().replace("v_", ""))
            profile, bits = _codec_private(c, t["private"])
            video = {"codec": c, "profile": profile, "bits": t["bits"] or bits, "width": t["width"], "height": t["height"]}
        elif t["type"] == 2:
            c = next((name for prefix, name in _MKV_AUDIO if codec.startswith(prefix)), codec.lower().replace("a_", ""))
            audio.append({"codec": c, "profile": "", "channels": t["channels"], "lang": lang, "title": t["name"],
                          "default": t["default"]})
        elif t["type"] == 0x11:
            subs.append({"n": len(subs), "codec": t["codec"], "type": languages.subtype(t["codec"]), "lang": lang,
                         "title": t["name"], "forced": t["forced"], "default": t["default"]})
    exact = video is None or video.get("bits") is not None
    return {"source": "file", "container": "matroska", "video": video, "audio": audio, "subs": subs, "exact": exact}


def _mp4_moov(path: str) -> Optional[bytes]:
    with open(path, "rb") as f:
        total = os.fstat(f.fileno()).st_size
        pos = 0
        while pos + 8 <= total:
            f.seek(pos)
            head = f.read(16)
            if len(head) < 8:
                return None
            size, kind = struct.unpack(">I4s", head[:8])
            hlen = 8
            if size == 1 and len(head) >= 16:
                size, hlen = struct.unpack(">Q", head[8:16])[0], 16
            elif size == 0:
                size = total - pos
            if size < hlen:
                return None
            if kind == b"moov":
                if size > languages.MAX_MOOV:
                    return None
                f.seek(pos + hlen)
                return f.read(size - hlen)
            pos += size
    return None


def probe_mp4_info(path: str) -> Optional[dict]:
    moov = _mp4_moov(path)
    if not moov:
        return None
    boxes = languages._boxes
    video, audio, subs = None, [], []
    for kind, a, b in boxes(moov, 0, len(moov)):
        if kind != b"trak":
            continue
        handler, lang, entry, entry_box = "", "", "", (0, 0)
        for k2, a2, b2 in boxes(moov, a, b):
            if k2 != b"mdia":
                continue
            for k3, a3, b3 in boxes(moov, a2, b2):
                if k3 == b"hdlr" and b3 - a3 >= 12:
                    handler = moov[a3 + 8:a3 + 12].decode("ascii", "replace")
                elif k3 == b"mdhd" and b3 - a3 >= 24:
                    off = a3 + (32 if moov[a3] == 1 else 20)
                    packed = struct.unpack(">H", moov[off:off + 2])[0] if off + 2 <= b3 else 0
                    code = "".join(chr(((packed >> s) & 0x1F) + 0x60) for s in (10, 5, 0)) if packed else ""
                    lang = languages.lang(code) if code.isalpha() else ""
                elif k3 == b"minf":
                    for k4, a4, b4 in boxes(moov, a3, b3):
                        if k4 != b"stbl":
                            continue
                        for k5, a5, b5 in boxes(moov, a4, b4):
                            if k5 == b"stsd" and b5 - a5 >= 16:
                                size = struct.unpack(">I", moov[a5 + 8:a5 + 12])[0]
                                entry = moov[a5 + 12:a5 + 16].decode("ascii", "replace")
                                entry_box = (a5 + 8, min(a5 + 8 + size, b5))
        if handler == "vide" and video is None:
            codec = _MP4_VIDEO.get(entry, entry)
            start, end = entry_box
            width = height = 0
            profile, bits = "", None
            if end - start >= 86:
                width, height = struct.unpack(">HH", moov[start + 32:start + 36])
                for k6, a6, b6 in boxes(moov, start + 86, end):
                    if k6 in (b"avcC", b"hvcC", b"av1C"):
                        profile, bits = _codec_private(codec, moov[a6:b6])
            video = {"codec": codec, "profile": profile, "bits": bits, "width": width, "height": height}
        elif handler == "soun":
            audio.append({"codec": _MP4_AUDIO.get(entry, entry.strip().lower()), "profile": "", "channels": 0,
                          "lang": lang, "title": "", "default": True})
        elif handler in ("subt", "sbtl", "text", "clcp"):
            subs.append({"n": len(subs), "codec": entry, "type": languages.subtype(entry), "lang": lang, "title": "",
                         "forced": False, "default": True})
    exact = video is None or video.get("bits") is not None
    return {"source": "file", "container": "mp4", "video": video, "audio": audio, "subs": subs, "exact": exact}


def probe_own(path: str) -> Optional[dict]:
    """Without ffprobe: MKV/WebM and MP4 only. None for other kinds of files."""
    ext = os.path.splitext(path)[1].lower()
    try:
        if ext in (".mkv", ".mk3d", ".webm"):
            return probe_mkv_info(path)
        if ext in (".mp4", ".m4v", ".mov"):
            return probe_mp4_info(path)
    except (OSError, ValueError, struct.error, IndexError):
        return None
    return None


def external_subs(video_path: str) -> List[dict]:
    """Subtitle files next to the video ("Show 01.de.ass"), as sub entries with their path."""
    folder, name = os.path.split(video_path)
    stem = os.path.splitext(name)[0]
    try:
        names = sorted(os.listdir(folder or "."))
    except OSError:
        return []
    out = []
    for n in names:
        base, ext = os.path.splitext(n)
        kind = languages.SUB_EXTENSIONS.get(ext.lower())
        if not kind or not _belongs(base, stem) or _belongs_longer(base, stem, names):
            continue
        rest = base[len(stem):].strip(" ._-")
        parts = [p for p in rest.split(".") if p]
        forced = any(p.lower() == "forced" for p in parts)
        code = next((p for p in reversed(parts) if p.lower() not in ("forced", "sdh", "cc", "hi", "default")), "")
        out.append({"codec": ext.lower().lstrip("."), "type": kind, "lang": languages.lang(code) if code and len(code) <= 8 else "",
                    "title": n, "forced": forced, "default": False, "external": True, "path": os.path.join(folder, n)})
    return out


def _belongs(sub_stem: str, video_stem: str) -> bool:
    """"Ep 1.en" and "Ep 1 [eng]" go with "Ep 1", "Ep 10" doesn't."""
    if len(sub_stem) < len(video_stem) or sub_stem[:len(video_stem)].casefold() != video_stem.casefold():
        return False
    return len(sub_stem) == len(video_stem) or not sub_stem[len(video_stem)].isalnum()


def _belongs_longer(sub_stem: str, video_stem: str, names: Sequence[str]) -> bool:
    """A subtitle belongs to the video with the longest matching name ("Ep 1 extended.srt")."""
    from .tv import VIDEO_EXTS
    for n in names:
        s, e = os.path.splitext(n)
        if e.lower() in VIDEO_EXTS and len(s) > len(video_stem) and _belongs(sub_stem, s):
            return True
    return False


class InfoCache:
    """Probe results per file, kept by path with its size and modified time (``media-info.json``)."""

    def __init__(self, path: Path):
        self.path = Path(path)
        self._lock = threading.Lock()
        self._save_lock = threading.Lock()
        self._files: Dict[str, dict] = {}
        self._dirty = False
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            if isinstance(data, dict) and data.get("version") == CACHE_VERSION and isinstance(data.get("files"), dict):
                self._files = data["files"]
        except (OSError, ValueError):
            pass

    @staticmethod
    def _stamp(path: str) -> Optional[Tuple[int, float]]:
        try:
            st = os.stat(path)
        except OSError:
            return None
        return st.st_size, round(st.st_mtime, 3)

    def get(self, path: str, ffprobe: Optional[str]) -> Optional[dict]:
        stamp = self._stamp(path)
        if stamp is None:
            return None
        with self._lock:
            hit = self._files.get(path)
        if hit and hit.get("size") == stamp[0] and hit.get("mtime") == stamp[1]:
            if not ffprobe or hit.get("ffprobe"):
                return hit.get("info")  # (read again once ffprobe is there: it's more exact)
        info = probe_ffprobe(path, ffprobe) if ffprobe else None
        if info is None:
            info = probe_own(path)
        with self._lock:
            self._files[path] = {"size": stamp[0], "mtime": stamp[1], "info": info, "at": time.time(),
                                 "ffprobe": bool(ffprobe)}
            self._dirty = True
        return info

    def peek(self, path: str) -> Optional[dict]:
        """What an earlier :meth:`get` read for this file, if the file hasn't changed since; never reads it."""
        stamp = self._stamp(path)
        with self._lock:
            hit = self._files.get(path)
        if stamp and hit and hit.get("size") == stamp[0] and hit.get("mtime") == stamp[1]:
            return hit.get("info")
        return None

    def save(self) -> None:
        with self._save_lock:
            with self._lock:
                if not self._dirty:
                    return
                data = json.dumps({"version": CACHE_VERSION, "files": self._files}, ensure_ascii=False)
                self._dirty = False
            try:
                self.path.parent.mkdir(parents=True, exist_ok=True)
                tmp = self.path.with_suffix(".part")
                tmp.write_text(data, encoding="utf-8")
                os.replace(tmp, self.path)
            except OSError as exc:
                log.warning("Couldn't save %s: %s", self.path, exc)


def probe(path: str, ffprobe: Optional[str] = None, cache: Optional[InfoCache] = None) -> Optional[dict]:
    """``{"source": "ffprobe"|"file", "video": {codec, profile, bits, width, height} or None,
    "audio": [{codec, profile, channels, lang}], "subs": [{n, codec, type, lang, title, forced}],
    "exact": bool}``, or None when the file can't be read. Subtitle files next to the video are
    added as subs with ``external: True``."""
    if cache is not None:
        info = cache.get(path, ffprobe)
    else:
        info = (probe_ffprobe(path, ffprobe) if ffprobe else None) or probe_own(path)
    if info is None:
        return None
    info = dict(info)
    info["external"] = external_subs(path)
    return info


# -- 2. "Plays on the TV?" -------------------------------------------------------------------------

OK, SOUND, SUBS, SLOW, CONVERT = "ok", "sound", "subs", "slow", "convert"
LEVELS = {OK: 0, SUBS: 1, SOUND: 2, SLOW: 3, CONVERT: 4}

PLEX = "plex"
CASTAPP = "castapp"
TARGET_NAMES = {PLEX: "Plex on the Shield", CASTAPP: "CastApp TV"}


def _reason(level: str, text: str, probably: bool, kind: str) -> dict:
    return {"level": level, "text": text, "probably": probably, "kind": kind}


# CastApp TV's capability key for a file type (capabilities version 3, CastApp main 001889a); also used by
# tvstream.py for Internet Archive videos.
FILE_KEYS = {".mkv": "container_mkv", ".mk3d": "container_mkv", ".webm": "container_webm", ".mp4": "container_mp4",
             ".m4v": "container_mp4", ".mov": "container_mp4", ".avi": "container_avi", ".ts": "container_ts",
             ".m2ts": "container_m2ts", ".mts": "container_m2ts", ".flv": "container_flv",
             ".mpg": "container_mpeg_ps", ".mpeg": "container_mpeg_ps", ".vob": "container_mpeg_ps",
             ".ogv": "container_ogg_video", ".ogg": "container_ogg_video", ".wmv": "container_asf", ".asf": "container_asf"}
# CastApp TV when it doesn't say (older versions): what its player (Media3) reads. It has no reader for
# ASF/WMV, its Ogg reader is for sound only (no Theora video), and its TS reader takes 188-byte packets
# only (Blu-ray .m2ts has 192). The same as CastApp TV 3 answers.
CASTAPP_FILES = {"container_mp4": True, "container_mkv": True, "container_webm": True, "container_ts": True,
                 "container_avi": True, "container_flv": True, "container_mpeg_ps": True,
                 "container_m2ts": False, "container_ogg_video": False, "container_asf": False}
_FILE_WORDS = {"container_m2ts": "Blu-ray .m2ts files", "container_ogg_video": "Ogg video files (.ogv)",
               "container_asf": "Windows Media files (.wmv)"}


def _file_rules_castapp(name: str, caps: dict) -> List[dict]:
    """The file type itself: CastApp TV gets the file as it is, so one its player can't open doesn't
    play at all (a TV copy, an MKV, fixes that)."""
    key = FILE_KEYS.get(os.path.splitext(name or "")[1].lower(), "")
    if not key:
        return []
    said = caps.get(key)
    answer = said if isinstance(said, bool) else CASTAPP_FILES.get(key)
    if answer is False:
        what = _FILE_WORDS.get(key) or os.path.splitext(name)[1].lower() + " files"
        return [_reason(CONVERT, f"CastApp TV can't open {what}", not isinstance(said, bool), "file")]
    return []


def _video_rules_plex(v: dict) -> List[dict]:
    c, bits = v.get("codec") or "", v.get("bits") or 8
    name = VIDEO_NAMES.get(c, c.upper() or "this video format")
    if c == "h264":
        if is_hi10p(v):
            return [_reason(CONVERT, "10-bit H.264 (Hi10P): the Shield's hardware can't decode it; Plex converts it, "
                                     "which is slow on the Shield", False, "video")]
        if "4:2:2" in (v.get("profile") or "") or "4:4:4" in (v.get("profile") or ""):
            return [_reason(CONVERT, f"H.264 {v['profile']}: the Shield's hardware can't decode it; Plex converts it", True, "video")]
    elif c == "hevc":
        if bits > 10:
            return [_reason(CONVERT, f"{bits}-bit H.265: the Shield decodes up to 10-bit; Plex converts it", True, "video")]
    elif c == "vp9":
        return [_reason(OK, "VP9 plays on the Shield", True, "video")]
    elif c == "av1":
        return [_reason(CONVERT, "AV1: the 2019 Shield has no AV1 decoder, so Plex converts it (slow)", True, "video")]
    elif c in ("mpeg2video", "vc1", "wmv3", "mpeg4"):
        return [_reason(OK, f"{name} plays on the Shield", True, "video")]
    elif c:
        return [_reason(CONVERT, f"{name}: the Shield can't play it directly; Plex converts it", True, "video")]
    else:
        return []
    if (v.get("width") or 0) > 4096 or (v.get("height") or 0) > 2304:
        return [_reason(CONVERT, "bigger than 4K: Plex converts it", True, "video")]
    return []


def _caps_flag(caps: dict, *names: str) -> Optional[bool]:
    for n in names:
        if isinstance(caps.get(n), bool):
            return caps[n]
    return None


def _software(caps: dict, v: dict, name: str, *keys: str) -> Optional[List[dict]]:
    """CastApp TV 2+: ``<codec>_sw`` = only a software decoder: fine up to SD, may stutter in HD."""
    if not any(caps.get(k + "_sw") is True for k in keys):
        return None
    if (v.get("height") or 0) and (v.get("height") or 0) <= 576:
        return [_reason(OK, f"{name}: CastApp TV decodes it in software, fine at this size", False, "video")]
    return [_reason(SLOW, f"{name}: CastApp TV only has a software decoder for it, so it may stutter in HD", False, "video")]


def _video_rules_castapp(v: dict, caps: dict) -> List[dict]:
    """CastApp TV plays the file as it is. ``caps`` is its /castapp/capabilities answer (version 2: one
    true/false per hardware decoder that does 1080p, plus ``<key>_sw`` for software-only ones); a missing
    key is unknown, and then AniBox's own table for the 2019 Shield applies ("probably")."""
    c, bits = v.get("codec") or "", v.get("bits") or 8
    name = VIDEO_NAMES.get(c, c.upper() or "this video format")
    tail = "; AniBox sends files as they are, so it won't play there"
    if c == "h264":
        if is_hi10p(v):
            flag = _caps_flag(caps, "h264_10bit", "hi10p")
            if flag:
                return []
            soft = _software(caps, v, "10-bit H.264 (Hi10P)", "h264_10bit", "hi10p")
            if soft:
                return soft
            return [_reason(CONVERT, "10-bit H.264 (Hi10P): CastApp TV uses the Shield's hardware, which can't decode it" + tail,
                            flag is None, "video")]
        if _caps_flag(caps, "h264") is False:
            return _software(caps, v, name, "h264") or [_reason(CONVERT, f"{name}: this TV said it can't decode it" + tail, False, "video")]
        return []
    if c == "hevc":
        flag = _caps_flag(caps, "hevc_10bit", "hevc") if bits == 10 else _caps_flag(caps, "hevc")  # version 1: "hevc" only
        label = "10-bit H.265 (HEVC)" if bits == 10 else "H.265 (HEVC)"
        if flag is False:
            return _software(caps, v, label, "hevc_10bit" if bits == 10 else "hevc") or \
                [_reason(CONVERT, f"{label}: this TV said it can't decode it" + tail, False, "video")]
        if bits > 10:
            return [_reason(CONVERT, f"{bits}-bit H.265: the Shield decodes up to 10-bit" + tail, True, "video")]
        return [] if flag else [_reason(OK, "H.265 plays on the Shield", True, "video")]
    if c in ("vp9", "av1", "vp8", "mpeg2video", "mpeg4"):
        key = {"mpeg2video": "mpeg2"}.get(c, c)
        flag = _caps_flag(caps, c, key)
        if flag is True:
            return []
        soft = _software(caps, v, name, key)
        if soft:
            return soft
        if flag is False:
            return [_reason(CONVERT, f"{name}: this TV said it can't decode it" + tail, False, "video")]
        if c == "av1":
            return [_reason(CONVERT, "AV1: the 2019 Shield has no AV1 decoder" + tail, True, "video")]
        return [_reason(OK, f"{name} plays on the Shield", True, "video")]
    if c:
        return [_reason(CONVERT, f"{name}: the Shield can't decode it" + tail, True, "video")]
    return []


def _audio_rules(audio: List[dict], target: str, caps: dict) -> List[dict]:
    out = []
    seen = set()
    for a in audio:
        c = a.get("codec") or ""
        if c in seen:
            continue
        seen.add(c)
        name = audio_text({"codec": c, "profile": a.get("profile")})
        if c in ("aac", "mp3", "opus", "vorbis", "flac", "pcm"):
            continue
        if c in ("ac3", "eac3"):
            if target == CASTAPP and _caps_flag(caps, c) is False:
                out.append(_reason(SOUND, f"{name}: this TV said it can't decode it, so it plays without sound", False, "audio"))
            continue
        if target == PLEX:
            if c == "dts":
                out.append(_reason(OK, f"{name}: the Shield passes it on to your TV/receiver or decodes it", True, "audio"))
            elif c == "truehd":
                out.append(_reason(SOUND, f"{name}: goes to an AV receiver as it is; without one Plex converts the sound "
                                          "(light work, the picture isn't converted)", True, "audio"))
            else:
                out.append(_reason(SOUND, f"{name}: Plex converts the sound (light work, the picture isn't converted)", True, "audio"))
        else:
            flag = _caps_flag(caps, c)
            if flag is True:
                continue
            if c in ("dts", "truehd"):
                out.append(_reason(SOUND, f"{name}: CastApp TV can only pass it on to a receiver that takes it; "
                                          "otherwise it plays without sound", flag is None, "audio"))
            else:
                out.append(_reason(SOUND, f"{name}: CastApp TV probably can't decode it and plays without sound", flag is None, "audio"))
    return out


def _sub_rules(subs: List[dict], target: str, caps: Optional[dict] = None) -> List[dict]:
    types = {s.get("type") for s in subs if s.get("type")}
    plain = types & {"srt", "vtt", "text", "hard"}
    out = []
    if "ass" in types:
        if target == PLEX:
            text = ("Styled subtitles (ASS): when they're on, Plex probably shows them without colours and positions, "
                    "or converts the video to burn them in (slow)")
        else:
            c = caps or {}
            if c.get("sub_ass_full") is True:
                text = "Styled subtitles (ASS): CastApp TV shows them fully"
            elif c.get("sub_ass") is True:
                text = ("Styled subtitles (ASS): CastApp TV shows them with positions, colours, bold and italic, "
                        "but not effects, karaoke or the file's own fonts")
            else:
                text = "Styled subtitles (ASS): CastApp TV probably shows them as plain text, without colours and positions"
        if plain:
            text += "; plain subtitles are there too, pick those"
        out.append(_reason(OK if plain else SUBS, text + ".", True, "subs"))
    if types & {"pgs", "vobsub"}:
        if target == PLEX:
            out.append(_reason(OK if plain else SUBS, "Picture subtitles (PGS/VobSub): when they're on, Plex probably "
                                                     "converts the video to burn them in (slow on the Shield); they can't "
                                                     "become plain text.", True, "subs"))
        else:
            known = (caps or {}).get("sub_pgs") is True
            out.append(_reason(OK, "Picture subtitles (PGS/VobSub): CastApp TV " + ("shows them" if known else "probably shows them"),
                               not known, "subs"))
    return out


def check(info: Optional[dict], target: str, caps: Optional[dict] = None, name: str = "") -> dict:
    """One file against one target. Returns ``{"level": ok|subs|sound|convert|unknown,
    "reasons": [{"level", "text", "probably", "kind"}], "exact": bool}``.

    Levels: ``convert`` = the picture has to be converted (Plex) or can't play at all (CastApp TV,
    which gets the file as it is); ``sound`` = only the sound is converted or missing; ``subs`` =
    only the subtitles are a problem when switched on. ``probably`` marks rules that come from how
    the players work, not from a test on your Shield. ``name``: the file's name, for its type (CastApp
    TV's ``container_*`` answers: e.g. Blu-ray .m2ts doesn't open there).
    """
    caps = caps or {}
    if not info:
        return {"level": "unknown", "reasons": [_reason("unknown", "AniBox couldn't read this file", False, "file")],
                "exact": False}
    v = info.get("video")
    reasons: List[dict] = []
    if target == CASTAPP and name:
        reasons += _file_rules_castapp(name, caps)
    if v:
        reasons += _video_rules_plex(v) if target == PLEX else _video_rules_castapp(v, caps)
    reasons += _audio_rules(info.get("audio") or [], target, caps)
    reasons += _sub_rules(list(info.get("subs") or []) + list(info.get("external") or []), target, caps)
    worst = max((r["level"] for r in reasons), key=lambda lv: LEVELS.get(lv, 0), default=OK)
    exact = bool(info.get("exact"))
    if v and v.get("codec") == "h264" and v.get("bits") is None:
        reasons.append(_reason(OK, "AniBox couldn't read the bit depth; download ffmpeg for an exact check", True, "video"))
    return {"level": worst, "reasons": reasons, "exact": exact}


def summary(level: str, reasons: List[dict], target: str) -> str:
    first = next((r["text"] for r in reasons if r["level"] == level), "")
    if level == CONVERT:
        return "Needs converting because " + first
    if level == SLOW:
        return "Plays, but may stutter. " + first
    if level in (SOUND, SUBS):
        return "Plays directly. " + first
    if level == "unknown":
        return "Can't tell. " + first
    return "Plays directly"


def check_show(infos: Sequence[Tuple[str, Optional[dict]]], target: str, caps: Optional[dict] = None,
               copies: Optional[set] = None) -> dict:
    """Several episodes (file name, info) of one show against one target, combined. ``copies``: the
    file names that have an up-to-date TV copy (tvcopy.py)."""
    copies = copies or set()
    files, reasons, seen = [], [], set()
    exact = True
    for name, info in infos:
        res = check(info, target, caps, name)
        exact = exact and res["exact"]
        for r in res["reasons"]:
            if r["text"] not in seen:
                seen.add(r["text"])
                reasons.append(r)
        info = info or {}
        files.append({"file": name, "level": res["level"], "video": video_text(info.get("video")) if info else "",
                      "audio": [audio_text(a) for a in info.get("audio") or []],
                      "subs": [sub_text(s) for s in list(info.get("subs") or []) + list(info.get("external") or [])],
                      "source": info.get("source", ""), "tvCopy": name in copies})
    known = [f["level"] for f in files if f["level"] in LEVELS]
    worst = max(known, key=lambda lv: LEVELS[lv]) if known else "unknown"  # a file AniBox can't read doesn't decide
    if worst != "unknown":
        reasons = [r for r in reasons if r["level"] != "unknown"]
    reasons.sort(key=lambda r: -LEVELS.get(r["level"], 0))
    text = summary(worst, reasons, target)
    if worst == CONVERT and all(f["tvCopy"] for f in files if f["level"] == CONVERT):
        text += (". A TV copy is ready, and Play on TV sends that instead" if target == CASTAPP else
                 ". TV copy ready (in AniBox's TV copies folder; add that folder to Plex to use it there)")
    return {"target": target, "name": TARGET_NAMES.get(target, target), "level": worst,
            "summary": text, "reasons": reasons, "files": files, "exact": exact,
            "probably": any(r["probably"] for r in reasons if r["level"] == worst),
            "tvCopies": sum(1 for f in files if f["tvCopy"])}


# -- 3. TV-friendly subtitles ----------------------------------------------------------------------

NEW = "new"
SKIP_EXISTS = "skip-exists"
SKIP_LOCKED = "skip-locked"
SKIP_PROTECTED = "skip-protected"
SKIP_IMAGE = "skip-image"
SKIP_PLAIN = "skip-plain"
SKIP_DUPLICATE = "skip-duplicate"
SKIP_NO_FFMPEG = "skip-no-ffmpeg"
SKIP_UNREADABLE = "skip-unreadable"
REASONS = {
    SKIP_EXISTS: "a file with this name is already there (never replaced)",
    SKIP_LOCKED: "locked: the episode was already there; unlock the show to include it",
    SKIP_PROTECTED: "protected folder: AniBox writes nothing here",
    SKIP_IMAGE: "picture subtitles (PGS/VobSub) can't become text without OCR",
    SKIP_PLAIN: "already has plain subtitles in this language",
    SKIP_DUPLICATE: "another subtitle of this language is used",
    SKIP_NO_FFMPEG: "needs ffmpeg (Settings → Player → Download ffmpeg)",
    SKIP_UNREADABLE: "AniBox couldn't read this file",
}
_SIGNS = re.compile(r"\b(signs?|songs?|s\s*&\s*s|forced|karaoke)\b", re.I)


def safe_lang(code: str) -> str:
    """A language code fit for a file name ("de", "eng"); anything else (from a file's tags or a
    website) becomes ""."""
    code = languages.lang(code or "")
    return code if re.fullmatch(r"[a-z]{2,3}", code) else ""


def _target_name(stem: str, lang: str, forced: bool) -> str:
    lang = safe_lang(lang)
    return stem + (f".{lang}" if lang else "") + (".forced" if forced else "") + ".srt"


def plan_episode(ep: dict, info: Optional[dict], locked: bool, protected: bool, have_ffmpeg: bool) -> List[dict]:
    """What "Make TV-friendly subtitles" would do for one episode (one item per subtitle)."""
    video = ep["path"]
    folder, name = os.path.split(video)
    stem = os.path.splitext(name)[0]
    base = {"key": ep["key"], "file": ep.get("file") or name, "video": video}
    # Locked and protected episodes aren't even read: nothing is ever written next to them.
    if protected:
        return [dict(base, action=SKIP_PROTECTED, path="", source="", lang="", label="")]
    if locked:
        return [dict(base, action=SKIP_LOCKED, path="", source="", lang="", label="")]
    if info is None:
        return [dict(base, action=SKIP_UNREADABLE, path="", source="", lang="", label="")]
    candidates = []
    for s in info.get("external") or []:
        if s.get("type") == "ass" and s.get("path"):
            candidates.append(dict(s, source="file"))
    for s in info.get("subs") or []:  # (inside the file)
        if s.get("type") == "ass":
            candidates.append(dict(s, source="track"))
    images = [s for s in list(info.get("subs") or []) + list(info.get("external") or []) if s.get("type") in ("pgs", "vobsub")]
    plain_langs = {s.get("lang") or "" for s in list(info.get("subs") or []) + list(info.get("external") or [])
                   if s.get("type") in ("srt", "vtt", "text")}
    out: List[dict] = []
    if not candidates and not images:
        return out
    try:
        existing = {n.casefold() for n in os.listdir(folder or ".")}
    except OSError:
        return [dict(base, action=SKIP_UNREADABLE, path="", source="", lang="", label="")]
    taken = set()
    # The main subtitle per language first: a file next to the video, then the default track, then signs-only ones.
    candidates.sort(key=lambda s: (s["source"] != "file", bool(s.get("forced") or _SIGNS.search(s.get("title") or "")),
                                   not s.get("default"), s.get("n", 0)))
    for s in candidates:
        forced = bool(s.get("forced") or _SIGNS.search(s.get("title") or ""))
        lang = s.get("lang") or ""
        target = os.path.join(folder, _target_name(stem, lang, forced))
        label = sub_text(s) + (f" · “{s['title']}”" if s.get("title") and s["source"] == "track" else "")
        item = dict(base, path=target, source=s["source"], lang=lang, forced=forced, label=label,
                    track=s.get("n"), ext_path=s.get("path", ""))
        if os.path.basename(target).casefold() in existing:
            item["action"] = SKIP_EXISTS
        elif target.casefold() in taken:
            item["action"] = SKIP_DUPLICATE
        elif not forced and lang in plain_langs:
            item["action"] = SKIP_PLAIN
        elif s["source"] == "track" and not have_ffmpeg:
            item["action"] = SKIP_NO_FFMPEG
        else:
            item["action"] = NEW
            taken.add(target.casefold())
        out.append(item)
    for s in images:
        out.append(dict(base, action=SKIP_IMAGE, path="", source="file" if s.get("external") else "track",
                        lang=s.get("lang") or "", label=sub_text(s)))
    return out


def plan_subtitles(show: dict, infos: Dict[str, Optional[dict]], locked_keys: set, protected: bool,
                   have_ffmpeg: bool) -> dict:
    items: List[dict] = []
    for ep in show["episodes"]:
        items += plan_episode(ep, infos.get(ep["key"]), ep["key"] in locked_keys, protected, have_ffmpeg)
    counts: Dict[str, int] = {}
    for it in items:
        counts[it["action"]] = counts.get(it["action"], 0) + 1
    for it in items:
        if it["action"] != NEW:
            it["reason"] = REASONS.get(it["action"], "")
    return {"show": show["id"], "items": items, "counts": counts, "new": counts.get(NEW, 0)}


def _srt_bytes(text: str) -> bytes:
    """UTF-8 with BOM and Windows line ends: the form TVs read most reliably."""
    return "﻿".encode("utf-8") + text.replace("\r\n", "\n").replace("\n", "\r\n").encode("utf-8")


def extract_tracks(video: str, tracks: Sequence[int], ffmpeg: str) -> Dict[int, str]:
    """ASS text of the given subtitle tracks (``0:s:N``), all in one pass over the file."""
    from .tv import _decode_text
    tmp = Path(tempfile.mkdtemp(prefix="anibox-subs-"))
    try:
        r = None
        outs = {}
        for codec in ("copy", "ass"):  # as it is; if ffmpeg refuses that, converted to ASS
            args = [ffmpeg, "-nostdin", "-v", "error", "-y", "-i", video]
            outs = {}
            for n in tracks:
                out = tmp / f"track{int(n)}.ass"
                outs[int(n)] = out
                args += ["-map", f"0:s:{int(n)}", "-c:s", codec, "-f", "ass", str(out)]
            r = subprocess.run(args, stdin=subprocess.DEVNULL, capture_output=True, timeout=EXTRACT_TIMEOUT,
                               creationflags=NO_WINDOW)
            if r.returncode == 0:
                break
        if r is None or r.returncode != 0:
            raise RuntimeError((r.stderr or b"").decode("utf-8", "replace").strip()[-300:] or "ffmpeg failed")
        result = {}
        for n, out in outs.items():
            if out.is_file() and out.stat().st_size <= MAX_SUBTITLE:
                result[n] = _decode_text(out.read_bytes())
        return result
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def write_new_file(path: str, data: bytes) -> None:
    """Create ``path`` with ``data``; fails (FileExistsError) if anything is there already."""
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_BINARY", 0), 0o666)
    ok = False
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
            fh.flush()
            try:
                os.fsync(fh.fileno())
            except OSError:
                pass  # some network drives don't support it
        ok = True
    finally:
        if not ok:
            try:
                os.remove(path)  # only the file this call just created
            except OSError:
                pass


class SubtitleLog:
    """``subtitle-log.jsonl``: one line per file AniBox added next to a video, and the undos."""

    def __init__(self, path: Path):
        self.path = Path(path)
        self._lock = threading.Lock()

    def add(self, show: str, key: str, path: str, data: bytes, kind: str, source: str = "") -> dict:
        rec = {"id": secrets.token_hex(6), "show": show, "key": key, "path": path, "sha256": _sha256(data),
               "size": len(data), "kind": kind, "source": source, "time": time.time()}
        with self._lock:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.path, "a", encoding="utf-8", newline="\n") as fh:
                fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
                fh.flush()
                os.fsync(fh.fileno())
        return rec

    def entries(self, show: Optional[str] = None) -> List[dict]:
        """Files added and not undone yet (optionally only of one show)."""
        try:
            lines = self.path.read_text(encoding="utf-8").splitlines()
        except FileNotFoundError:
            return []
        recs, done = [], set()
        for line in lines:
            try:
                rec = json.loads(line)
            except ValueError:
                continue
            if not isinstance(rec, dict):
                continue
            if "undone" in rec:
                done |= set(rec.get("undone") or [])
            elif rec.get("id") and rec.get("path") and rec.get("sha256"):
                recs.append(rec)
        return [r for r in recs if r["id"] not in done and (show is None or r.get("show") == show)]

    def undo(self, show: Optional[str] = None) -> dict:
        """Remove the files AniBox added (of one show, or all), newest first; only if unchanged."""
        result = {"removed": 0, "kept": 0, "missing": 0, "failed": 0, "kept_paths": [], "errors": []}
        undone = []
        for rec in reversed(self.entries(show)):
            path = str(rec["path"])
            if os.path.splitext(path)[1].lower() not in SUBTITLE_EXTS:
                result["failed"] += 1
                result["errors"].append({"path": path, "error": "not a subtitle file; left alone"})
                continue
            try:
                if not os.path.lexists(path):
                    result["missing"] += 1
                    undone.append(rec["id"])
                    continue
                if os.path.islink(path) or not os.path.isfile(path):
                    result["kept"] += 1
                    result["kept_paths"].append(path)
                    continue
                with open(path, "rb") as fh:
                    data = fh.read(MAX_SUBTITLE + 1)
                if _sha256(data) != rec["sha256"]:
                    result["kept"] += 1  # changed since AniBox wrote it: yours now
                    result["kept_paths"].append(path)
                    undone.append(rec["id"])
                    continue
                os.remove(path)
                result["removed"] += 1
                undone.append(rec["id"])
            except OSError as exc:
                result["failed"] += 1
                result["errors"].append({"path": path, "error": exc.strerror or str(exc)})
        if undone:
            with self._lock:
                with open(self.path, "a", encoding="utf-8", newline="\n") as fh:
                    fh.write(json.dumps({"undone": undone, "time": time.time()}) + "\n")
        return result


def write_subtitles(plan: dict, ffmpeg: Optional[str], sublog: SubtitleLog, still_allowed: Callable[[str], bool],
                    progress: Optional[Callable[[int, int], None]] = None) -> dict:
    """Write the ``new`` items of a plan. ``still_allowed(key)`` is asked right before each file
    (the episode must still be unlocked). Never overwrites; each written file is logged."""
    from .tv import _decode_text, ass_to_srt
    result = {"written": 0, "skipped": 0, "failed": 0, "errors": [], "files": []}
    todo = [it for it in plan.get("items") or [] if it.get("action") == NEW and not it.get("done")]
    by_video: Dict[str, List[dict]] = {}
    for it in todo:
        by_video.setdefault(it["video"], []).append(it)
    done_count = 0
    for video, items in by_video.items():
        texts: Dict[int, str] = {}
        error = ""
        tracks = sorted({int(it["track"]) for it in items if it["source"] == "track" and it.get("track") is not None})
        if tracks and still_allowed(items[0]["key"]):
            if not ffmpeg:
                error = REASONS[SKIP_NO_FFMPEG]
            else:
                try:
                    texts = extract_tracks(video, tracks, ffmpeg)
                except (OSError, RuntimeError, subprocess.TimeoutExpired) as exc:
                    error = f"ffmpeg couldn't take the subtitles out: {exc}"
        for it in items:
            done_count += 1
            if progress:
                progress(done_count, len(todo))
            try:
                if not still_allowed(it["key"]):
                    result["skipped"] += 1
                    result["errors"].append({"path": it["path"], "error": "locked now; skipped"})
                    continue
                if not os.path.isfile(video):
                    raise RuntimeError("the video is no longer there")
                if it["source"] == "file":
                    with open(it["ext_path"], "rb") as fh:
                        raw = fh.read(MAX_SUBTITLE + 1)
                    if len(raw) > MAX_SUBTITLE:
                        raise RuntimeError("the subtitle file is too big")
                    ass = _decode_text(raw)
                else:
                    if error:
                        raise RuntimeError(error)
                    if int(it["track"]) not in texts:
                        raise RuntimeError("ffmpeg gave no text for this track")
                    ass = texts[int(it["track"])]
                srt = ass_to_srt(ass)
                if not srt.strip():
                    raise RuntimeError("no text lines in it (only signs or drawings)")
                data = _srt_bytes(srt)
                if os.path.lexists(it["path"]):
                    result["skipped"] += 1
                    result["errors"].append({"path": it["path"], "error": REASONS[SKIP_EXISTS]})
                    continue
                write_new_file(it["path"], data)
                sublog.add(plan.get("show") or "", it["key"], it["path"], data, "made", it["source"])
                it["done"] = True
                result["written"] += 1
                result["files"].append(it["path"])
            except FileExistsError:
                result["skipped"] += 1
                result["errors"].append({"path": it["path"], "error": REASONS[SKIP_EXISTS]})
            except (OSError, RuntimeError, ValueError) as exc:
                result["failed"] += 1
                result["errors"].append({"path": it["path"], "error": getattr(exc, "strerror", None) or str(exc)})
    return result
