"""Import your watched history from Plex (read-only).

Three steps, each usable on its own:

1. ``SignIn``: sign in with a code at plex.tv/link, the same way the Library Check does, and keep
   the server address and token in the Library Check's ``settings.json`` (one sign-in for both
   tools). Signing in adds "AniBox Library Check" to the Plex account under Authorized Devices.
2. ``fetch_history``: read every episode of every TV-type library with its watch state and the
   file it plays. Only HTTP GET requests are sent (through the Library Check's GET-only client),
   so nothing on the Plex server can change.
3. ``match_keys`` + ``apply_history``: find the AniBox episode for each Plex file and copy the
   watch state into AniBox's own database. AniBox never un-marks anything and never overwrites
   its own resume positions.
"""

from __future__ import annotations

import http.client
import re
import threading
import time
import unicodedata
import uuid
from typing import Callable, Dict, Iterator, List, Optional, Tuple

from . import __version__
from anibox_check import cli as check_cli
from anibox_check.plex import PAGE_SIZE, TYPE_EPISODE, PlexError, PlexReader, normalize_server_url
from anibox_check.plextv import (
    MAX_NETWORK_ERRORS, PLEX_TV, PRODUCT, PinExpired, PlexTv, PlexTvError, Server, find_working_address,
)
from .watching import RESUME_MIN_SECONDS

LINK_URL = "https://plex.tv/link"  # where the user types the code (always the real site)
APP_PRODUCT = "AniBox"  # how AniBox names itself to the Plex server
DEFAULT_CLIENT_ID = "anibox"  # used if a sign-in typed in by hand never created a client id
PROBE_TIMEOUT = 6.0  # seconds per address while looking for one that answers (same as the CLI)
SERVER_INFO_KEY = "server_info"  # {"name": ..., "server": ...}; the CLI ignores unknown keys

# What the sign-in changes on the user's account; show this before calling SignIn.start().
AUTHORIZED_DEVICE = PRODUCT
SIGN_IN_NOTE = (
    f'Signing in adds "{AUTHORIZED_DEVICE}" to your Plex account under Authorized Devices, where you '
    "can remove it any time. AniBox only reads from Plex and never changes anything there."
)
EXPIRED_MESSAGE = "The code expired. Start the sign-in again."

LogFn = Callable[[str], None]


# -- reading Plex (GET only) ---------------------------------------------------------------------


class _Reader(PlexReader):
    """The Library Check's GET-only Plex client, introducing itself as AniBox.

    ``PlexReader._get`` adds caller headers after its own, and ``urllib`` replaces a header of the
    same name, so these override the Library Check's product name and client id.
    """

    def __init__(self, base_url: str, token: str, client_id: str, **kwargs):
        super().__init__(base_url, token, **kwargs)
        self._identity = {
            "X-Plex-Product": APP_PRODUCT,
            "X-Plex-Version": __version__,
            "X-Plex-Client-Identifier": client_id or DEFAULT_CLIENT_ID,
        }

    def _get(self, path: str, params: Optional[dict] = None, headers: Optional[dict] = None) -> dict:
        merged = dict(self._identity)
        merged.update(headers or {})
        return super()._get(path, params, merged)

    def episode_pages(self, section_key: str) -> Iterator[Tuple[List[dict], int, Optional[int]]]:
        """(page, episodes read so far, total) for every page of a section's episodes.

        Pages the same way as ``PlexReader._paged``, but one page at a time so the app can show
        progress (a big library on a waking Shield takes a while).
        """
        start = 0
        while True:
            data = self._get(
                f"/library/sections/{section_key}/all",
                {"type": TYPE_EPISODE},
                headers={"X-Plex-Container-Start": str(start), "X-Plex-Container-Size": str(PAGE_SIZE)},
            )
            mc = data.get("MediaContainer") or {}
            page = [m for m in mc.get("Metadata") or [] if isinstance(m, dict)]
            total = mc.get("totalSize")
            total_n = int(_num(total)) if total is not None else None
            start += len(page)
            yield page, start, total_n
            if not page or total_n is None or start >= total_n:
                return


def _num(value) -> float:
    """Plex numbers as float (missing or odd values count as 0)."""
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _episode_entries(ep: dict, section: str) -> List[dict]:
    """One entry per file of an episode (none if Plex lists no file for it)."""
    watched = _num(ep.get("viewCount")) > 0
    offset = _num(ep.get("viewOffset")) / 1000.0  # Plex counts milliseconds
    ep_duration = _num(ep.get("duration")) / 1000.0
    viewed_at = int(_num(ep.get("lastViewedAt")))
    base = {
        "watched": watched,
        "viewed_at": viewed_at,
        "section": section,
        "show": str(ep.get("grandparentTitle") or ""),
        "title": str(ep.get("title") or ""),
    }
    out: List[dict] = []
    # Several Media are versions of the same episode (e.g. 1080p and 720p): each is complete on
    # its own, so each gets the full watch state. Several Parts are one episode split into files.
    for media in ep.get("Media") or []:
        if not isinstance(media, dict):
            continue
        parts = [p for p in media.get("Part") or [] if isinstance(p, dict) and p.get("file")]
        if not parts:
            continue
        if len(parts) == 1:
            duration = _num(parts[0].get("duration")) / 1000.0 or _num(media.get("duration")) / 1000.0 or ep_duration
            out.append(dict(base, file=str(parts[0]["file"]), position=offset, duration=duration))
            continue
        durations = [_num(p.get("duration")) / 1000.0 for p in parts]
        known = all(d > 0 for d in durations)
        start = 0.0
        for part, duration in zip(parts, durations):
            # The resume point counts across all files of the episode. Files already played
            # through count as watched; without part lengths the point can't be placed, so no
            # position is passed on rather than a wrong one.
            played_through = known and offset > 0 and offset >= start + duration
            if known and start <= offset < start + duration:
                position = offset - start
            else:
                position = 0.0
            out.append(dict(base, file=str(part["file"]), watched=watched or played_through,
                            position=position, duration=duration))
            start += duration
    return out


def fetch_history(server_url: str, token: str, client_id: str, log: Optional[LogFn] = None) -> List[dict]:
    """Every episode file of every TV-type library on the Plex server, with its watch state.

    Returns dicts with ``file`` (Plex's path, e.g. ``/storage/ABCD-1234/NVIDIA_SHIELD/Anime/Show/
    Show 01.mkv``), ``watched`` (viewCount > 0), ``position`` and ``duration`` (seconds),
    ``viewed_at`` (lastViewedAt, 0 if never), ``section`` (library title), plus ``show`` and
    ``title`` for display. Episodes without a file are left out. Movie libraries are skipped.

    Blocks for a while (it waits for a sleeping Shield), so run it off the UI's thread.
    Raises ``anibox_check.plex.PlexAuthError`` (sign in again), ``PlexError`` (not reachable or
    not Plex) or ``ValueError`` (unusable address).
    """
    say = log or (lambda message: None)
    reader = _Reader(server_url, token, client_id)
    sections = [s for s in reader.sections() if s.type == "show"]
    entries: List[dict] = []
    for n, section in enumerate(sections, 1):
        say(f"Reading '{section.title}' ({n} of {len(sections)}) ...")
        for page, done, total in reader.episode_pages(section.key):
            for ep in page:
                entries.extend(_episode_entries(ep, section.title))
            if total:
                say(f"{section.title}: {min(done, total)} of {total} episodes")
    say(f"Read {len(entries)} episode files from Plex.")
    return entries


# -- matching Plex files to AniBox episodes -------------------------------------------------------


def _parts(path: str) -> Tuple[str, ...]:
    # NFC because a name typed on a Mac can arrive decomposed; the letters are the same.
    return tuple(unicodedata.normalize("NFC", p) for p in re.split(r"[\\/]+", path or "") if p)


def _fold(parts: Tuple[str, ...]) -> Tuple[str, ...]:
    return tuple(p.casefold() for p in parts)


def match_keys(entries: List[dict], keys: List[str]) -> Tuple[List[Tuple[str, dict]], List[dict]]:
    """Pair Plex entries with AniBox episode keys by the end of their paths.

    A key (``Anime\\Show\\Show 01.mkv`` or ``One Piece\\One Piece\\Season 01\\One Piece 01.mkv``)
    matches an entry when the last N parts of the entry's path are the key's N parts, ignoring
    case. The longest matching key wins. If two different keys match equally well (they differ
    only in upper/lower case), the one with the exact spelling wins, else the entry stays
    unmatched; one entry never gets two keys. Several entries can get the same key (two Plex
    libraries over the same folder); ``apply_history`` merges those.

    Indexed by the whole path tail, so ~15,000 × ~15,000 takes well under a second even when
    every show names its files "E01.mkv".
    """
    index: Dict[Tuple[str, ...], List[str]] = {}
    for key in keys:
        parts = _parts(key)
        if not parts:
            continue
        bucket = index.setdefault(_fold(parts), [])
        if key not in bucket:
            bucket.append(key)
    lengths = sorted({len(k) for k in index}, reverse=True)
    matched: List[Tuple[str, dict]] = []
    unmatched: List[dict] = []
    for entry in entries:
        raw = _parts(str(entry.get("file") or ""))
        folded = _fold(raw)
        choice: Optional[str] = None
        for n in lengths:
            if n > len(folded):
                continue
            bucket = index.get(folded[len(folded) - n:])
            if not bucket:
                continue
            if len(bucket) == 1:
                choice = bucket[0]
            else:
                exact = [k for k in bucket if _parts(k) == raw[len(raw) - n:]]
                choice = exact[0] if len(exact) == 1 else None
            break  # the longest tail decides; a shorter, less specific one never overrules it
        if choice is None:
            unmatched.append(entry)
        else:
            matched.append((choice, entry))
    return matched, unmatched


# -- copying the watch state into AniBox ----------------------------------------------------------


def _show_id(key: str) -> str:
    return "\\".join(key.split("\\")[:2])


def _merge(entries: List[dict]) -> dict:
    """One state per AniBox episode: watched anywhere wins, else the latest resume point."""
    watched = any(e.get("watched") for e in entries)
    latest = max(entries, key=lambda e: (int(_num(e.get("viewed_at"))), _num(e.get("position"))))
    return {
        "watched": watched,
        "position": _num(latest.get("position")),
        "duration": _num(latest.get("duration")),
        "viewed_at": max(int(_num(e.get("viewed_at"))) for e in entries),
    }


def apply_history(store, matched: List[Tuple[str, dict]], profile: Optional[str] = None) -> dict:
    """Copy Plex's watch state into AniBox's database (``match_keys`` output).

    Rules: watched in Plex → watched in AniBox (nothing is ever un-marked). Not watched but at
    least 30 s in → that resume position, only if AniBox has no progress for the episode yet.
    Anything else stays as it is.

    Counts are per AniBox episode: ``watched`` newly marked, ``positions`` resume points saved,
    ``already`` AniBox already had it (watched, or its own progress for a half-watched one),
    ``unchanged`` nothing to take over (never played in Plex, or under 30 s).

    ``profile``: the AniBox profile it goes into (the one that started the import; switching profile
    while it runs doesn't split it). Default: the active one.
    """
    grouped: Dict[str, List[dict]] = {}
    for key, entry in matched:
        grouped.setdefault(key, []).append(entry)

    counts = {"watched": 0, "positions": 0, "already": 0, "unchanged": 0}
    to_mark: Dict[str, List[Tuple[int, str]]] = {}
    positions: List[Tuple[int, str, str, float, float]] = []
    for key, entries in grouped.items():
        state = _merge(entries)
        old = store.progress(key, profile=profile)
        if state["watched"]:
            if old and old.get("watched"):
                counts["already"] += 1
            else:
                to_mark.setdefault(_show_id(key), []).append((state["viewed_at"], key))
                counts["watched"] += 1
        elif state["position"] >= RESUME_MIN_SECONDS:
            if old:
                counts["already"] += 1  # AniBox's own progress is newer knowledge than Plex's
            else:
                positions.append((state["viewed_at"], key, _show_id(key), state["position"], state["duration"]))
                counts["positions"] += 1
        else:
            counts["unchanged"] += 1

    # The Store stamps every write with the current time, and "Continue watching" sorts by that
    # stamp. Writing in the order things were watched in Plex keeps the latest ones on top
    # (as far as the clock's resolution allows). One write per show keeps the import quick.
    ops: List[Tuple[int, int, int, Callable[[], None]]] = []
    for show, items in to_mark.items():
        items.sort()
        keys = [k for _, k in items]
        ops.append((items[-1][0], 0, len(ops), lambda s=show, ks=keys: store.set_watched(ks, s, True, profile=profile)))
    for when, key, show, position, duration in positions:
        ops.append((when, 1, len(ops),
                    lambda k=key, s=show, p=position, d=duration: store.save_position(k, s, p, d, profile=profile)))
    ops.sort(key=lambda o: o[:3])
    for op in ops:
        op[3]()
    return counts


# -- signing in ---------------------------------------------------------------------------------


def _error(message: str) -> dict:
    return {"state": "error", "message": message}


def _probe(uri: str, token: str, client_id: str) -> bool:
    """Does this address answer as a Plex server that accepts the token? (one quick GET)"""
    try:
        _Reader(uri, token, client_id, timeout=PROBE_TIMEOUT, attempts=1).identity()
        return True
    except (PlexError, ValueError, OSError):
        return False


def _saved_info(settings: dict) -> Optional[dict]:
    server, token = settings.get("server"), settings.get("token")
    if not server or not token:
        return None
    info = settings.get(SERVER_INFO_KEY)
    name = info.get("name") if isinstance(info, dict) and info.get("server") == server else ""
    # A sign-in made in the Library Check has no name saved; show the address then.
    return {"name": str(name or server), "url": str(server)}


def saved_credentials() -> Optional[Tuple[str, str, str]]:
    """(server url, server token, client id) for ``fetch_history``, or None. Keep the token server-side."""
    settings = check_cli.load_settings()
    if not settings.get("server") or not settings.get("token"):
        return None
    return str(settings["server"]), str(settings["token"]), str(settings.get("client_id") or DEFAULT_CLIENT_ID)


class SignIn:
    """Sign-in with a code at plex.tv/link, driven by the app window.

    ``start()`` asks plex.tv for a code (one quick request). The window shows the code and calls
    ``poll()`` every second or two. Each ``poll()`` does at most one short request to plex.tv;
    once the code is entered, looking for a reachable server (which can take several seconds per
    address) runs on a background thread while ``poll()`` keeps answering "waiting" with
    ``step: "server"``. Safe to call from several threads.

    States: ``idle`` (not started), ``waiting`` (``step`` "code" or "server", ``code``, ``url``,
    ``message``), ``done`` (``server`` name, ``url``), ``expired`` and ``error`` (``message``).

    On success the server address, the server's own access token and the client id are saved in
    the Library Check's settings.json (keys ``server``, ``token``, ``client_id``, plus
    ``server_info`` for the name), so the Library Check uses the same sign-in. On Windows the
    token is encrypted there for the current Windows user (``anibox_check.secret``);
    ``load_settings``/``save_settings`` handle that, so this code only sees the plain token.
    """

    def __init__(self, plex_tv: str = PLEX_TV, timeout: float = 10.0, min_interval: float = 1.0):
        self.plex_tv = plex_tv
        self.timeout = timeout
        self.min_interval = min_interval  # polls closer together than this don't ask plex.tv again
        self._lock = threading.Lock()
        self._gen = 0  # bumped by start(); answers for an older attempt are dropped
        self._status: dict = {"state": "idle"}
        self._tv: Optional[PlexTv] = None
        self._pin = None
        self._client_id = ""
        self._deadline = 0.0
        self._last_check = 0.0
        self._checking = False
        self._linked = False
        self._errors = 0

    def start(self) -> dict:
        """Ask plex.tv for a new code (drops any earlier attempt)."""
        settings = check_cli.load_settings()
        # Reuse the Library Check's client id, so plex.tv lists one device, not one per sign-in.
        client_id = str(settings.get("client_id") or "") or str(uuid.uuid4())
        tv = PlexTv(client_id, base=self.plex_tv, timeout=self.timeout)
        try:
            pin = tv.create_pin()
        except Exception as exc:  # shown in the app; nothing was changed anywhere
            with self._lock:
                self._gen += 1
                self._status = _error(str(exc) if isinstance(exc, PlexTvError) else f"Could not reach plex.tv ({exc})")
                return dict(self._status)
        with self._lock:
            self._gen += 1
            self._tv, self._pin, self._client_id = tv, pin, client_id
            self._deadline = time.monotonic() + max(0, pin.expires_in)
            self._last_check = 0.0
            self._checking = False
            self._linked = False
            self._errors = 0
            self._status = {
                "state": "waiting", "step": "code", "code": pin.code, "url": LINK_URL,
                "expires_in": pin.expires_in,
                "message": f"Open {LINK_URL} on any device signed in to Plex and enter the code {pin.code}.",
            }
            return dict(self._status)

    def poll(self) -> dict:
        """The current state; checks plex.tv once if the code may have been entered by now."""
        with self._lock:
            status = dict(self._status)
            if status["state"] != "waiting" or self._linked:
                return status
            now = time.monotonic()
            if now >= self._deadline:
                self._status = {"state": "expired", "message": EXPIRED_MESSAGE}
                return dict(self._status)
            if self._checking or now - self._last_check < self.min_interval:
                return status
            self._checking = True
            gen, tv, pin = self._gen, self._tv, self._pin
        token: Optional[str] = None
        expired = False
        problem = ""
        try:
            token = tv.check_pin(pin)
        except PinExpired:
            expired = True
        except (PlexTvError, OSError, http.client.HTTPException, ValueError) as exc:
            problem = str(exc) or type(exc).__name__
        except Exception as exc:  # never leave the state machine stuck in "checking"
            problem = str(exc) or type(exc).__name__
        with self._lock:
            if gen != self._gen:
                return dict(self._status)
            self._checking = False
            self._last_check = time.monotonic()
            if expired:
                self._status = {"state": "expired", "message": EXPIRED_MESSAGE}
                return dict(self._status)
            if problem:
                # A dropped Wi-Fi for a moment shouldn't end the sign-in; many in a row do.
                self._errors += 1
                if self._errors > MAX_NETWORK_ERRORS:
                    self._status = _error(f"Lost the connection to plex.tv ({problem})")
                return dict(self._status)
            self._errors = 0
            if not token:
                return dict(self._status)
            self._linked = True
            self._status = dict(self._status, step="server", message="Signed in. Looking for your Plex server ...")
            status = dict(self._status)
            client_id = self._client_id
        threading.Thread(target=self._finish, args=(gen, tv, token, client_id),
                         daemon=True, name="anibox-plex-signin").start()
        return status

    def saved(self) -> Optional[dict]:
        """``{"name", "url"}`` of the saved sign-in (this app's or the Library Check's), or None. Never the token."""
        return _saved_info(check_cli.load_settings())

    # -- background part -----------------------------------------------------------------------

    def _finish(self, gen: int, tv: PlexTv, account_token: str, client_id: str) -> None:
        try:
            server, address = self._find_server(tv, account_token, client_id)
            url = normalize_server_url(address)
        except Exception as exc:  # shown in the app
            self._set(gen, _error(str(exc) or type(exc).__name__))
            return
        with self._lock:
            if gen != self._gen:
                return  # the user started over meanwhile; don't save the older sign-in
            settings = check_cli.load_settings()
            # Same keys as the Library Check CLI; only the server's own token is kept, not the
            # account token.
            settings.update({
                "client_id": client_id, "server": url, "token": server.access_token,
                SERVER_INFO_KEY: {"name": server.name, "server": url},
            })
            try:
                check_cli.save_settings(settings)
            except OSError as exc:
                self._status = _error(f"Signed in, but couldn't save the sign-in ({exc})")
                return
            self._status = {"state": "done", "server": server.name, "url": url,
                            "message": f"Connected to '{server.name}'."}

    def _find_server(self, tv: PlexTv, account_token: str, client_id: str) -> Tuple[Server, str]:
        servers = tv.servers(account_token)
        if not servers:
            raise PlexTvError("No Plex server found on this Plex account.")
        # Own servers only (sorted first by plextv); a friend's shared server is a last resort.
        candidates = [s for s in servers if s.owned] or servers
        for server in candidates:
            address = find_working_address(server, lambda uri, token: _probe(uri, token, client_id))
            if address:
                return server, address
        names = ", ".join(f"'{s.name}'" for s in candidates)
        them = "it" if len(candidates) == 1 else "them"
        raise PlexTvError(f"Found {names}, but couldn't reach {them} from this computer. Is the server on and awake?")

    def _set(self, gen: int, status: dict) -> None:
        with self._lock:
            if gen == self._gen:
                self._status = status
