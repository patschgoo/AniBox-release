"""Home, library, show and franchise pages, matches, details and episode titles.

Part of the App class (see server.py); the methods use the App's attributes.
"""

from __future__ import annotations

from typing import Optional

from .apierror import ApiError
from .library import entry_json
from .malapi import MalError
from .watching import continue_watching, episode_state, show_card



class RoutesLibraryMixin:
    def _kitsu_id(self, mal_id) -> Optional[str]:
        if self._kitsu_ids is None:
            self._kitsu_ids = {str(m.get("mal_id")): str(m["kitsu_id"]) for m in self.library.datasets().mapping
                               if m.get("mal_id") and m.get("kitsu_id")}
        return self._kitsu_ids.get(str(mal_id)) if mal_id else None

    def _episode_info(self, show_id: str) -> dict:
        """Episode titles/pictures: your file names first, then Kitsu (and the One Piece Wiki)."""
        show = self.library.show(show_id)
        if not show:
            raise ApiError("Show not found", 404)
        online = bool(self.store.settings().get("episode_info", True))
        if online and show.get("mal_id") and not self.episodes.fresh(show) and not self.episodes.status(show_id):
            self.episodes.fetch_async(show, self._kitsu_id(show["mal_id"]))
        state = self.episodes.status(show_id)
        out = {"state": "loading" if state == "loading" else "done", "error": "" if state in ("", "loading") else state,
               "online": online, "episodes": self.episodes.for_show(show, self._plex_episodes(show))}
        return self._tmdb_episode_info(show, out)  # series: titles from TMDB after your own (routes_tmdb.py)

    def _details(self, show_id: str, refresh: bool = False) -> dict:
        show = self.library.show(show_id)
        if not show:
            raise ApiError("Show not found", 404)
        if not show.get("mal_id"):
            return {"details": None}
        client = self.store.settings().get("mal_client_id") or ""
        try:
            d = self.mal.details(show["mal_id"], client, refresh=refresh)
        except MalError as exc:
            return {"details": self.mal.cached(show["mal_id"]), "error": str(exc), "hasClientId": bool(client)}
        return {"details": d, "hasClientId": bool(client)}

    def _franchise_groups(self):
        """[(key, franchise, owned show dicts)] for the selected libraries, plus shows in no franchise."""
        report = self.library.report()
        shows = self.library.shows()
        by_mal = {}
        for sh in shows:
            if sh.get("mal_id"):
                by_mal.setdefault(sh["mal_id"], []).append(sh)
        groups, placed = [], set()
        for fr in report.franchises:
            owned = []
            for e in fr.entries:
                for sh in by_mal.get(e.mal_id, []):
                    if sh["id"] not in placed:
                        placed.add(sh["id"])
                        owned.append(sh)
            if owned:
                key = "f" + min((e.mal_id for e in fr.entries), key=lambda m: int(m) if m.isdigit() else 0)
                groups.append((key, fr, owned))
        loose = [sh for sh in shows if sh["id"] not in placed]
        return groups, loose

    def _franchises(self) -> dict:
        settings = self.store.settings()
        posters = bool(settings.get("posters", True))
        progress = self.store.all_progress()
        groups, loose = self._franchise_groups()
        out = []
        for key, fr, owned in groups:
            cards = sorted((show_card(sh, progress, posters) for sh in owned),
                           key=lambda c: (c["year"] or 9999, c["title"].casefold()))
            if len(cards) == 1 and fr.count("missing") == 0:
                out.append(dict(self._cards_with_langs([(owned[0], cards[0])])[0], kind="show"))
                continue
            out.append({
                "kind": "franchise", "key": key, "title": fr.name, "poster": next((c["poster"] for c in cards if c["poster"]), ""),
                "shows": len(cards), "files": sum(c["files"] for c in cards), "watched": sum(c["watched"] for c in cards),
                "have": fr.count("owned", include_short=True), "total": len(fr.entries), "missing": fr.count("missing"),
                "finished": all(c["finished"] for c in cards), "started": any(c["started"] for c in cards),
                "last_played": max(c["last_played"] for c in cards), "year": cards[0]["year"],
                "library": cards[0]["library"], "libraries": sorted({c["library"] for c in cards}),
            })
        out += [dict(c, kind="show") for c in self._tmdb_cards(self._cards_with_langs([(sh, show_card(sh, progress, posters)) for sh in loose]))]
        out.sort(key=lambda c: c["title"].casefold())
        return {"items": out, "libraries": self.library.selected_libraries()}

    def _franchise(self, key: str) -> dict:
        settings = self.store.settings()
        posters = bool(settings.get("posters", True))
        progress = self.store.all_progress()
        groups, _ = self._franchise_groups()
        for k, fr, owned in groups:
            if k == key:
                cards = sorted(self._cards_with_langs([(sh, show_card(sh, progress, posters)) for sh in owned]),
                               key=lambda c: (c["year"] or 9999, c["title"].casefold()))
                return {"key": k, "title": fr.name, "shows": cards,
                        "entries": [entry_json(e) for e in fr.entries],
                        "have": fr.count("owned", include_short=True), "total": len(fr.entries),
                        "missing": fr.count("missing")}
        raise ApiError("Franchise not found", 404)

    def _home(self) -> dict:
        settings = self.store.settings()
        shows = self.library.shows()
        progress = self.store.all_progress()
        posters = bool(settings.get("posters", True))
        recent = sorted(shows, key=lambda s: s.get("added", 0), reverse=True)[:14]
        by_id = {sh["id"]: sh for sh in shows}
        cont = continue_watching(shows, progress, posters)
        return {
            "continue": self._tmdb_cards(self._cards_with_langs([(by_id[c["id"]], c) for c in cont])),
            "recent": self._tmdb_cards(self._cards_with_langs([(s, show_card(s, progress, posters)) for s in recent])),
            "counts": {"shows": len(shows), "episodes": sum(len(s["episodes"]) for s in shows),
                       "matched": sum(1 for s in shows if s.get("mal_id"))},
            "hasFolders": bool(settings.get("folders")),
            "scannedAt": self.library.scanned_at,
            "update": self.updates.info() if settings.get("update_check", True) else None,
            "localUpdate": self._local_update(),
            "updateResult": self._update_result(),
        }

    def _update_result(self) -> Optional[dict]:
        if self.update_result is None and not self._update_result_checked_late:
            self.update_result = self.selfupdate.take_result()  # the helper may have written it after the start
            self._update_result_checked_late = self.update_result is not None
        return self.update_result

    def _local_update(self) -> Optional[dict]:
        """A newer AniBox zip in Downloads that "Update now" can install, or None."""
        try:
            if self.selfupdate.why_not():
                return None
            from .selfupdate import downloads_dir, find_update
            found = find_update(downloads_dir())["found"]
            return {"version": found["version"], "name": found["name"]} if found else None
        except Exception:  # never let this break the Home page
            return None

    def _library(self) -> dict:
        settings = self.store.settings()
        progress = self.store.all_progress()
        posters = bool(settings.get("posters", True))
        shows = self.library.shows()
        cards = self._cards_with_langs([(s, show_card(s, progress, posters)) for s in shows])
        kinds = {s["id"]: self.library.show_kind(s) for s in shows}
        for c in cards:
            c["kind"], c["atype"] = kinds.get(c["id"], ("series", ""))
        self._tmdb_cards(cards)  # series and movies: TMDB posters (routes_tmdb.py)
        cards.sort(key=lambda c: c["title"].casefold())
        libs = self.library.selected_libraries()
        return {"shows": cards, "libraries": libs, "kinds": {n: self.library.library_kind(n) for n in libs}}

    def _show(self, show_id: str) -> dict:
        show = self.library.show(show_id)
        if not show:
            raise ApiError("Show not found", 404)
        settings = self.store.settings()
        progress = self.store.all_progress()
        card = show_card(show, progress, bool(settings.get("posters", True)))
        card.update(self._langs(show))
        self._tmdb_cards([card])  # series and movies: the TMDB poster (routes_tmdb.py)
        lock = self.library.lock_view(show)
        eps = []
        for e in show["episodes"]:
            st = episode_state(e, progress)
            eps.append({"key": e["key"], "label": e["label"], "file": e["file"], "season": e["season"],
                        "number": e["number"], "locked": e["key"] in lock["keys"], **st})
        try:
            missing = self.library.missing_for(show)
        except Exception:
            missing = []
        locked_show = bool(lock["keys"])
        lock.pop("keys")
        card["plex"] = self._plex_for_show(show)
        if card["plex"]:
            card["plex"]["locked"] = locked_show
            if card["plex"]["malId"] and card["plex"]["malId"] != (show.get("mal_id") or ""):
                card["plex"]["malTitle"] = (self.library.datasets().titles.get(card["plex"]["malId"]) or {}).get("title", "")
        card.update(episodes=eps, missing=missing, note=show.get("note") or "", manual=bool(show.get("manual")), lock=lock,
                    malUrl=f"https://myanimelist.net/anime/{show['mal_id']}" if show.get("mal_id") else "",
                    hasClientId=bool(settings.get("mal_client_id")))
        return card

    def _set_watched(self, body: dict) -> dict:
        watched = bool(body.get("watched", True))
        keys = [str(k) for k in body.get("keys") or []]
        show_id = str(body.get("show") or "")
        if show_id and not keys:
            show = self.library.show(show_id)
            if not show:
                raise ApiError("Show not found", 404)
            keys = [e["key"] for e in show["episodes"]]
        if not keys:
            raise ApiError("Nothing to mark")
        show_of = {}
        for k in keys:
            show, idx = self.library.episode(k)
            if show and idx >= 0:
                show_of[k] = show["id"]
        for k, sid in show_of.items():
            self.store.set_watched([k], sid, watched)
        return {"ok": True, "count": len(show_of)}
