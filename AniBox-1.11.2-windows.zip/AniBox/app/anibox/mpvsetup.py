"""Download the mpv player for Windows (once, about 34 MB).

The same build Frostbox uses for its player (shinchiro/mpv-winbuild-cmake, 2026-11-05), pinned by
version and checksum. It's unpacked with Windows' own tar.exe into %LOCALAPPDATA%\\AniBox\\mpv.
"""

from __future__ import annotations

import hashlib
import logging
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import urllib.request
from pathlib import Path

log = logging.getLogger("anibox.mpv")

VERSION = "20261105"
ASSET = "mpv-x86_64-20261105-git-3138fc8eea.7z"
SHA256 = "89aa56f9769f81f783576183212e7b4802c91909ecf860b4468113cbfd106d93"
SIZE = 34199875
URL = f"https://github.com/shinchiro/mpv-winbuild-cmake/releases/download/{VERSION}/{ASSET}"


class MpvSetup:
    def __init__(self, data_dir: Path, url: str = URL, sha256: str = SHA256):
        self.target = data_dir.parent / "mpv"
        self.url = url
        self.sha256 = sha256
        self.status = {"state": "idle", "received": 0, "total": SIZE, "message": ""}
        self._thread = None

    def start(self) -> bool:
        if self.status["state"] == "running":
            return False
        if not sys.platform.startswith("win"):
            self.status = {"state": "error", "received": 0, "total": SIZE,
                           "message": "The automatic download is for Windows. Install mpv with your package manager."}
            return False
        self.status = {"state": "running", "received": 0, "total": SIZE, "message": "Downloading mpv …"}
        self._thread = threading.Thread(target=self._run, daemon=True, name="anibox-mpv-setup")
        self._thread.start()
        return True

    def _run(self) -> None:
        tmp = Path(tempfile.mkdtemp(prefix="anibox-mpv-"))
        try:
            archive = tmp / ASSET
            self.download(archive)
            self.status["message"] = "Unpacking …"
            unpack = tmp / "unpacked"
            unpack.mkdir()
            self.unpack(archive, unpack)
            if not (unpack / "mpv.exe").is_file():
                raise RuntimeError("mpv.exe wasn't in the download.")
            if self.target.exists():
                shutil.rmtree(self.target)
            shutil.copytree(unpack, self.target)
            self.status.update(state="done", message="mpv is ready.")
            log.info("mpv %s installed in %s", VERSION, self.target)
        except Exception as exc:
            log.exception("mpv setup failed")
            self.status.update(state="error", message=f"Couldn't set up mpv: {exc}")
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    @staticmethod
    def unpack(archive: Path, dest: Path) -> None:
        """Windows' own tar.exe first (Windows 11 opens .7z); 7-Zip if it's installed and tar can't."""
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        tools = [[os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32", "tar.exe"),
                  "-xf", str(archive), "-C", str(dest)]]
        for base in (os.environ.get("ProgramFiles", r"C:\Program Files"), os.environ.get("ProgramFiles(x86)", "")):
            if base and os.path.isfile(os.path.join(base, "7-Zip", "7z.exe")):
                tools.append([os.path.join(base, "7-Zip", "7z.exe"), "x", "-y", f"-o{dest}", str(archive)])
        errors = []
        for cmd in tools:
            try:
                r = subprocess.run(cmd, capture_output=True, creationflags=flags, timeout=300)
            except (OSError, subprocess.TimeoutExpired) as exc:
                errors.append(f"{os.path.basename(cmd[0])}: {exc}")
                continue
            if r.returncode == 0 and (dest / "mpv.exe").is_file():
                return
            errors.append(f"{os.path.basename(cmd[0])}: {(r.stderr or r.stdout or b'').decode('utf-8', 'replace').strip()[:200]}")
        log.warning("Unpacking mpv failed: %s", errors)
        raise RuntimeError("Windows couldn't unpack the mpv download. Install 7-Zip (7-zip.org) and click "
                           "Download mpv again, or install mpv from mpv.io and enter its path below.")

    def download(self, dest: Path) -> None:
        req = urllib.request.Request(self.url, headers={"User-Agent": "AniBox"})
        digest = hashlib.sha256()
        with urllib.request.urlopen(req, timeout=120) as resp, open(dest, "wb") as out:
            total = int(resp.headers.get("Content-Length") or SIZE)
            self.status["total"] = total
            while True:
                chunk = resp.read(1 << 20)
                if not chunk:
                    break
                out.write(chunk)
                digest.update(chunk)
                self.status["received"] += len(chunk)
        if digest.hexdigest().lower() != self.sha256.lower():
            raise RuntimeError("the download is damaged (checksum doesn't match). Try again.")
