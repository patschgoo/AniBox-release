"""Settings and watch progress, kept in a small SQLite database in AniBox's data folder.

Episodes are identified by their path *inside* the share (``Anime\\Show\\Show 01.mkv``), so
progress survives a changed IP address or drive letter.

Profiles ("Who's watching?"): each profile has its own watch progress and resume points
(``progress``), its own audio/subtitle choice per show (``show_prefs``) and a few settings of its own
(``PROFILE_SETTINGS``). Everything else is shared: the other settings, locks, matches by hand, the
languages found in the files. ``Store.profile`` is the active profile; every progress method works on
it unless the caller passes ``profile=`` (the players do: they save to the profile that was active
when the episode started). The first profile is ``main`` ("Me"). A database from before profiles is
moved into it once (``_migrate_profiles``), after a copy in ``backups\\before-profiles-….db``.
"""

from __future__ import annotations

import hashlib
import hmac
import inspect
import json
import logging
import os
import re
import secrets
import sqlite3
import threading
import time
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

log = logging.getLogger("anibox.store")

DEFAULTS = {
    "folders": [],  # folders to scan (shares or library folders)
    "libraries": [],  # library folders to show; empty = all
    "mpv_path": "",
    "fullscreen": True,
    "resume_back": 10,  # seconds to go back when resuming (Frostbox default)
    "watched_at": 95,  # percent of an episode that counts as watched (Frostbox default)
    "autoplay": True,
    "countdown": 8,  # seconds before the next episode starts
    "still_watching_after": 3,  # episodes in a row without touching anything, then ask (0 = never)
    "remote_enabled": False,
    "remote_port": 43211,
    "remote_key": "",
    "posters": True,
    "audio_langs": "",  # preferred audio languages, e.g. "jpn,ger" (empty = what the file says)
    "sub_langs": "",  # preferred subtitle languages, e.g. "ger,eng"
    "subs": "auto",  # auto (what the file says), on (always pick one), off
    "skip_openings": "button",  # off, button, auto (needs chapters named Opening/OP in the file)
    "skip_endings": "button",
    "update_check": True,
    "release_repo": "patschgoo/AniBox-release",  # where new versions are published (updates.py)
    "mal_client_id": "",  # optional, for descriptions/scores/genres from the official MyAnimeList API
    "protected": [],  # folders AniBox never writes into (NFO export); old episodes are locked anyway
    "tv_device": "",  # last TV used for "Play on TV"
    "chromecast": True,  # Play on TV also finds Chromecasts / Google Cast devices (chromecast.py)
    "mpv_log": False,  # write mpv's own detailed log to logs/mpv.log
    "protect_existing": True,  # episodes that were already there are locked (see Store.lock_snapshot)
    "episode_info": True,  # episode titles and pictures from Kitsu (and the One Piece Wiki)
    "library_kinds": {},  # library folder -> anime / series / movies; missing = decided automatically
    "inbox_folders": [],  # where "Add new videos" looks; empty = the Downloads folder
    "import_mode": "move",
    "import_write_nfo": False,  # Add new videos: also write info files (.nfo) for the new episodes
    "plex_scan_section": "",  # Add new videos: then ask this Plex library (key) to scan; "" = don't  # move (the download disappears from Downloads) or copy
    "embed_player": True,  # Windows: play inside the AniBox window (embed.py), else in mpv's own window
    "plex_check_sections": [],  # Plex libraries the Missing page checks (keys); empty = all
    "ia_download_dir": "",  # Internet Archive downloads; empty = Downloads\AniBox Internet Archive
    "ia_add_to_library": True,  # scan finished Internet Archive downloads into the library
    "airing_notices": True,  # Home: "Episode 7 is out" for shows you watch, air dates from AniList (airing.py)
    "mal_username": "",  # your MyAnimeList user name (a public list is read with the Client ID)
    "anilist_username": "",  # your AniList user name (public profiles need no sign-in)
    "anilist_client_id": "",  # your own AniList app, only needed to connect for sync
    "lists_rewatch": False,  # when you watch a finished show again: count it as a rewatch on your lists
    "lists_source": "",  # mal or anilist: which list the cards and the Lists page show first
    "tmdb_api_key": "",  # optional, posters/descriptions/episode titles for series and movies from TMDB (tmdb.py)
    "ffmpeg_path": "",  # folder with ffmpeg/ffprobe (or ffmpeg.exe); empty = the downloaded copy, then PATH
    "ia_cache": True,  # Internet Archive streams load into a cache on this PC first (iacache.py)
    "ia_cache_dir": "",  # empty = <AniBox data folder>\app\ia-cache
    "ia_cache_gb": 20,  # the cache never grows over this (kept episodes don't count)
    "ia_cache_connections": 8,  # parallel connections to archive.org per file
    "ia_cache_ahead": 2,  # episodes loaded ahead of the one playing
    "ia_keep_dir": "",  # "Keep": empty = "AniBox Keep" beside the Internet Archive download folder
    "anilist_info": True,  # show pages: banner, characters, staff, tags, trailer from AniList (anilistinfo.py)
    "anilist_cast": "",  # voice actors shown first: ja, de, en; empty = from audio_langs
    "tv_copy_dir": "",  # TV copies (tvcopy.py): empty = <AniBox data folder>\app\tv-copies; never inside a library folder
    "tv_copy_encoder": "auto",  # auto (NVIDIA, Intel, AMD graphics if one works, else the processor), nvidia, intel, amd, cpu
    "tv_copy_audio": "ac3",  # DTS/TrueHD and other sound the TV can't play: ac3 (keeps 5.1) or aac (stereo)
    "watch_inbox": True,  # while AniBox runs: notice new videos in the "Add new videos" folders (watchfolders.py)
    "auto_rescan_minutes": 0,  # while AniBox runs: quick rescan of the library folders every N minutes (0 = off)
    "intro_auto": False,  # find openings/endings by comparing episodes when a show's page opens (introdetect.py)
}

PRIVATE_SETTINGS = ("remote_key",)

# -- profiles ------------------------------------------------------------------------------------------

MAIN = "main"  # the first profile; it can be renamed, never deleted or restricted
# Settings each profile has for itself (written to the active profile; the shared value is the default).
PROFILE_SETTINGS = ("audio_langs", "sub_langs", "subs", "skip_openings", "skip_endings", "autoplay",
                    "still_watching_after")
MAX_PROFILES = 12
COLORS = ("#7FD3FF", "#FF9F6E", "#C3B4FF", "#5EE0A0", "#F472B6", "#F0C674", "#60A5FA", "#FF6B6B")
PIN_ITERATIONS = 200_000
PIN_RE = re.compile(r"[0-9]{4,8}")
PIN_HASH_RE = re.compile(r"pbkdf2_sha256\$([0-9]{4,7})\$[0-9a-f]{32}\$[0-9a-f]{64}")
PROFILE_ID_RE = re.compile(r"main|p[0-9a-f]{8}")


def hash_pin(pin: str) -> str:
    """A PIN (4–8 digits) as a salted PBKDF2 hash; the PIN itself is never kept."""
    if not PIN_RE.fullmatch(pin or ""):
        raise ValueError("A PIN has 4 to 8 digits.")
    salt = os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", pin.encode("ascii"), salt, PIN_ITERATIONS)
    return f"pbkdf2_sha256${PIN_ITERATIONS}${salt.hex()}${digest.hex()}"


def verify_pin(stored: str, pin: str) -> bool:
    if not stored or not PIN_HASH_RE.fullmatch(stored) or not PIN_RE.fullmatch(str(pin or "")):
        return False
    _, iterations, salt, digest = stored.split("$")
    if int(iterations) > 2_000_000:  # a damaged or made-up hash must not keep AniBox busy
        return False
    got = hashlib.pbkdf2_hmac("sha256", str(pin).encode("ascii"), bytes.fromhex(salt), int(iterations))
    return hmac.compare_digest(got.hex(), digest)


def _clean_name(value) -> str:
    text = "".join(c for c in str(value or "") if c.isprintable())
    return " ".join(text.split())[:30]


def _clean_color(value) -> str:
    text = str(value or "").strip()
    return text.upper() if re.fullmatch(r"#[0-9A-Fa-f]{6}", text) else ""


def _clean_emoji(value) -> str:
    """An emoji (or a letter or two) shown instead of the first letter of the name."""
    text = "".join(c for c in str(value or "") if c.isprintable() and not c.isspace() and c not in "<>&\"'")
    return text[:8]


def clean_restrictions(raw, profile_id: str) -> dict:
    """{"restricted", "libraries", "hideAdult", "archive"}. Only a restricted (kids) profile is limited;
    ``main`` never is, so there's always a profile that can open Settings."""
    r = raw if isinstance(raw, dict) else {}
    on = bool(r.get("restricted")) and profile_id != MAIN
    if not on:
        return {"restricted": False, "libraries": [], "hideAdult": False, "archive": True}
    libs = r.get("libraries") if isinstance(r.get("libraries"), list) else []
    return {"restricted": True, "libraries": sorted({str(x).strip() for x in libs if str(x).strip()})[:200],
            "hideAdult": bool(r.get("hideAdult", True)), "archive": bool(r.get("archive", False))}


def _loads(text, default):
    try:
        value = json.loads(text) if text else default
    except (TypeError, ValueError):
        return default
    return value if isinstance(value, type(default)) else default


def _call_hook(fn, key: str, show: str, profile: str) -> None:
    """Watched hooks get the profile when they take it (``fn(key, show, profile=...)``); older ones
    (``fn(key, show)``) still work."""
    try:
        params = inspect.signature(fn).parameters.values()
        takes = any(p.name == "profile" or p.kind is p.VAR_KEYWORD for p in params)
    except (TypeError, ValueError):
        takes = False
    if takes:
        fn(key, show, profile=profile)
    else:
        fn(key, show)


PROGRESS_TABLE = """CREATE TABLE IF NOT EXISTS progress (
    profile TEXT NOT NULL DEFAULT 'main',
    key TEXT NOT NULL,
    show TEXT NOT NULL DEFAULT '',
    position REAL NOT NULL DEFAULT 0,
    duration REAL NOT NULL DEFAULT 0,
    watched INTEGER NOT NULL DEFAULT 0,
    updated REAL NOT NULL DEFAULT 0,
    PRIMARY KEY (profile, key)
)"""
SHOW_PREFS_TABLE = """CREATE TABLE IF NOT EXISTS show_prefs (
    profile TEXT NOT NULL DEFAULT 'main',
    show TEXT NOT NULL,
    audio TEXT NOT NULL DEFAULT '',
    sub TEXT NOT NULL DEFAULT '',
    PRIMARY KEY (profile, show)
)"""
PROGRESS_COLS = "key, show, position, duration, watched, updated"
OLD_COLUMNS = {"progress": PROGRESS_COLS, "show_prefs": "show, audio, sub"}
NEW_TABLES = {"progress": PROGRESS_TABLE, "show_prefs": SHOW_PREFS_TABLE}

# progress and show_prefs are made by _migrate_profiles (keyed by profile).
SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS overrides (show TEXT PRIMARY KEY, mal_id TEXT NOT NULL, updated REAL NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS profiles (id TEXT PRIMARY KEY, name TEXT NOT NULL, color TEXT NOT NULL DEFAULT '',
    emoji TEXT NOT NULL DEFAULT '', pin TEXT NOT NULL DEFAULT '', restrictions TEXT NOT NULL DEFAULT '{}',
    settings TEXT NOT NULL DEFAULT '{}', created REAL NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS locked (key TEXT PRIMARY KEY);
CREATE TABLE IF NOT EXISTS unlocked_shows (show TEXT PRIMARY KEY);
CREATE TABLE IF NOT EXISTS show_langs (show TEXT PRIMARY KEY, audio TEXT NOT NULL DEFAULT '[]', subs TEXT NOT NULL DEFAULT '[]',
    source TEXT NOT NULL DEFAULT '', manual_audio TEXT, manual_subs TEXT, updated REAL NOT NULL DEFAULT 0);
"""


class Store:
    def __init__(self, path: Path):
        self.path = path
        self._lock = threading.RLock()
        # fn(key, show, profile=...) (or fn(key, show)), called when a player saves an episode as watched (routes_lists.py)
        self.watched_hooks = []
        # Called after move_keys with (episodes, shows): e.g. collections follow a renamed show folder.
        self.moved_hooks = []
        self.export_check = None  # fn() that raises when a backup may not be downloaded right now (routes_profiles.py)
        self._db = sqlite3.connect(str(path), check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        with self._lock:
            self._db.executescript(SCHEMA)
            # Columns added after 1.3.0 (subtitle types)
            cols = {r[1] for r in self._db.execute("PRAGMA table_info(show_langs)").fetchall()}
            if "subtypes" not in cols:
                self._db.execute("ALTER TABLE show_langs ADD COLUMN subtypes TEXT NOT NULL DEFAULT '[]'")
            if "manual_subtypes" not in cols:
                self._db.execute("ALTER TABLE show_langs ADD COLUMN manual_subtypes TEXT")
            self._db.commit()
            self._migrate_profiles()
        active = self.meta("active_profile")
        self.profile = active if isinstance(active, str) and self.profile_row(active) else MAIN
        if not self.settings().get("remote_key"):
            self.update_settings({"remote_key": secrets.token_urlsafe(9)})

    def close(self) -> None:
        with self._lock:
            self._db.close()

    # -- profiles: the database from before profiles moves into "main" (once) ----------------------------

    def _columns(self, table: str) -> List[str]:
        return [r[1] for r in self._db.execute(f"PRAGMA table_info({table})").fetchall()]

    def _migrate_profiles(self) -> None:
        """``progress`` and ``show_prefs`` keyed by (profile, key/show). A database from before profiles
        (1.10 and older: keyed by key/show alone) is copied to ``backups\\before-profiles-<time>.db`` first;
        then, in one transaction, its rows move into the profile ``main``. If anything goes wrong nothing
        changes (and AniBox doesn't start, rather than work on half a database). Safe to run again: a
        database that has the profile column already is left as it is."""
        db = self._db
        stale = [t for t in ("progress", "show_prefs") if self._columns(t) and "profile" not in self._columns(t)]
        if stale:
            stamp = time.strftime("%Y-%m-%d-%H%M%S")
            copy = self.path.parent / "backups" / f"before-profiles-{stamp}.db"
            try:
                self.copy_to(copy)
            except Exception as exc:
                raise RuntimeError(f"AniBox couldn't make a safety copy of your watch progress ({exc}), so it "
                                   "didn't change the database. Free some space and start AniBox again.") from exc
            log.info("Before profiles: copy of the database saved as %s", copy)
            try:
                db.execute("BEGIN IMMEDIATE")
                moved = {}
                for table in stale:
                    old = f"{table}_before_profiles"
                    db.execute(f"ALTER TABLE {table} RENAME TO {old}")
                    db.execute(NEW_TABLES[table])
                    cols = OLD_COLUMNS[table]
                    db.execute(f"INSERT INTO {table}(profile, {cols}) SELECT ?, {cols} FROM {old}", (MAIN,))
                    before = db.execute(f"SELECT COUNT(*) FROM {old}").fetchone()[0]
                    after = db.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
                    if before != after:
                        raise RuntimeError(f"{table}: {before} rows before, {after} after")
                    db.execute(f"DROP TABLE {old}")
                    moved[table] = after
                db.execute("INSERT OR IGNORE INTO profiles(id, name, color, created) VALUES(?,?,?,?)",
                           (MAIN, "Me", COLORS[0], time.time()))
                db.execute("INSERT INTO meta(key, value) VALUES('profiles_since', ?) "
                           "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (json.dumps(time.time()),))
                db.commit()
            except Exception:
                db.rollback()
                log.exception("Moving the watch progress into profiles failed; nothing was changed")
                raise
            log.info("Watch progress moved into the profile \"main\": %s", moved)
        db.execute(PROGRESS_TABLE)
        db.execute(SHOW_PREFS_TABLE)
        db.execute("CREATE INDEX IF NOT EXISTS progress_profile_show ON progress(profile, show)")
        db.execute("CREATE INDEX IF NOT EXISTS progress_profile_updated ON progress(profile, updated)")
        db.execute("INSERT OR IGNORE INTO profiles(id, name, color, created) VALUES(?,?,?,?)",
                   (MAIN, "Me", COLORS[0], time.time()))
        db.commit()
        self._compat_indexes()

    def _compat_indexes(self) -> None:
        """While "main" is the only profile, AniBox 1.10 and older can still use this database (say an
        update went back to the old version): their upserts need ``key``/``show`` unique on their own,
        and their rows get the profile "main" by default. The second profile ends that."""
        with self._lock:
            db = self._db
            single = db.execute("SELECT COUNT(*) FROM profiles").fetchone()[0] <= 1 and all(
                db.execute(f"SELECT 1 FROM {t} WHERE profile != ? LIMIT 1", (MAIN,)).fetchone() is None
                for t in ("progress", "show_prefs"))
            if single:
                db.execute("CREATE UNIQUE INDEX IF NOT EXISTS progress_key_main ON progress(key)")
                db.execute("CREATE UNIQUE INDEX IF NOT EXISTS show_prefs_show_main ON show_prefs(show)")
            else:
                db.execute("DROP INDEX IF EXISTS progress_key_main")
                db.execute("DROP INDEX IF EXISTS show_prefs_show_main")
            db.commit()

    def _pid(self, profile: Optional[str]) -> str:
        return profile or self.profile

    def _gone(self, profile: Optional[str]) -> bool:
        """A player still saving for a profile that was deleted meanwhile: nothing is written."""
        return bool(profile) and profile != self.profile and self.profile_row(profile) is None

    # -- settings ----------------------------------------------------------------------------

    def settings(self, profile: Optional[str] = None) -> dict:
        """All settings; ``PROFILE_SETTINGS`` as the profile (default: the active one) has them."""
        with self._lock:
            rows = self._db.execute("SELECT key, value FROM settings").fetchall()
            own = self._db.execute("SELECT settings FROM profiles WHERE id=?", (self._pid(profile),)).fetchone()
        out = dict(DEFAULTS)
        for r in rows:
            try:
                out[r["key"]] = json.loads(r["value"])
            except ValueError:
                continue
        if own:
            mine = _loads(own["settings"], {})
            out.update({k: mine[k] for k in PROFILE_SETTINGS if k in mine})
        return out

    def update_settings(self, changes: dict, profile: Optional[str] = None) -> dict:
        """``PROFILE_SETTINGS`` go to the profile (default: the active one), the rest is shared."""
        allowed = {k: v for k, v in changes.items() if k in DEFAULTS}
        pid = self._pid(profile)
        with self._lock:
            own = self._db.execute("SELECT settings FROM profiles WHERE id=?", (pid,)).fetchone()
            mine = {k: v for k, v in allowed.items() if k in PROFILE_SETTINGS} if own else {}
            for k, v in allowed.items():
                if k in mine:
                    continue
                self._db.execute(
                    "INSERT INTO settings(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                    (k, json.dumps(v)),
                )
            if mine:
                merged = dict(_loads(own["settings"], {}), **mine)
                self._db.execute("UPDATE profiles SET settings=? WHERE id=?", (json.dumps(merged), pid))
            self._db.commit()
        return self.settings(pid)

    # -- progress (of the active profile, or the one passed) ------------------------------------------

    def progress(self, key: str, profile: Optional[str] = None) -> Optional[dict]:
        with self._lock:
            r = self._db.execute(f"SELECT {PROGRESS_COLS} FROM progress WHERE profile=? AND key=?",
                                 (self._pid(profile), key)).fetchone()
        return dict(r) if r else None

    def all_progress(self, profile: Optional[str] = None) -> Dict[str, dict]:
        with self._lock:
            rows = self._db.execute(f"SELECT {PROGRESS_COLS} FROM progress WHERE profile=?",
                                    (self._pid(profile),)).fetchall()
        return {r["key"]: dict(r) for r in rows}

    def progress_everywhere(self, key: str) -> Dict[str, dict]:
        """This episode's progress in every profile that has some: profile id -> row."""
        with self._lock:
            rows = self._db.execute(f"SELECT profile, {PROGRESS_COLS} FROM progress WHERE key=?", (key,)).fetchall()
        return {r["profile"]: {k: r[k] for k in r.keys() if k != "profile"} for r in rows}

    def watched_by_everyone(self) -> Dict[str, float]:
        """Episodes every profile that started them has finished: key -> when the last one finished.
        (For clean-ups that shouldn't take away what someone is in the middle of.)"""
        with self._lock:
            rows = self._db.execute("SELECT key, MIN(watched) AS all_w, MAX(updated) AS last FROM progress "
                                    "GROUP BY key").fetchall()
        return {r["key"]: float(r["last"] or 0) for r in rows if r["all_w"]}

    def save_position(self, key: str, show: str, position: float, duration: float, watched: Optional[bool] = None,
                      profile: Optional[str] = None) -> None:
        if self._gone(profile):
            return
        pid = self._pid(profile)
        now = time.time()
        with self._lock:
            old = self._db.execute("SELECT watched FROM progress WHERE profile=? AND key=?", (pid, key)).fetchone()
            w = int(watched) if watched is not None else (old["watched"] if old else 0)
            self._db.execute(
                "INSERT INTO progress(profile, key, show, position, duration, watched, updated) VALUES(?,?,?,?,?,?,?) "
                "ON CONFLICT(profile, key) DO UPDATE SET show=excluded.show, position=excluded.position, "
                "duration=excluded.duration, watched=excluded.watched, updated=excluded.updated",
                (pid, key, show, float(position or 0), float(duration or 0), w, now),
            )
            self._db.commit()
        if watched:
            for fn in list(self.watched_hooks):
                try:
                    _call_hook(fn, key, show, pid)
                except Exception:  # a hook never stops the progress from being saved
                    pass

    def set_watched(self, keys: Iterable[str], show: str, watched: bool, profile: Optional[str] = None) -> None:
        if self._gone(profile):
            return
        pid = self._pid(profile)
        now = time.time()
        with self._lock:
            for key in keys:
                self._db.execute(
                    "INSERT INTO progress(profile, key, show, position, duration, watched, updated) VALUES(?,?,?,0,0,?,?) "
                    "ON CONFLICT(profile, key) DO UPDATE SET watched=excluded.watched, position=0, updated=excluded.updated",
                    (pid, key, show, int(watched), now),
                )
            self._db.commit()

    def delete_progress(self, keys: Iterable[str], profile: Optional[str] = None) -> None:
        """Forget these episodes' progress (they count as never played)."""
        pid = self._pid(profile)
        with self._lock:
            for key in keys:
                self._db.execute("DELETE FROM progress WHERE profile=? AND key=?", (pid, key))
            self._db.commit()

    def restore_progress(self, rows: Dict[str, Optional[dict]], profile: Optional[str] = None) -> None:
        """Put rows back exactly as they were (an undo): a row dict, or None = no row."""
        if self._gone(profile):
            return
        pid = self._pid(profile)
        with self._lock:
            for key, row in rows.items():
                if row is None:
                    self._db.execute("DELETE FROM progress WHERE profile=? AND key=?", (pid, key))
                else:
                    self._db.execute(
                        "INSERT OR REPLACE INTO progress(profile, key, show, position, duration, watched, updated) "
                        "VALUES(?,?,?,?,?,?,?)",
                        (pid, key, str(row.get("show") or ""), float(row.get("position") or 0),
                         float(row.get("duration") or 0), int(bool(row.get("watched"))), float(row.get("updated") or 0)))
            self._db.commit()

    def recent_shows(self, limit: int = 12, profile: Optional[str] = None) -> List[str]:
        """Shows played most recently, newest first."""
        with self._lock:
            rows = self._db.execute(
                "SELECT show, MAX(updated) AS u FROM progress WHERE profile=? AND show != '' GROUP BY show "
                "ORDER BY u DESC LIMIT ?", (self._pid(profile), limit),
            ).fetchall()
        return [r["show"] for r in rows]

    # -- manual matches ("this folder is MAL entry X", or "" = no MAL entry) --------------------

    def overrides(self) -> Dict[str, str]:
        with self._lock:
            rows = self._db.execute("SELECT show, mal_id FROM overrides").fetchall()
        return {r["show"]: r["mal_id"] for r in rows}

    def set_override(self, show: str, mal_id: Optional[str]) -> None:
        """``mal_id`` None removes the manual match (back to automatic)."""
        with self._lock:
            if mal_id is None:
                self._db.execute("DELETE FROM overrides WHERE show=?", (show,))
            else:
                self._db.execute(
                    "INSERT INTO overrides(show, mal_id, updated) VALUES(?,?,?) "
                    "ON CONFLICT(show) DO UPDATE SET mal_id=excluded.mal_id, updated=excluded.updated",
                    (show, str(mal_id), time.time()))
            self._db.commit()

    def override_times(self) -> List[Tuple[str, str, float]]:
        """(show, mal_id, when it was set) of every match by hand, for the History page."""
        with self._lock:
            rows = self._db.execute("SELECT show, mal_id, updated FROM overrides").fetchall()
        return [(r["show"], r["mal_id"], float(r["updated"] or 0)) for r in rows]

    # -- audio/subtitle choice per show -----------------------------------------------------------

    def show_pref(self, show: str, profile: Optional[str] = None) -> dict:
        with self._lock:
            r = self._db.execute("SELECT audio, sub FROM show_prefs WHERE profile=? AND show=?",
                                 (self._pid(profile), show)).fetchone()
        return {"audio": r["audio"], "sub": r["sub"]} if r else {"audio": "", "sub": ""}

    def set_show_pref(self, show: str, audio: Optional[str] = None, sub: Optional[str] = None,
                      profile: Optional[str] = None) -> None:
        if self._gone(profile):
            return
        pid = self._pid(profile)
        cur = self.show_pref(show, pid)
        audio = cur["audio"] if audio is None else audio
        sub = cur["sub"] if sub is None else sub
        with self._lock:
            self._db.execute(
                "INSERT INTO show_prefs(profile, show, audio, sub) VALUES(?,?,?,?) "
                "ON CONFLICT(profile, show) DO UPDATE SET audio=excluded.audio, sub=excluded.sub", (pid, show, audio, sub))
            self._db.commit()

    # -- small internal values (last update check, ...) ---------------------------------------------

    def meta(self, key: str, default=None):
        with self._lock:
            r = self._db.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        if not r:
            return default
        try:
            return json.loads(r["value"])
        except ValueError:
            return default

    def set_meta(self, key: str, value) -> None:
        with self._lock:
            self._db.execute("INSERT INTO meta(key, value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                             (key, json.dumps(value)))
            self._db.commit()

    # -- backup ---------------------------------------------------------------------------------

    def export_data(self) -> dict:
        """Everything worth keeping, as plain JSON (no secrets; a PIN only as its salted hash).

        Format 2: the top level is the profile "main" exactly as format 1 had it (so an older AniBox can
        still restore it); ``profiles`` adds every profile with its own settings, and the other profiles'
        progress and audio/subtitle choices."""
        if self.export_check:
            self.export_check()  # e.g. a kids profile can't download everyone's progress
        with self._lock:
            rows = self._db.execute(f"SELECT profile, {PROGRESS_COLS} FROM progress").fetchall()
            prefs = self._db.execute("SELECT profile, show, audio, sub FROM show_prefs").fetchall()
            profiles = [dict(r) for r in self._db.execute("SELECT * FROM profiles ORDER BY created, id").fetchall()]
        progress: Dict[str, list] = {}
        for r in rows:
            d = dict(r)
            progress.setdefault(d.pop("profile"), []).append(d)
        show_prefs: Dict[str, dict] = {}
        for r in prefs:
            show_prefs.setdefault(r["profile"], {})[r["show"]] = {"audio": r["audio"], "sub": r["sub"]}
        listed = []
        for p in profiles:
            entry = {"id": p["id"], "name": p["name"], "color": p["color"], "emoji": p["emoji"], "pin": p["pin"],
                     "restrictions": clean_restrictions(_loads(p["restrictions"], {}), p["id"]),
                     "settings": {k: v for k, v in _loads(p["settings"], {}).items() if k in PROFILE_SETTINGS},
                     "created": p["created"]}
            if p["id"] != MAIN:
                entry.update(progress=progress.get(p["id"], []), showPrefs=show_prefs.get(p["id"], {}))
            listed.append(entry)
        settings = {k: v for k, v in self.settings(MAIN).items() if k not in PRIVATE_SETTINGS}
        return {"app": "AniBox", "kind": "backup", "format": 2, "exported": time.time(), "settings": settings,
                "progress": progress.get(MAIN, []), "overrides": self.overrides(), "showPrefs": show_prefs.get(MAIN, {}),
                "profiles": listed}

    def import_data(self, data: dict) -> dict:
        """Merge a backup: for each episode the newer entry wins; nothing is deleted. The top level (all of
        a backup from before profiles) goes into "main"; profiles that aren't here yet are added (found
        by id, then by name). A profile that is here keeps its name, picture and PIN."""
        if not isinstance(data, dict) or data.get("app") != "AniBox" or data.get("kind") != "backup":
            raise ValueError("That isn't an AniBox backup file.")
        added = self._merge_rows(MAIN, data.get("progress"), data.get("showPrefs"))
        for show, mal in (data.get("overrides") or {}).items():
            self.set_override(str(show), str(mal))
        settings = {k: v for k, v in (data.get("settings") or {}).items() if k in DEFAULTS and k not in PRIVATE_SETTINGS}
        if settings:
            self.update_settings(settings, profile=MAIN)
        new_profiles = 0
        for p in data.get("profiles") or []:
            if not isinstance(p, dict):
                continue
            pid, created = self._import_profile(p)
            if pid is None:
                continue
            new_profiles += created
            if pid != MAIN:
                added += self._merge_rows(pid, p.get("progress"), p.get("showPrefs"))
        return {"episodes": added, "overrides": len(data.get("overrides") or {}), "profiles": new_profiles}

    def _merge_rows(self, pid: str, progress, prefs) -> int:
        added = 0
        with self._lock:
            for p in progress if isinstance(progress, list) else []:
                if not isinstance(p, dict) or not p.get("key"):
                    continue
                old = self._db.execute("SELECT updated FROM progress WHERE profile=? AND key=?",
                                       (pid, str(p["key"]))).fetchone()
                if old and float(old["updated"]) >= float(p.get("updated") or 0):
                    continue
                self._db.execute(
                    "INSERT INTO progress(profile, key, show, position, duration, watched, updated) VALUES(?,?,?,?,?,?,?) "
                    "ON CONFLICT(profile, key) DO UPDATE SET show=excluded.show, position=excluded.position, "
                    "duration=excluded.duration, watched=excluded.watched, updated=excluded.updated",
                    (pid, str(p["key"]), str(p.get("show") or ""), float(p.get("position") or 0),
                     float(p.get("duration") or 0), int(bool(p.get("watched"))), float(p.get("updated") or 0)))
                added += 1
            self._db.commit()
        for show, pref in (prefs.items() if isinstance(prefs, dict) else []):
            if isinstance(pref, dict):
                self.set_show_pref(str(show), str(pref.get("audio") or ""), str(pref.get("sub") or ""), profile=pid)
        return added

    def _import_profile(self, p: dict) -> Tuple[Optional[str], int]:
        """(id here, 1 if it was added) for a profile of a backup; (None, 0) if it can't be added."""
        pid = str(p.get("id") or "")
        name = _clean_name(p.get("name"))
        with self._lock:
            if PROFILE_ID_RE.fullmatch(pid) and self.profile_row(pid):
                return pid, 0
            same = next((r for r in self.profiles() if name and r["name"].casefold() == name.casefold()), None)
            if same:
                return same["id"], 0
            if not name or len(self.profiles()) >= MAX_PROFILES:
                return None, 0
            if not PROFILE_ID_RE.fullmatch(pid) or pid == MAIN:
                pid = "p" + secrets.token_hex(4)
            pin = str(p.get("pin") or "")
            own = p.get("settings") if isinstance(p.get("settings"), dict) else {}
            self._db.execute(
                "INSERT INTO profiles(id, name, color, emoji, pin, restrictions, settings, created) VALUES(?,?,?,?,?,?,?,?)",
                (pid, name, _clean_color(p.get("color")), _clean_emoji(p.get("emoji")),
                 pin if PIN_HASH_RE.fullmatch(pin) else "", json.dumps(clean_restrictions(p.get("restrictions"), pid)),
                 json.dumps({k: v for k, v in own.items() if k in PROFILE_SETTINGS}),
                 float(p.get("created") or 0) or time.time()))
            self._db.commit()
        self._compat_indexes()
        return pid, 1

    def copy_to(self, dest: Path) -> None:
        """A consistent copy of the database file (safe while AniBox runs)."""
        dest.parent.mkdir(parents=True, exist_ok=True)
        tmp = dest.with_suffix(".part")
        target = sqlite3.connect(str(tmp))
        try:
            with self._lock:
                self._db.backup(target)
        finally:
            target.close()
        os.replace(tmp, dest)

    def auto_backup(self, folder: Path, keep: int = 7) -> Optional[Path]:
        """Once a day: a copy of the database in ``folder`` (the last ``keep`` days are kept)."""
        name = time.strftime("anibox-%Y-%m-%d.db")
        dest = folder / name
        if dest.exists():
            return None
        with self._lock:
            any_progress = self._db.execute("SELECT 1 FROM progress LIMIT 1").fetchone() is not None
        if not any_progress and not self.overrides():
            return None  # nothing worth keeping yet
        self.copy_to(dest)
        old = sorted(folder.glob("anibox-????-??-??.db"))[:-keep]
        for f in old:
            try:
                f.unlink()  # AniBox's own copies only
            except OSError:
                pass
        return dest

    # -- locks: what was already there stays as it is until the user unlocks the show ------------------

    def lock_snapshot(self, keys: Iterable[str]) -> int:
        """Lock these episodes (the ones that exist right now). Returns how many are locked in total."""
        with self._lock:
            self._db.executemany("INSERT OR IGNORE INTO locked(key) VALUES(?)", [(k,) for k in keys])
            self._db.commit()
            return self._db.execute("SELECT COUNT(*) FROM locked").fetchone()[0]

    def move_keys(self, episodes: Dict[str, Tuple[str, str]], shows: Dict[str, str]) -> None:
        """Follow episodes and shows whose key changed although the file didn't (AniBox now reads the
        folder layout differently). ``episodes``: old key -> (new key, new show id); ``shows``: old show
        id -> new show id. Watch progress (of every profile) and locks move along; so do matches by hand
        and language choices, unless the new show has its own. "Unlocked" doesn't move: the show is
        locked again. Nothing is deleted except the old copies of rows that moved."""
        with self._lock:
            db = self._db
            for old, (new, show) in episodes.items():
                db.execute("UPDATE progress SET key=?, show=? WHERE key=? AND NOT EXISTS "
                           "(SELECT 1 FROM progress AS p2 WHERE p2.profile = progress.profile AND p2.key = ?)",
                           (new, show, old, new))
                db.execute("INSERT OR IGNORE INTO locked(key) SELECT ? FROM locked WHERE key=?", (new, old))
                db.execute("DELETE FROM locked WHERE key=?", (old,))
            for old, new in shows.items():
                for table in ("overrides", "show_langs"):
                    if db.execute(f"SELECT 1 FROM {table} WHERE show=?", (new,)).fetchone() is None:
                        db.execute(f"UPDATE {table} SET show=? WHERE show=?", (new, old))
                db.execute("UPDATE show_prefs SET show=? WHERE show=? AND NOT EXISTS "
                           "(SELECT 1 FROM show_prefs AS s2 WHERE s2.profile = show_prefs.profile AND s2.show = ?)",
                           (new, old, new))
            db.commit()
        for fn in list(self.moved_hooks):
            try:
                fn(dict(episodes), dict(shows))
            except Exception:  # a hook never undoes the move
                log.warning("A moved-keys hook failed", exc_info=True)

    def locked_keys(self) -> set:
        with self._lock:
            return {r["key"] for r in self._db.execute("SELECT key FROM locked").fetchall()}

    def unlocked_shows(self) -> set:
        with self._lock:
            return {r["show"] for r in self._db.execute("SELECT show FROM unlocked_shows").fetchall()}

    def set_unlocked(self, show: str, unlocked: bool) -> None:
        with self._lock:
            if unlocked:
                self._db.execute("INSERT OR IGNORE INTO unlocked_shows(show) VALUES(?)", (show,))
            else:
                self._db.execute("DELETE FROM unlocked_shows WHERE show=?", (show,))
            self._db.commit()

    # -- languages per show (languages.py): found automatically, or set by hand --------------------------

    def all_show_langs(self) -> Dict[str, dict]:
        with self._lock:
            rows = self._db.execute("SELECT * FROM show_langs").fetchall()
        out = {}
        for r in rows:
            out[r["show"]] = {"audio": json.loads(r["audio"]), "subs": json.loads(r["subs"]), "source": r["source"],
                              "subtypes": json.loads(r["subtypes"] or "[]"),
                              "manual": None if r["manual_audio"] is None else
                              {"audio": json.loads(r["manual_audio"]), "subs": json.loads(r["manual_subs"] or "[]"),
                               "subtypes": json.loads(r["manual_subtypes"] or "[]")}}
        return out

    def set_show_langs(self, show: str, audio, subs, source: str, subtypes=()) -> None:
        """What AniBox found (from the files or the player); a choice made by hand stays."""
        with self._lock:
            self._db.execute(
                "INSERT INTO show_langs(show, audio, subs, subtypes, source, updated) VALUES(?,?,?,?,?,?) "
                "ON CONFLICT(show) DO UPDATE SET audio=excluded.audio, subs=excluded.subs, subtypes=excluded.subtypes, "
                "source=excluded.source, updated=excluded.updated",
                (show, json.dumps(sorted(set(audio))), json.dumps(sorted(set(subs))), json.dumps(sorted(set(subtypes or ()))),
                 source, time.time()))
            self._db.commit()

    def set_manual_langs(self, show: str, audio, subs, subtypes=()) -> None:
        """Your own choice; ``audio`` None = back to automatic."""
        with self._lock:
            self._db.execute("INSERT OR IGNORE INTO show_langs(show) VALUES(?)", (show,))
            self._db.execute("UPDATE show_langs SET manual_audio=?, manual_subs=?, manual_subtypes=? WHERE show=?",
                             (None if audio is None else json.dumps(sorted(set(audio))),
                              None if audio is None else json.dumps(sorted(set(subs or []))),
                              None if audio is None else json.dumps(sorted(set(subtypes or []))), show))
            self._db.commit()

    # -- profiles ("Who's watching?") ------------------------------------------------------------------

    @staticmethod
    def _public(r) -> dict:
        return {"id": r["id"], "name": r["name"], "color": r["color"] or COLORS[0], "emoji": r["emoji"],
                "hasPin": bool(r["pin"]), "restrictions": clean_restrictions(_loads(r["restrictions"], {}), r["id"]),
                "created": float(r["created"] or 0)}

    def profile_row(self, pid: str) -> Optional[dict]:
        """A profile's public fields (never the PIN hash), or None."""
        with self._lock:
            r = self._db.execute("SELECT * FROM profiles WHERE id=?", (str(pid or ""),)).fetchone()
        return self._public(r) if r else None

    def profiles(self) -> List[dict]:
        """Every profile, "main" first, then in the order they were made."""
        with self._lock:
            rows = self._db.execute("SELECT * FROM profiles ORDER BY id != 'main', created, id").fetchall()
        return [self._public(r) for r in rows]

    def restrictions(self, pid: Optional[str] = None) -> dict:
        row = self.profile_row(self._pid(pid))
        return row["restrictions"] if row else clean_restrictions({}, MAIN)

    def is_restricted(self, pid: Optional[str] = None) -> bool:
        return self.restrictions(pid)["restricted"]

    def set_profile(self, pid: str) -> None:
        """Make ``pid`` the active profile (remembered for the next start)."""
        if not self.profile_row(pid):
            raise ValueError("That profile doesn't exist.")
        self.profile = pid
        self.set_meta("active_profile", pid)

    def add_profile(self, name: str, color: str = "", emoji: str = "", restrictions=None) -> dict:
        """A new profile. Its own settings start as the active profile has them."""
        name = _clean_name(name)
        if not name:
            raise ValueError("Give the profile a name.")
        with self._lock:
            existing = self.profiles()
            if len(existing) >= MAX_PROFILES:
                raise ValueError(f"AniBox has room for {MAX_PROFILES} profiles.")
            if any(p["name"].casefold() == name.casefold() for p in existing):
                raise ValueError("There's a profile with that name already.")
            pid = "p" + secrets.token_hex(4)
            mine = {k: v for k, v in self.settings().items() if k in PROFILE_SETTINGS}
            self._db.execute(
                "INSERT INTO profiles(id, name, color, emoji, pin, restrictions, settings, created) VALUES(?,?,?,?,?,?,?,?)",
                (pid, name, _clean_color(color) or COLORS[len(existing) % len(COLORS)], _clean_emoji(emoji), "",
                 json.dumps(clean_restrictions(restrictions, pid)), json.dumps(mine), time.time()))
            self._db.commit()
        self._compat_indexes()
        return self.profile_row(pid)

    def update_profile(self, pid: str, name: Optional[str] = None, color: Optional[str] = None,
                       emoji: Optional[str] = None, restrictions=None) -> dict:
        row = self.profile_row(pid)
        if not row:
            raise ValueError("That profile doesn't exist.")
        changes = {}
        if name is not None:
            name = _clean_name(name)
            if not name:
                raise ValueError("Give the profile a name.")
            if any(p["id"] != pid and p["name"].casefold() == name.casefold() for p in self.profiles()):
                raise ValueError("There's a profile with that name already.")
            changes["name"] = name
        if color is not None:
            changes["color"] = _clean_color(color) or row["color"]
        if emoji is not None:
            changes["emoji"] = _clean_emoji(emoji)
        if restrictions is not None:
            changes["restrictions"] = json.dumps(clean_restrictions(restrictions, pid))
        with self._lock:
            for k, v in changes.items():
                self._db.execute(f"UPDATE profiles SET {k}=? WHERE id=?", (v, pid))
            self._db.commit()
        return self.profile_row(pid)

    def set_pin(self, pid: str, pin: Optional[str]) -> None:
        """Set (4–8 digits, kept only as a salted hash) or remove (None/"") a profile's PIN."""
        if not self.profile_row(pid):
            raise ValueError("That profile doesn't exist.")
        stored = hash_pin(str(pin)) if pin else ""
        with self._lock:
            self._db.execute("UPDATE profiles SET pin=? WHERE id=?", (stored, pid))
            self._db.commit()

    def check_pin(self, pid: str, pin: str) -> bool:
        with self._lock:
            r = self._db.execute("SELECT pin FROM profiles WHERE id=?", (str(pid or ""),)).fetchone()
        return bool(r) and verify_pin(r["pin"], pin)

    def delete_profile(self, pid: str) -> None:
        """Remove a profile with its watch progress and audio/subtitle choices ("main" stays)."""
        if pid == MAIN:
            raise ValueError("The first profile can't be deleted.")
        if not self.profile_row(pid):
            raise ValueError("That profile doesn't exist.")
        with self._lock:
            for table in ("progress", "show_prefs"):
                self._db.execute(f"DELETE FROM {table} WHERE profile=?", (pid,))
            self._db.execute("DELETE FROM profiles WHERE id=?", (pid,))
            self._db.commit()
        if self.profile == pid:
            self.set_profile(MAIN)
        self._compat_indexes()

    def profile_counts(self) -> Dict[str, dict]:
        """profile -> {"watched": episodes watched, "started": episodes with progress}."""
        with self._lock:
            rows = self._db.execute(
                "SELECT profile, COUNT(*) AS n, SUM(watched) AS w FROM progress GROUP BY profile").fetchall()
        return {r["profile"]: {"watched": int(r["w"] or 0), "started": int(r["n"] or 0)} for r in rows}
