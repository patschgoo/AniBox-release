"""Folder watching (watchfolders.py): the window's routes and the background thread.

Part of the App class (see server.py); the methods use the App's attributes. Only the AniBox window
reaches these routes.
"""

from __future__ import annotations

import logging
import os
import threading
from typing import Iterable, List

from .watchfolders import FolderWatch

log = logging.getLogger("anibox.server")

_LOCK = threading.Lock()


class RoutesWatchFoldersMixin:
    GET_ROUTES = {"/api/watch": "_watch_get"}
    POST_ROUTES = {"/api/watch/dismiss": "_watch_dismiss"}

    def _watch(self) -> FolderWatch:
        w = self.__dict__.get("_folder_watch")
        if w is not None:
            return w
        with _LOCK:
            w = self.__dict__.get("_folder_watch")
            if w is None:
                w = FolderWatch(self.data_dir, self.store.settings, self._inbox_roots, self._watch_exclude,
                                self._watch_added, self._watch_playing, self._watch_busy, self._watch_rescan)
                self.__dict__["_folder_watch"] = w
        return w

    def _watch_start(self) -> None:
        """Called once when AniBox starts serving; the thread ends when AniBox closes."""
        w = self._watch()
        threading.Thread(target=w.run, args=(self._stopping,), daemon=True, name="anibox-watch").start()

    # -- what the watcher asks the App

    def _watch_exclude(self) -> List[str]:
        out = list(self.store.settings().get("folders") or [])
        tvc = self.__dict__.get("tvcopies")
        if tvc is not None:
            out.append(tvc.folder())
        return out

    def _watch_added(self) -> Iterable[str]:
        """Videos AniBox already copied from the inbox into the library (Add new videos in "copy" mode)."""
        try:
            st = os.stat(self.fileops.log_path)
        except OSError:
            st = None
        sig = (st.st_size, st.st_mtime) if st else None
        cached = self.__dict__.get("_watch_added_cache")
        if cached and cached[0] == sig:
            return cached[1]
        added = set()
        try:
            for b in self.fileops.batches():
                if b.get("undone"):
                    continue
                for e in b["files"]:
                    if e.get("op") == "copy" and e.get("src"):
                        added.add(e["src"])
        except Exception:
            log.exception("Folder watching: reading the file log failed")
        self.__dict__["_watch_added_cache"] = (sig, added)
        return added

    def _watch_playing(self) -> bool:
        return bool(self.player.running or self.tv.active)

    def _watch_busy(self) -> bool:
        return self.library.status.get("state") == "running" or self.fileops.state.get("state") == "running"

    def _watch_rescan(self) -> bool:
        folders = self.store.settings().get("folders") or []
        return bool(folders) and self.library.scan_async(folders)

    # -- routes

    def _watch_get(self, query: dict) -> dict:
        w = self._watch()
        if self.store.settings().get("watch_inbox", True) and w.clock() >= w.next_inbox:
            w.check_inbox()  # due anyway (e.g. right after the start): Home shows the right count at once
        return w.status()

    def _watch_dismiss(self, body: dict) -> dict:
        n = self._watch().dismiss()
        return {"ok": True, "hidden": n, **self._watch().status()}
