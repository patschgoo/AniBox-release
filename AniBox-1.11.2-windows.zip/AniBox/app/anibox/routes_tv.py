"""Play on TV (CastApp TV, other DLNA TVs and Chromecasts).

Part of the App class (see server.py); the methods use the App's attributes.
"""

from __future__ import annotations

from . import tvplayer
from .apierror import ApiError



def _tv_json(d: dict) -> dict:
    return {"id": d.get("id"), "name": d.get("name"), "model": d.get("model") or "",
            "manufacturer": d.get("manufacturer") or "", "castapp": bool(d.get("castapp")),
            "kind": d.get("kind") or "dlna"}


class RoutesTvMixin:
    def _tv_post(self, path: str, body: dict) -> dict:
        if path == "/api/tv/discover":
            return {"devices": [_tv_json(d) for d in self.tv.discover(float(body.get("timeout") or 3.0))]}
        if path == "/api/tv/add":
            return {"device": _tv_json(self.tv.add(str(body.get("address") or "")))}
        device = str(body.get("device") or "")
        if not device:
            raise ApiError("Pick a TV first.")
        if path == "/api/tv/pair":
            return self.tv.pair(device, str(body.get("code") or "") or None)
        # Play on TV. "Move" continues what plays on this PC right now (from the same show: an
        # Internet Archive video keeps following its item or series playlist).
        show, key, start = str(body.get("show") or ""), str(body.get("key") or ""), None
        if body.get("move") and self.player.running and self.player.key:
            show, key, start = self.player.show_id, self.player.key, max(0.0, self.player.pos - 3)
            self.player.stop()
        if self.tv.probe is None:  # subtitle tracks: what "Plays on the TV?" read with ffprobe, if it did
            self.tv.probe = self._tv_file_info
        self.tv.play(device, show_id=show, key=key, from_start=bool(body.get("fromStart")), start=start)
        return {"ok": True, "device": self.tv.renderer.name if self.tv.renderer else ""}

    def _tv_file_info(self, path: str, kind: str):
        return tvplayer.file_info(path, kind, self._media()["cache"])
