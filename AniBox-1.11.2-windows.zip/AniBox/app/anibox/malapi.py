"""Extra details from the official MyAnimeList API: description, score, genres, studios.

Optional: it needs a free "Client ID" that you create yourself on myanimelist.net
(Profile → Account settings → API → Create ID; app type "other"). Without one, AniBox shows
what the offline anime lists know (title, type, year, episodes, poster).

Answers are kept for 30 days in ``<data>/mal/<id>.json``; AniBox asks again only after that.
MyAnimeList's API has no episode titles, so episodes stay "Episode 1, 2, ...".
"""

from __future__ import annotations

import json
import logging
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Optional

log = logging.getLogger("anibox.mal")

API = "https://api.myanimelist.net/v2"
FIELDS = ("synopsis,mean,rank,popularity,genres,studios,start_date,end_date,num_episodes,rating,"
          "media_type,status,source,average_episode_duration,alternative_titles,start_season")
MAX_AGE = 30 * 86400
RATINGS = {"g": "G - All Ages", "pg": "PG - Children", "pg_13": "PG-13", "r": "R - 17+", "r+": "R+", "rx": "Rx"}


class MalError(RuntimeError):
    pass


class MalApi:
    def __init__(self, cache_dir: Path, base: str = API):
        self.cache_dir = cache_dir
        self.base = base.rstrip("/")

    def cached(self, mal_id: str) -> Optional[dict]:
        try:
            return json.loads((self.cache_dir / f"{int(mal_id)}.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None

    def details(self, mal_id: str, client_id: str, refresh: bool = False) -> Optional[dict]:
        """The entry's details (from the cache when fresh). None without a client ID."""
        mal_id = str(int(mal_id))
        path = self.cache_dir / f"{mal_id}.json"
        old = self.cached(mal_id)
        if old and not refresh and time.time() - path.stat().st_mtime < MAX_AGE:
            return old
        if not client_id:
            return old
        url = f"{self.base}/anime/{mal_id}?" + urllib.parse.urlencode({"fields": FIELDS})
        req = urllib.request.Request(url, headers={"X-MAL-CLIENT-ID": client_id, "User-Agent": "AniBox"})
        try:
            with urllib.request.urlopen(req, timeout=15) as r:
                data = json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            if exc.code in (400, 401, 403):
                raise MalError("MyAnimeList didn't accept the Client ID. Check it in Settings.") from exc
            if exc.code == 404:
                raise MalError("MyAnimeList doesn't know this entry.") from exc
            log.warning("MyAnimeList answered %s for %s", exc.code, mal_id)
            if old:
                return old
            raise MalError(f"MyAnimeList answered with an error ({exc.code}). Try again later.") from exc
        except (OSError, ValueError) as exc:
            log.warning("MyAnimeList not reachable: %s", exc)
            if old:
                return old
            raise MalError("MyAnimeList isn't reachable right now.") from exc
        out = simplify(data)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".part")
        tmp.write_text(json.dumps(out, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, path)
        return out


def simplify(d: dict) -> dict:
    """Only what AniBox shows, in plain words."""
    alt = d.get("alternative_titles") or {}
    season = d.get("start_season") or {}
    return {
        "synopsis": (d.get("synopsis") or "").replace("[Written by MAL Rewrite]", "").strip(),
        "mean": d.get("mean"),
        "rank": d.get("rank"),
        "popularity": d.get("popularity"),
        "genres": [g.get("name") for g in d.get("genres") or [] if g.get("name")],
        "studios": [s.get("name") for s in d.get("studios") or [] if s.get("name")],
        "start_date": d.get("start_date") or "",
        "end_date": d.get("end_date") or "",
        "num_episodes": d.get("num_episodes"),
        "rating": RATINGS.get(d.get("rating") or "", d.get("rating") or ""),
        "source": (d.get("source") or "").replace("_", " "),
        "season": f"{season.get('season', '').title()} {season.get('year', '')}".strip(),
        "title_en": alt.get("en") or "",
        "title_ja": alt.get("ja") or "",
        "fetched": time.time(),
    }
