"""Extras from AniList for a show's page: banner, characters and voice actors, staff, genres and tags,
the trailer, the official site and where it streams.

The data comes from **AniList's** free public GraphQL API (``graphql.anilist.co``, no account), one
question per show, asked by its AniList number (from Fribb's anime list, which maps MyAnimeList
numbers to AniList's). That number is the only thing sent; AniBox uses the same small client as the
new-episode notices (airing.py): a ``User-Agent``, a pause of ~2 s between questions and patience
when AniList answers 429 "too many".

- **Only on demand:** a show is asked about when its page opens, and then kept for ``MAX_AGE`` (14
  days) in ``<data>/anilist/<AniList id>.json`` (written atomically). "Load all" in Settings fills
  the cache slowly in the background (``LOAD_PAUSE`` more between questions) and can be cancelled.
- **Voice actors** come in Japanese, German and English in the same question, so switching the
  cast language on the page needs no new question.
- **Pictures** (banner, characters, people) stay on AniList's picture server (``s4.anilist.co``);
  the window loads them from there without a referrer. Only addresses on AniList's own servers are
  kept; anything else in an answer is dropped.
- Entries AniList doesn't have (404) are remembered as "not on AniList" for the same 14 days.
"""

from __future__ import annotations

import json
import logging
import os
import re
import threading
import time
import urllib.parse
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Optional

from . import languages
from .airing import ANILIST, INTERVAL, AniList, AniListError

log = logging.getLogger("anibox.anilistinfo")

MAX_AGE = 14 * 86400  # ask again after this long
RETRY_AFTER_ERROR = 10 * 60  # a show whose question failed isn't asked again by itself for this long
LOAD_PAUSE = 2.0  # "Load all": seconds on top of the client's own pause (~15 questions a minute)
LOAD_GIVE_UP = 5  # "Load all" stops after this many failures in a row (offline, AniList down)
CACHE_VERSION = 1
CAST_LANGS = ("ja", "de", "en")
CAST_NAMES = {"ja": "Japanese", "de": "German", "en": "English"}
TAG_RANK = 50  # a tag counts (shown as "top tag", used by smart collections) from this rank on
MAX_STAFF = 8
MAX_CHARACTERS = 25
IMAGE_HOSTS = ("s4.anilist.co", "img.anili.st")
TRAILER_SITES = {"youtube": "https://www.youtube.com/watch?v={id}", "dailymotion": "https://www.dailymotion.com/video/{id}"}
TRAILER_NAMES = {"youtube": "YouTube", "dailymotion": "Dailymotion"}
# The main people, in this order (AniList's role names; "Director (eps 1-12)" counts as "Director").
MAIN_ROLES = ("Original Creator", "Original Story", "Director", "Chief Director", "Series Composition", "Music",
              "Character Design", "Original Character Design")
ROLES = {"MAIN": "Main", "SUPPORTING": "Supporting", "BACKGROUND": "Background"}
SEASONS = {"WINTER": "Winter", "SPRING": "Spring", "SUMMER": "Summer", "FALL": "Fall"}

_PERSON = "name { full } image { medium }"
QUERY = """query ($id: Int) {
  Media(id: $id, type: ANIME) {
    id idMal siteUrl
    bannerImage
    coverImage { extraLarge color }
    trailer { id site thumbnail }
    genres
    tags { name rank isMediaSpoiler isGeneralSpoiler }
    studios(isMain: true) { nodes { name } }
    averageScore
    season seasonYear
    externalLinks { site url type }
    characters(sort: [ROLE, RELEVANCE, ID], perPage: 25) {
      edges {
        role
        node { %(p)s }
        ja: voiceActors(language: JAPANESE, sort: [RELEVANCE, ID]) { %(p)s }
        de: voiceActors(language: GERMAN, sort: [RELEVANCE, ID]) { %(p)s }
        en: voiceActors(language: ENGLISH, sort: [RELEVANCE, ID]) { %(p)s }
      }
    }
    staff(sort: [RELEVANCE, ID], perPage: 25) { edges { role node { %(p)s } } }
  }
}""" % {"p": _PERSON}

_TRAILER_ID = re.compile(r"^[A-Za-z0-9_-]{3,40}$")
_COLOR = re.compile(r"^#[0-9a-fA-F]{6}$")
_ROLE_NOTE = re.compile(r"\s*\(.*\)\s*$")


# -- reading AniList's answer --------------------------------------------------------------------

def _text(v, limit: int = 200) -> str:
    return v.strip()[:limit] if isinstance(v, str) else ""


def image(url) -> str:
    """An address on AniList's picture server, or "" (other hosts and AniList's "no picture" image)."""
    if not isinstance(url, str) or not url.startswith("https://"):
        return ""
    parts = urllib.parse.urlsplit(url)
    if parts.hostname not in IMAGE_HOSTS or parts.path.endswith("/default.jpg") or len(url) > 400:
        return ""
    return url


def _person(p) -> Optional[dict]:
    if not isinstance(p, dict):
        return None
    name = _text((p.get("name") or {}).get("full") if isinstance(p.get("name"), dict) else "", 120)
    if not name:
        return None
    pic = p.get("image") if isinstance(p.get("image"), dict) else {}
    return {"name": name, "image": image(pic.get("medium"))}


def trailer(t) -> Optional[dict]:
    """{"site", "id", "url", "name"} for a YouTube or Dailymotion trailer, else None."""
    if not isinstance(t, dict):
        return None
    site = _text(t.get("site"), 30).lower()
    tid = _text(t.get("id"), 60)
    if site not in TRAILER_SITES or not _TRAILER_ID.match(tid):
        return None
    return {"site": site, "id": tid, "url": TRAILER_SITES[site].format(id=tid), "name": TRAILER_NAMES[site]}


def staff(edges) -> List[dict]:
    """The main people (director, series composition, music, character design …), each once with
    their main roles, in the order of ``MAIN_ROLES``; at most ``MAX_STAFF``."""
    people: Dict[str, dict] = {}
    for e in edges if isinstance(edges, list) else []:
        if not isinstance(e, dict):
            continue
        role = _ROLE_NOTE.sub("", _text(e.get("role"), 120))
        if role not in MAIN_ROLES:
            continue
        p = _person(e.get("node"))
        if not p:
            continue
        cur = people.setdefault(p["name"], dict(p, roles=[]))
        if role not in cur["roles"]:
            cur["roles"].append(role)
        if not cur["image"]:
            cur["image"] = p["image"]
    out = sorted(people.values(), key=lambda p: min(MAIN_ROLES.index(r) for r in p["roles"]))
    for p in out:
        p["roles"].sort(key=MAIN_ROLES.index)
    return out[:MAX_STAFF]


def characters(edges) -> List[dict]:
    out = []
    for e in edges if isinstance(edges, list) else []:
        if not isinstance(e, dict):
            continue
        ch = _person(e.get("node"))
        if not ch:
            continue
        va = {}
        for lang in CAST_LANGS:
            people = [p for p in (_person(x) for x in (e.get(lang) or [])) if p] if isinstance(e.get(lang), list) else []
            if people:
                va[lang] = people[:2]
        ch.update(role=ROLES.get(_text(e.get("role"), 20), ""), va=va)
        out.append(ch)
        if len(out) >= MAX_CHARACTERS:
            break
    return out


def parse(m: dict) -> dict:
    """What AniBox keeps of AniList's answer, in plain fields (also the shape of the cache files)."""
    aid = m.get("id") if isinstance(m.get("id"), int) else None
    cover = m.get("coverImage") if isinstance(m.get("coverImage"), dict) else {}
    tags = []
    for t in m.get("tags") or []:
        if isinstance(t, dict) and _text(t.get("name"), 60):
            rank = t.get("rank") if isinstance(t.get("rank"), int) else 0
            tags.append({"name": _text(t["name"], 60), "rank": rank,
                         "spoiler": bool(t.get("isMediaSpoiler") or t.get("isGeneralSpoiler"))})
    tags.sort(key=lambda t: (-t["rank"], t["name"].casefold()))
    links, seen = [], set()
    for x in m.get("externalLinks") or []:
        if not isinstance(x, dict) or x.get("type") not in ("INFO", "STREAMING"):
            continue
        url, site = _text(x.get("url"), 400), _text(x.get("site"), 40)
        if url.startswith("https://") and site and url not in seen:
            seen.add(url)
            links.append({"site": site, "url": url, "type": "site" if x["type"] == "INFO" else "stream"})
    links.sort(key=lambda x: x["type"] != "site")  # the official site first
    studios = [_text(s.get("name"), 80) for s in ((m.get("studios") or {}).get("nodes") or [])
               if isinstance(s, dict) and _text(s.get("name"), 80)] if isinstance(m.get("studios"), dict) else []
    season = SEASONS.get(m.get("season") or "", "")
    year = m.get("seasonYear") if isinstance(m.get("seasonYear"), int) else None
    site = _text(m.get("siteUrl"), 200)
    color = _text(cover.get("color"), 10)
    return {
        "id": aid,
        "url": site if site.startswith("https://anilist.co/") else (f"https://anilist.co/anime/{aid}" if aid else ""),
        "banner": image(m.get("bannerImage")),
        "cover": image(cover.get("extraLarge")),
        "color": color if _COLOR.match(color) else "",
        "trailer": trailer(m.get("trailer")),
        "genres": [g for g in (_text(x, 40) for x in m.get("genres") or []) if g][:12],
        "tags": tags[:30],
        "studios": studios[:4],
        "score": m.get("averageScore") if isinstance(m.get("averageScore"), int) else None,
        "season": f"{season} {year}".strip() if season or year else "",
        "year": year,
        "links": links[:12],
        "characters": characters(((m.get("characters") or {}).get("edges")) if isinstance(m.get("characters"), dict) else []),
        "staff": staff(((m.get("staff") or {}).get("edges")) if isinstance(m.get("staff"), dict) else []),
    }


def top_tags(info: dict, spoilers: bool = False) -> List[str]:
    """Tag names that count (rank ``TAG_RANK`` or more), spoiler tags only when asked."""
    return [t["name"] for t in info.get("tags") or [] if t.get("rank", 0) >= TAG_RANK and (spoilers or not t.get("spoiler"))]


# -- the cast language -----------------------------------------------------------------------------

def cast_order(audio_langs: str) -> List[str]:
    """Japanese, German and English in the order of the audio-language setting ("ger,jpn" -> de, ja, en).
    Without a German or English choice, English comes before German."""
    picked = _picked(audio_langs)
    return picked + [c for c in ("ja", "en", "de") if c not in picked]


def default_cast(audio_langs: str, chosen: str = "") -> str:
    """The cast shown first: the one picked on a show page, else the first of Japanese/German/English in
    the audio-language setting, else Japanese."""
    if chosen in CAST_LANGS:
        return chosen
    picked = _picked(audio_langs)
    return picked[0] if picked else "ja"


def _picked(audio_langs: str) -> List[str]:
    out: List[str] = []
    for part in re.split(r"[,;\s]+", audio_langs or ""):
        code = languages.lang(part)
        if code in CAST_LANGS and code not in out:
            out.append(code)
    return out


# -- the cache and the questions ------------------------------------------------------------------------

class AniListInfo:
    """The cache of AniList extras, the questions (one at a time) and the "Load all" job."""

    def __init__(self, cache_dir: Path, base: str = ANILIST, interval: float = INTERVAL,
                 sleep: Callable[[float], None] = time.sleep, clock: Callable[[], float] = time.time):
        self.cache_dir = Path(cache_dir)
        self.client = AniList(base, interval, sleep)
        self.clock = clock
        self._ask = threading.Lock()  # one question at a time, so the client's pause holds for all
        self._lock = threading.RLock()
        self._busy: Dict[int, str] = {}  # AniList id -> "loading" / "error"
        self._failed: Dict[int, float] = {}
        self._index: Optional[Dict[int, Optional[dict]]] = None  # AniList id -> summary (None: not on AniList)
        self._cancel = threading.Event()
        self._error_logged = False
        self.job = {"state": "idle", "done": 0, "total": 0, "failed": 0, "skipped": 0, "started": 0.0,
                    "finished": 0.0, "error": ""}

    # -- files ----------------------------------------------------------------------------------------

    def path(self, aid: int) -> Path:
        return self.cache_dir / f"{int(aid)}.json"

    def entry(self, aid: int) -> Optional[dict]:
        """The cache file: {"fetched", "media" (None = not on AniList)}, or None."""
        try:
            data = json.loads(self.path(aid).read_text(encoding="utf-8"))
        except (OSError, ValueError, TypeError):
            return None
        if not isinstance(data, dict) or data.get("version") != CACHE_VERSION or \
                not isinstance(data.get("fetched"), (int, float)) or not (data.get("media") is None or isinstance(data.get("media"), dict)):
            return None
        return data

    def cached(self, aid: int) -> Optional[dict]:
        e = self.entry(aid)
        return e["media"] if e else None

    def is_fresh(self, aid: int) -> bool:
        e = self.entry(aid)
        return bool(e) and self.clock() - float(e["fetched"]) < MAX_AGE

    def _store(self, aid: int, media: Optional[dict]) -> None:
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        path = self.path(aid)
        tmp = path.with_name(path.name + ".part")
        tmp.write_text(json.dumps({"version": CACHE_VERSION, "id": int(aid), "fetched": self.clock(), "media": media},
                                  ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, path)
        with self._lock:
            if self._index is not None:
                self._index[int(aid)] = _summary(media)

    # -- what smart collections and cards need, without reading every file each time -----------------------

    def summaries(self) -> Dict[int, Optional[dict]]:
        """AniList id -> {"genres", "tags" (names that count, no spoilers), "banner", "score", "year"} of
        every show in the cache (None: not on AniList). Read once, then kept up to date."""
        with self._lock:
            if self._index is None:
                index: Dict[int, Optional[dict]] = {}
                try:
                    names = list(self.cache_dir.glob("*.json"))
                except OSError:
                    names = []
                for p in names:
                    if not p.stem.isdigit():
                        continue
                    e = self.entry(int(p.stem))
                    if e is not None:
                        index[int(p.stem)] = _summary(e["media"])
                self._index = index
            return dict(self._index)

    # -- asking -----------------------------------------------------------------------------------------------

    def fetch(self, aid: int, force: bool = False) -> Optional[dict]:
        """Ask AniList now (in this thread) and keep the answer. None: AniList doesn't have it.
        Raises AniListError when AniList can't be asked."""
        aid = int(aid)
        with self._ask:
            if not force and self.is_fresh(aid):  # asked by another thread meanwhile
                return self.cached(aid)
            try:
                data = self.client.query(QUERY, {"id": aid})
            except AniListError as exc:
                if getattr(exc.__cause__, "code", None) == 404:
                    self._store(aid, None)
                    log.info("AniList doesn't have %s", aid)
                    return None
                raise
            m = data.get("Media")
            media = parse(m) if isinstance(m, dict) else None
            self._store(aid, media)
            return media

    def status(self, aid: int) -> str:
        """"loading", "error" (the last question failed) or ""."""
        with self._lock:
            return self._busy.get(int(aid), "")

    def fetch_async(self, aid: int) -> bool:
        aid = int(aid)
        with self._lock:
            if self._busy.get(aid) == "loading":
                return False
            failed = self._failed.get(aid)
            if failed and self.clock() - failed < RETRY_AFTER_ERROR:
                return False
            self._busy[aid] = "loading"
        threading.Thread(target=self._fetch_safe, args=(aid,), daemon=True, name="anibox-anilist").start()
        return True

    def _fetch_safe(self, aid: int) -> None:
        try:
            self.fetch(aid)
            with self._lock:
                self._busy.pop(aid, None)
                self._failed.pop(aid, None)
            self._error_logged = False
        except Exception as exc:  # offline, AniList down: the page shows what's cached (or nothing)
            if not self._error_logged:
                log.warning("AniList extras couldn't be loaded: %s", exc)
                self._error_logged = True
            with self._lock:
                self._busy[aid] = "error"
                self._failed[aid] = self.clock()

    # -- "Load all" ---------------------------------------------------------------------------------------------

    def load_all(self, ids: Iterable[int], pause: float = LOAD_PAUSE, allowed: Callable[[], bool] = lambda: True) -> bool:
        """Fill the cache for these AniList ids in the background (only the ones not fresh). False when
        a job is running already."""
        wanted = sorted({int(a) for a in ids})
        with self._lock:
            if self.job["state"] == "running":
                return False
            todo = [a for a in wanted if not self.is_fresh(a)]
            self._cancel.clear()
            self.job = {"state": "running", "done": 0, "total": len(todo), "failed": 0, "skipped": len(wanted) - len(todo),
                        "started": self.clock(), "finished": 0.0, "error": ""}
        threading.Thread(target=self._load_all, args=(todo, pause, allowed), daemon=True, name="anibox-anilist-all").start()
        return True

    def cancel(self) -> None:
        self._cancel.set()

    def _load_all(self, todo: List[int], pause: float, allowed: Callable[[], bool]) -> None:
        job, in_a_row, state = self.job, 0, "done"
        for i, aid in enumerate(todo):
            if self._cancel.is_set() or not allowed():
                state = "cancelled"
                break
            try:
                self.fetch(aid)
                in_a_row = 0
                with self._lock:
                    self._failed.pop(aid, None)
            except Exception as exc:
                job["failed"] += 1
                in_a_row += 1
                log.info("Load all: AniList %s failed (%s)", aid, exc)
                if in_a_row >= LOAD_GIVE_UP:
                    state = "error"
                    job["error"] = "AniList isn't reachable right now. What's loaded so far stays; try again later."
                    break
            job["done"] += 1
            if i + 1 < len(todo) and pause > 0 and self._cancel.wait(pause):
                state = "cancelled"
                break
        job["finished"] = self.clock()
        job["state"] = state
        log.info("AniList extras, Load all: %s, %d of %d asked, %d failed", state, job["done"], job["total"], job["failed"])


def _summary(media: Optional[dict]) -> Optional[dict]:
    if not media:
        return None
    return {"genres": list(media.get("genres") or []), "tags": top_tags(media), "banner": media.get("banner") or "",
            "score": media.get("score"), "year": media.get("year")}
