"""Series and movie info from TMDB (tmdb.py): posters on the cards, a box on the show page, episode
titles, "Wrong match?", and the Settings panel. Only for shows in series and movie libraries (anime
has MyAnimeList), and only with the user's own TMDB key: without one nothing is asked.

Part of the App class (see server.py); the methods use the App's attributes.
"""

from __future__ import annotations

import logging
import os
import threading
import time
from types import SimpleNamespace
from typing import Optional

from . import tmdb as tmdblib
from .apierror import ApiError

log = logging.getLogger("anibox.server")

_INIT_LOCK = threading.Lock()
RETRY_AFTER_FAILURE = 600  # a show whose lookup failed (no connection …) is tried again after 10 minutes
AUTO_FILL_EVERY = 600  # looking up new shows by itself at most this often


class RoutesTmdbMixin:
    GET_ROUTES = {
        "/api/tmdb": "_tmdb_status",
        "/api/tmdb/show": "_tmdb_show",
        "/api/tmdb/search": "_tmdb_search",
    }
    POST_ROUTES = {
        "/api/tmdb/key": "_tmdb_set_key",
        "/api/tmdb/fetch": "_tmdb_fetch",
        "/api/tmdb/match": "_tmdb_match",
    }

    # -- set up on first use ------------------------------------------------------------------------

    def _tmdb_box(self) -> SimpleNamespace:
        box = self.__dict__.get("_tmdb_state")
        if box is None:
            with _INIT_LOCK:
                box = self.__dict__.get("_tmdb_state")
                if box is None:
                    client = tmdblib.Tmdb(self.data_dir / "tmdb", api=os.environ.get("ANIBOX_TMDB_API"),
                                          images=os.environ.get("ANIBOX_TMDB_IMAGES"))
                    box = SimpleNamespace(client=client, lock=threading.Lock(), job={"state": "idle"},
                                          busy=set(), failed={}, last_auto=0.0)
                    self.__dict__["_tmdb_state"] = box
        return box

    @property
    def tmdb(self) -> tmdblib.Tmdb:
        return self._tmdb_box().client

    def _tmdb_key(self) -> str:
        return tmdblib.clean_key(self.store.settings().get("tmdb_api_key") or "")

    def _tmdb_kind(self, show: dict, kinds: Optional[dict] = None) -> str:
        """"tv" or "movie" for shows in series and movie libraries, "" for anime and Internet Archive items."""
        lib = show.get("library") or ""
        if str(show.get("id") or "").startswith("ia:"):
            return ""
        kind = kinds.get(lib) if kinds is not None and lib in kinds else self.library.library_kind(lib)
        if kinds is not None:
            kinds[lib] = kind
        return {"series": "tv", "movies": "movie"}.get(kind, "")

    def _tmdb_shows(self):
        kinds = {}
        return [(sh, k) for sh in self.library.shows() for k in [self._tmdb_kind(sh, kinds)] if k]

    # -- cards and episode titles (called from routes_library.py) --------------------------------------

    def _tmdb_cards(self, cards: list) -> list:
        """Series and movie cards get their TMDB poster (and year). Unknown shows are looked up in the
        background, each one once."""
        key = self._tmdb_key()
        if not key:
            return cards
        t = self.tmdb
        posters = bool(self.store.settings().get("posters", True))
        kinds, pending = {}, False
        for c in cards:
            if c.get("kind") == "franchise" or not c.get("id"):
                continue
            kind = self._tmdb_kind(c, kinds)
            if not kind:
                continue
            m = t.match_for(c["id"])
            if t.needs_match(m, kind):
                pending = True
                continue
            if not m.get("id"):
                continue
            d = t.cached_details(m["kind"], m["id"])
            if not d:
                pending = True
                continue
            if posters and d.get("poster"):
                c["poster"] = f"/tmdb/poster/{m['kind']}-{m['id']}"
            if not c.get("year") and d.get("year"):
                c["year"] = d["year"]
        box = self._tmdb_box()
        if pending and time.time() - box.last_auto > AUTO_FILL_EVERY:
            box.last_auto = time.time()
            self._tmdb_fill_start()
        return cards

    def _tmdb_episode_info(self, show: dict, out: dict) -> dict:
        """Episode titles from TMDB for series, after your own file names and Plex's titles."""
        kind = self._tmdb_kind(show)
        key = self._tmdb_key()
        if kind != "tv" or not key:
            return out
        if self._tmdb_ensure(show, kind, key):
            out["state"] = "loading"
        m = self.tmdb.match_for(show["id"])
        if not m or not m.get("id") or m.get("kind") != "tv":
            return out
        episodes = out.setdefault("episodes", {})
        for e in show["episodes"]:
            if e.get("number") is None or e.get("season") is None:
                continue
            info = ((self.tmdb.cached_season(m["id"], e["season"]) or {}).get("episodes") or {}).get(str(e["number"]))
            cur = episodes.get(e["key"]) or {}
            if not info or not info.get("title") or cur.get("title"):
                continue
            episodes[e["key"]] = {"title": info["title"], "own": False, "image": cur.get("image") or "",
                                  "aired": info.get("aired") or "", "plot": info.get("plot") or "",
                                  "number": e["number"], "source": "TMDB"}
        return out

    def _tmdb_poster(self, name: str) -> Optional[bytes]:
        """For /tmdb/poster/<kind>-<id> (server.py): from the cache, or fetched once."""
        return self.tmdb.poster(name, self._tmdb_key())

    # -- fetching ---------------------------------------------------------------------------------------

    def _tmdb_update(self, show: dict, kind: str, key: str, refresh: bool = False) -> None:
        """Match (if needed), details and poster; for series also the seasons on your drive."""
        t = self.tmdb
        m = t.match_for(show["id"])
        if t.needs_match(m, kind):
            m = t.auto_match(show["id"], show["folder"], kind, key)
        if not m.get("id"):
            return
        try:
            d = t.details(m["kind"], m["id"], key, refresh=refresh)
        except tmdblib.TmdbError as exc:
            if exc.status == 404 and not m.get("manual"):  # gone from TMDB: search again next time
                t.set_match(show["id"], kind, None, False)
                return
            raise
        if d.get("poster"):
            t.poster(f"{m['kind']}-{m['id']}", key)
        if m["kind"] == "tv":
            seasons = sorted({e["season"] for e in show["episodes"] if e.get("season") is not None and e.get("number") is not None})
            for n in seasons[:60]:
                if refresh or not t.season_fresh(m["id"], n):
                    t.season(m["id"], n, key)

    def _tmdb_needs_work(self, show: dict, kind: str) -> bool:
        t = self.tmdb
        m = t.match_for(show["id"])
        if t.needs_match(m, kind):
            return True
        if not m.get("id"):
            return False
        if not t.details_fresh(m["kind"], m["id"]):
            return True
        if m["kind"] == "tv":
            return any(not t.season_fresh(m["id"], e["season"]) for e in show["episodes"]
                       if e.get("season") is not None and e.get("number") is not None)
        return False

    def _tmdb_ensure(self, show: dict, kind: str, key: str) -> bool:
        """Start looking up one show in the background if something is missing. True while it runs."""
        box = self._tmdb_box()
        sid = show["id"]
        with box.lock:
            if sid in box.busy:
                return True
            failed = box.failed.get(sid)
            if failed and time.time() - failed[0] < RETRY_AFTER_FAILURE:
                return False
            if not self._tmdb_needs_work(show, kind):
                return False
            box.busy.add(sid)

        def run():
            try:
                self._tmdb_update(show, kind, key)
                box.failed.pop(sid, None)
            except tmdblib.TmdbError as exc:
                box.failed[sid] = (time.time(), str(exc))
            except Exception as exc:  # shown on the show page, never breaks it
                log.exception("TMDB lookup of %s failed", sid)
                box.failed[sid] = (time.time(), str(exc))
            finally:
                with box.lock:
                    box.busy.discard(sid)

        threading.Thread(target=run, daemon=True, name="anibox-tmdb-show").start()
        return True

    def _tmdb_fill_start(self, refresh: bool = False) -> bool:
        """Look up every series and movie that needs it, in the background (Settings → Get info now)."""
        key = self._tmdb_key()
        if not key:
            return False
        box = self._tmdb_box()
        with box.lock:
            if box.job.get("state") == "running":
                return False
            box.job = {"state": "running", "done": 0, "total": 0, "message": "Looking up your series and movies on TMDB …",
                       "started": time.time()}
        threading.Thread(target=self._tmdb_fill_run, args=(key, refresh), daemon=True, name="anibox-tmdb").start()
        return True

    def _tmdb_fill_run(self, key: str, refresh: bool) -> None:
        box = self._tmdb_box()
        todo = [(sh, k) for sh, k in self._tmdb_shows() if refresh or self._tmdb_needs_work(sh, k)]
        box.job["total"] = len(todo)
        problems = 0
        try:
            for i, (show, kind) in enumerate(todo):
                with box.lock:
                    if show["id"] in box.busy:
                        continue
                    box.busy.add(show["id"])
                try:
                    self._tmdb_update(show, kind, key, refresh=refresh)
                except tmdblib.TmdbError as exc:
                    if exc.status == 401 or str(exc) == tmdblib.NO_CONNECTION:
                        box.job = {"state": "error", "message": str(exc), "done": i, "total": len(todo), "at": time.time()}
                        return
                    problems += 1
                    log.info("TMDB: %s: %s", show["id"], exc)
                finally:
                    with box.lock:
                        box.busy.discard(show["id"])
                box.job["done"] = i + 1
            ids = [sh["id"] for sh, _ in self._tmdb_shows()]
            c = self.tmdb.counts(ids)
            msg = f"Done: {c['found']} of {len(ids)} series and movies found on TMDB."
            if problems:
                msg += f" {problems} couldn't be looked up; AniBox tries them again later."
            box.job = {"state": "done", "message": msg, "done": len(todo), "total": len(todo), "at": time.time()}
            log.info("TMDB: %d shows looked up (%d requests so far)", len(todo), self.tmdb.requests)
        except Exception as exc:  # shown in Settings
            log.exception("TMDB lookup failed")
            box.job = {"state": "error", "message": f"Something went wrong: {exc}", "at": time.time()}

    # -- API -----------------------------------------------------------------------------------------

    def _tmdb_status(self, query: dict) -> dict:
        key = self._tmdb_key()
        ids = [sh["id"] for sh, _ in self._tmdb_shows()]
        return {"hasKey": bool(key), "keyKind": tmdblib.key_kind(key) if key else "",
                "keyHint": (key[:4] + "…" + key[-4:]) if len(key) > 12 else ("…" if key else ""),
                "shows": len(ids), "counts": self.tmdb.counts(ids), "job": dict(self._tmdb_box().job),
                "attribution": tmdblib.ATTRIBUTION}

    def _tmdb_set_key(self, body: dict) -> dict:
        key = tmdblib.clean_key(str(body.get("key") or ""))
        if not key:
            self.store.update_settings({"tmdb_api_key": ""})
            log.info("TMDB key removed")
            return {"ok": True, "hasKey": False, "message": "Key removed. AniBox doesn't ask TMDB anything now."}
        kind = tmdblib.key_kind(key)
        if not kind:
            raise ApiError("That doesn't look like a TMDB key. Copy the “API Read Access Token” (the long one) "
                           "or the “API Key” from themoviedb.org → Settings → API.")
        checked = True
        try:
            self.tmdb.check_key(key)
        except tmdblib.TmdbError as exc:
            if exc.status == 401:
                raise ApiError(tmdblib.KEY_REFUSED)
            checked = False  # no connection right now: keep it and try later
        self.store.update_settings({"tmdb_api_key": key})
        log.info("TMDB key saved (%s)%s", "API Read Access Token" if kind == "v4" else "API Key",
                 "" if checked else ", not checked: TMDB didn't answer")
        self._tmdb_box().failed.clear()
        self._tmdb_fill_start()
        return {"ok": True, "hasKey": True, "checked": checked,
                "message": "Key saved. AniBox now looks up your series and movies." if checked else
                "Key saved, but TMDB didn't answer to check it. AniBox tries again later."}

    def _tmdb_fetch(self, body: dict) -> dict:
        if not self._tmdb_key():
            raise ApiError("Add your TMDB key first.")
        self._tmdb_box().failed.clear()
        started = self._tmdb_fill_start(refresh=bool(body.get("refresh")))
        return {"ok": True, "started": started, "job": dict(self._tmdb_box().job)}

    def _tmdb_show(self, query: dict) -> dict:
        show = self.library.show(query.get("id", ""))
        if not show:
            raise ApiError("Show not found", 404)
        kind = self._tmdb_kind(show)
        if not kind:
            return {"applies": False}
        key = self._tmdb_key()
        if not key:
            return {"applies": True, "hasKey": False, "kind": kind}
        loading = self._tmdb_ensure(show, kind, key)
        t = self.tmdb
        m = t.match_for(show["id"])
        details = t.cached_details(m["kind"], m["id"]) if m and m.get("id") else None
        if details:
            show_poster = details.get("poster") and self.store.settings().get("posters", True)
            details = dict(details, posterUrl=f"/tmdb/poster/{m['kind']}-{m['id']}" if show_poster else "")
        failed = self._tmdb_box().failed.get(show["id"])
        title, year = tmdblib.parse_folder(show["folder"])
        return {"applies": True, "hasKey": True, "kind": kind, "match": m, "details": details,
                "state": "loading" if loading else "done", "error": failed[1] if failed and not loading else "",
                "query": title, "year": year, "attribution": tmdblib.ATTRIBUTION}

    def _tmdb_search(self, query: dict) -> dict:
        key = self._tmdb_key()
        if not key:
            raise ApiError("Add your TMDB key first (Settings → Series and movie info).")
        text = (query.get("q") or "").strip()
        if not text:
            return {"results": []}
        kind = query.get("kind") if query.get("kind") in tmdblib.KINDS else "tv"
        title, year = tmdblib.parse_folder(text)
        try:
            results = self.tmdb.search(kind, title, year, key)
            if not results and year:
                results = self.tmdb.search(kind, title, None, key)
        except tmdblib.TmdbError as exc:
            raise ApiError(str(exc), 502 if exc.status != 401 else 400)
        return {"results": results[:20]}

    def _tmdb_match(self, body: dict) -> dict:
        show = self.library.show(str(body.get("show") or ""))
        if not show:
            raise ApiError("Show not found", 404)
        kind = self._tmdb_kind(show)
        if not kind:
            raise ApiError("TMDB info is only for series and movies, not anime.")
        t = self.tmdb
        if body.get("auto"):
            t.forget_match(show["id"])
            log.info("TMDB match of %s: back to automatic", show["id"])
        elif body.get("none"):
            t.set_match(show["id"], kind, None, True)
            log.info("TMDB match of %s: not on TMDB (by hand)", show["id"])
        else:
            try:
                tmdb_id = int(body.get("id"))
            except (TypeError, ValueError):
                raise ApiError("Pick an entry.")
            if tmdb_id <= 0:
                raise ApiError("Pick an entry.")
            want = body.get("kind") if body.get("kind") in tmdblib.KINDS else kind
            t.set_match(show["id"], want, tmdb_id, True)
            log.info("TMDB match of %s: %s %s (by hand)", show["id"], want, tmdb_id)
        self._tmdb_box().failed.pop(show["id"], None)
        key = self._tmdb_key()
        if key:
            self._tmdb_ensure(show, kind, key)
        return {"ok": True, "match": t.match_for(show["id"])}
