"""Watch an old episode again, or start a show or playlist again from an episode (Frostbox's
"Erneut ansehen").

- **Just this episode** is the player's ``once`` mode (player.py): it plays and then stops, nothing
  runs on by itself, and "Continue" stays where you were (watching.next_up goes back to the first
  unwatched episode after the one you watched again, with its resume point).
- **Start again from here** (:func:`restart`): this episode and every later one count as not
  watched again; earlier ones stay watched; "Continue" starts at this episode. The old progress of
  those episodes is kept in ``rewatch-log.jsonl`` in AniBox's data folder, so it can be undone
  (:func:`undo`, also from the History page). It never touches your MyAnimeList/AniList lists:
  AniBox's sync never lowers progress there.
- A restart belongs to the profile it was done in (``profile`` in the log; older entries: ``main``),
  and Undo puts the progress back into that profile, whichever profile is active then.
"""

from __future__ import annotations

import json
import logging
import os
import secrets
import threading
import time
from pathlib import Path
from typing import Dict, List, Optional

from .store import MAIN

log = logging.getLogger("anibox.rewatch")

LOG_NAME = "rewatch-log.jsonl"
_lock = threading.Lock()


def _read(data_dir: Path) -> List[dict]:
    try:
        lines = (Path(data_dir) / LOG_NAME).read_text(encoding="utf-8").splitlines()
    except OSError:
        return []
    out = []
    for line in lines:
        try:
            r = json.loads(line)
        except ValueError:
            continue
        if isinstance(r, dict):
            out.append(r)
    return out


def _append(data_dir: Path, record: dict) -> None:
    path = Path(data_dir) / LOG_NAME
    with open(path, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(record, ensure_ascii=False) + "\n")
        fh.flush()
        os.fsync(fh.fileno())


def restart(store, data_dir: Path, show: dict, key: str) -> dict:
    """Start ``show`` again from the episode ``key``: it and all later ones count as not watched."""
    eps = show.get("episodes") or []
    idx = next((i for i, e in enumerate(eps) if e.get("key") == key), -1)
    if idx < 0:
        raise ValueError("That episode isn't in this list (any more).")
    keys = [e["key"] for e in eps[idx:]]
    profile = store.profile  # all of it in the profile active now, even if another one is picked meanwhile
    with _lock:
        before: Dict[str, Optional[dict]] = {k: store.progress(k, profile=profile) for k in keys}
        reset = sum(1 for r in before.values() if r and (r.get("watched") or float(r.get("position") or 0) > 0))
        store.delete_progress(keys, profile=profile)
        store.save_position(key, show["id"], 0, 0, watched=False, profile=profile)  # "Continue" starts here
        record = {"id": secrets.token_hex(6), "time": time.time(), "show": show["id"],
                  "title": str(show.get("title") or ""), "from": str(eps[idx].get("label") or ""),
                  "count": len(keys), "reset": reset, "rows": before, "profile": profile}
        _append(data_dir, record)
    log.info("Started %s again from %s (%d episodes, %d had progress)", record["title"], record["from"], len(keys), reset)
    return {"id": record["id"], "from": record["from"], "count": len(keys), "reset": reset}


def entries(data_dir: Path) -> List[dict]:
    """The restarts, newest first, for the History page."""
    records = _read(data_dir)
    undone = {r["undo"]: float(r.get("time") or 0) for r in records if r.get("undo")}
    out = []
    for r in records:
        if not r.get("id") or r.get("undo"):
            continue
        out.append({"id": "rewatch:" + r["id"], "kind": "rewatch", "time": float(r.get("time") or 0),
                    "title": f"Started {r.get('title') or 'a show'} again from {r.get('from') or 'an episode'}",
                    "detail": f"{r.get('reset', 0)} episodes counted as not watched again",
                    "show": "" if str(r.get("show") or "").startswith("ia:") else (r.get("show") or ""),
                    "profile": str(r.get("profile") or MAIN),
                    "undone": undone.get(r["id"]) or None, "undo": {"can": r["id"] not in undone, "why": ""}})
    out.sort(key=lambda e: e["time"], reverse=True)
    return out


def undo(store, data_dir: Path, entry_id: str, check: bool = False) -> dict:
    """Put the progress back as it was before that restart. Episodes played since keep their new
    progress (nothing you did afterwards is lost); ``check`` only says what would happen."""
    with _lock:
        records = _read(data_dir)
        rec = next((r for r in records if r.get("id") == entry_id and not r.get("undo")), None)
        if rec is None:
            raise ValueError("That change isn't in the list anymore.")
        if any(r.get("undo") == entry_id for r in records):
            raise ValueError("That change was undone already.")
        when = float(rec.get("time") or 0)
        rows = rec.get("rows") or {}
        profile = str(rec.get("profile") or MAIN)  # back into the profile it was done in
        if not store.profile_row(profile):
            raise ValueError("The profile this was done in doesn't exist any more.")
        back, kept = {}, 0
        for k, old in rows.items():
            cur = store.progress(k, profile=profile)
            if cur is not None and float(cur.get("updated") or 0) > when + 0.5:
                kept += 1  # played since: keep what you did
                continue
            back[k] = old
        if check:
            return {"ok": True, "kind": "rewatch", "restore": len(back), "kept": kept}
        store.restore_progress(back, profile=profile)
        _append(data_dir, {"undo": entry_id, "time": time.time()})
    log.info("Undid starting %s again (%d episodes back, %d kept)", rec.get("title"), len(back), kept)
    return {"ok": True, "restored": len(back), "kept": kept, "title": rec.get("title") or ""}
