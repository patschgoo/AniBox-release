"""Watch statistics and a recommended watch order for franchises. Only reads what AniBox knows.

Statistics come from the watch progress in AniBox's database: every episode marked as watched
counts, on the day it was marked (episodes marked by hand or copied from Plex count on the day you
did that). Hours = watched episodes × their length: the length the player saw, else the show's
other episodes, else the anime lists' episode length, else a typical length for the kind of show.

Watch order: the franchise's entries in release order (year, then season of the year), from the
anime lists. The lists link related entries but don't say which is the prequel or the sequel, so
release order is the order. Short clips (commercials, music videos) are left out of the numbered
steps; OVAs, specials and music videos are marked optional.
"""

from __future__ import annotations

import time
from datetime import date, datetime, timedelta
from typing import Callable, Dict, Iterable, List, Optional, Tuple

SEASONS = {"WINTER": 0, "SPRING": 1, "SUMMER": 2, "FALL": 3}
OPTIONAL_TYPES = {"OVA", "SPECIAL", "MUSIC"}
TYPICAL_SECONDS = {"anime": 24 * 60, "series": 42 * 60, "movie": 100 * 60}
MIN_DURATION = 60  # shorter "durations" are broken files, not episodes
KIND_LABELS = {"anime": "Anime", "series": "Series", "movie": "Movies"}
TYPE_LABELS = {"TV": "TV series", "MOVIE": "Movies", "OVA": "OVAs", "ONA": "ONAs", "SPECIAL": "Specials",
               "MUSIC": "Music videos", "": "Not on MyAnimeList", "UNKNOWN": "Unknown"}


def _local_day(ts: float) -> date:
    return datetime.fromtimestamp(ts).date()


def _streaks(days: Iterable[date], today: date) -> Tuple[int, int]:
    """(current streak, longest streak) in days. The current one may end yesterday (today isn't over)."""
    have = set(days)
    longest = run = 0
    prev = None
    for d in sorted(have):
        run = run + 1 if prev is not None and d - prev == timedelta(days=1) else 1
        longest = max(longest, run)
        prev = d
    start = today if today in have else today - timedelta(days=1)
    current = 0
    while start in have:
        current += 1
        start -= timedelta(days=1)
    return current, longest


def _last_months(now: float, n: int = 12) -> List[Tuple[int, int]]:
    d = datetime.fromtimestamp(now)
    y, m = d.year, d.month
    out = []
    for _ in range(n):
        out.append((y, m))
        y, m = (y, m - 1) if m > 1 else (y - 1, 12)
    return out[::-1]


def watch_stats(shows: List[dict], progress: Dict[str, dict], kind_of: Callable[[dict], Tuple[str, str]],
                titles: Dict[str, dict], genres_of: Callable[[str], Optional[List[str]]] = lambda m: None,
                poster_of: Callable[[dict], str] = lambda s: "", now: Optional[float] = None) -> dict:
    """Totals, the last 12 months, sections, MyAnimeList types, genres, most watched, finished this
    year and the streak, for these shows (the libraries the Library page shows)."""
    now = time.time() if now is None else now
    this_year = datetime.fromtimestamp(now).year
    months = {ym: {"episodes": 0, "seconds": 0.0} for ym in _last_months(now)}
    kinds: Dict[str, dict] = {}
    types: Dict[str, dict] = {}
    genres: Dict[str, dict] = {}
    per_show: List[dict] = []
    days = []
    total_eps = total_secs = estimated = 0
    started = finished = files = 0
    genres_known = genre_candidates = 0
    for sh in shows:
        eps = sh.get("episodes") or []
        files += len(eps)
        kind, _ = kind_of(sh)
        known = [float((progress.get(e["key"]) or {}).get("duration") or 0) for e in eps]
        known = [d for d in known if d >= MIN_DURATION]
        show_avg = sum(known) / len(known) if known else 0.0
        info = titles.get(str(sh.get("mal_id") or "")) or {}
        list_len = float(info.get("duration") or 0) if sh.get("mal_id") else 0.0
        watched_eps, secs, last = 0, 0.0, 0.0
        for e in eps:
            p = progress.get(e["key"]) or {}
            if not p.get("watched"):
                continue
            dur = float(p.get("duration") or 0)
            if dur < MIN_DURATION:
                estimated += 1
                dur = show_avg or (list_len if list_len >= MIN_DURATION else 0) or TYPICAL_SECONDS.get(kind, 24 * 60)
            when = float(p.get("updated") or 0)
            watched_eps += 1
            secs += dur
            last = max(last, when)
            if when:
                days.append(_local_day(when))
                d = datetime.fromtimestamp(when)
                if (d.year, d.month) in months:
                    months[(d.year, d.month)]["episodes"] += 1
                    months[(d.year, d.month)]["seconds"] += dur
        if not watched_eps:
            continue
        started += 1
        done = watched_eps >= len(eps)
        finished += 1 if done else 0
        total_eps += watched_eps
        total_secs += secs
        for bucket, key in ((kinds, kind), (types, (sh.get("type") or "") if kind == "anime" else None)):
            if key is None:
                continue
            b = bucket.setdefault(key, {"shows": 0, "episodes": 0, "seconds": 0.0})
            b["shows"] += 1
            b["episodes"] += watched_eps
            b["seconds"] += secs
        if kind == "anime" and sh.get("mal_id"):
            genre_candidates += 1
            g = genres_of(str(sh["mal_id"]))
            if g is not None:
                genres_known += 1
                for name in g:
                    b = genres.setdefault(name, {"shows": 0, "episodes": 0, "seconds": 0.0})
                    b["shows"] += 1
                    b["episodes"] += watched_eps
                    b["seconds"] += secs
        per_show.append({"id": sh["id"], "title": sh.get("title") or sh.get("folder") or "", "poster": poster_of(sh),
                         "library": sh.get("library") or "", "episodes": watched_eps, "files": len(eps),
                         "hours": round(secs / 3600, 1), "finished": done, "last": last, "_secs": secs})

    def rows(bucket: Dict[str, dict], labels: Dict[str, str]) -> List[dict]:
        out = [{"key": k, "label": labels.get(k, k or "Other"), "shows": v["shows"],
                "episodes": v["episodes"], "hours": round(v["seconds"] / 3600, 1)} for k, v in bucket.items()]
        return sorted(out, key=lambda r: (-r["hours"], -r["episodes"], r["label"]))

    top = sorted(per_show, key=lambda s: (-s["_secs"], -s["episodes"], s["title"].casefold()))[:10]
    done_year = sorted((s for s in per_show if s["finished"] and s["last"] and datetime.fromtimestamp(s["last"]).year == this_year),
                       key=lambda s: s["last"], reverse=True)
    for s in per_show:
        s.pop("_secs", None)
    current, longest = _streaks(days, _local_day(now))
    genre_rows = rows(genres, {})[:15] if genres_known else []
    return {
        "year": this_year,
        "totals": {"shows": len(shows), "files": files, "started": started, "finished": finished,
                   "episodes": total_eps, "hours": round(total_secs / 3600, 1), "estimated": estimated},
        "months": [{"month": f"{y:04d}-{m:02d}", "episodes": v["episodes"], "hours": round(v["seconds"] / 3600, 1)}
                   for (y, m), v in months.items()],
        "kinds": rows(kinds, KIND_LABELS),
        "types": rows(types, TYPE_LABELS),
        "genres": genre_rows, "genresKnown": genres_known, "genreShows": genre_candidates,
        "top": top,
        "finishedThisYear": [{"id": s["id"], "title": s["title"], "poster": s["poster"], "when": s["last"],
                              "episodes": s["episodes"]} for s in done_year],
        "streak": {"current": current, "longest": longest, "days": len(set(days)),
                   "today": _local_day(now) in set(days)},
    }


# -- watch order ---------------------------------------------------------------------------------------


def order_key(entry: dict, titles: Dict[str, dict]) -> tuple:
    info = titles.get(str(entry.get("mal_id"))) or {}
    year = entry.get("year") or info.get("year") or 9999
    season = SEASONS.get(str(info.get("season") or "").upper(), 4)
    mal = str(entry.get("mal_id") or "")
    return (int(year), season, int(mal) if mal.isdigit() else 0)


def watch_order(entries: List[dict], titles: Dict[str, dict], shows_by_mal: Dict[str, List[dict]],
                progress: Dict[str, dict], poster_of: Callable[[dict], str] = lambda s: "") -> List[dict]:
    """The franchise's entries (``entry_json`` dicts) in release order, each with what you have and
    what you've watched: ``have`` (owned, partial, unsure, missing, upcoming) and ``watch`` (watched,
    partly, unwatched, or "" when it isn't on your drives)."""
    out = []
    step = 0
    for e in sorted(entries, key=lambda x: order_key(x, titles)):
        mal = str(e.get("mal_id") or "")
        info = titles.get(mal) or {}
        owned = shows_by_mal.get(mal) or []
        n_files = sum(len(s.get("episodes") or []) for s in owned)
        watched = sum(1 for s in owned for ep in s.get("episodes") or [] if (progress.get(ep["key"]) or {}).get("watched"))
        touched = any((progress.get(ep["key"]) or {}).get("updated") for s in owned for ep in s.get("episodes") or [])
        if owned:
            watch = "watched" if n_files and watched >= n_files else "partly" if watched or touched else "unwatched"
        else:
            watch = ""
        have = e.get("status") or ("owned" if owned else "missing")
        if owned and have in ("missing", "upcoming"):
            have = "owned"
        short = bool(e.get("short"))
        if not short:
            step += 1
        best = max(owned, key=lambda s: len(s.get("episodes") or []), default=None)
        out.append({
            "step": 0 if short else step, "mal_id": mal, "title": e.get("title") or info.get("title") or f"MAL #{mal}",
            "type": e.get("type") or info.get("type") or "", "year": e.get("year") or info.get("year"),
            "season": (info.get("season") or "").title() if info.get("season") not in (None, "UNDEFINED") else "",
            "episodes": e.get("episodes"), "short": short,
            "optional": short or (e.get("type") or info.get("type") or "") in OPTIONAL_TYPES,
            "have": have, "watch": watch, "watched": watched, "files": n_files,
            "show": best["id"] if best else "", "poster": poster_of(best) if best else "",
            "mal_url": e.get("mal_url") or f"https://myanimelist.net/anime/{mal}",
        })
    return out


def next_in_order(order: List[dict], mal_id: str) -> Optional[dict]:
    """What to watch after ``mal_id``: the next entry in the watch order that isn't watched yet, the
    main story (series, movies, ONAs) before optional OVAs and specials; short clips never. If
    everything after it is watched, the first one before it that isn't."""
    idx = next((i for i, e in enumerate(order) if e["mal_id"] == str(mal_id)), None)
    if idx is None:
        return None
    todo = lambda e: not e["short"] and e["watch"] != "watched" and e["mal_id"] != str(mal_id)  # noqa: E731
    for part, after in ((order[idx + 1:], True), (order[:idx], False)):
        pick = next((e for e in part if todo(e) and not e["optional"]), None) or next((e for e in part if todo(e)), None)
        if pick:
            return dict(pick, after=after)
    return None
