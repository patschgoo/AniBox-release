"""Moving, copying and renaming video files for AniBox, with a log and an undo.

Used by "Add new videos" (from Downloads into a library folder) and by "Move or rename" (a show
that is new or that the user unlocked). Rules, whatever the caller asks:

- **Never overwrite.** If the target file already exists, that file is skipped and reported.
- **Never delete anything that wasn't moved.** A move between drives is copy → check size → delete
  the original; if the copy is short, the original stays and the copy is removed again.
- **Everything goes into a log** (``app/file-log.jsonl``): one line per file, grouped by batch, so the
  last batch can be undone (moved back, or a copy removed again if it's unchanged).
- Subtitle and info files next to a video (``Title 01.en.ass``, ``Title 01.nfo``) go with it.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import threading
import time
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Optional

CHUNK = 4 * 1024 * 1024
WINDOWS_BAD = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
RESERVED = {"CON", "PRN", "AUX", "NUL"} | {f"COM{i}" for i in range(1, 10)} | {f"LPT{i}" for i in range(1, 10)}


class FileOpError(Exception):
    pass


def safe_name(name: str, fallback: str = "Untitled") -> str:
    """A file or folder name Windows accepts: no <>:"/\\|?*, no trailing dots or spaces, not CON etc.
    (Like Windows itself, characters are dropped: "Re:Zero" -> "ReZero", ".hack//Sign" -> "hackSign".)"""
    name = WINDOWS_BAD.sub("", name or "")
    name = re.sub(r"\s+", " ", name).strip(" .")
    if not name or name.upper().split(".")[0] in RESERVED:
        name = (name + "_") if name else fallback
    return name[:150]


def sidecars(video: Path) -> List[Path]:
    """Files that belong to a video: same name start, e.g. "Title 01.en.ass", "Title 01.nfo"."""
    stem = video.stem
    try:
        return sorted(p for p in video.parent.iterdir()
                      if p.is_file() and p != video and p.name.startswith(stem + ".") and not p.name.endswith((".part", ".tmp")))
    except OSError:
        return []


def with_sidecars(src: Path, dst: Path) -> List[Dict[str, str]]:
    """The operations for one video and the files that belong to it."""
    ops = [{"src": str(src), "dst": str(dst)}]
    for side in sidecars(src):
        rest = side.name[len(src.stem):]  # ".en.ass"
        ops.append({"src": str(side), "dst": str(dst.with_name(dst.stem + rest))})
    return ops


class FileOps:
    """Runs a list of {src, dst} operations in the background and keeps the log."""

    def __init__(self, log_path: Path):
        self.log_path = Path(log_path)
        self.state = {"state": "idle"}
        self._lock = threading.Lock()

    # -- checking a plan -------------------------------------------------------------------------

    @staticmethod
    def check(ops: Iterable[dict], allowed_roots: Iterable[str] = (), forbidden_roots: Iterable[str] = ()) -> List[dict]:
        """Each op with a "problem" ("" if fine): missing source, target exists, outside the allowed
        folders, inside a protected folder, the same file twice."""
        allowed = [os.path.normcase(os.path.abspath(r)) for r in allowed_roots]
        forbidden = [os.path.normcase(os.path.abspath(r)) for r in forbidden_roots]
        seen, out = set(), []
        for op in ops:
            src, dst = op["src"], op["dst"]
            nd = os.path.normcase(os.path.abspath(dst))
            problem = ""
            if not os.path.isfile(src):
                problem = "The file isn't there anymore."
            elif os.path.exists(dst) and os.path.normcase(os.path.abspath(src)) != nd:
                problem = "A file with this name is already there; it's left alone."
            elif nd in seen:
                problem = "Two files would get the same name."
            elif allowed and not any(nd == a or nd.startswith(a.rstrip("\\/") + os.sep) for a in allowed):
                problem = "That place isn't one of your library folders."
            elif any(nd == f or nd.startswith(f.rstrip("\\/") + os.sep) for f in forbidden):
                problem = "That folder is protected."
            seen.add(nd)
            out.append({**op, "problem": problem})
        return out

    # -- running ---------------------------------------------------------------------------------

    def start(self, ops: List[dict], mode: str, label: str, done: Optional[Callable[[dict], None]] = None) -> dict:
        """Run the ops (only those without a problem) in a background thread. ``mode``: move or copy."""
        if mode not in ("move", "copy"):
            raise FileOpError("Unknown mode")
        with self._lock:
            if self.state.get("state") == "running":
                raise FileOpError("AniBox is still busy with the last files.")
            todo = [op for op in ops if not op.get("problem")]
            total = sum(os.path.getsize(op["src"]) for op in todo if os.path.isfile(op["src"]))
            batch = time.strftime("%Y%m%d-%H%M%S") + f"-{os.getpid() % 1000}"
            used, base, n = {e.get("batch") for e in self.entries()}, batch, 2
            while batch in used:  # two batches in the same second: each one stays undoable on its own
                batch, n = f"{base}-{n}", n + 1
            self.state = {"state": "running", "label": label, "batch": batch, "done": 0, "files": len(todo),
                          "bytes": 0, "total": total, "current": "", "errors": []}

        def run():
            ok = []
            for op in todo:
                self.state["current"] = os.path.basename(op["src"])
                try:
                    self._one(op["src"], op["dst"], mode, batch)
                    ok.append(op)
                except Exception as exc:  # reported; the others go on
                    self.state["errors"].append({"file": op["src"], "error": str(exc)})
                self.state["done"] += 1
            self.state.update(current="", moved=len(ok))
            if done:
                try:
                    done({**self.state, "ops": ok})
                except Exception as exc:
                    self.state["errors"].append({"file": "", "error": f"After moving: {exc}"})
            self.state.update(state="done", finished=time.time())

        threading.Thread(target=run, daemon=True, name="anibox-fileops").start()
        return self.state

    def _one(self, src: str, dst: str, mode: str, batch: str) -> None:
        if os.path.exists(dst):
            raise FileOpError("a file with this name is already there")
        size = os.path.getsize(src)
        created = self._makedirs(os.path.dirname(dst))
        how = mode
        if mode == "move":
            try:
                os.rename(src, dst)  # same drive: instant, nothing copied
                how = "rename"
            except OSError:
                self._copy(src, dst, size)
                os.remove(src)
        else:
            self._copy(src, dst, size)
        if how == "rename":
            self.state["bytes"] += size  # copies count while they run
        self._log({"batch": batch, "op": how, "src": src, "dst": dst, "size": size, "dirs": created, "time": time.time(),
                   "label": self.state.get("label", "")})

    def _copy(self, src: str, dst: str, size: int) -> None:
        part = dst + ".anibox-part"
        try:
            with open(src, "rb") as fi, open(part, "xb") as fo:
                while True:
                    buf = fi.read(CHUNK)
                    if not buf:
                        break
                    fo.write(buf)
                    self.state["bytes"] += len(buf)
            if os.path.getsize(part) != size:
                raise FileOpError("the copy came out the wrong size")
            shutil.copystat(src, part)
            os.rename(part, dst)
        except BaseException:
            try:
                os.remove(part)
            except OSError:
                pass
            raise

    @staticmethod
    def _makedirs(folder: str) -> List[str]:
        created = []
        path = os.path.abspath(folder)
        while path and not os.path.isdir(path):
            created.append(path)
            parent = os.path.dirname(path)
            if parent == path:
                break
            path = parent
        for d in reversed(created):
            os.mkdir(d)
        return list(reversed(created))

    def _log(self, entry: dict) -> None:
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.log_path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(entry, ensure_ascii=False) + "\n")

    # -- undo ------------------------------------------------------------------------------------

    def entries(self) -> List[dict]:
        try:
            lines = self.log_path.read_text(encoding="utf-8").splitlines()
        except OSError:
            return []
        out = []
        for line in lines:
            try:
                out.append(json.loads(line))
            except ValueError:
                continue
        return out

    def last_batch(self) -> Optional[dict]:
        entries = [e for e in self.entries() if not e.get("undone")]
        undone = {e["batch"] for e in self.entries() if e.get("undo_of")}
        batches = [e["batch"] for e in entries if not e.get("undo_of") and e["batch"] not in undone]
        if not batches:
            return None
        b = batches[-1]
        files = [e for e in entries if e["batch"] == b and not e.get("undo_of")]
        return {"batch": b, "files": len(files), "time": files[-1]["time"], "example": os.path.basename(files[0]["dst"])}

    def undo_last(self) -> dict:
        last = self.last_batch()
        if not last:
            raise FileOpError("Nothing to undo.")
        files = [e for e in self.entries() if e.get("batch") == last["batch"] and not e.get("undo_of")]
        done, problems, dirs = 0, [], []
        for e in reversed(files):
            src, dst = e["src"], e["dst"]
            try:
                if not os.path.isfile(dst):
                    raise FileOpError("it isn't where AniBox put it anymore")
                if os.path.getsize(dst) != e.get("size"):
                    raise FileOpError("it was changed since")
                if e["op"] == "copy":
                    os.remove(dst)  # the copy AniBox made; the original is still in its place
                else:
                    if os.path.exists(src):
                        raise FileOpError("there's a file at the old place again")
                    self._makedirs(os.path.dirname(src))
                    try:
                        os.rename(dst, src)
                    except OSError:
                        self._copy(dst, src, e["size"])
                        os.remove(dst)
                done += 1
                dirs += e.get("dirs") or []
            except Exception as exc:
                problems.append({"file": dst, "error": str(exc)})
        for d in sorted(set(dirs), key=len, reverse=True):  # folders AniBox made, if they're empty now
            try:
                os.rmdir(d)
            except OSError:
                pass
        self._log({"batch": last["batch"], "undo_of": last["batch"], "time": time.time(), "files": done})
        return {"undone": done, "problems": problems}

    # -- undo of any batch, also an older one (History page) ---------------------------------------

    def batches(self) -> List[dict]:
        """Every batch in the log, oldest first: {"batch", "label", "time", "files": [log entries],
        "undone": time of its undo or None}."""
        out: Dict[str, dict] = {}
        for e in self.entries():
            b = e.get("batch")
            if not b:
                continue
            if e.get("undo_of"):
                if e["undo_of"] in out:
                    out[e["undo_of"]]["undone"] = e.get("time") or 0.0
                continue
            if not e.get("src") or not e.get("dst"):
                continue
            info = out.setdefault(b, {"batch": b, "label": e.get("label") or "", "time": e.get("time") or 0.0,
                                      "files": [], "undone": None})
            info["files"].append(e)
        return list(out.values())

    @staticmethod
    def _touched(files: Iterable[dict]) -> set:
        return {os.path.normcase(os.path.abspath(p)) for e in files for p in (e.get("src"), e.get("dst")) if p}

    def undo_blocker(self, batch_id: str, batches: Optional[List[dict]] = None) -> Optional[dict]:
        """A later batch (not undone) that moved, copied or renamed one of the same files, or None.
        Only reads the log."""
        batches = self.batches() if batches is None else batches
        idx = next((i for i, b in enumerate(batches) if b["batch"] == batch_id), None)
        if idx is None:
            return None
        mine = self._touched(batches[idx]["files"])
        for later in batches[idx + 1:]:
            if not later["undone"] and mine & self._touched(later["files"]):
                return later
        return None

    @staticmethod
    def _undo_problem(e: dict) -> str:
        """Why this file can't be put back ("" if it can). Looks at the drive."""
        src, dst = e["src"], e["dst"]
        if not os.path.isfile(dst):
            return "it isn't where AniBox put it anymore"
        if os.path.getsize(dst) != e.get("size"):
            return "it was changed since"
        if e.get("op") != "copy" and os.path.exists(src):
            return "there's a file at the old place again"
        return ""

    def undo_problems(self, batch_id: str) -> List[dict]:
        """[{"file", "error"}] for every file of the batch that can't be put back (reads the drives)."""
        b = next((x for x in self.batches() if x["batch"] == batch_id), None)
        if not b:
            raise FileOpError("That change isn't in the list.")
        return [{"file": e["dst"], "error": p} for e in b["files"] for p in [self._undo_problem(e)] if p]

    def undo_batch(self, batch_id: str) -> dict:
        """Undo one batch, also an older one. Refused, with nothing changed, when it was undone already,
        when a later batch (not undone) touched one of its files (undo that one first), or when any of its
        files changed since. Then like ``undo_last``: moved files go back, copies are removed, folders AniBox
        made go if they're empty."""
        if self.state.get("state") == "running":
            raise FileOpError("AniBox is still busy with the last files.")
        batches = self.batches()
        b = next((x for x in batches if x["batch"] == batch_id), None)
        if not b:
            raise FileOpError("That change isn't in the list.")
        if b["undone"]:
            raise FileOpError("That change was undone already.")
        later = self.undo_blocker(batch_id, batches)
        if later:
            when = time.strftime("%Y-%m-%d %H:%M", time.localtime(later["time"]))
            raise FileOpError(f"A later change ({when}) moved some of the same files. Undo that one first.")
        problems = [(e, p) for e in b["files"] for p in [self._undo_problem(e)] if p]
        if problems:
            e, p = problems[0]
            raise FileOpError(f"{len(problems)} of its files changed since ({os.path.basename(e['dst'])}: {p}), "
                              "so AniBox leaves this change as it is.")
        done, failed, dirs = 0, [], []
        for e in reversed(b["files"]):
            try:
                problem = self._undo_problem(e)
                if problem:
                    raise FileOpError(problem)
                if e.get("op") == "copy":
                    os.remove(e["dst"])  # the copy AniBox made; the original is still in its place
                else:
                    self._makedirs(os.path.dirname(e["src"]))
                    try:
                        os.rename(e["dst"], e["src"])
                    except OSError:
                        self._copy(e["dst"], e["src"], e["size"])
                        os.remove(e["dst"])
                done += 1
                dirs += e.get("dirs") or []
            except Exception as exc:
                failed.append({"file": e["dst"], "error": str(exc)})
        for d in sorted(set(dirs), key=len, reverse=True):  # folders AniBox made, if they're empty now
            try:
                os.rmdir(d)
            except OSError:
                pass
        self._log({"batch": batch_id, "undo_of": batch_id, "time": time.time(), "files": done})
        return {"undone": done, "problems": failed}
