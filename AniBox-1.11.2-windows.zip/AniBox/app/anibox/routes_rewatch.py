"""Watch again / start again from here (rewatch.py): the window's routes.

Part of the App class (see server.py); the methods use the App's attributes.
"""

from __future__ import annotations

from . import rewatch
from .apierror import ApiError


class RoutesRewatchMixin:
    POST_ROUTES = {
        "/api/rewatch/restart": "_rewatch_restart",
        "/api/rewatch/undo": "_rewatch_undo",
    }

    def _rewatch_restart(self, body: dict) -> dict:
        show_id, key = str(body.get("show") or ""), str(body.get("key") or "")
        if not show_id or not key:
            raise ApiError("Pick an episode first.")
        show = self.player.show_of(show_id)
        if not show:
            raise ApiError("That show or playlist isn't there any more.")
        try:
            return rewatch.restart(self.store, self.data_dir, show, key)
        except ValueError as exc:
            raise ApiError(str(exc))

    def _rewatch_undo(self, body: dict) -> dict:
        rid = str(body.get("id") or "")
        if rid.startswith("rewatch:"):
            rid = rid[len("rewatch:"):]
        try:
            return rewatch.undo(self.store, self.data_dir, rid, check=bool(body.get("check")))
        except ValueError as exc:
            raise ApiError(str(exc))
