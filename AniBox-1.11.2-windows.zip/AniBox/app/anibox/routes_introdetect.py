"""Openings and endings without chapters: "Find opening and ending" on a show's page, "Check every
show" in Settings, hand corrections, and the automatic look when a show's page opens (if switched on).

Part of the App class (see server.py); the methods use the App's attributes. Only the AniBox window
reaches these routes (``GET_ROUTES``/``POST_ROUTES`` are never served to the phone remote). The state
is made on first use (``_intro()``), so the App's ``__init__`` needs nothing for it.

Nothing here writes next to the videos: everything found is kept in ``skip-markers.json`` in AniBox's
own data folder (introdetect.py).
"""

from __future__ import annotations

import atexit
import logging
import threading
import time
from typing import Optional

from . import introdetect
from .apierror import ApiError
from .ffmpegsetup import find_tools

log = logging.getLogger("anibox.server")
_INIT = threading.Lock()


def _seconds(value) -> Optional[float]:
    """12.5, "12.5", "1:32" or "1:02:03" -> seconds; None if it isn't a time."""
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value or "").strip()
    if not text:
        return None
    try:
        parts = [float(p) for p in text.split(":")]
    except ValueError:
        return None
    if len(parts) > 3 or any(p < 0 for p in parts):
        return None
    total = 0.0
    for p in parts:
        total = total * 60 + p
    return total


class RoutesIntroMixin:
    GET_ROUTES = {
        "/api/intro/show": "_intro_show_get",
        "/api/intro/job": "_intro_job_get",
    }
    POST_ROUTES = {
        "/api/intro/find": "_intro_find",
        "/api/intro/all": "_intro_all",
        "/api/intro/cancel": "_intro_cancel",
        "/api/intro/edit": "_intro_edit",
        "/api/intro/off": "_intro_off",
    }

    # -- state ---------------------------------------------------------------------------------------

    def _intro(self) -> introdetect.Detector:
        det = self.__dict__.get("_intro_detector")
        if det is not None:
            return det
        with _INIT:
            det = self.__dict__.get("_intro_detector")
            if det is None:
                det = introdetect.Detector(introdetect.store_for(self.data_dir), self._intro_tools,
                                           busy=self._intro_playing, keepalive=self._intro_keepalive)
                self.__dict__["_intro_detector"] = det
                atexit.register(self._intro_stop)  # AniBox closes: stop ffmpeg too
                self.__dict__["_intro_auto_seen"] = (None, set())  # (scan time, shows looked at automatically)
        return det

    def _intro_keepalive(self) -> None:
        self.last_seen = time.time()  # like downloads: AniBox stays open while it's looking

    def _intro_stop(self) -> None:
        det = self.__dict__.get("_intro_detector")
        if det is not None and det.running:
            det.cancel()
            det.wait(3)

    def _intro_tools(self) -> dict:
        return find_tools(self.data_dir, self.store.settings().get("ffmpeg_path") or "")

    def _intro_playing(self, show_id: str) -> bool:
        """Is this show playing (here or on a TV)? Then nothing is looked at automatically."""
        player = getattr(self, "player", None)
        if player is not None and player.running and player.show_id == show_id:
            return True
        tv = getattr(self, "tv", None)
        try:
            return bool(tv is not None and tv.active and tv.show_id == show_id)
        except Exception:
            return False

    def _intro_show(self, show_id) -> dict:
        show = self.library.show(str(show_id or ""))
        if not show:
            raise ApiError("Show not found", 404)
        return show

    # -- reading ---------------------------------------------------------------------------------------

    def _intro_episode_row(self, ep: dict) -> dict:
        store = self._intro().store
        e = store.entry(ep["path"])
        eff = store.effective(e)
        chapters = (e or {}).get("chapters") or []
        return {"key": ep["key"], "label": ep.get("label") or "", "file": ep.get("file") or "",
                "checked": bool(e), "note": (e or {}).get("note") or "", "chapters": chapters,
                "duration": (e or {}).get("duration") or 0, "edited": bool((e or {}).get("manual")),
                "opening": eff["opening"], "ending": eff["ending"]}

    def _intro_show_get(self, query: dict) -> dict:
        show = self._intro_show(query.get("id", ""))
        det = self._intro()
        settings = self.store.settings()
        tools = self._intro_tools()
        auto = bool(settings.get("intro_auto"))
        started_auto = False
        if auto and tools.get("ffmpeg"):
            scan, seen = self.__dict__.get("_intro_auto_seen") or (None, set())
            if scan != self.library.scanned_at:
                seen = set()
                self.__dict__["_intro_auto_seen"] = (self.library.scanned_at, seen)
            if show["id"] not in seen and not self._intro_playing(show["id"]):
                seen.add(show["id"])
                det.queue([show], auto=True)  # only episodes without chapters or an earlier result
                started_auto = True
        rows = [self._intro_episode_row(ep) for ep in show["episodes"]]
        counts = {"total": len(rows), "checked": sum(1 for r in rows if r["checked"]),
                  "opening": sum(1 for r in rows if r["opening"]), "ending": sum(1 for r in rows if r["ending"]),
                  "chapters": sum(1 for r in rows if r["chapters"])}
        job = det.state()
        mine = job.get("show") == show["id"] or show["id"] in job.get("queuedShows", [])
        method = ""
        if tools.get("ffmpeg"):
            method = introdetect.pick_method(tools["ffmpeg"])
        return {"show": show["id"], "off": det.store.is_off(show["id"]), "ffmpeg": bool(tools.get("ffmpeg")),
                "method": method, "auto": auto, "startedAuto": started_auto, "episodes": rows, "counts": counts,
                "job": job if mine else {"state": "idle", "busy": job.get("state") == "running",
                                         "busyTitle": job.get("title") or ""}}

    def _intro_job_get(self, query: dict) -> dict:
        return self._intro().state()

    # -- looking ---------------------------------------------------------------------------------------

    def _intro_need_ffmpeg(self) -> None:
        if not self._intro_tools().get("ffmpeg"):
            raise ApiError("AniBox needs ffmpeg for this. Download it under Settings → Player.")

    def _intro_find(self, body: dict) -> dict:
        show = self._intro_show(body.get("show"))
        self._intro_need_ffmpeg()
        again = bool(body.get("again"))
        log.info("Openings/endings: looking at %s%s", show["id"], " again" if again else "")
        return {"ok": True, "job": self._intro().queue([show], again=again)}

    def _intro_all(self, body: dict) -> dict:
        self._intro_need_ffmpeg()
        det = self._intro()
        if det.batch.get("state") == "running":
            return {"ok": True, "job": det.state()}
        shows = sorted(self.library.shows(), key=lambda s: (s.get("title") or s["folder"]).casefold())
        if not shows:
            raise ApiError("Scan your folders first (Settings → Folders).")
        log.info("Openings/endings: checking every show (%d)", len(shows))
        return {"ok": True, "job": det.queue(shows, batch=True)}

    def _intro_cancel(self, body: dict) -> dict:
        return {"ok": True, "job": self._intro().cancel()}

    # -- hand corrections ----------------------------------------------------------------------------

    def _intro_edit(self, body: dict) -> dict:
        """``{show, key, opening: {start, end} | null, ending: …}`` (kinds left out stay as they are), or
        ``{show, key, reset: true}``: back to what AniBox found."""
        show = self._intro_show(body.get("show"))
        key = str(body.get("key") or "")
        ep = next((e for e in show["episodes"] if e["key"] == key), None)
        if ep is None:
            raise ApiError("Episode not found", 404)
        store = self._intro().store
        if body.get("reset"):
            store.reset_manual(ep["path"])
        else:
            entry = store.entry(ep["path"]) or {}
            duration = float(entry.get("duration") or 0)
            changes = {}
            for kind in introdetect.KINDS:
                if kind not in body:
                    continue
                value = body[kind]
                if value is None:
                    changes[kind] = None
                    continue
                if not isinstance(value, dict):
                    raise ApiError(f"The {kind} needs a start and an end.")
                start, end = _seconds(value.get("start")), _seconds(value.get("end"))
                if start is None or end is None:
                    raise ApiError(f"Type the {kind}'s start and end like 1:32.")
                if end - start < 1:
                    raise ApiError(f"The {kind} has to end after it starts.")
                if duration and end > duration + 1:
                    raise ApiError(f"The {kind} ends after the episode does ({int(duration // 60)}:{int(duration % 60):02d}).")
                changes[kind] = {"start": start, "end": end}
            if not changes:
                raise ApiError("Nothing to change.")
            try:
                for kind, part in changes.items():
                    store.set_manual(ep["path"], show["id"], kind, part)
            except introdetect.DetectError as exc:
                raise ApiError(str(exc))
        store.save()
        log.info("Openings/endings of %s changed by hand%s", key, " (back to what was found)" if body.get("reset") else "")
        return {"ok": True, "episode": self._intro_episode_row(ep)}

    def _intro_off(self, body: dict) -> dict:
        show = self._intro_show(body.get("show"))
        off = bool(body.get("off", True))
        store = self._intro().store
        store.set_off(show["id"], off)
        store.save()
        log.info("Openings/endings found by AniBox for %s: %s", show["id"], "off" if off else "on")
        return {"ok": True, "off": off}
