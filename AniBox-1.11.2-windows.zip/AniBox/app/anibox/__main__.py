import sys


def _too_old() -> int:
    text = "AniBox needs Python 3.9 or newer. Get it from python.org."
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(None, text, "AniBox", 0x10)
    except Exception:
        print(text, file=sys.stderr)
    return 1


if __name__ == "__main__":
    if sys.version_info < (3, 9):
        sys.exit(_too_old())
    from .main import main
    sys.exit(main())
