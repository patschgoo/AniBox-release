"""Check my library: a health check of the scanned library, and a move plan such as Anime2 → Anime.

Both only read. The health check works on AniBox's list of your files (made by the last scan), so it
doesn't touch the drives at all, except for the optional file check, which opens every video and reads
its first few KB (``READ_FIRST``, at most ``READ_MAX``) to see whether it starts like a video file.

What the health check finds:

- **Same episode twice** in one folder (two files with the same number: versions, languages), and
  the same show in two folders (same MyAnimeList entry, e.g. one in ``Anime2`` and one in ``Anime``).
- **Missing episodes in the middle** (1–5 and 7–12 but no 6). With MyAnimeList's episode count also
  at the start and, for finished shows only, at the end.
- **Empty or broken files** (file check only): 0 bytes, much smaller than the other episodes, not
  starting like a video container, unreadable.
- **Odd names**: files without a number among numbered ones, numbers that don't fit the show, leftover
  download names ("[Group]", "1080p").

``move_plan`` lists, for every show folder of one library ("Anime2"), where its files would go in
another ("Anime"): old path → new path, into the show's folder there if it already has one, named like
the files there. It only makes the list; nothing is moved (see ``conditions``).
"""

from __future__ import annotations

import csv
import html
import io
import os
import re
import statistics
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Callable, Dict, Iterable, List, Optional, Sequence, Tuple

import anibox  # noqa: F401  (makes anibox_check importable)
from anibox_check.folders import compact_key

from .fileops import safe_name
from .importer import name_pattern, new_name
from .library import natural_key

READ_FIRST = 4096  # enough for every container below
READ_MAX = 64 * 1024  # read on only if the start isn't recognized (an MPEG-TS stream can start late)
READERS = 4  # files read at the same time
SMALL_RATIO = 0.2  # "much smaller": under a fifth of the other episodes' usual size ...
SMALL_MIN_TYPICAL = 50 * 1024 * 1024  # ... and only where episodes are usually at least this big
FINISHED = "FINISHED"

GROUPS = {
    "dupes": "Same episode twice",
    "twice": "Same show in two folders",
    "gaps": "Missing episodes",
    "broken": "Empty or broken files",
    "odd": "Odd names",
}
ODD_KINDS = {
    "no-number": "Files without an episode number",
    "doesnt-fit": "Numbers that don't fit the show",
    "download-name": "Download names",
    "folder-name": "Folder name looks like a download",
}

_DOUBLE = re.compile(r"(?<![\d.])(\d{1,4})\s?[-~&+]\s?(\d{1,4})(?![\dp])")  # "Show 01-02": a double episode
_HALF = re.compile(r"(?<![\d.])(\d{1,4})\.5(?!\d)")  # "Show 06.5": a recap between 6 and 7
_RELEASE = re.compile(
    r"^\s*\[[^\]]+\]|\[[0-9A-Fa-f]{8}\]|\b(?:480|540|576|720|1080|1440|2160)[pi]\b"
    r"|\b(?:x26[45]|h\.?26[45]|hevc|xvid|10.?bit|web-?dl|web-?rip|bd-?rip|blu-?ray|dvd-?rip|hdtv|flac|opus)\b", re.I)
_SCENE = re.compile(r"[^ ]+(?:\.[^ .]+){3,}")  # Scene.Style.Name.S01E01 (no spaces, many dots)
_LANG_TAIL = re.compile(r"(\.[A-Za-z]{2,12})+$")  # "Show 01.English": kept when a file is renamed


# -- numbers and labels --------------------------------------------------------------------------------

def ranges(numbers: Iterable[int]) -> str:
    """[1, 2, 3, 6, 9, 10] -> "1–3, 6, 9–10"."""
    nums = sorted(set(numbers))
    out, i = [], 0
    while i < len(nums):
        j = i
        while j + 1 < len(nums) and nums[j + 1] == nums[j] + 1:
            j += 1
        out.append(str(nums[i]) if i == j else f"{nums[i]}–{nums[j]}")
        i = j + 1
    return ", ".join(out)


def describe(keys: Iterable[Tuple[int, int]], seasonal: bool = False) -> str:
    """Episodes as text: "1–3, 6", or "Season 1: 2 · Season 2: 1–4 · Specials: 1" for shows with seasons."""
    by_season: Dict[int, List[int]] = {}
    for s, n in keys:
        by_season.setdefault(s, []).append(n)
    if not by_season:
        return ""
    if not seasonal and set(by_season) == {1}:
        return ranges(by_season[1])
    parts = []
    for s in sorted(by_season, key=lambda x: (x == 0, x)):
        parts.append(f"{'Specials' if s == 0 else f'Season {s}'}: {ranges(by_season[s])}")
    return " · ".join(parts)


def _stem_after_title(file_name: str, folder: str) -> str:
    stem = os.path.splitext(file_name)[0]
    if folder and stem.casefold().startswith(folder.casefold()) and len(stem) > len(folder):
        stem = stem[len(folder):]
    return stem


def _records(show: dict) -> List[dict]:
    """One record per episode file: its (season, number) as the library read it, the numbers it covers
    (a double episode "01-02" covers 1 and 2), whether it's a ".5" recap, and its season folder."""
    recs = []
    for e in show["episodes"]:
        sub, _, name = e["file"].rpartition("\\")
        n, s = e.get("number"), e.get("season")
        stem = _stem_after_title(name, show["folder"])
        covers: List[int] = []
        half = False
        if n is not None:
            covers = [n]
            m = _DOUBLE.search(stem)
            if m and int(m.group(1)) == n and 0 < int(m.group(2)) - n <= 3:
                covers = list(range(n, int(m.group(2)) + 1))
            h = _HALF.search(stem)
            half = bool(h and int(h.group(1)) == n)
        recs.append({"ep": e, "season": s if s is not None else 1, "number": n, "covers": covers, "half": half,
                     "sub": sub, "name": name})
    numbered = {(r["season"], r["number"]) for r in recs if r["number"] is not None}
    if len(numbered) == 1 and len(recs) >= 3:  # every file "has" the same number: it's part of the title
        for r in recs:
            r.update(number=None, covers=[], half=False)
    return recs


def _seasonal(recs: List[dict]) -> bool:
    return any(r["sub"] for r in recs) or len({r["season"] for r in recs if r["number"] is not None}) > 1


def _show_ref(show: dict) -> dict:
    return {"show": show["id"], "library": show["library"], "folder": show["folder"],
            "title": show.get("title") or show["folder"], "mal_id": show.get("mal_id") or ""}


def _keys(recs: List[dict]) -> set:
    return {(r["season"], n) for r in recs if r["number"] is not None and not r["half"] for n in r["covers"]}


# -- the checks that only use the file list --------------------------------------------------------------

def _dupes(show: dict, recs: List[dict]) -> Optional[dict]:
    seen: Dict[Tuple[int, int], List[str]] = {}
    for r in recs:
        if r["number"] is None or r["half"]:
            continue
        for n in r["covers"]:
            seen.setdefault((r["season"], n), []).append(r["ep"]["file"])
    seasonal = _seasonal(recs)
    twice = [(k, files) for k, files in sorted(seen.items()) if len(files) > 1]
    if not twice:
        return None
    eps = [{"label": ("Special " if k[0] == 0 else f"Season {k[0]} · Episode " if seasonal else "Episode ") + str(k[1]),
            "files": files} for k, files in twice]
    return {**_show_ref(show), "episodes": eps, "count": len(eps),
            "files": sorted({f for _, files in twice for f in files}, key=natural_key)}


def _mal_count(show: dict, recs: List[dict]) -> Optional[int]:
    """MyAnimeList's episode count, where it applies: one MAL entry per folder, no season folders."""
    n = show.get("mal_episodes")
    if not isinstance(n, int) or n <= 0 or _seasonal(recs):
        return None
    return n


def _gaps(show: dict, recs: List[dict], titles: dict) -> Tuple[Optional[dict], List[str]]:
    """(the gaps item or None, files whose numbers are above MyAnimeList's count)."""
    seasonal = _seasonal(recs)
    count = _mal_count(show, recs)
    status = (titles.get(str(show.get("mal_id"))) or {}).get("status") if show.get("mal_id") else None
    by_season: Dict[int, set] = {}
    for r in recs:
        if r["number"] is not None and not r["half"] and r["season"] != 0:
            by_season.setdefault(r["season"], set()).update(n for n in r["covers"] if n >= 1)
    parts, notes, total, too_high = [], [], 0, []
    for season in sorted(by_season):
        have = by_season[season]
        if not have:
            continue
        prefix = f"Season {season}: " if seasonal else ""
        lo = min(have)
        cnt = count if count and lo <= count else None  # lo above the count: numbered on from an earlier season
        if cnt:
            high = sorted(n for n in have if n > cnt)
            if high:
                too_high += [r["ep"]["file"] for r in recs if r["number"] in high]
            have = {n for n in have if n <= cnt}
            lo = min(have)
        hi = max(have)
        inner = [n for n in range(lo, hi + 1) if n not in have]
        if len(inner) > 20 and len(inner) > 2 * len(have):  # 1, 2, 3, 500: one number is probably wrong
            nums = sorted(have)
            a, b = max(zip(nums, nums[1:]), key=lambda p: p[1] - p[0])
            parts.append(f"{prefix}numbers jump from {a} to {b} (a wrong number in a name?)")
            continue
        if inner:
            parts.append(prefix + ranges(inner))
            total += len(inner)
        if cnt and lo > 1:
            parts.append(f"{prefix}at the start: {ranges(range(1, lo))}")
            total += lo - 1
        if cnt and hi < cnt:
            if status == FINISHED:
                parts.append(f"{prefix}at the end: {ranges(range(hi + 1, cnt + 1))}")
                total += cnt - hi
            elif status in ("ONGOING", "UPCOMING"):
                notes.append(f"Still airing: MyAnimeList plans {cnt} episodes, so the ones after {hi} aren't counted as missing.")
    if not parts:
        return None, too_high
    unnumbered = sum(1 for r in recs if r["number"] is None)
    if unnumbered:
        notes.append(f"{unnumbered} file(s) without a number might be some of these.")
    if count:
        notes.insert(0, f"MyAnimeList lists {count} episodes.")
    return {**_show_ref(show), "missing": " · ".join(parts), "count": total, "note": " ".join(notes)}, too_high


def _odd(show: dict, recs: List[dict], too_high: List[str]) -> List[dict]:
    out = []
    ref = _show_ref(show)
    numbered = [r for r in recs if r["number"] is not None]
    unnumbered = [r["ep"]["file"] for r in recs if r["number"] is None]
    if len(numbered) >= 2 and unnumbered:
        out.append({**ref, "kind": "no-number", "label": ODD_KINDS["no-number"], "files": sorted(unnumbered, key=natural_key),
                    "note": "The other files in this folder have episode numbers; AniBox can't tell which episode these are."})
    if too_high:
        out.append({**ref, "kind": "doesnt-fit", "label": ODD_KINDS["doesnt-fit"], "files": sorted(too_high, key=natural_key),
                    "note": f"MyAnimeList lists {show.get('mal_episodes')} episodes for this show. A typo in the name, or an extra?"})
    loud = [r["ep"]["file"] for r in recs if _RELEASE.search(r["name"]) or _SCENE.fullmatch(os.path.splitext(r["name"])[0])]
    if loud:
        out.append({**ref, "kind": "download-name", "label": ODD_KINDS["download-name"], "files": sorted(loud, key=natural_key),
                    "note": f"{len(loud)} of {len(recs)} file names still look like downloads ([Group], 1080p …). "
                            f"Your library names files like “{show['folder']} 01”."})
    if _RELEASE.search(show["folder"]) or _SCENE.fullmatch(show["folder"]):
        out.append({**ref, "kind": "folder-name", "label": ODD_KINDS["folder-name"], "files": [],
                    "note": "MyAnimeList titles don't have tags like these, so the folder may not be recognized."})
    return out


def _episode_set(show: dict) -> Optional[set]:
    keys = _keys(_records(show))
    if keys:
        return keys
    return {(1, 1)} if len(show["episodes"]) == 1 else None  # one file without a number: a movie


def _dub(show: dict) -> Tuple[str, ...]:
    """Dub languages in the names. A German or English dub next to the Japanese version is another version
    of the show, not a copy ("dual audio" names count as Japanese)."""
    return tuple(sorted(set((show.get("name_langs") or {}).get("audio") or ()) - {"ja"}))


def _twice(shows: Sequence[dict]) -> List[dict]:
    groups: Dict[Tuple[str, str], List[dict]] = {}
    for sh in shows:
        if sh.get("mal_id"):
            key = ("mal", str(sh["mal_id"]))
        else:
            name = compact_key(sh["folder"])
            if len(name) < 3:
                continue
            key = ("name", name)
        groups.setdefault(key, []).append(sh)
    out = []
    for key, shs in groups.items():
        if len(shs) < 2:
            continue
        shs = sorted(shs, key=lambda s: (s["library"].casefold(), natural_key(s["folder"])))
        sets = {sh["id"]: _episode_set(sh) for sh in shs}
        seasonal = any(_seasonal(_records(sh)) for sh in shs)
        where: Dict[Tuple[int, int], int] = {}
        for s in sets.values():
            for k in s or ():
                where[k] = where.get(k, 0) + 1
        both = sorted(k for k, n in where.items() if n > 1)
        folders = []
        for sh in shs:
            own = sets[sh["id"]]
            only = sorted(k for k in own or () if where[k] == 1)
            folders.append({**_show_ref(sh), "files": len(sh["episodes"]), "only": describe(only, seasonal),
                            "onlyCount": len(only), "numbered": own is not None})
        langs = {_dub(sh) for sh in shs}
        language = len(langs) > 1
        if language:
            note = "These look like different languages (e.g. a German dub). That's fine if you want both."
        elif both:
            note = f"{len(both)} episode(s) are in more than one of these folders."
        else:
            note = "No episode is in two of these folders; together they make one show."
        out.append({"key": key[1], "mal_id": key[1] if key[0] == "mal" else "", "title": shs[0].get("title") or shs[0]["folder"],
                    "folders": folders, "both": describe(both, seasonal), "bothCount": len(both),
                    "language": language, "note": note})
    out.sort(key=lambda g: (g["language"], natural_key(g["title"])))
    return out


# -- the file check: the first bytes of every file ---------------------------------------------------------

_ASF = bytes.fromhex("3026B2758E66CF11A6D900AA0062CE6C")
_MP4_BOXES = (b"ftyp", b"moov", b"mdat", b"free", b"wide", b"skip", b"pnot")


def _ts_packets(head: bytes) -> Optional[str]:
    """MPEG transport stream: a sync byte 0x47 every 188 bytes (192 for Blu-ray .m2ts, 204 with checksums)."""
    for size, name in ((188, "MPEG-TS"), (192, "MPEG-TS (Blu-ray)"), (204, "MPEG-TS")):
        need = min(5, len(head) // size)
        if need < 3:
            continue
        for start in range(0, min(size, len(head) - (need - 1) * size)):
            if all(head[start + i * size] == 0x47 for i in range(need)):
                return name
    return None


def sniff(head: bytes) -> Optional[str]:
    """The kind of video container the bytes start with, or None."""
    if head[:4] == b"\x1a\x45\xdf\xa3":
        return "Matroska (MKV/WebM)"
    if head[4:8] in _MP4_BOXES:
        return "MP4/MOV"
    if head[:4] == b"RIFF" and head[8:12] in (b"AVI ", b"AVIX"):
        return "AVI"
    if head[:4] == b"\x00\x00\x01\xba":
        return "MPEG-PS (MPG/VOB)"
    if head[:4] == b"\x00\x00\x01\xb3":
        return "MPEG video"
    if head[:4] == b"OggS":
        return "Ogg (OGM/OGV)"
    if head[:16] == _ASF:
        return "ASF (WMV)"
    if head[:3] == b"FLV":
        return "Flash video"
    if head[:4] == b".RMF":
        return "RealMedia"
    return _ts_packets(head)


def explain_unknown(head: bytes) -> str:
    """Why a file that doesn't start like a video looks broken, in plain words."""
    if not head.strip(b"\x00"):
        return "The start of the file is only zeros: the download or copy probably didn't finish."
    for magic, what in ((b"PK\x03\x04", "a ZIP archive"), (b"Rar!", "a RAR archive"), (b"7z\xbc\xaf\x27\x1c", "a 7-Zip archive"),
                        (b"\x1f\x8b", "a packed (gzip) file"), (b"%PDF", "a PDF document")):
        if head.startswith(magic):
            return f"This is really {what} with a video name."
    text = head[:200].lstrip(b"\xef\xbb\xbf \t\r\n").lower()
    if text.startswith((b"<!doctype", b"<html", b"<?xml", b"{", b"<head")):
        return "This is really a web page or text file (an error page saved instead of the video?)."
    shown = " ".join(f"{b:02X}" for b in head[:8])
    return f"It doesn't start like any video file AniBox knows (first bytes {shown}). It may be broken."


def _open_video(path: str):
    return open(path, "rb")


def probe(path: str) -> dict:
    """Read the start of one file: {"size", "kind"} or {"size", "problem"} or {"error"}. Only reads."""
    try:
        with _open_video(path) as fh:
            size = os.fstat(fh.fileno()).st_size
            head = fh.read(READ_FIRST)
            kind = sniff(head)
            if kind is None and len(head) == READ_FIRST:
                head += fh.read(READ_MAX - READ_FIRST)
                kind = sniff(head)
    except FileNotFoundError:
        return {"error": "It isn't there anymore (scan again)."}
    except OSError as exc:
        return {"error": f"It can't be read: {exc.strerror or exc}."}
    if size == 0:
        return {"size": 0, "problem": "Empty (0 bytes)."}
    if kind is None:
        return {"size": size, "problem": explain_unknown(head)}
    return {"size": size, "kind": kind}


def probe_files(paths: Sequence[str], workers: int = READERS, progress: Optional[Callable[[int, int], None]] = None,
                stop=None) -> Dict[str, dict]:
    """``probe`` every path, a few at a time. Stops early when ``stop`` (an Event) is set."""
    out: Dict[str, dict] = {}
    if not paths:
        return out
    pool = ThreadPoolExecutor(max_workers=max(1, workers), thread_name_prefix="anibox-health")
    try:
        futures = {pool.submit(probe, p): p for p in paths}
        for fut in as_completed(futures):
            out[futures[fut]] = fut.result()
            if progress:
                progress(len(out), len(paths))
            if stop is not None and stop.is_set():
                break
    finally:
        pool.shutdown(wait=True, cancel_futures=True)
    return out


def _size_text(n: float) -> str:
    for unit in ("bytes", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.0f} {unit}" if unit == "bytes" else f"{n:.1f} {unit}"
        n /= 1024
    return ""


def _broken(shows: Sequence[dict], results: Dict[str, dict]) -> List[dict]:
    out = []
    sizes: Dict[Tuple[str, str], List[Tuple[str, int]]] = {}  # (show, season folder) -> [(path, size)]
    for sh in shows:
        for e in sh["episodes"]:
            r = results.get(e["path"])
            if r is None:
                continue
            problem = r.get("error") or r.get("problem")
            if problem:
                out.append({**_show_ref(sh), "key": e["key"], "file": e["file"], "problem": problem, "size": r.get("size")})
            elif r.get("size"):
                sizes.setdefault((sh["id"], e["file"].rpartition("\\")[0]), []).append((e["path"], r["size"]))
    by_path = {e["path"]: (sh, e) for sh in shows for e in sh["episodes"]}
    for group in sizes.values():
        if len(group) < 3:
            continue
        for path, size in group:
            typical = statistics.median(s for p, s in group if p != path)
            if typical >= SMALL_MIN_TYPICAL and size < typical * SMALL_RATIO:
                sh, e = by_path[path]
                out.append({**_show_ref(sh), "key": e["key"], "file": e["file"], "size": size,
                            "problem": f"Much smaller than the other episodes ({_size_text(size)}; they're about "
                                       f"{_size_text(typical)}). Maybe an unfinished download or a broken copy."})
    out.sort(key=lambda b: (b["library"].casefold(), natural_key(b["folder"]), natural_key(b["file"])))
    return out


# -- the whole check ---------------------------------------------------------------------------------------

def check(shows: Sequence[dict], titles: Optional[dict] = None, read_files: bool = False,
          progress: Optional[Callable[[int, int], None]] = None, stop=None, workers: int = READERS) -> dict:
    """The health check of these shows (as the library has them). Reads the drives only with ``read_files``."""
    titles = titles or {}
    shows = sorted(shows, key=lambda s: (s["library"].casefold(), natural_key(s["folder"])))
    # A show in several folders (Anime2 and Anime, same language): its gaps are counted over all of them.
    families: Dict[Tuple[str, Tuple[str, ...]], List[dict]] = {}
    for sh in shows:
        if sh.get("mal_id"):
            families.setdefault((str(sh["mal_id"]), _dub(sh)), []).append(sh)
    dupes, gaps, odd = [], [], []
    for sh in shows:
        recs = _records(sh)
        d = _dupes(sh, recs)
        if d:
            dupes.append(d)
        g, too_high = _gaps(sh, recs, titles)
        family = families.get((str(sh["mal_id"]), _dub(sh))) if sh.get("mal_id") else None
        if family and len(family) > 1:
            g = None
            if sh is family[0]:
                g, _ = _gaps(sh, [r for f in family for r in _records(f)], titles)
                if g:
                    others = ", ".join(f["id"] for f in family[1:])
                    g["note"] = f"Counted together with {others} (the same show in more than one folder). {g['note']}".strip()
                    g["together"] = [f["id"] for f in family]
        if g:
            gaps.append(g)
        odd += _odd(sh, recs, too_high)
    twice = _twice(shows)
    broken: List[dict] = []
    paths = [e["path"] for sh in shows for e in sh["episodes"]]
    read = 0
    if read_files:
        results = probe_files(paths, workers=workers, progress=progress, stop=stop)
        read = len(results)
        broken = _broken(shows, results)
    return {
        "checked": time.time(), "filesChecked": bool(read_files), "filesRead": read, "filesTotal": len(paths),
        "filesStopped": bool(read_files and read < len(paths)),
        "shows": len(shows), "libraries": sorted({s["library"] for s in shows}, key=str.casefold),
        "groups": {"dupes": dupes, "twice": twice, "gaps": gaps, "broken": broken, "odd": odd},
        "counts": {"dupes": len(dupes), "twice": sum(1 for t in twice if not t["language"]),
                   "twiceLanguage": sum(1 for t in twice if t["language"]), "gaps": len(gaps),
                   "broken": len(broken), "odd": len(odd)},
    }


# -- the move plan ("Anime2" -> "Anime") -------------------------------------------------------------------

def suggest_pairs(names: Iterable[str]) -> List[Tuple[str, str]]:
    """Libraries named like another one plus " 2" ("Anime2" -> "Anime", "Anime [ger dub] 2" -> "Anime [ger dub]")."""
    names = list(names)
    by_fold = {n.casefold(): n for n in names}
    out = []
    for n in sorted(names, key=str.casefold):
        m = re.match(r"^(.*?\S)\s*2$", n)
        base = by_fold.get(m.group(1).casefold()) if m else None
        if base and base != n:
            out.append((n, base))
    return out


def conditions(source: str, target: str) -> List[str]:
    """When the move would be safe, in plain words (from the user's own rules)."""
    return [
        "This is only a list. AniBox doesn't move anything here, and nothing on your drives changes.",
        f"Move only after your new Plex library with working matching covers the {target} folder. "
        f"Files moved into {target} are not seen by the old {target} library in Plex (its scanner doesn't work "
        f"anymore), so they would disappear from Plex until then.",
        "Plex's watched marks don't move with the files. AniBox's own watch progress does.",
        "Locked shows (their episodes were already there) have to be unlocked on the show's page first. "
        f"Where a show is already in {target}, only its new episodes are added; what's there stays as it is.",
        "Files on another drive are copied and then removed from the old place. That takes a while and needs "
        "free space on the other drive.",
        f"An empty {target} folder on another drive is never used and stays as it is. Removing the empty "
        f"{source} folder (and its entry in Plex) afterwards is up to you.",
        "You move the files yourself later, with Move or rename on each show's page (or a future move tool). "
        "This list shows what that would do.",
    ]


_drive_cache: Dict[str, str] = {}


def drive_of(path: str) -> str:
    """Which drive a folder is on: the volume's id where the system says it, else the drive or share name."""
    key = os.path.normcase(os.path.abspath(path))
    if key not in _drive_cache:
        try:
            dev = os.stat(path).st_dev
        except OSError:
            dev = 0
        _drive_cache[key] = f"dev:{dev}" if dev else "drive:" + os.path.normcase(os.path.splitdrive(key)[0])
    return _drive_cache[key]


def _new_file_name(name: str, number: int, prefix: str, sep: str, digits: int) -> str:
    stem, ext = os.path.splitext(name)
    m = _LANG_TAIL.search(stem)
    return new_name(prefix, sep, digits, number, "") + (m.group(0) if m else "") + ext.lower()


def _plan_show(sh: dict, target_show: Optional[dict], dest_dir: str) -> dict:
    recs = _records(sh)
    top = [r for r in recs if not r["sub"]]
    if target_show:
        t_top = [e["file"] for e in target_show["episodes"] if "\\" not in e["file"]]
        prefix, sep, digits = name_pattern(t_top or [r["name"] for r in top], target_show["folder"])
        if not t_top:
            prefix = target_show["folder"]
    else:
        prefix, sep, digits = name_pattern([r["name"] for r in top], sh["folder"])
        if prefix.casefold() != sh["folder"].casefold():  # names that don't follow "<Folder> 01" get that pattern
            prefix, sep = safe_name(sh["folder"]), " "
    highest = max([n for r in recs for n in r["covers"]] + [sh.get("mal_episodes") or 0, 1])
    digits = max(digits, len(str(highest)))
    counts: Dict[Tuple[str, int], int] = {}
    for r in recs:
        if r["number"] is not None:
            counts[(r["sub"], r["number"])] = counts.get((r["sub"], r["number"]), 0) + 1
    have: Dict[Tuple[str, int], str] = {}
    names: set = set()
    if target_show:
        for e in target_show["episodes"]:
            sub = e["file"].rpartition("\\")[0]
            names.add(e["file"].casefold())
            if e.get("number") is not None:
                have.setdefault((sub, e["number"]), e["file"])
    files, taken = [], {}
    for r in recs:
        e = r["ep"]
        name = r["name"]
        keep = (r["number"] is None or r["half"] or len(r["covers"]) > 1 or r["sub"]
                or counts.get((r["sub"], r["number"]), 0) > 1)
        new = name if keep else _new_file_name(name, r["number"], prefix, sep, digits)
        rel = (r["sub"] + "\\" if r["sub"] else "") + new
        conflict = ""
        hit = next((have[(r["sub"], n)] for n in r["covers"] if not r["half"] and (r["sub"], n) in have), None)
        if hit:
            conflict = f"This episode is already in {target_show['library']}\\{target_show['folder']} ({hit})."
        elif rel.casefold() in names:
            conflict = "A file with this name is already there."
        elif rel.casefold() in taken:
            conflict = f"Two files would get the same name (also {taken[rel.casefold()]})."
        elif r["number"] is not None and counts.get((r["sub"], r["number"]), 0) > 1:
            conflict = "The same episode is twice in this folder; names kept. Pick one before moving."
        taken.setdefault(rel.casefold(), e["file"])
        files.append({"key": e["key"], "file": e["file"], "from": e["path"], "to": os.path.join(dest_dir, *rel.split("\\")),
                      "rename": new != name, "conflict": conflict})
    return {"files": files, "pattern": f"{prefix}{sep}{'0' * (digits - 1)}1"}


def move_plan(shows: Sequence[dict], source: str, target: str, roots: Dict[str, List[Tuple[str, int]]],
              show_folder_path: Callable[[dict], str], lock_of: Optional[Callable[[dict], dict]] = None,
              protected: Sequence[str] = (), plex_of: Optional[Callable[[dict], dict]] = None,
              drive: Optional[Callable[[str], str]] = None) -> dict:
    """Where every file of the library ``source`` would go in ``target``. Only reads (AniBox's list, and
    which drive each library folder is on)."""
    drive = drive or drive_of
    base = {"from": source, "to": target, "conditions": conditions(source, target), "shows": [], "error": "",
            "totals": {"shows": 0, "files": 0, "renamed": 0, "merged": 0, "newFolders": 0, "conflicts": 0,
                       "locked": 0, "otherDrive": 0}}
    if not source or not target or source == target:
        return {**base, "error": "Pick two different libraries."}
    src_shows = sorted((s for s in shows if s["library"] == source), key=lambda s: natural_key(s["folder"]))
    if not src_shows:
        return {**base, "error": f"There are no shows in “{source}”."}
    target_roots = [r for r in roots.get(target) or [] if r[1] > 0]
    if not target_roots:
        return {**base, "error": f"AniBox doesn't know where “{target}” is on your drives. Scan your folders first."}
    root = target_roots[0][0]
    base["targetDir"] = root
    tgt = [s for s in shows if s["library"] == target]
    by_mal: Dict[str, dict] = {}
    by_name: Dict[str, dict] = {}
    for s in sorted(tgt, key=lambda s: len(s["episodes"]), reverse=True):
        if s.get("mal_id"):
            by_mal.setdefault(str(s["mal_id"]), s)
        by_name.setdefault(s["folder"].casefold(), s)
    folded = [p.casefold() for p in protected]
    out, totals = [], base["totals"]
    for sh in src_shows:
        match = by_mal.get(str(sh.get("mal_id") or "")) if sh.get("mal_id") else None
        match = match or by_name.get(sh["folder"].casefold())
        src_dir = show_folder_path(sh)
        dest_dir = show_folder_path(match) if match else os.path.join(root, safe_name(sh["folder"]))
        plan = _plan_show(sh, match, dest_dir)
        flags = []
        lock = lock_of(sh) if lock_of else {"keys": set(), "locked": 0}
        locked = len(lock.get("keys") or ())
        if locked:
            flags.append(f"Locked: {locked} episode(s) were already there. Unlock the show on its page before moving it.")
        other = drive(os.path.dirname(src_dir)) != drive(os.path.dirname(dest_dir))
        if other:
            flags.append("On another drive: the files are copied, then removed from the old place.")
        if match and all("\\" in e["file"] for e in match["episodes"]) and any("\\" not in f["file"] for f in plan["files"]):
            flags.append(f"{match['id']} keeps its episodes in season folders; these files would go next to them. Check that.")
        if source.casefold() in folded or target.casefold() in folded:
            flags.append("A protected folder: AniBox wouldn't move anything here.")
        if plex_of:
            px = plex_of(sh) or {}
            if px.get("legacy"):
                flags.append(f"In an old Plex library ({px.get('section') or 'old agent'}).")
        conflicts = sum(1 for f in plan["files"] if f["conflict"])
        out.append({**_show_ref(sh), "fromDir": src_dir, "toDir": dest_dir, "merge": bool(match),
                    "into": match["id"] if match else "", "pattern": plan["pattern"], "files": plan["files"],
                    "flags": flags, "locked": locked, "otherDrive": other, "conflicts": conflicts,
                    "renamed": sum(1 for f in plan["files"] if f["rename"])})
        totals["shows"] += 1
        totals["files"] += len(plan["files"])
        totals["renamed"] += out[-1]["renamed"]
        totals["merged" if match else "newFolders"] += 1
        totals["conflicts"] += conflicts
        totals["locked"] += 1 if locked else 0
        totals["otherDrive"] += 1 if other else 0
    return {**base, "shows": out}


# -- export (CSV for Excel, a web page) ------------------------------------------------------------------

def _csv(rows: List[List[str]]) -> str:
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=";", lineterminator="\r\n")
    for r in rows:
        w.writerow(r)
    return "﻿" + buf.getvalue()  # BOM: Excel reads umlauts and Japanese correctly


def health_csv(result: dict) -> str:
    g = result.get("groups") or {}
    rows = [["Group", "Library", "Folder", "What", "Details", "Files"]]
    for d in g.get("dupes", []):
        for ep in d["episodes"]:
            rows.append([GROUPS["dupes"], d["library"], d["folder"], ep["label"], f"{len(ep['files'])} files", " | ".join(ep["files"])])
    for t in g.get("twice", []):
        details = (f"In more than one: {t['both']}. " if t["both"] else "") + t["note"]
        for f in t["folders"]:
            rows.append([GROUPS["twice"], f["library"], f["folder"], t["title"],
                         details + (f" Only here: {f['only']}." if f["only"] else ""), f"{f['files']} files"])
    for x in g.get("gaps", []):
        rows.append([GROUPS["gaps"], x["library"], x["folder"], x["missing"], x["note"], ""])
    for b in g.get("broken", []):
        rows.append([GROUPS["broken"], b["library"], b["folder"], b["file"], b["problem"], ""])
    for o in g.get("odd", []):
        rows.append([GROUPS["odd"], o["library"], o["folder"], o["label"], o["note"], " | ".join(o["files"])])
    return _csv(rows)


def plan_csv(plan: dict) -> str:
    rows = [["Show", "From library", "Now", "Would go to", "Renamed", "Into an existing folder", "Problem", "Notes"]]
    for sh in plan.get("shows") or []:
        for f in sh["files"]:
            rows.append([sh["title"], plan["from"], f["from"], f["to"], "yes" if f["rename"] else "",
                         sh["into"] or "", f["conflict"], " ".join(sh["flags"])])
    return _csv(rows)


_PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8"><title>{title}</title>
<style>
body{{background:#07090C;color:#E9EEF4;font:15px/1.45 "Segoe UI",system-ui,sans-serif;margin:0;padding:28px 34px}}
h1,h2{{font-family:Sora,"Segoe UI",sans-serif}} h1{{font-size:28px;margin:0 0 6px}} h2{{font-size:19px;margin:30px 0 8px}}
.muted{{color:#93A0AF}} table{{border-collapse:collapse;width:100%;margin:6px 0 14px}}
th,td{{text-align:left;padding:7px 9px;border-top:1px solid #1E242E;vertical-align:top;font-size:14px}}
th{{font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:#93A0AF}}
.note{{background:rgba(240,198,116,.08);border:1px solid rgba(240,198,116,.35);color:#F7E3B5;border-radius:12px;padding:10px 14px;margin:10px 0}}
.bad{{color:#FF6B6B}} code{{overflow-wrap:anywhere}} li{{margin:4px 0}}
</style></head><body><h1>{title}</h1><p class="muted">{sub}</p>{body}
<p class="muted" style="margin-top:30px">Made by {made_by}. Read-only: nothing on your drives was changed.</p></body></html>"""


def _e(x) -> str:
    return html.escape(str(x if x is not None else ""))


def _table(head: List[str], rows: List[List[str]]) -> str:
    if not rows:
        return '<p class="muted">Nothing found.</p>'
    return ("<table><thead><tr>" + "".join(f"<th>{_e(h)}</th>" for h in head) + "</tr></thead><tbody>" +
            "".join("<tr>" + "".join(f"<td>{c}</td>" for c in r) + "</tr>" for r in rows) + "</tbody></table>")


def health_html(result: dict, made_by: str) -> str:
    g = result.get("groups") or {}
    br = "<br>"
    body = []
    body.append(f"<h2>{GROUPS['dupes']} ({len(g.get('dupes', []))})</h2>" + _table(
        ["Library", "Folder", "Episode", "Files"],
        [[_e(d["library"]), _e(d["folder"]), _e(ep["label"]), br.join(_e(f) for f in ep["files"])]
         for d in g.get("dupes", []) for ep in d["episodes"]]))
    body.append(f"<h2>{GROUPS['twice']} ({len(g.get('twice', []))})</h2>" + _table(
        ["Show", "Folders", "In more than one", "Note"],
        [[_e(t["title"]), br.join(_e(f"{f['library']}\\{f['folder']} ({f['files']} files" + (f"; only here: {f['only']}" if f["only"] else "") + ")")
                                  for f in t["folders"]), _e(t["both"]), _e(t["note"])] for t in g.get("twice", [])]))
    body.append(f"<h2>{GROUPS['gaps']} ({len(g.get('gaps', []))})</h2>" + _table(
        ["Library", "Folder", "Missing", "Note"],
        [[_e(x["library"]), _e(x["folder"]), _e(x["missing"]), _e(x["note"])] for x in g.get("gaps", [])]))
    if result.get("filesChecked"):
        body.append(f"<h2>{GROUPS['broken']} ({len(g.get('broken', []))})</h2>" + _table(
            ["Library", "Folder", "File", "Problem"],
            [[_e(b["library"]), _e(b["folder"]), _e(b["file"]), f'<span class="bad">{_e(b["problem"])}</span>'] for b in g.get("broken", [])]))
    else:
        body.append(f"<h2>{GROUPS['broken']}</h2><p class=\"muted\">Not checked: the files themselves weren't read this time.</p>")
    body.append(f"<h2>{GROUPS['odd']} ({len(g.get('odd', []))})</h2>" + _table(
        ["Library", "Folder", "What", "Files", "Note"],
        [[_e(o["library"]), _e(o["folder"]), _e(o["label"]), br.join(_e(f) for f in o["files"][:30]) +
          (f"{br}… and {len(o['files']) - 30} more" if len(o["files"]) > 30 else ""), _e(o["note"])] for o in g.get("odd", [])]))
    when = time.strftime("%Y-%m-%d %H:%M", time.localtime(result.get("checked") or time.time()))
    sub = f"{result.get('shows', 0)} show folders in {', '.join(result.get('libraries') or [])}, checked {when}."
    return _PAGE.format(title="AniBox · Health check", sub=_e(sub), body="".join(body), made_by=_e(made_by))


def plan_html(plan: dict, made_by: str) -> str:
    t = plan.get("totals") or {}
    body = ['<div class="note"><ul>' + "".join(f"<li>{_e(c)}</li>" for c in plan.get("conditions") or []) + "</ul></div>"]
    if plan.get("error"):
        body.append(f"<p>{_e(plan['error'])}</p>")
    for sh in plan.get("shows") or []:
        head = f"{sh['folder']} → " + (f"into {sh['into']}" if sh["merge"] else f"new folder {sh['toDir']}")
        body.append(f"<h2>{_e(head)}</h2>" + "".join(f'<p class="note">{_e(f)}</p>' for f in sh["flags"]) + _table(
            ["Now", "Would go to", "Problem"],
            [[f"<code>{_e(f['from'])}</code>", f"<code>{_e(f['to'])}</code>", f'<span class="bad">{_e(f["conflict"])}</span>']
             for f in sh["files"]]))
    sub = (f"{plan.get('from')} → {plan.get('to')}: {t.get('shows', 0)} shows, {t.get('files', 0)} files, "
           f"{t.get('merged', 0)} into existing folders, {t.get('conflicts', 0)} problems, {t.get('locked', 0)} locked shows.")
    return _PAGE.format(title="AniBox · Move plan (not moved)", sub=_e(sub), body="".join(body), made_by=_e(made_by))
