"""Posters, descriptions, genres and episode titles for your series and movies (not anime), from TMDB.

TMDB (themoviedb.org) is a free movie and TV database run by its community. Its API needs a free key
of your own (themoviedb.org → account settings → API). Both kinds TMDB shows there work: the long
"API Read Access Token" (sent as ``Authorization: Bearer``) and the short "API Key" (32 letters and
digits, sent as ``api_key=``). Without a key AniBox never asks TMDB anything.

- What AniBox sends: a show's folder name (without release tags) and its year when it searches,
  then the TMDB number of the match. Every request carries only ``AniBox/<version>`` as its name.
- Matching: series are searched with ``/search/tv``, movies with ``/search/movie``. "Title (2019)",
  "Title [2019]" and "Title.2019.1080p…" give a year. The best result: the same title first, then
  the same year, then the most popular one. You can pick another one by hand ("Wrong match?").
- Kept in ``<data>/tmdb/`` for 30 days: ``matches.json`` (show → TMDB number), ``tv-<id>.json`` /
  ``movie-<id>.json`` (details), ``tv-<id>-s<n>.json`` (one season's episode titles) and
  ``posters/<kind>-<id>.jpg``. The window never talks to TMDB; AniBox serves the posters itself.

"This product uses the TMDB API but is not endorsed or certified by TMDB." (TMDB's attribution rule.)
"""

from __future__ import annotations

import http.client
import json
import logging
import os
import re
import threading
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from . import __version__

log = logging.getLogger("anibox.tmdb")

API = "https://api.themoviedb.org/3"
IMAGES = "https://image.tmdb.org/t/p/w342"  # posters, 342 pixels wide
WEB = "https://www.themoviedb.org"
LANGUAGE = "en-US"
MAX_AGE = 30 * 86400
RETRY_NOT_FOUND = 30 * 86400  # a folder TMDB didn't know is searched again after this
KINDS = ("tv", "movie")
ATTRIBUTION = "This product uses the TMDB API but is not endorsed or certified by TMDB."
USER_AGENT = f"AniBox/{__version__}"
TIMEOUT = 15

KEY_REFUSED = "TMDB didn't accept the key. Check it in Settings → Series and movie info (TMDB)."
NO_CONNECTION = "TMDB didn't answer. Check the internet connection and try again."

_V3_KEY = re.compile(r"^[0-9a-f]{32}$", re.I)
_TOKEN = re.compile(r"^[A-Za-z0-9._~+/=-]{40,2000}$")
_YEAR_PAREN = re.compile(r"[(\[]\s*((?:19|20)\d\d)\s*[)\]]")
_BRACKETS = re.compile(r"\[[^\]]*\]|\{[^}]*\}")
_TAGS = re.compile(r"\s(?:2160p|1080p|720p|576p|480p|uhd|x26[45]|h\.?26[45]|hevc|10.?bit|web-?dl|webrip|"
                   r"bdrip|brrip|blu-?ray|dvdrip|hdtv|remux|aac|ac3|dts)\b.*$", re.I)
_SEASON_TAIL = re.compile(r"\s+(?:-\s*)?(?:season|staffel|s)\s?\d{1,2}(?:\s?-\s?\d{1,2})?\s*$", re.I)
_COUNTRY_TAIL = re.compile(r"\s*[(\[](?:US|UK|GB|AU|CA|NZ|IE)[)\]]\s*$", re.I)  # "The Office (US)"
POSTER_NAME = re.compile(r"^(tv|movie)-(\d{1,10})$")


class TmdbError(RuntimeError):
    def __init__(self, message: str, status: int = 0):
        super().__init__(message)
        self.status = status


def clean_key(text: str) -> str:
    """The key as pasted: spaces, quotes and a "Bearer " in front are dropped."""
    t = (text or "").strip().strip('"').strip("'").strip()
    if t.lower().startswith("bearer "):
        t = t[7:].strip()
    return t


def key_kind(key: str) -> str:
    """"v3" (the short API Key), "v4" (the long API Read Access Token) or "" (doesn't look like either)."""
    if _V3_KEY.match(key or ""):
        return "v3"
    if _TOKEN.match(key or ""):
        return "v4"
    return ""


def parse_folder(name: str) -> Tuple[str, Optional[int]]:
    """("Title", year or None) from a folder name: "Title (2019)", "Title [2019]", "Title.2019.1080p.WEB"."""
    s = name or ""
    year = None
    m = None
    for m in _YEAR_PAREN.finditer(s):
        pass
    if m and m.start() > 0:
        year = int(m.group(1))
        s = s[:m.start()]
    s = _BRACKETS.sub(" ", s)
    if " " not in s.strip() and (s.count(".") >= 1 or s.count("_") >= 1):  # Scene.Style.Names
        tokens = [t for t in re.split(r"[._]+", s) if t]
        if year is None:
            this_year = time.gmtime().tm_year
            for i in range(len(tokens) - 1, 0, -1):
                if re.fullmatch(r"(?:19|20)\d\d", tokens[i]) and int(tokens[i]) <= this_year + 1:
                    year = int(tokens[i])
                    tokens = tokens[:i]
                    break
        s = " ".join(tokens)
    s = s.replace("_", " ")
    s = _TAGS.sub("", s)
    s = re.sub(r"\s+", " ", s).strip(" -_.,")
    s = _SEASON_TAIL.sub("", s).strip(" -_.,")
    s = _COUNTRY_TAIL.sub("", s).strip(" -_.,")
    return (s or (name or "").strip()), year


def norm(text: str) -> str:
    t = unicodedata.normalize("NFKD", text or "").casefold()
    t = "".join(c for c in t if not unicodedata.combining(c))
    t = t.replace("&", " and ").replace("'", "").replace("’", "")
    return re.sub(r"[^0-9a-z]+", " ", t).strip()


def _year(date) -> Optional[int]:
    m = re.match(r"^(\d{4})", str(date or ""))
    return int(m.group(1)) if m else None


def result_json(r: dict, kind: str) -> dict:
    """One search result in plain words."""
    title = r.get("name") if kind == "tv" else r.get("title")
    original = r.get("original_name") if kind == "tv" else r.get("original_title")
    return {"id": r.get("id"), "kind": kind, "title": title or original or "", "original": original or "",
            "year": _year(r.get("first_air_date") if kind == "tv" else r.get("release_date")),
            "overview": (r.get("overview") or "")[:400], "popularity": float(r.get("popularity") or 0),
            "url": f"{WEB}/{kind}/{r.get('id')}"}


def pick(results: List[dict], title: str, year: Optional[int]) -> Optional[dict]:
    """The best search result (``result_json`` shape): the same title, then the same year, then popularity."""
    if not results:
        return None
    q = norm(title)

    def score(r):
        names = {norm(r.get("title") or ""), norm(r.get("original") or "")}
        return (q in names, bool(year) and r.get("year") == year, r.get("popularity") or 0)

    return max(results, key=score)


def _atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".part")
    tmp.write_bytes(data)
    os.replace(tmp, path)


class Tmdb:
    def __init__(self, folder: Path, api: Optional[str] = None, images: Optional[str] = None):
        self.folder = folder
        self.api = (api or API).rstrip("/")
        self.images = (images or IMAGES).rstrip("/")
        self._lock = threading.RLock()
        self._mem: Dict[str, Tuple[float, dict]] = {}  # file name -> (mtime, data): details and seasons
        self._matches: Dict[str, dict] = {}
        self.requests = 0  # how many requests went to TMDB (shown in the log, used by the tests)
        try:
            data = json.loads((folder / "matches.json").read_text(encoding="utf-8"))
            if isinstance(data.get("shows"), dict):
                self._matches = {k: v for k, v in data["shows"].items() if isinstance(v, dict)}
        except FileNotFoundError:
            pass
        except (OSError, ValueError, AttributeError):
            log.warning("TMDB matches couldn't be read; folders are searched again")

    # -- talking to TMDB -----------------------------------------------------------------------------

    def _open(self, url: str, key: str, accept: str = "application/json"):
        headers = {"User-Agent": USER_AGENT, "Accept": accept}
        if key_kind(key) != "v3":
            headers["Authorization"] = "Bearer " + key
        return urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=TIMEOUT)

    def _get(self, path: str, params: dict, key: str) -> dict:
        if not key:
            raise TmdbError("No TMDB key.")
        q = {k: v for k, v in params.items() if v not in (None, "")}
        if key_kind(key) == "v3":
            q["api_key"] = key
        url = f"{self.api}{path}" + ("?" + urllib.parse.urlencode(q) if q else "")
        for attempt in range(3):
            self.requests += 1
            try:
                with self._open(url, key) as resp:
                    raw = resp.read(5_000_001)
                if len(raw) > 5_000_000:
                    raise TmdbError("TMDB's answer was too big.")
                data = json.loads(raw.decode("utf-8"))
                if not isinstance(data, dict):
                    raise TmdbError("TMDB sent an answer AniBox can't read.")
                return data
            except urllib.error.HTTPError as exc:
                wait = exc.headers.get("Retry-After") if exc.headers else None
                exc.close()
                if exc.code == 429 and attempt < 2:  # too many at once: wait a moment
                    try:
                        time.sleep(max(0.0, min(10.0, float(wait or 2))))
                    except ValueError:
                        time.sleep(2)
                    continue
                if exc.code == 401:
                    raise TmdbError(KEY_REFUSED, 401) from None
                if exc.code == 404:
                    raise TmdbError("TMDB doesn't know this entry.", 404) from None
                log.warning("TMDB answered %s for %s", exc.code, path)  # never the query: it may hold the key
                raise TmdbError(f"TMDB answered with an error ({exc.code}). Try again later.", exc.code) from None
            except (urllib.error.URLError, OSError, http.client.HTTPException) as exc:
                log.info("TMDB not reachable (%s): %s", path, getattr(exc, "reason", exc))
                raise TmdbError(NO_CONNECTION) from None
            except ValueError:
                raise TmdbError("TMDB sent an answer AniBox can't read.") from None
        raise TmdbError("TMDB is busy right now. Try again in a minute.", 429)

    def check_key(self, key: str) -> None:
        """Raises TmdbError(KEY_REFUSED, 401) if TMDB doesn't take the key."""
        self._get("/authentication", {}, key)

    def search(self, kind: str, title: str, year: Optional[int], key: str) -> List[dict]:
        kind = kind if kind in KINDS else "tv"
        params = {"query": title, "language": LANGUAGE, "include_adult": "false"}
        if year:
            params["first_air_date_year" if kind == "tv" else "year"] = year
        data = self._get(f"/search/{kind}", params, key)
        return [result_json(r, kind) for r in data.get("results") or [] if isinstance(r, dict) and r.get("id")]

    # -- cache files -----------------------------------------------------------------------------------

    def _read(self, name: str, max_age: Optional[float] = None) -> Optional[dict]:
        path = self.folder / name
        try:
            mtime = path.stat().st_mtime
        except OSError:
            return None
        if max_age is not None and time.time() - mtime > max_age:
            return None
        with self._lock:
            hit = self._mem.get(name)
            if hit and hit[0] == mtime:
                return hit[1]
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None
        with self._lock:
            self._mem[name] = (mtime, data)
        return data

    def _write(self, name: str, data: dict) -> None:
        _atomic_write(self.folder / name, json.dumps(data, ensure_ascii=False).encode("utf-8"))

    # -- matches: which TMDB entry a show folder is --------------------------------------------------

    def _save_matches(self) -> None:
        self._write("matches.json", {"version": 1, "shows": self._matches})

    def match_for(self, show_id: str) -> Optional[dict]:
        with self._lock:
            m = self._matches.get(show_id)
            return dict(m) if m else None

    @staticmethod
    def needs_match(m: Optional[dict], kind: str) -> bool:
        if not m:
            return True
        if m.get("manual"):
            return False
        if m.get("kind") != kind:
            return True  # the library is now read as series instead of movies (or the other way round)
        return not m.get("id") and time.time() - float(m.get("tried") or 0) > RETRY_NOT_FOUND

    def set_match(self, show_id: str, kind: str, tmdb_id: Optional[int], manual: bool, **extra) -> dict:
        m = {"kind": kind if kind in KINDS else "tv", "id": int(tmdb_id) if tmdb_id else None, "manual": bool(manual),
             "tried": time.time(), **extra}
        with self._lock:
            self._matches[show_id] = m
            self._save_matches()
        return dict(m)

    def forget_match(self, show_id: str) -> None:
        """Back to automatic: the folder is searched again."""
        with self._lock:
            if self._matches.pop(show_id, None) is not None:
                self._save_matches()

    def auto_match(self, show_id: str, folder: str, kind: str, key: str) -> dict:
        title, year = parse_folder(folder)
        results = self.search(kind, title, year, key)
        if not results and year:
            results = self.search(kind, title, None, key)  # e.g. a show's later season in a "(2023)" folder
        best = pick(results, title, year)
        log.info("TMDB: %s → %s", show_id, f"{best['kind']} {best['id']} ({best['title']}, {best['year']})" if best else "not found")
        return self.set_match(show_id, kind, best["id"] if best else None, False, query=title, year=year)

    def counts(self, show_ids: List[str]) -> dict:
        with self._lock:
            found = sum(1 for s in show_ids if (self._matches.get(s) or {}).get("id"))
            missing = sum(1 for s in show_ids if s in self._matches and not self._matches[s].get("id"))
        return {"found": found, "notFound": missing, "open": len(show_ids) - found - missing}

    # -- details, seasons, posters -----------------------------------------------------------------------

    def cached_details(self, kind: str, tmdb_id) -> Optional[dict]:
        return self._read(f"{kind}-{int(tmdb_id)}.json") if kind in KINDS and tmdb_id else None

    def details_fresh(self, kind: str, tmdb_id) -> bool:
        return bool(kind in KINDS and tmdb_id and self._read(f"{kind}-{int(tmdb_id)}.json", MAX_AGE))

    def details(self, kind: str, tmdb_id: int, key: str, refresh: bool = False) -> dict:
        name = f"{kind}-{int(tmdb_id)}.json"
        fresh = None if refresh else self._read(name, MAX_AGE)
        if fresh:
            return fresh
        d = self._get(f"/{kind}/{int(tmdb_id)}", {"language": LANGUAGE}, key)
        out = {
            "kind": kind, "id": int(tmdb_id),
            "title": (d.get("name") if kind == "tv" else d.get("title")) or "",
            "original": (d.get("original_name") if kind == "tv" else d.get("original_title")) or "",
            "overview": (d.get("overview") or "").strip(),
            "tagline": (d.get("tagline") or "").strip(),
            "year": _year(d.get("first_air_date") if kind == "tv" else d.get("release_date")),
            "genres": [g.get("name") for g in d.get("genres") or [] if isinstance(g, dict) and g.get("name")],
            "poster": d.get("poster_path") or "",
            "runtime": d.get("runtime") if kind == "movie" else None,
            "status": d.get("status") or "",
            "seasons": [{"n": s.get("season_number"), "name": s.get("name") or "", "episodes": s.get("episode_count")}
                        for s in d.get("seasons") or [] if isinstance(s, dict) and isinstance(s.get("season_number"), int)],
            "url": f"{WEB}/{kind}/{int(tmdb_id)}",
            "fetched": time.time(),
        }
        self._write(name, out)
        return out

    def cached_season(self, tmdb_id, season: int) -> Optional[dict]:
        return self._read(f"tv-{int(tmdb_id)}-s{int(season)}.json")

    def season_fresh(self, tmdb_id, season: int) -> bool:
        return bool(self._read(f"tv-{int(tmdb_id)}-s{int(season)}.json", MAX_AGE))

    def season(self, tmdb_id: int, season: int, key: str) -> dict:
        """One season's episode titles, overviews and air dates. A season TMDB doesn't have is kept empty."""
        name = f"tv-{int(tmdb_id)}-s{int(season)}.json"
        fresh = self._read(name, MAX_AGE)
        if fresh:
            return fresh
        try:
            d = self._get(f"/tv/{int(tmdb_id)}/season/{int(season)}", {"language": LANGUAGE}, key)
        except TmdbError as exc:
            if exc.status != 404:
                raise
            d = {}
        eps = {}
        for e in d.get("episodes") or []:
            if isinstance(e, dict) and isinstance(e.get("episode_number"), int):
                eps[str(e["episode_number"])] = {"title": (e.get("name") or "").strip(),
                                                 "plot": (e.get("overview") or "").strip(),
                                                 "aired": e.get("air_date") or ""}
        out = {"id": int(tmdb_id), "season": int(season), "episodes": eps, "fetched": time.time()}
        self._write(name, out)
        return out

    def poster_path(self, name: str) -> Optional[Path]:
        return self.folder / "posters" / f"{name}.jpg" if POSTER_NAME.match(name or "") else None

    def poster(self, name: str, key: str) -> Optional[bytes]:
        """The poster of "tv-123" / "movie-456": from the cache, else fetched once (only with a key)."""
        path = self.poster_path(name)
        if path is None:
            return None
        try:
            return path.read_bytes()
        except OSError:
            pass
        if not key:
            return None
        m = POSTER_NAME.match(name)
        d = self.cached_details(m.group(1), m.group(2))
        poster = (d or {}).get("poster") or ""
        if not re.fullmatch(r"/[A-Za-z0-9_-]{1,100}\.(?:jpg|jpeg|png|webp)", poster):
            return None
        self.requests += 1
        try:
            req = urllib.request.Request(self.images + poster, headers={"User-Agent": USER_AGENT})
            with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
                data = resp.read(5_000_001)
        except (urllib.error.URLError, OSError, http.client.HTTPException):
            return None
        if not data or len(data) > 5_000_000:
            return None
        _atomic_write(path, data)
        return data
