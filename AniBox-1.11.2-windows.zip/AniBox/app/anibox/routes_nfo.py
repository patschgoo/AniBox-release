"""Info files (NFO) for Plex/Jellyfin: preview, write on request, undo, locks.

Part of the App class (see server.py); the methods use the App's attributes.
"""

from __future__ import annotations

import logging
import os
import secrets
import time

from .apierror import ApiError

log = logging.getLogger("anibox.server")


class RoutesNfoMixin:
    def _nfo_inputs(self, shows):
        ds = self.library.datasets()
        wanted = {sh["mal_id"] for sh in shows if sh.get("mal_id")}
        ids = {}
        for m in ds.mapping:
            mal = str(m.get("mal_id") or "")
            if mal in wanted:
                ids[mal] = {"anidb": m.get("anidb_id"), "anilist": m.get("anilist_id"), "tvdb": m.get("tvdb_id"),
                            "tmdb": m.get("themoviedb_id"), "imdb": m.get("imdb_id")}
        details = {mal: d for mal in wanted for d in [self.mal.cached(mal)] if d}
        return ds.titles, ids, details

    def _nfo_preview(self, libraries, posters: bool) -> dict:
        from . import nfo
        if not libraries:
            raise ApiError("Pick at least one library.")
        shows = [sh for sh in self.library.shows(all_libraries=True) if sh["library"] in libraries]
        plan = self._nfo_plan_for(shows, posters)
        token = secrets.token_urlsafe(8)
        self.nfo_plan = (token, plan)
        log.info("NFO preview for %s: %s", libraries, plan.get("counts"))
        return {"token": token, "counts": plan.get("counts", {}), "shows": plan.get("shows", 0),
                "text": nfo.preview_text(plan, limit=300)}

    def _nfo_plan_for(self, shows, posters: bool) -> dict:
        """The info files for these shows; episodes (and shows) that are locked are left out."""
        from . import nfo
        titles, ids, details = self._nfo_inputs(shows)
        protected = self.store.settings().get("protected") or []
        # Episode titles (your file names, Kitsu) go into the episode files; only what's cached.
        views = []
        for sh in shows:
            info = self.episodes.for_show(sh, self._plex_episodes(sh))
            view = dict(sh, episodes=[dict(e, online=info.get(e["key"])) if e["key"] in info else e for e in sh["episodes"]])
            views.append(view)
        plan = nfo.plan(views, titles, ids, details=details, protected=protected,
                        posters=(lambda mal: self.poster(str(mal))) if posters else None, write_posters=posters)
        self._apply_locks(plan, shows)
        return plan

    def _apply_locks(self, plan: dict, shows) -> None:
        """Episodes (and shows) that were already there are skipped until the show is unlocked."""
        from . import nfo
        locked, unlocked = self.store.locked_keys(), self.store.unlocked_shows()
        locked_paths, locked_shows = set(), set()
        for sh in shows:
            view = self.library.lock_view(sh, locked, unlocked)
            if view["keys"]:
                locked_shows.add(sh["id"])
                locked_paths |= {os.path.normcase(e["path"]) for e in sh["episodes"] if e["key"] in view["keys"]}
        for it in plan.get("items") or []:
            if it.get("action") not in nfo.WRITE_ACTIONS:
                continue
            if it.get("kind") == "episode":
                hit = os.path.normcase(str(it.get("video") or "")) in locked_paths
            else:
                hit = it.get("show") in locked_shows  # show files only for new or unlocked shows
            if hit:
                it["action"] = nfo.SKIP_LOCKED
                it.pop("content", None)
        counts = {a: 0 for a in nfo.ACTIONS}
        for it in plan.get("items") or []:
            counts[it["action"]] = counts.get(it["action"], 0) + 1
        plan["counts"] = counts
        plan["shows"] = len({it.get("show") for it in plan.get("items") or [] if it.get("action") in nfo.WRITE_ACTIONS})

    def _nfo_write(self, token: str) -> dict:
        from . import nfo
        if not self.nfo_plan or self.nfo_plan[0] != token:
            raise ApiError("Make a new preview first.")
        _, plan = self.nfo_plan
        self.nfo_plan = None
        result = nfo.write(plan, self.nfo_undo)
        log.info("NFO files written: %s", {k: v for k, v in result.items() if k != "errors"})
        return {"ok": True, **result}

    def _nfo_undo(self) -> dict:
        from . import nfo
        if not self.nfo_undo.is_file():
            raise ApiError("There's nothing to undo.")
        result = nfo.undo(self.nfo_undo)
        done = self.nfo_undo.with_name(time.strftime("nfo-undo-done-%Y%m%d-%H%M%S.jsonl"))
        os.replace(self.nfo_undo, done)
        log.info("NFO files undone: %s", {k: v for k, v in result.items() if k not in ("kept_paths", "errors")})
        return {"ok": True, **result}
