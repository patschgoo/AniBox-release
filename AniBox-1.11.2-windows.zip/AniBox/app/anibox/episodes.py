"""Episode titles and pictures, without touching your files.

Where the titles come from, best first:

1. **Your own file names.** Files you named by hand ("001  Romance Dawn.mp4",
   "One Piece 001 - Romance Dawn.mkv") already carry a title; AniBox shows it and never replaces it.
2. **Kitsu** (kitsu.io, free, no account): titles, air dates, short descriptions and pictures per
   episode, for the same entries as MyAnimeList (one season = one entry). The link from a
   MyAnimeList entry to Kitsu comes from the anime lists (Fribb/anime-lists).
3. **The One Piece Wiki** (onepiece.fandom.com): a picture for every One Piece episode.

Everything is only shown in AniBox (and written into new .nfo files if you ask for that). Answers
are kept in ``<data>/episodes/`` for a week, so each show is asked for at most once a week.
"""

from __future__ import annotations

import json
import logging
import os
import re
import threading
import time
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Dict, List, Optional

log = logging.getLogger("anibox.episodes")

KITSU = "https://kitsu.io/api/edge"
ONE_PIECE_WIKI = "https://onepiece.fandom.com/api.php"
ONE_PIECE_MAL = "21"
MAX_AGE = 7 * 86400
PAGE = 20  # Kitsu's largest page
WIKI_BATCH = 50  # MediaWiki answers up to 50 titles at once
TIMEOUT = 15

_TAG_RE = re.compile(r"\[[^\]]*\]|\((?:[^)]*(?:\d{3,4}p|x26[45]|hevc|aac|flac|bd|web|dual|multi)[^)]*)\)", re.I)
_NUM_START = re.compile(r"^\s*[-_.#]*\s*(?:s\d{1,2}\s*)?(?:e|ep|episode|folge|eps)?\s*\.?\s*\d{1,4}(?:v\d)?\b\s*[-_.:|~]*\s*", re.I)
_NUM_END = re.compile(r"\s*[-_.:|~]*\s*(?:e|ep|episode|folge)?\s*\d{1,4}(?:v\d)?\s*$", re.I)
_JUNK = re.compile(r"^(?:end|final|fin|ova|oad|special|sp|tv|bd|uncut|uncensored|v\d|\W)*$", re.I)


def _fold(text: str) -> str:
    return re.sub(r"[^0-9a-z]+", "", (text or "").casefold())


def own_title(file: str, folder: str, show_title: str = "") -> str:
    """The title in a file name you typed yourself, or "" (e.g. for "Show 01.mkv")."""
    name = os.path.splitext(file.replace("\\", "/").rsplit("/", 1)[-1])[0]
    name = _TAG_RE.sub(" ", name).replace("_", " ").strip()
    for prefix in sorted({folder, show_title} - {""}, key=len, reverse=True):
        # Drop the show's name at the start, however it's spaced or punctuated.
        pattern = r"\W*".join(re.escape(ch) for ch in prefix if not ch.isspace())
        name = re.sub(r"^\W*" + pattern + r"\W*", "", name, flags=re.I) if pattern else name
    name = _NUM_START.sub("", name, count=1)
    name = _NUM_END.sub("", name, count=1).strip(" -_.:|~")
    letters = sum(ch.isalpha() for ch in name)
    if letters < 3 or _JUNK.match(name) or _fold(name) in (_fold(folder), _fold(show_title)):
        return ""
    return name


def absolute_numbers(episodes: List[dict]) -> List[Optional[int]]:
    """The episode number counted from the start of the entry, for each AniBox episode.

    Flat folders: the number in the file name. "Season NN" folders whose numbers restart at 1
    (like the One Piece folders): earlier seasons' highest numbers are added up. If an earlier
    season doesn't start at 1, the count after it would be a guess, so those get None.
    """
    seasons: Dict[int, List[int]] = {}
    in_season = any("\\" in (e.get("file") or "") for e in episodes)
    if not in_season:
        return [e.get("number") if (e.get("season") or 1) != 0 else None for e in episodes]
    for e in episodes:
        if e.get("number") is not None and e.get("season"):
            seasons.setdefault(e["season"], []).append(e["number"])
    offsets: Dict[int, Optional[int]] = {}
    total: Optional[int] = 0
    for s in sorted(seasons):
        offsets[s] = total
        nums = seasons[s]
        if total is None or min(nums) != 1:
            total = None
        else:
            total += max(nums)
    out: List[Optional[int]] = []
    for e in episodes:
        off = offsets.get(e.get("season") or 0)
        out.append(off + e["number"] if off is not None and e.get("number") is not None else None)
    return out


class EpisodeInfo:
    def __init__(self, cache_dir: Path, kitsu: str = KITSU, wiki: str = ONE_PIECE_WIKI):
        self.cache_dir = cache_dir
        self.kitsu = kitsu.rstrip("/")
        self.wiki = wiki
        self._busy: Dict[str, str] = {}  # show id -> "loading" / error text
        self._lock = threading.Lock()

    # -- cache ------------------------------------------------------------------------------------

    def _path(self, name: str) -> Path:
        return self.cache_dir / name

    def _load(self, name: str, max_age: float = MAX_AGE) -> Optional[dict]:
        p = self._path(name)
        try:
            if time.time() - p.stat().st_mtime > max_age:
                return None
            return json.loads(p.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None

    def _save(self, name: str, data: dict) -> None:
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        p = self._path(name)
        tmp = p.with_suffix(".part")
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, p)

    def _get(self, url: str, accept: str = "application/json") -> dict:
        req = urllib.request.Request(url, headers={"User-Agent": "AniBox", "Accept": accept})
        with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
            return json.loads(r.read(5_000_000).decode("utf-8"))

    # -- sources -----------------------------------------------------------------------------------

    def _kitsu_page(self, kitsu_id: str, offset: int) -> dict:
        query = urllib.parse.urlencode({
            "page[limit]": PAGE, "page[offset]": offset, "sort": "number",
            "fields[episodes]": "number,canonicalTitle,titles,airdate,synopsis,thumbnail"})
        return self._get(f"{self.kitsu}/anime/{int(kitsu_id)}/episodes?{query}", "application/vnd.api+json")

    def kitsu_episodes(self, kitsu_id: str) -> Dict[str, dict]:
        """{"5": {"title", "aired", "plot", "image"}} for a Kitsu entry (all pages, a few at a time)."""
        first = self._kitsu_page(kitsu_id, 0)
        pages = [first]
        count = int((first.get("meta") or {}).get("count") or 0)
        offsets = list(range(PAGE, min(count, 5000), PAGE)) if count else []
        if not count and len(first.get("data") or []) == PAGE:  # no count given: page by page
            offset = PAGE
            while offset <= 5000:
                page = self._kitsu_page(kitsu_id, offset)
                pages.append(page)
                if len(page.get("data") or []) < PAGE:
                    break
                offset += PAGE
        elif offsets:
            with ThreadPoolExecutor(max_workers=4) as pool:  # One Piece: 70 pages
                pages += list(pool.map(lambda o: self._kitsu_page(kitsu_id, o), offsets))
        out: Dict[str, dict] = {}
        for page in pages:
            for it in page.get("data") or []:
                a = it.get("attributes") or {}
                n = a.get("number")
                if not isinstance(n, int):
                    continue
                titles = a.get("titles") or {}
                title = (a.get("canonicalTitle") or titles.get("en") or titles.get("en_us") or titles.get("en_jp") or "").strip()
                if re.fullmatch(r"(episode|ep\.?)\s*\d+", title, re.I):
                    title = ""  # placeholders aren't titles
                thumb = (a.get("thumbnail") or {}).get("original") or ""
                out[str(n)] = {"title": title, "aired": a.get("airdate") or "",
                               "plot": (a.get("synopsis") or "").strip(), "image": thumb if thumb.startswith("https://") else ""}
        return out

    def _wiki_batch(self, chunk: List[int]) -> Dict[str, str]:
        query = urllib.parse.urlencode({
            "action": "query", "prop": "pageimages", "piprop": "thumbnail", "pithumbsize": 480,
            "titles": "|".join(f"Episode {n}" for n in chunk), "format": "json", "redirects": 1})
        data = self._get(f"{self.wiki}?{query}")
        out = {}
        for page in ((data.get("query") or {}).get("pages") or {}).values():
            m = re.fullmatch(r"Episode (\d+)", page.get("title") or "")
            src = ((page.get("thumbnail") or {}).get("source") or "")
            if m and src.startswith("https://"):
                out[m.group(1)] = src
        return out

    def wiki_images(self, numbers: List[int]) -> Dict[str, str]:
        """One Piece Wiki: {"1100": "https://...jpg"} for the "Episode N" pages."""
        chunks = [numbers[i:i + WIKI_BATCH] for i in range(0, len(numbers), WIKI_BATCH)]
        out: Dict[str, str] = {}
        with ThreadPoolExecutor(max_workers=3) as pool:
            for part in pool.map(self._wiki_batch, chunks):
                out.update(part)
        return out

    # -- per show ------------------------------------------------------------------------------------

    def cached(self, show: dict) -> Optional[dict]:
        return self._load(f"show-{_fold(show['id'])[:80]}.json", max_age=10 ** 9)

    def status(self, show_id: str) -> str:
        with self._lock:
            return self._busy.get(show_id, "")

    def fetch_async(self, show: dict, kitsu_id: Optional[str]) -> None:
        with self._lock:
            if self._busy.get(show["id"]) == "loading":
                return
            self._busy[show["id"]] = "loading"
        threading.Thread(target=self._fetch, args=(show, kitsu_id), daemon=True, name="anibox-episodes").start()

    def fresh(self, show: dict) -> bool:
        return self._load(f"show-{_fold(show['id'])[:80]}.json") is not None

    def _fetch(self, show: dict, kitsu_id: Optional[str]) -> None:
        try:
            numbers = [n for n in absolute_numbers(show["episodes"]) if n]
            by_number: Dict[str, dict] = {}
            source = ""
            if kitsu_id:
                by_number = self.kitsu_episodes(kitsu_id)
                source = "Kitsu"
            if show.get("mal_id") == ONE_PIECE_MAL and numbers:
                images = self.wiki_images(sorted(set(numbers)))
                for n, url in images.items():
                    by_number.setdefault(n, {"title": "", "aired": "", "plot": "", "image": ""})["image"] = url
                source = (source + " + One Piece Wiki").strip(" +")
            self._save(f"show-{_fold(show['id'])[:80]}.json", {"source": source, "episodes": by_number, "fetched": time.time()})
            log.info("Episode info for %s: %d episodes from %s", show["id"], len(by_number), source or "nowhere")
            with self._lock:
                self._busy.pop(show["id"], None)
        except Exception as exc:
            log.warning("Episode info for %s failed: %s", show.get("id"), exc)
            with self._lock:
                self._busy[show["id"]] = "Couldn't load episode titles right now."

    def for_show(self, show: dict, plex: Optional[Dict[str, dict]] = None) -> Dict[str, dict]:
        """{episode key: {"title", "own", "image", "aired", "plot", "number", "source"}} from what's cached.

        Order for titles: your own file name, then what Plex already had (``plex``: episode key ->
        Plex's episode fields, from the copy of Plex's details), then Kitsu.
        """
        data = self.cached(show) or {}
        online = data.get("episodes") or {}
        plex = plex or {}
        out: Dict[str, dict] = {}
        for ep, n in zip(show["episodes"], absolute_numbers(show["episodes"])):
            own = own_title(ep.get("file") or "", show.get("folder") or "", show.get("title") or "")
            info = (online.get(str(n)) if n else None) or {}
            px = plex.get(ep["key"]) or {}
            ptitle = (px.get("title") or "").strip()
            if re.fullmatch(r"(episode|ep\.?|folge)\s*\d+", ptitle, re.I):
                ptitle = ""  # Plex's placeholder, not a title
            title = own or ptitle or info.get("title") or ""
            if not (title or info.get("image")):
                continue
            source = "your file name" if own else "your Plex library" if ptitle else data.get("source", "")
            plot = "" if own else (px.get("summary") or "") if ptitle else (info.get("plot") or "")
            out[ep["key"]] = {"title": title, "own": bool(own), "image": info.get("image") or "",
                              "aired": px.get("originallyAvailableAt") or info.get("aired") or "", "plot": plot,
                              "number": n, "source": source}
        return out
