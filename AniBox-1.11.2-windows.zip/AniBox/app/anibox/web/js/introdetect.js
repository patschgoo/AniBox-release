/* AniBox window · Openings and endings without chapters, found by comparing the sound of a show's
   episodes (routes_introdetect.py, introdetect.py). Nothing is written next to the videos.
   Plain scripts sharing one page: loaded in order by index.html. */
"use strict";

var INTRO_NOTES = { short: "too short to compare", unreadable: "couldn't be read", alone: "no other episode to compare with",
  chapters: "has chapters" };

function introHere(id) { return showData && showData.id === id && currentPage === "show"; }
function introPart(p, chapter) {
  if (p) return fmt(p.start) + "–" + fmt(p.end) + (p.source === "edited" ? ' <span class="pill partial">edited</span>' :
    (p.conf != null && p.conf < 0.6 ? ' <span class="muted" title="Only some of the other episodes agree">(unsure)</span>' : ""));
  return chapter ? '<span class="muted">chapter</span>' : '<span class="muted">—</span>';
}
function introSeconds(text) {  // "1:32" -> 92; "" -> null; NaN when it isn't a time
  text = String(text || "").trim(); if (!text) return null;
  var parts = text.split(":"), total = 0;
  if (parts.length > 3) return NaN;
  for (var i = 0; i < parts.length; i++) { if (!/^\d+(\.\d+)?$/.test(parts[i])) return NaN; total = total * 60 + Number(parts[i]); }
  return total;
}

// ---------- Show page
showPanels.push(function (box, d) {
  box.innerHTML = '<section class="panel" style="margin-top:22px"><div class="kicker">Skip opening and ending</div>' +
    '<div class="section" style="margin:6px 0 10px"><h3 style="margin:0">Opening and ending</h3><div class="row" style="margin:0">' +
    '<button class="btn small" id="introFind">Find opening and ending</button><button class="btn small" id="introCancel" hidden>Cancel</button>' +
    '<button class="btn small" id="introOff" hidden></button></div></div>' +
    '<div id="introState" class="muted">…</div><div id="introList"></div></section>';
  introLoad(d);
});
function introLoad(d) {
  api("/api/intro/show?id=" + encodeURIComponent(d.id)).then(function (r) {
    if (!introHere(d.id) || !$("introState")) return;
    introDraw(d, r);
    var j = r.job || {};
    if (j.state === "running" || (j.queuedShows || []).indexOf(d.id) >= 0) setTimeout(function () { introLoad(d); }, 1000);
  }).catch(function (e) { if ($("introState")) $("introState").textContent = e.message; });
}
function introDraw(d, r) {
  var c = r.counts, j = r.job || {}, mine = j.show === d.id, waiting = (j.queuedShows || []).indexOf(d.id) >= 0;
  var running = mine && j.state === "running";
  var line = "";
  if (!r.ffmpeg) {
    line = '<div class="note">This needs ffmpeg: <a href="#/settings">Settings → Player → Download ffmpeg</a>.</div>';
  } else if (running) {
    line = "<b>Looking …</b> " + esc(j.phase || "") + (j.total ? " · " + j.done + " of " + j.total : "") +
      '<div class="meter" style="margin-top:8px"><i style="width:' + (j.total ? Math.round(100 * j.done / j.total) : 3) + '%"></i></div>';
  } else if (waiting) {
    line = "Waiting: AniBox is looking at another show first.";
  } else if (!c.checked) {
    line = "Not looked for yet. AniBox compares the sound of the episodes, like Plex does: it reads only the first 6 and the last 5 minutes of each file and changes nothing in your folders. " +
      (c.chapters ? "" : "Episodes with chapters called Opening or Ending don't need this.");
  } else {
    line = "Opening found in <b>" + c.opening + "</b> and ending in <b>" + c.ending + "</b> of " + plural(c.total, "episode") + "." +
      (c.checked < c.total ? " " + (c.total - c.checked) + " not looked at yet." : "") +
      (r.off ? '<div class="note">Turned off for this show: the Skip button only uses chapters in the files.</div>' : "");
  }
  if (mine && j.state === "error") line += '<div class="note">' + esc(j.message || "") + "</div>";
  if (mine && j.state === "cancelled") line += '<p class="muted" style="margin:6px 0 0">Cancelled. What was finished is kept.</p>';
  if (!running && j.busy && !waiting) line += '<p class="muted" style="margin:6px 0 0">Busy with ' + esc(j.busyTitle || "another show") + " right now.</p>";
  $("introState").innerHTML = line;
  $("introState").classList.toggle("muted", !c.checked && !running);
  var all = c.checked >= c.total && c.total > 0;
  $("introFind").textContent = all ? "Look again" : "Find opening and ending";
  $("introFind").title = all ? "Compare every episode again (your own corrections stay)" : "Compare the episodes that weren't looked at yet";
  $("introFind").disabled = running || waiting || !r.ffmpeg;
  $("introFind").onclick = function () {
    post("/api/intro/find", { show: d.id, again: all }).then(function () { introLoad(d); }).catch(fail);
  };
  $("introCancel").hidden = !(running || waiting);
  $("introCancel").onclick = function () { post("/api/intro/cancel").then(function () { introLoad(d); }).catch(fail); };
  var found = c.opening + c.ending > 0;
  $("introOff").hidden = !found && !r.off;
  $("introOff").textContent = r.off ? "Turn on again" : "Turn off for this show";
  $("introOff").title = r.off ? "Use what AniBox found for the Skip button again" : "The Skip button then only uses chapters in the files";
  $("introOff").onclick = function () {
    post("/api/intro/off", { show: d.id, off: !r.off }).then(function () { toast(r.off ? "Turned on." : "Turned off."); introLoad(d); }).catch(fail);
  };
  var rows = r.episodes.filter(function (e) { return e.checked || e.opening || e.ending; });
  if (!rows.length) { $("introList").innerHTML = ""; return; }
  var table = '<div class="tw" style="max-height:44vh;overflow:auto;margin-top:12px"><table><thead><tr><th>Episode</th><th>Opening</th><th>Ending</th><th></th></tr></thead><tbody>' +
    r.episodes.map(function (e) {
      var note = !e.opening && !e.ending && INTRO_NOTES[e.note] ? '<div class="muted" style="font-size:12px">' + esc(INTRO_NOTES[e.note]) + "</div>" : "";
      return "<tr" + (r.off ? ' style="opacity:.55"' : "") + "><td>" + esc(e.label) + '<div class="muted" style="font-size:12px">' + esc(e.file) + "</div>" + note + "</td>" +
        "<td>" + (e.checked || e.opening ? introPart(e.opening, e.chapters.indexOf("opening") >= 0) : '<span class="muted">not looked at</span>') + "</td>" +
        "<td>" + (e.checked || e.ending ? introPart(e.ending, e.chapters.indexOf("ending") >= 0) : "") + "</td>" +
        '<td><button class="btn small" data-intro-edit="' + esc(e.key) + '">Edit</button></td></tr>';
    }).join("") + "</tbody></table></div>";
  $("introList").innerHTML = r.episodes.length > 12 ? '<details style="margin-top:10px"><summary class="muted" style="cursor:pointer">Every episode (' + r.episodes.length + ")</summary>" + table + "</details>" : table;
  $("introList").querySelectorAll("[data-intro-edit]").forEach(function (b) {
    b.onclick = function () {
      var key = b.getAttribute("data-intro-edit");
      introEdit(d, r.episodes.filter(function (e) { return e.key === key; })[0]);
    };
  });
}

// Correct one episode's times by hand (or say there's no opening/ending).
function introEdit(d, e) {
  if (!e) return;
  function val(p, k) { return p ? fmt(p[k]) : ""; }
  function row(kind, label, p) {
    return '<div class="field"><div class="lbl">' + label + '<small>Start and end, like 1:32</small></div><div class="row" style="margin:0">' +
      '<input class="input" id="ie_' + kind + '_s" value="' + esc(val(p, "start")) + '" placeholder="start" style="width:90px" aria-label="' + label + ' start">' +
      '<span class="muted">to</span><input class="input" id="ie_' + kind + '_e" value="' + esc(val(p, "end")) + '" placeholder="end" style="width:90px" aria-label="' + label + ' end">' +
      '<label class="check"><input type="checkbox" id="ie_' + kind + '_none"' + (p ? "" : " checked") + "> None</label></div></div>";
  }
  openModal('<div class="kicker">Skip opening and ending</div><h2>' + esc(e.label) + '</h2><p class="muted" style="margin-top:-6px">' + esc(e.file) +
    (e.duration ? " · " + fmt(e.duration) : "") + "</p>" + row("opening", "Opening", e.opening) + row("ending", "Ending", e.ending) +
    '<p class="muted" style="font-size:13px">Skipping goes to the end you type here. Chapters in the file still win over these times.</p>' +
    '<div class="row" style="margin-top:16px;justify-content:flex-end">' + (e.edited ? '<button class="btn" id="ieReset">Back to what AniBox found</button>' : "") +
    '<button class="btn" data-close>Cancel</button><button class="btn primary" id="ieSave">Save</button></div>');
  ["opening", "ending"].forEach(function (k) {
    function sync() { var none = $("ie_" + k + "_none").checked; $("ie_" + k + "_s").disabled = none; $("ie_" + k + "_e").disabled = none; }
    $("ie_" + k + "_none").onchange = sync; sync();
  });
  if ($("ieReset")) $("ieReset").onclick = function () {
    post("/api/intro/edit", { show: d.id, key: e.key, reset: true }).then(function () { closeModal(); toast("Back to what AniBox found."); introLoad(d); }).catch(fail);
  };
  $("ieSave").onclick = function () {
    var body = { show: d.id, key: e.key }, changed = false, bad = "";
    [["opening", e.opening], ["ending", e.ending]].forEach(function (x) {
      var k = x[0], old = x[1];
      if ($("ie_" + k + "_none").checked) { if (old) { body[k] = null; changed = true; } return; }
      var s = introSeconds($("ie_" + k + "_s").value), en = introSeconds($("ie_" + k + "_e").value);
      if (s == null || en == null || isNaN(s) || isNaN(en)) { bad = "Type the " + k + "'s start and end like 1:32."; return; }
      if (!old || Math.abs(old.start - s) >= 1 || Math.abs(old.end - en) >= 1) { body[k] = { start: s, end: en }; changed = true; }
    });
    if (bad) { toast(bad, true); return; }
    if (!changed) { closeModal(); return; }
    post("/api/intro/edit", body).then(function () { closeModal(); toast("Saved"); introLoad(d); }).catch(fail);
  };
}

// ---------- Settings
settingsPanels.push(function (box) {
  if (box.previousElementSibling) box.style.marginTop = "18px";
  var s = (typeof settingsData !== "undefined" && settingsData && settingsData.settings) || {};
  box.innerHTML = '<section class="panel"><h2>Openings and endings without chapters</h2>' +
    '<p class="muted">Many files have no chapters, so the Skip button has nothing to go by. AniBox can find the opening and ending by comparing the sound of a show\'s episodes, like Plex does. ' +
    "It reads only the first 6 and the last 5 minutes of each file, one show at a time, and changes nothing in your folders. What it finds is kept in AniBox's data folder; chapters in a file always win. Each show's page shows the times and lets you correct them.</p>" +
    field("Find openings when a show is opened", "Looks at that show's episodes without chapters that weren't looked at yet, in the background. Never while the show is playing. Needs ffmpeg.", sw("intro_auto", !!s.intro_auto)) +
    '<div class="field"><div class="lbl">Check every show<small>Every show of the libraries you show, one at a time, with a short pause between files. On the Shield\'s drives this takes a while; you can keep using AniBox and cancel any time.</small></div>' +
    '<div class="row" style="margin:0"><button class="btn small" id="introAll">Check every show</button><button class="btn small" id="introAllStop" hidden>Cancel</button></div></div>' +
    '<div id="introAllInfo" class="muted"></div></section>';
  $("introAll").onclick = function () { post("/api/intro/all").then(introAllStatus).catch(fail); };
  $("introAllStop").onclick = function () { post("/api/intro/cancel").then(introAllStatus).catch(fail); };
  introAllStatus();
});
function introAllStatus() {
  api("/api/intro/job").then(function (j) {
    if (currentPage !== "settings" || !$("introAllInfo")) return;
    var b = j.batch || {}, run = b.state === "running";
    $("introAllInfo").innerHTML = run ? "Checking … " + b.done + " of " + plural(b.total, "show") + (j.title ? " · now " + esc(j.title) + (j.phase ? ": " + esc(j.phase) : "") : "") :
      b.state === "done" ? "Checked " + plural(b.total, "show") + ": openings or endings found in " + b.found + "." + (b.skipped ? " " + b.skipped + " skipped because they were playing." : "") :
      b.state === "cancelled" ? "Cancelled after " + b.done + " of " + plural(b.total, "show") + ". What was finished is kept." : "";
    $("introAll").disabled = run;
    $("introAllStop").hidden = !run;
    if (run) setTimeout(introAllStatus, 1500);
  }).catch(function () {});
}
