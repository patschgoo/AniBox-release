// Watch again / start again from here (rewatch.py), on show pages and series playlists.
// rewatchDialog({show, key, label, title, done}) — done() redraws the page afterwards.
function rewatchDialog(o) {
  var ia = String(o.key || "").indexOf("ia:") === 0;
  var canKeep = ia && typeof iaCacheDecorate === "function";
  openModal('<div class="kicker">Watch again</div><h2>' + esc(o.label) + '</h2><p class="muted">' + esc(o.title || "") + "</p>" +
    '<div class="rw-opts">' +
    '<button class="rw-opt" id="rwOnce"><b>▶ Just this episode</b><span>Plays it once. Afterwards nothing starts by itself, and Continue stays where you were.</span></button>' +
    (canKeep ? '<button class="rw-opt" id="rwKeep"><b>▶ Just this episode, and keep it</b><span>The same, and it stays on this PC in your Keep folder.</span></button>' : "") +
    '<button class="rw-opt warn" id="rwRestart"><b>↺ Start again from here</b><span>This episode and every later one count as not watched again; the ones before stay watched. Continue then starts here. You can undo it.</span></button>' +
    '</div><div class="row" style="margin-top:14px;justify-content:flex-end"><button class="btn" data-close>Cancel</button></div>');
  $("rwOnce").onclick = function () { closeModal(); play({ show: o.show, key: o.key, once: true, fromStart: true }); };
  if (canKeep) $("rwKeep").onclick = function () {
    closeModal();
    post("/api/iacache/keep", { key: o.key, keep: true, title: o.title || "" }).catch(fail);
    play({ show: o.show, key: o.key, once: true, fromStart: true });
  };
  $("rwRestart").onclick = function () {
    openModal('<div class="kicker">Start again</div><h2>Start ' + esc(o.title || "this") + " again from " + esc(o.label) + "?</h2>" +
      "<p>" + esc(o.label) + " and every episode after it count as not watched again, and their resume points go. The episodes before it stay watched. Continue starts at " + esc(o.label) + ".</p>" +
      '<p class="muted">Your MyAnimeList/AniList lists don\'t change (AniBox never lowers progress there). Undo: right after this, or later on the History page.</p>' +
      '<div class="row" style="margin-top:16px;justify-content:flex-end"><button class="btn" data-close>Cancel</button><button class="btn warn" id="rwYes">Start again from here</button></div>');
    $("rwYes").onclick = function () {
      closeModal();
      post("/api/rewatch/restart", { show: o.show, key: o.key }).then(function (r) {
        rewatchUndoBar("Started again from " + r.from + (r.reset ? " · " + plural(r.reset, "episode") + " not watched again" : "") + ".", r.id, o.done);
        if (o.done) o.done();
      }).catch(fail);
    };
  };
}

// A small bar with "Undo" for 30 seconds (later: the History page).
function rewatchUndoBar(text, id, done) {
  var bar = $("rwBar");
  if (!bar) { bar = document.createElement("div"); bar.id = "rwBar"; bar.className = "rw-bar"; document.body.appendChild(bar); }
  bar.innerHTML = "<span>" + esc(text) + '</span><button class="btn small" id="rwUndo">Undo</button>';
  bar.hidden = false;
  clearTimeout(rewatchUndoBar.h);
  rewatchUndoBar.h = setTimeout(function () { bar.hidden = true; }, 30000);
  $("rwUndo").onclick = function () {
    bar.hidden = true;
    post("/api/rewatch/undo", { id: id }).then(function (r) {
      toast("Put back as it was" + (r.kept ? " (" + plural(r.kept, "episode") + " you played since kept their progress)" : "") + ".");
      if (done) done();
    }).catch(fail);
  };
}

// The small "Watch again" button in an episode row (only on watched ones).
function rewatchButton() {
  return ' <button type="button" class="again" data-again title="Watch it again, or start again from here">Watch again</button>';
}
