/* AniBox window · The player inside the window (Windows): mpv draws into a small window of AniBox's
   own that sits exactly over #dockVideo (see embed.py). This file finds the AniBox window once,
   switches the views and tells AniBox whenever the video area moves.
   Views: big (the page area), mini (a corner, keep browsing), fill (the whole window), full (screen).
   HTML can't be drawn on top of the video, so the video is hidden while a dialog is open.
   Plain scripts sharing one page: loaded in order by index.html. */
"use strict";

var dock = { mode: "", tried: false, attached: false, lastEvent: null, sent: "", wantBig: false };

// ---------- find the AniBox window (once per page load)
function embedAttach(force) {
  if (!state || !state.embed || !state.embed.available || !state.embed.enabled) return;
  if (dock.tried && !force) return;
  dock.tried = true;
  var marker = "AniBox " + Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
  var title = document.title;
  document.title = marker;  // AniBox looks for the window with exactly this title
  post("/api/embed/attach", { marker: marker }).then(function (r) { dock.attached = !!r.ok; })
    .catch(function () { dock.attached = false; })
    .then(function () { document.title = title; });
}

// ---------- views
function dockSetMode(m) {
  var prev = dock.mode;
  if (m === "full" && !document.fullscreenElement) {
    document.documentElement.requestFullscreen().catch(function () { dockSetMode("fill"); });
  } else if (m !== "full" && document.fullscreenElement) {
    document.exitFullscreen().catch(function () {});
  }
  dock.mode = m;
  ["big", "mini", "fill", "full"].forEach(function (x) { document.body.classList.toggle("dock-" + x, x === m); });
  document.body.classList.toggle("dock-on", !!m);
  $("dock").hidden = !m;
  if (prev !== m) dockMeasure();
  dockSync();
}
function dockOpen() {
  dock.lastEvent = state.player.uiEvent ? state.player.uiEvent.n : 0;
  $("dockSlot").appendChild($("bSkip"));  // "Skip opening" can't float over the video; it goes in the head
  dockSetMode(state.embed && state.embed.startFull ? "full" : "big");
}
function dockClose() {
  if (document.fullscreenElement) document.exitFullscreen().catch(function () {});
  document.body.appendChild($("bSkip"));
  dock.mode = "";
  ["big", "mini", "fill", "full", "on"].forEach(function (x) { document.body.classList.remove("dock-" + x); });
  $("dock").hidden = true;
  dock.sent = "";
}
function dockAct(kind) {  // f / double-click / Esc pressed inside the video
  if (kind === "zoom") dockSetMode(dock.mode === "fill" || dock.mode === "full" ? "big" : "fill");
  else if (kind === "esc" && (dock.mode === "fill" || dock.mode === "full")) dockSetMode("big");
}

// Called after every /api/state poll (bar.js).
function dockUpdate() {
  if (!state) return;
  embedAttach(false);
  var p = state.player;
  var on = !!(p && p.active && p.embedded);
  if (!on) { if (dock.mode) dockClose(); return; }
  if (!dock.mode) dockOpen();
  else if (dock.wantBig && dock.mode === "mini") dockSetMode("big");
  dock.wantBig = false;
  $("dockTitle").textContent = p.title + (p.sub ? " · " + p.sub : "");
  if (p.uiEvent && p.uiEvent.n !== dock.lastEvent) {
    if (dock.lastEvent !== null) dockAct(p.uiEvent.kind);
    dock.lastEvent = p.uiEvent.n;
  }
  dockSync();
}

// ---------- tell AniBox where the video area is
function overlayOpen() {
  return !$("modal").hidden || !$("trackPop").hidden || !$("still").hidden;
}
function dockMeasure() {
  var bar = $("bar"), top = document.querySelector(".top");
  document.documentElement.style.setProperty("--barh", (bar && !bar.hidden ? Math.ceil(window.innerHeight - bar.getBoundingClientRect().top) : 0) + "px");
  document.documentElement.style.setProperty("--toph", (top ? Math.ceil(top.getBoundingClientRect().height) : 0) + "px");
}
function dockSync() {
  if (!dock.mode) return;
  var r = $("dockVideo").getBoundingClientRect();
  var hidden = overlayOpen();
  $("dockPh").textContent = hidden ? "The video is hidden while this is open." : "Starting the video …";
  var msg = { x: r.left, y: r.top, w: r.width, h: r.height, dpr: window.devicePixelRatio || 1,
              iw: window.innerWidth, ih: window.innerHeight, visible: !hidden && r.width > 20 && r.height > 20 };
  var key = JSON.stringify(msg);
  if (key === dock.sent && Date.now() - (dock.sentAt || 0) < 3000) return;  // again now and then: Edge may stack its own parts on top
  dock.sent = key;
  dock.sentAt = Date.now();
  post("/api/embed/place", msg).catch(function () {});
}
function dockHide() {  // e.g. the window is being closed
  if (dock.mode) post("/api/embed/place", { visible: false }).catch(function () {});
}

window.addEventListener("resize", function () { dockMeasure(); dockSync(); });
document.addEventListener("fullscreenchange", function () {
  if (!document.fullscreenElement && dock.mode === "full") dockSetMode("big");
  setTimeout(function () { dockMeasure(); dockSync(); }, 50);
});
window.addEventListener("hashchange", function () { if (dock.mode === "big" || dock.mode === "fill") dockSetMode("mini"); });
if (window.ResizeObserver) new ResizeObserver(function () { dockSync(); }).observe($("dockVideo"));
["modal", "trackPop", "still"].forEach(function (id) {
  new MutationObserver(function () { dockSync(); }).observe($(id), { attributes: true, attributeFilter: ["hidden"] });
});
window.addEventListener("pagehide", dockHide);

$("dMini").onclick = function () { dockSetMode("mini"); };
$("dBig").onclick = function () { dockSetMode("big"); };
$("dFill").onclick = function () { dockSetMode(dock.mode === "fill" ? "big" : "fill"); };
$("dFull").onclick = function () { dockSetMode(dock.mode === "full" ? "big" : "full"); };
$("dClose").onclick = function () { cmd("stop"); };

// Keys while the page (not the video) has the focus. Inside the video, mpv's own keys work.
document.addEventListener("keydown", function (e) {
  if (!dock.mode || e.target.matches("input, textarea, select") || e.ctrlKey || e.altKey || e.metaKey) return;
  if (e.key === "f" || e.key === "F") { e.preventDefault(); dockSetMode(dock.mode === "full" ? "big" : "full"); }
  else if (e.key === "Escape" && (dock.mode === "fill" || dock.mode === "full")) { e.preventDefault(); dockSetMode("big"); }
  else if (e.key === "ArrowLeft") { e.preventDefault(); cmd("seek-rel", -10); }
  else if (e.key === "ArrowRight") { e.preventDefault(); cmd("seek-rel", 10); }
});
