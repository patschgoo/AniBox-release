/* AniBox window · ffmpeg, "Plays on the TV?", TV-friendly subtitles and finding subtitles online
   (routes_media.py). Plain scripts sharing one page: loaded in order by index.html. */
"use strict";

var MEDIA_PILL = { ok: ["owned", "Plays directly"], subs: ["partial", "Plays · subtitles"], sound: ["partial", "Plays · sound"], slow: ["partial", "May stutter"], convert: ["missing", "Needs converting"], unknown: ["", "Can't tell"] };
var SUB_COUNTS = [["skip-exists", "already there (kept as they are)"], ["skip-plain", "not needed: plain subtitles in that language are there"],
  ["skip-duplicate", "not needed: another subtitle of that language is used"], ["skip-image", "picture subtitles (PGS/VobSub): can't become text"],
  ["skip-no-ffmpeg", "need ffmpeg (Settings → Player → Download ffmpeg)"], ["skip-locked", "episodes locked (were already there)"],
  ["skip-protected", "episodes in a protected folder"], ["skip-unreadable", "episodes AniBox couldn't read"]];

function mediaHere(id) { return showData && showData.id === id && currentPage === "show"; }

// ---------- Settings: ffmpeg (in the Player section), subtitle sites, checking every show
settingsPanels.push(function (box) {
  if (box.previousElementSibling) box.style.marginTop = "18px";
  box.innerHTML = '<section class="panel"><h2>Subtitles online and the TV check</h2>' +
    '<p class="muted">On a show\'s page, <b>Find subtitles online</b> searches two free sites. Each needs your own free key; without one nothing is sent anywhere. ' +
    "The keys stay on this PC (encrypted for your Windows user) and are only sent to their site.</p>" +
    '<div class="field"><div class="lbl">Jimaku API key<small>Japanese subtitles for anime. Sign up on <a href="https://jimaku.cc" target="_blank" rel="noopener noreferrer">jimaku.cc ↗</a>, open your account page and create an API key.</small></div>' +
    '<input class="input" type="password" id="jkKey" autocomplete="off" spellcheck="false"></div>' +
    '<div class="field"><div class="lbl">OpenSubtitles API key<small>Many languages. Sign up on <a href="https://www.opensubtitles.com" target="_blank" rel="noopener noreferrer">opensubtitles.com ↗</a>, open <a href="https://www.opensubtitles.com/consumers" target="_blank" rel="noopener noreferrer">opensubtitles.com/consumers ↗</a>, add a new consumer (any name, e.g. AniBox) and copy its API key. Searching needs only the key.</small></div>' +
    '<input class="input" type="password" id="osKey" autocomplete="off" spellcheck="false"></div>' +
    '<div class="field"><div class="lbl">OpenSubtitles username and password<small>Needed for downloads (free accounts get a few downloads a day).</small></div>' +
    '<input class="input" id="osUser" autocomplete="off" spellcheck="false" placeholder="Username" style="width:150px"><input class="input" type="password" id="osPass" autocomplete="off" placeholder="Password" style="width:150px"></div>' +
    '<div class="row"><button class="btn small primary" id="subKeysSave">Save keys</button><button class="btn small" id="subKeysClear">Remove saved keys</button><span class="muted" id="subKeysInfo"></span></div>' +
    '<div class="field" style="margin-top:12px"><div class="lbl">Check every show for the TV<small>Reads the first and a middle episode of every show (only their start, nothing is changed) and says whether Plex on the Shield or CastApp TV can play them directly. Then Library → “May need converting” lists the shows that can\'t. Without ffmpeg the check is less exact.</small></div>' +
    '<button class="btn small" id="checkAll">Check every show</button></div><div id="checkAllInfo" class="muted"></div></section>';
  var slot = document.createElement("div"); slot.id = "ffmpegBox";
  var mpv = $("mpvBox");
  if (mpv && mpv.parentNode) mpv.parentNode.insertBefore(slot, mpv.nextSibling); else box.querySelector("section").appendChild(slot);
  $("subKeysSave").onclick = function () {
    var b = {};
    [["jkKey", "jimaku_key"], ["osKey", "opensubtitles_key"], ["osUser", "opensubtitles_user"], ["osPass", "opensubtitles_password"]].forEach(function (f) {
      var v = $(f[0]).value.trim(); if (v !== "") b[f[1]] = v;
    });
    post("/api/media/accounts", b).then(function (r) { toast("Saved"); mediaAccounts(r.accounts); ["jkKey", "osKey", "osPass"].forEach(function (id) { $(id).value = ""; }); }).catch(fail);
  };
  $("subKeysClear").onclick = function () {
    if (!confirm("Remove the saved Jimaku and OpenSubtitles keys and the OpenSubtitles sign-in from this PC?")) return;
    post("/api/media/accounts", { jimaku_key: "", opensubtitles_key: "", opensubtitles_user: "", opensubtitles_password: "" })
      .then(function (r) { toast("Removed"); $("osUser").value = ""; mediaAccounts(r.accounts); }).catch(fail);
  };
  $("checkAll").onclick = function () { post("/api/media/check/all").then(function () { mediaStatus(); }).catch(fail); };
  mediaStatus();
});
function mediaAccounts(a) {
  if (!$("subKeysInfo")) return;
  var have = [a.jimaku ? "Jimaku key saved" : "", a.opensubtitles ? "OpenSubtitles key saved" : "", a.opensubtitlesLogin ? "OpenSubtitles account " + a.opensubtitlesUser : ""].filter(Boolean);
  $("subKeysInfo").textContent = have.length ? have.join(" · ") + ". Leave a box empty to keep what's saved." : "No keys saved yet.";
  $("jkKey").placeholder = a.jimaku ? "saved · type to replace" : "Paste the key";
  $("osKey").placeholder = a.opensubtitles ? "saved · type to replace" : "Paste the key";
  if (a.opensubtitlesUser && !$("osUser").value) $("osUser").value = a.opensubtitlesUser;
  $("osPass").placeholder = a.opensubtitlesLogin ? "saved" : "Password";
}
function mediaStatus() {
  api("/api/media/status").then(function (st) {
    if (currentPage !== "settings") return;
    mediaAccounts(st.accounts);
    drawFfmpeg(st);
    var j = st.checkAll || {};
    if ($("checkAllInfo")) $("checkAllInfo").textContent = j.state === "running" ? "Checking … " + j.done + " of " + j.total + " shows" :
      j.state === "done" ? "Checked " + j.total + " shows: " + j.convert + " may need converting." : j.state === "error" ? j.message || "" : "";
    if ($("checkAll")) $("checkAll").disabled = j.state === "running";
    if ((st.setup && st.setup.state === "running") || j.state === "running") setTimeout(mediaStatus, 1000);
  }).catch(function () {});
}
function drawFfmpeg(st) {
  var box = $("ffmpegBox"); if (!box) return;
  var s = st.setup || {};
  var pathField = '<div class="field"><div class="lbl">ffmpeg folder<small>Leave empty to use the one AniBox downloads (or one that\'s installed).</small></div><input class="input wide" id="ffPath" value="' + esc((settingsData && settingsData.settings.ffmpeg_path) || "") + '" placeholder="C:\\…\\ffmpeg\\bin"></div>';
  if (s.state === "running") {
    var pct = s.total ? Math.round(100 * s.received / s.total) : 0;
    box.innerHTML = '<div class="field"><div class="lbl">Downloading ffmpeg …<small>' + pct + "% of " + Math.round(s.total / 1048576) + ' MB</small><div class="meter"><i style="width:' + pct + '%"></i></div></div></div>';
    return;
  }
  if (st.ffmpeg && st.ffprobe) {
    box.innerHTML = '<div class="field"><div class="lbl">ffmpeg is ready<small>' + esc(st.ffmpeg) + "</small></div></div>" + pathField;
  } else {
    box.innerHTML = '<div class="field"><div class="lbl">ffmpeg isn\'t installed yet<small>' + (s.state === "error" ? esc(s.message) + " " : "") +
      "Needed for “Make TV-friendly subtitles” (subtitles inside MKV files) and an exact “Plays on the TV?” check. " +
      (st.canDownload ? "One-time download, about 114 MB, checked against a fixed checksum." : "Install ffmpeg with your package manager.") + "</small></div>" +
      (st.canDownload ? '<button class="btn primary" id="getFfmpeg">Download ffmpeg</button>' : "") + "</div>" + pathField;
    if ($("getFfmpeg")) $("getFfmpeg").onclick = function () { post("/api/media/ffmpeg/install").then(function () { setTimeout(mediaStatus, 300); }).catch(fail); };
  }
  $("ffPath").onchange = function () { save("ffmpeg_path", this.value.trim()).then(mediaStatus).catch(function () {}); };
}

// ---------- Show page: "Plays on the TV?" and the subtitle buttons
var showPanels = showPanels || [];
showPanels.push(function (box, d) {
  box.innerHTML = '<section class="panel" style="margin-top:22px"><div class="kicker">On the TV</div>' +
    '<div class="section" style="margin:6px 0 10px"><h3 style="margin:0">Plays on the TV?</h3><button class="btn small" id="tvRecheck">Check again</button></div>' +
    '<div id="tvCheck" class="muted">Reading the first and a middle episode …</div>' +
    '<h3 style="margin:20px 0 6px">Subtitles</h3><p class="muted" style="margin:0 0 10px">Plex on the Shield and many TVs can\'t show styled subtitles (ASS) or picture subtitles. A plain <code>.srt</code> file next to the episode works almost everywhere.</p>' +
    '<div class="row"><button class="btn small" id="tvSubs">Make TV-friendly subtitles</button><button class="btn small" id="findSubs">Find subtitles online</button>' +
    '<button class="btn small" id="undoSubs" hidden>Undo added subtitles</button></div></section>';
  $("tvRecheck").onclick = function () { $("tvCheck").textContent = "Checking …"; post("/api/media/check", { show: d.id, refresh: true }).then(function () { setTimeout(function () { tvCheck(d); }, 400); }).catch(fail); };
  $("tvSubs").onclick = function () { tvSubsDialog(d); };
  $("findSubs").onclick = function () { findSubsDialog(d); };
  $("undoSubs").onclick = function () { undoSubs(d); };
  tvCheck(d);
  subsAdded(d);
});
function tvCheck(d) {
  api("/api/media/check?id=" + encodeURIComponent(d.id)).then(function (r) {
    if (!mediaHere(d.id) || !$("tvCheck")) return;
    if (r.state === "loading" && !r.targets) { setTimeout(function () { tvCheck(d); }, 1200); return; }
    if (r.state === "error") { $("tvCheck").innerHTML = '<div class="note">' + esc(r.error) + "</div>"; return; }
    $("tvCheck").classList.remove("muted");
    $("tvCheck").innerHTML = (r.targets || []).map(function (t) {
      var p = MEDIA_PILL[t.level] || MEDIA_PILL.unknown;
      var why = t.reasons.filter(function (x) { return x.level !== "ok" || x.probably; });
      var notes = [];
      if (t.target === "castapp" && !t.device) notes.push("No CastApp TV found yet (Play on TV → Search again finds it), so this uses AniBox's own table for the Shield.");
      else if (t.target === "castapp" && !t.capsKnown) notes.push("CastApp TV didn't say what it plays, so this uses AniBox's own table for the Shield.");
      return '<div style="padding:8px 0;border-top:1px solid var(--line)"><span class="pill ' + p[0] + '">' + esc(p[1]) + "</span> <b>" + esc(t.name) + "</b> · " + esc(t.summary) +
        (t.probably ? ' <span class="muted">(probably: from how the players work, not yet tried on your Shield)</span>' : "") +
        (why.length || t.files.length ? '<details style="margin-top:6px"><summary class="muted" style="cursor:pointer">Why, and what\'s inside</summary>' +
          (why.length ? '<ul style="margin:8px 0">' + why.map(function (x) { return "<li>" + esc(x.text) + (x.probably ? ' <span class="muted">(probably)</span>' : "") + "</li>"; }).join("") + "</ul>" : "") +
          '<div class="tw"><table><tbody>' + t.files.map(function (f) {
            return "<tr><td>" + esc(f.file) + (f.tvCopy ? ' <span class="pill owned">TV copy ready</span>' : "") + '</td><td class="muted">' + esc([f.video].concat(f.audio, f.subs).filter(Boolean).join(" · ")) + "</td></tr>";
          }).join("") + "</tbody></table></div>" + notes.map(function (n) { return '<p class="muted" style="margin:6px 0 0">' + esc(n) + "</p>"; }).join("") + "</details>" : "") + "</div>";
    }).join("") + (r.ffprobe ? "" : '<p class="muted" style="margin:8px 0 0">Without ffmpeg AniBox reads only the start of MKV and MP4 files. <a href="#/settings">Download ffmpeg</a> (Settings → Player) for an exact check.</p>') +
      (r.state === "loading" ? '<p class="muted">Checking again …</p>' : "");
    if (typeof tvCopyCheck === "function" && r.state !== "loading") tvCopyCheck(d, r);  // "Make TV copies …" (tvcopy.js)
    if (r.state === "loading") setTimeout(function () { tvCheck(d); }, 1200);
  }).catch(function (e) { if ($("tvCheck")) $("tvCheck").textContent = e.message; });
}
function subsAdded(d) {
  api("/api/media/subs/preview?id=" + encodeURIComponent(d.id)).then(function (r) {
    if (!mediaHere(d.id) || !$("undoSubs")) return;
    $("undoSubs").hidden = !r.added;
    $("undoSubs").textContent = "Undo added subtitles (" + r.added + ")";
  }).catch(function () {});
}
function undoSubs(d) {
  if (!confirm("Remove the subtitle files AniBox added for " + d.title + "? Files you changed since are kept.")) return;
  post("/api/media/subs/undo", { show: d.id }).then(function (r) {
    toast(r.removed + " removed" + (r.kept ? ", " + r.kept + " kept because they changed" : "") + ".");
    subsAdded(d); tvCheck(d);
  }).catch(fail);
}

// "Make TV-friendly subtitles": preview first, then write, then Undo.
function tvSubsDialog(d) {
  openModal('<div class="kicker">Subtitles for the TV</div><h2>Make TV-friendly subtitles</h2>' +
    '<p class="muted">Plex on the Shield and many TVs can\'t show styled subtitles (ASS/SSA, the usual fansub format): Plex then converts the whole video to burn them in, which is slow on the Shield, or shows them without styling. ' +
    "AniBox can add a plain <code>.srt</code> file next to each episode (for example <code>Show 01.de.srt</code>), which Plex and almost every TV show as they are. " +
    "The <code>.srt</code> keeps the text but loses colours, fonts and positions: signs and notes on the screen appear as normal lines at the bottom.</p>" +
    '<p class="muted">Picture subtitles (PGS from Blu-rays, VobSub from DVDs) can\'t become text without letter recognition (OCR), so AniBox offers nothing for them. ' +
    "Only episodes that aren't locked get files. AniBox never replaces a file, and Undo removes exactly the files it added.</p>" +
    '<div id="tsBody" class="muted">Looking at the episodes …</div>' +
    '<div class="row" style="margin-top:16px;justify-content:flex-end"><button class="btn" data-close>Close</button><button class="btn primary" id="tsGo" disabled>Add files</button></div>');
  var token = "";
  post("/api/media/subs/preview", { show: d.id }).then(function wait() {
    api("/api/media/subs/preview?id=" + encodeURIComponent(d.id)).then(function (r) {
      if (!$("tsBody")) return;
      if (r.state === "loading") { $("tsBody").textContent = "Looking at the episodes … " + r.done + " of " + r.total; setTimeout(wait, 700); return; }
      if (r.state === "error") { $("tsBody").innerHTML = '<div class="note">' + esc(r.error) + "</div>"; return; }
      token = r.token;
      var c = r.counts || {};
      var lines = SUB_COUNTS.filter(function (x) { return c[x[0]]; }).map(function (x) { return "<li><b>" + c[x[0]] + "</b> " + esc(x[1]) + "</li>"; });
      var list = (r.items || []).filter(function (it) { return it.action === "new" || it.action === "skip-exists" || it.action === "skip-image" || it.action === "skip-no-ffmpeg"; }).slice(0, 300);
      $("tsBody").classList.remove("muted");
      $("tsBody").innerHTML = (r.new ? "<p><b>" + plural(r.new, "file") + " would be added.</b></p>" :
        "<p><b>Nothing to add.</b> " + (c["skip-locked"] && !(r.items || []).length ? "All episodes of this show were already there and are locked. Unlock the show first if you want subtitle files for them." :
          "No episode has styled subtitles that need a plain copy.") + "</p>") +
        (lines.length ? '<ul style="margin:6px 0 10px">' + lines.join("") + "</ul>" : "") +
        (c["skip-no-ffmpeg"] ? '<div class="note">Subtitles inside the video files need ffmpeg to be taken out. <a href="#/settings">Download ffmpeg</a> under Settings → Player, then try again.</div>' : "") +
        (list.length ? '<div class="tw" style="max-height:34vh;overflow:auto"><table><tbody>' + list.map(function (it) {
          return "<tr><td>" + esc(it.file) + '</td><td class="muted">' + esc(it.label || "") + "</td><td>" + (it.action === "new" ? "→ " + esc(it.name) : '<span class="muted">' + esc(it.reason || "") + "</span>") + "</td></tr>";
        }).join("") + "</tbody></table></div>" : "");
      $("tsGo").disabled = !r.new;
      $("tsGo").textContent = r.new ? "Add " + plural(r.new, "file") : "Add files";
    }).catch(fail);
  }).catch(fail);
  $("tsGo").onclick = function () {
    $("tsGo").disabled = true;
    post("/api/media/subs/write", { show: d.id, token: token }).then(function () {
      (function wait() {
        api("/api/media/subs/job").then(function (j) {
          if (!$("tsBody")) return;
          if (j.state === "running") { $("tsBody").innerHTML = "<p>Making subtitles … " + j.done + " of " + j.total + "</p><p class=\"muted\">Taking a subtitle out of a video reads the whole file, so this takes a moment per episode on the Shield's drives.</p>"; setTimeout(wait, 800); return; }
          var errs = j.errors || [];
          $("tsBody").innerHTML = j.state === "error" ? '<div class="note">' + esc(j.message || "") + "</div>" :
            "<p><b>" + plural(j.written || 0, "file") + " added.</b> " + (j.written ? "Plex picks them up with its next scan of the library. <b>Undo added subtitles</b> on the show page removes them again." : "") + "</p>" +
            (errs.length ? '<div class="note">' + errs.slice(0, 20).map(function (e) { return esc((e.path || "").split(/[\\/]/).pop() + ": " + e.error); }).join("<br>") + "</div>" : "");
          $("tsGo").hidden = true;
          subsAdded(d); tvCheck(d);
        }).catch(fail);
      })();
    }).catch(function (e) { $("tsGo").disabled = false; fail(e); });
  };
}

// "Find subtitles online": Jimaku or OpenSubtitles, per episode.
function findSubsDialog(d) {
  var eps = d.episodes || [];
  var first = eps.filter(function (e) { return !e.locked; })[0] || eps[0];
  openModal('<div class="kicker">Subtitles online</div><h2>Find subtitles</h2>' +
    '<div class="row"><select class="select" id="fsEp" style="max-width:360px">' + eps.map(function (e) {
      return '<option value="' + esc(e.key) + '"' + (first && e.key === first.key ? " selected" : "") + ">" + (e.locked ? "🔒 " : "") + esc(e.label + " · " + e.file) + "</option>";
    }).join("") + "</select>" +
    '<select class="select" id="fsProv"><option value="jimaku">Jimaku (Japanese, anime)</option><option value="opensubtitles">OpenSubtitles (many languages)</option></select></div>' +
    '<div class="row" style="margin-top:10px"><input class="input wide" id="fsQ" value="' + esc(d.title) + '" aria-label="Search for">' +
    '<input class="input" id="fsLang" placeholder="Languages, e.g. de,en" style="width:170px" title="OpenSubtitles only. Empty = your subtitle languages from Settings"><button class="btn primary" id="fsGo">Search</button></div>' +
    '<p class="muted" style="font-size:13px">Only the title (or the show\'s AniList/IMDb number), the episode number and, for OpenSubtitles, a short fingerprint of the video file are sent. The file is saved next to the video as <code>&lt;video name&gt;.&lt;language&gt;.srt</code> (or .ass); nothing is ever replaced, and Undo on the show page removes it again.</p>' +
    '<div id="fsOut"></div><div class="row" style="margin-top:16px;justify-content:flex-end"><button class="btn" data-close>Close</button></div>');
  var token = "";
  function locked() { var k = $("fsEp").value; return eps.some(function (e) { return e.key === k && e.locked; }); }
  $("fsProv").onchange = function () { $("fsLang").hidden = this.value !== "opensubtitles"; };
  $("fsProv").onchange.call($("fsProv"));
  $("fsGo").onclick = function () {
    $("fsOut").innerHTML = '<p class="muted">Searching …</p>';
    var q = "?show=" + encodeURIComponent(d.id) + "&key=" + encodeURIComponent($("fsEp").value) + "&provider=" + $("fsProv").value +
      "&q=" + encodeURIComponent($("fsQ").value.trim()) + "&langs=" + encodeURIComponent($("fsLang").value.trim());
    api("/api/media/subs/search" + q).then(function (r) {
      if (!$("fsOut")) return;
      if (!r.ok) {
        $("fsOut").innerHTML = '<div class="note">' + esc(r.error) + (r.reason === "no_key" || r.reason === "login" ? ' <a href="#/settings">Settings →</a>' : "") + "</div>";
        return;
      }
      token = r.token;
      var lock = r.locked || locked();
      $("fsOut").innerHTML = (lock ? '<div class="note">This episode was already there and is locked, so AniBox doesn\'t add files next to it. Unlock the show first (on its page).</div>' : "") +
        '<div class="tw" style="max-height:40vh;overflow:auto"><table><thead><tr><th>Language</th><th>Name</th><th>Format</th><th class="num">Downloads</th><th></th></tr></thead><tbody>' +
        r.results.map(function (x) {
          return "<tr><td>" + esc(x.lang || "?") + "</td><td>" + esc(x.release || x.name) + (x.hashMatch ? ' <span class="pill owned">fits this file</span>' : "") +
            (x.note ? '<div class="muted" style="font-size:12px">' + esc(x.note) + "</div>" : "") + "</td><td>" + esc(x.format) + '</td><td class="num">' + (x.downloads == null ? "" : x.downloads.toLocaleString()) +
            "</td><td>" + (x.downloadable && !lock ? '<button class="btn small" data-dl="' + x.id + '">Download</button>' : "") + "</td></tr>";
        }).join("") + "</tbody></table></div>";
    }).catch(function (e) { if ($("fsOut")) $("fsOut").innerHTML = '<div class="note">' + esc(e.message) + "</div>"; });
  };
  $("fsOut").addEventListener("click", function (e) {
    var b = e.target.closest("[data-dl]"); if (!b) return;
    b.disabled = true; b.textContent = "…";
    post("/api/media/subs/download", { token: token, id: Number(b.getAttribute("data-dl")) }).then(function (r) {
      b.textContent = "Saved"; toast("Saved " + r.file + " next to the video."); subsAdded(d);
    }).catch(function (err) { b.disabled = false; b.textContent = "Download"; fail(err); });
  });
  $("fsQ").addEventListener("keydown", function (e) { if (e.key === "Enter") $("fsGo").click(); });
}
