/* AniBox window · The now-playing bar, tracks, skip, "Still watching?", and polling AniBox's state.
   Plain scripts sharing one page: loaded in order by index.html. */
"use strict";

// ---------- now playing bar + state
function drawBar() {
  var p = state.player;
  $("bar").hidden = !p.active;
  document.body.style.paddingBottom = p.active ? "130px" : "";
  if (p.active) {
    $("barKicker").textContent = p.kicker; $("barTitle").textContent = p.title; $("barSub").textContent = p.sub;
    $("barArt").style.backgroundImage = p.art ? "url('" + p.art + "')" : p.malId ? "url('/img/" + encodeURIComponent(p.malId) + "')" : "";
    var seek = $("bSeek");
    seek.max = Math.max(1, Math.floor(p.dur));
    if (!drawBar.drag) { seek.value = Math.floor(p.pos); $("bPos").textContent = fmt(p.pos); }
    $("bDur").textContent = fmt(p.dur);
    $("bPlayIco").innerHTML = p.paused ? PLAY : PAUSE;
    $("bPlay").setAttribute("aria-label", p.paused ? "Play" : "Pause");
    $("bPrev").disabled = !p.hasPrev; $("bNext").disabled = !p.hasNext;
    if (!drawBar.vol) $("bVol").value = p.volume;
    $("bCount").hidden = p.stage !== "countdown";
    $("bCount").textContent = "Next episode in " + p.countdown + " s";
  }
  var sk = p.active && p.skip;
  $("bSkip").hidden = !sk;
  if (sk) $("bSkip").firstChild.textContent = "Skip " + p.skip.kind + " ";
  $("bTracks").hidden = !p.active || !(p.tracks.audio.length > 1 || p.tracks.sub.length);
  $("bTv").hidden = !p.active || p.target === "tv";  // Internet Archive streams can move to the TV too
  $("bVol").max = p.target === "tv" ? 100 : 130;
  if (!p.active) toggleTracks(false); else if (!$("trackPop").hidden) drawTracks();
  $("still").hidden = !(p.still && p.still.stage);
  $("stillNext").textContent = p.still && p.still.next ? "Next up: " + p.still.next : "";
  if (p.error && p.error !== drawBar.err) { toast(p.error, true); }
  drawBar.err = p.error;
}
function cmd(c, v) { return post("/api/cmd", { cmd: c, value: v }).then(poll).catch(fail); }
function drawTracks() {
  var t = state.player.tracks, html = "";
  if (t.audio.length) html += "<h3>Audio</h3>" + t.audio.map(function (a) { return '<button data-aud="' + a.id + '"' + (a.selected ? ' class="on"' : "") + "><span>" + esc(a.label) + "</span><small>" + esc(a.info) + "</small></button>"; }).join("");
  if (t.sub.length) html += "<h3>Subtitles</h3>" + '<button data-sub="no"' + (state.player.subOff ? ' class="on"' : "") + "><span>Off</span></button>" +
    t.sub.map(function (a) { return '<button data-sub="' + a.id + '"' + (a.selected ? ' class="on"' : "") + "><span>" + esc(a.label) + "</span><small>" + esc(a.info) + "</small></button>"; }).join("");
  html += '<div class="hint">AniBox remembers your choice for this show. In the player window: # switches audio, j subtitles, Shift+S skips an opening.</div>';
  $("trackPop").innerHTML = html;
}
function toggleTracks(open) {
  var pop = $("trackPop");
  if (open === undefined) open = pop.hidden;
  pop.hidden = !open; $("bTracks").setAttribute("aria-expanded", open ? "true" : "false");
  if (open) drawTracks();
}
$("bTracks").onclick = function () { toggleTracks(); };
$("trackPop").addEventListener("click", function (e) {
  var a = e.target.closest("[data-aud]"), sb = e.target.closest("[data-sub]");
  if (a) cmd("audio", Number(a.getAttribute("data-aud")));
  if (sb) cmd("sub", sb.getAttribute("data-sub") === "no" ? "no" : Number(sb.getAttribute("data-sub")));
});
$("bSkip").onclick = function () { cmd("skip"); };
$("bTv").onclick = function () { tvDialog({ move: true }); };
$("bPlay").onclick = function () { cmd("play-pause"); };
$("bPrev").onclick = function () { cmd("prev"); };
$("bNext").onclick = function () { cmd("next"); };
$("bStop").onclick = function () { cmd("stop"); };
document.querySelectorAll("#bar [data-rel]").forEach(function (b) { b.onclick = function () { cmd("seek-rel", Number(b.getAttribute("data-rel"))); }; });
$("bSeek").addEventListener("input", function () { drawBar.drag = true; $("bPos").textContent = fmt(this.value); });
$("bSeek").addEventListener("change", function () { cmd("seek-to", Number(this.value)); setTimeout(function () { drawBar.drag = false; }, 800); });
$("bVol").addEventListener("input", function () { drawBar.vol = true; });
$("bVol").addEventListener("change", function () { cmd("volume", Number(this.value)); setTimeout(function () { drawBar.vol = false; }, 800); });
$("stillGo").onclick = function () { cmd("still-continue"); };
$("stillStop").onclick = function () { cmd("still-stop"); };
document.body.addEventListener("click", function (e) {
  var b = e.target.closest("[data-play]"); if (b) play({ show: b.getAttribute("data-play") });
});

var lastKey = "";
function poll() {
  return api("/api/state").then(function (s) {
    var prevScan = lastScanState;
    state = s; lastScanState = s.scan.state;
    drawBar();
    dockUpdate();
    var pill = $("scanPill");
    pill.hidden = s.scan.state !== "running";
    if (s.scan.state === "running") pill.textContent = "Scanning · " + s.scan.found.toLocaleString() + " files";
    if (currentPage === "settings") { drawScan(); drawMpv(); }
    if (prevScan === "running" && s.scan.state === "done") { toast("Scan finished."); if (currentPage !== "settings") route(); else settings(); }
    if (prevScan === "running" && s.scan.state === "error") toast(s.scan.message, true);
    var key = s.player.active ? s.player.key : "";
    if (key !== lastKey) { lastKey = key; if (currentPage === "show" && showData) drawEps(); }
  }).catch(function () { $("scanPill").hidden = false; $("scanPill").textContent = "AniBox isn't running"; });
}
function loop() { poll().then(function () { setTimeout(loop, document.hidden ? 5000 : dock.mode ? 400 : 1000); }, function () { setTimeout(loop, 3000); }); }
document.addEventListener("keydown", function (e) {
  if (e.target.matches("input, textarea") || !state || !state.player.active) return;
  if (e.key === " ") { e.preventDefault(); cmd("play-pause"); }
});
