/* AniBox window · Missing page: what's missing per franchise, from your folders or from a Plex
   library (this used to be the separate Library Check program), plus HTML/CSV export.
   Plain scripts sharing one page: loaded in order by index.html. */
"use strict";

// ---------- Missing
function missing(source) {
  source = source === "plex" ? "plex" : "folders";
  clearTimeout(missing.t);
  render('<div class="empty">' + (source === "plex" ? "Loading the last Plex check …" : "Comparing your library with the anime lists …") + "</div>");
  api("/api/missing?source=" + source).then(function (d) {
    if (currentPage !== "missing") return;
    document.body.classList.add("hide-have", "hide-short");
    var plex = source === "plex", has = !d.empty && d.stats;
    var html = '<div class="section" style="margin-top:0"><div><div class="kicker">What\'s missing</div><h1 style="margin-top:6px">Seasons, OVAs, specials and movies you don\'t have</h1></div></div>' +
      '<div class="row" style="justify-content:space-between;margin:4px 0 18px"><div class="seg" role="tablist">' +
      '<button role="tab" data-src="folders"' + (plex ? "" : ' class="on"') + ">Your folders</button>" +
      '<button role="tab" data-src="plex"' + (plex ? ' class="on"' : "") + ">Your Plex library</button></div>" +
      (has ? '<div class="row"><a class="btn small" href="/api/missing/export?source=' + source + '&amp;format=html" download>Save as web page</a>' +
        '<a class="btn small" href="/api/missing/export?source=' + source + '&amp;format=csv" download title="Opens in Excel; columns are split with semicolons">Save as spreadsheet</a></div>' : "") + "</div>";
    if (plex) html += plexCheckHtml(d);
    if (has) html += reportHtml(d, plex);
    render(html);
    view.querySelectorAll("[data-src]").forEach(function (b) {
      b.onclick = function () { location.hash = b.getAttribute("data-src") === "plex" ? "#/missing/plex" : "#/missing"; };
    });
    if (has) {
      $("hh").onchange = function () { document.body.classList.toggle("hide-have", this.checked); };
      $("hs").onchange = function () { document.body.classList.toggle("hide-short", this.checked); };
    }
    view.querySelectorAll("[data-match]").forEach(function (b) {
      b.onclick = function () { matchDialog(b.getAttribute("data-match"), b.getAttribute("data-folder"), false, function () { missing(source); }); };
    });
    view.querySelectorAll("[data-ignore]").forEach(function (b) {
      b.onclick = function () {
        post("/api/ignore", { key: b.getAttribute("data-ignore"), ignore: b.getAttribute("data-on") === "1" }).then(function () { missing(source); }).catch(fail);
      };
    });
    if (plex) plexCheckWire(d);
  }).catch(function (e) { render('<div class="empty">' + esc(e.message) + "</div>"); });
}

function reportHtml(d, plex) {
  var s = d.stats;
  return '<div class="stats" style="margin-top:6px"><div class="stat"><b>' + s.folders + "</b>" + (plex ? "Plex items checked" : "folders checked") + '</div><div class="stat"><b>' + s.identified + '</b>recognized</div><div class="stat"><b>' + s.have +
    '</b>entries you have</div><div class="stat"><b>' + s.missing + '</b>missing</div><div class="stat"><b>' + s.incomplete + "</b>incomplete</div>" +
    (plex && s.check ? '<div class="stat"><b>' + s.check + "</b>to check</div>" : "") + '<div class="stat"><b>' + d.complete + "</b>complete franchises</div></div>" +
    '<div class="row" style="margin:20px 0"><label class="check"><input type="checkbox" id="hh" checked> Hide what I have</label><label class="check"><input type="checkbox" id="hs" checked> Hide short clips (ads, music videos)</label></div>' +
    (plex && s.check ? '<p class="muted" style="margin-top:-8px">“Check” means AniBox can\'t tell from Plex\'s numbering whether you have it; the line under the title says where it would be.</p>' : "") +
    d.gaps.map(function (g) {
      return '<details class="fr"><summary><span class="name">' + esc(g.name) + '</span><span class="muted">' + g.have + "/" + g.total + " have" + (g.missing ? " · " + g.missing + " missing" : "") +
        '</span></summary><div class="tw"><table><thead><tr><th>Status</th><th>Title</th><th>Type</th><th class="num">Eps</th><th class="num">Year</th><th></th></tr></thead><tbody>' +
        g.entries.map(entryRow).join("") + "</tbody></table></div></details>";
    }).join("") +
    '<div class="section"><h2>Not recognized (' + d.notFound.length + ')</h2><span class="muted">' +
    (plex ? "Plex items whose IDs fit no MyAnimeList entry. Hide the ones you don't care about." : "Folders no MyAnimeList entry fits. Hide the ones you don't care about.") + "</span></div>" +
    '<div class="panel" style="padding:4px 8px">' + (d.notFound.map(function (i) { return nfRow(i, false, plex); }).join("") || '<div class="nf muted">None</div>') + "</div>" +
    (d.ignored.length ? '<div class="section"><h2>Hidden (' + d.ignored.length + ')</h2></div><div class="panel" style="padding:4px 8px">' + d.ignored.map(function (i) { return nfRow(i, true, plex); }).join("") + "</div>" : "") +
    '<p class="muted" style="margin-top:24px">Data: Fribb/anime-lists and anime-offline-database (updated ' + esc(d.titlesUpdated || "?") + "). Read-only: " +
    (plex ? "nothing in Plex was changed." : "nothing on your drives was changed.") + "</p>";
}

function plexCheckHtml(d) {
  if (!d.signedIn) return '<section class="panel"><h2>Check your Plex library</h2><p class="muted">AniBox reads your Plex libraries (it never changes anything there) and lists what\'s missing in the numbering Plex uses, e.g. “Would go in Season 1, episodes 27–38”.</p>' +
    '<p>Sign in to Plex first: <a href="#/settings">Settings → Your Plex library</a>.</p></section>';
  var c = d.check || {}, running = c.state === "running";
  return '<section class="panel"><h2>Check your Plex library</h2><p class="muted">Reads the libraries you pick (only reads, never changes Plex) and compares every show with the anime lists, in the numbering the library uses.' +
    (d.fetched ? " Last check: " + esc(ago(d.fetched)) + (d.server ? " on " + esc(d.server) : "") + (d.sections && d.sections.length ? " (" + d.sections.map(esc).join(", ") + ")" : "") + "." : "") + "</p>" +
    '<div class="row"><button class="btn primary" id="plexCheck"' + (running ? " disabled" : "") + ">" + (d.fetched ? "Check again" : "Check now") + '</button><button class="btn" id="plexLibs"' + (running ? " disabled" : "") + ">Choose libraries …</button></div>" +
    '<div id="plexLibList"></div>' +
    (running ? '<p id="plexMsg" style="color:var(--acc)">' + esc(c.message || "Working …") + "</p>" : "") +
    (c.state === "error" ? '<div class="note">' + esc(c.message) + "</div>" : "") + "</section>";
}

function plexCheckWire(d) {
  if (!d.signedIn) return;
  if ($("plexCheck")) $("plexCheck").onclick = function () {
    var boxes = view.querySelectorAll("[data-sec]"), body = {};
    if (boxes.length) body.sections = Array.prototype.filter.call(boxes, function (b) { return b.checked; }).map(function (b) { return b.getAttribute("data-sec"); });
    if (body.sections && !body.sections.length) return toast("Pick at least one library.", true);
    post("/api/missing/plex", body).then(function () { missing("plex"); }).catch(fail);
  };
  if ($("plexLibs")) $("plexLibs").onclick = function () {
    var box = $("plexLibList"); box.innerHTML = '<p class="muted">Asking Plex for its libraries …</p>';
    api("/api/missing/plex/sections").then(function (r) {
      box.innerHTML = '<div style="margin-top:12px">' + r.sections.map(function (s) {
        return '<label class="check"><input type="checkbox" data-sec="' + esc(s.key) + '"' + (s.chosen ? " checked" : "") + "> " + esc(s.title) +
          ' <span class="muted">· ' + (s.type === "show" ? "TV shows" : "Movies") + "</span></label>";
      }).join("") + '<p class="muted">Tick the anime libraries, then “Check now”. AniBox remembers the choice.</p></div>';
    }).catch(function (e) { box.innerHTML = '<div class="note">' + esc(e.message) + "</div>"; });
  };
  if (d.check && d.check.state === "running") waitPlexCheck();
}
function waitPlexCheck() {
  missing.t = setTimeout(function () {
    if (currentPage !== "missing" || !$("plexMsg")) return;
    api("/api/missing?source=plex").then(function (n) {
      if (n.check && n.check.state === "running") { $("plexMsg").textContent = n.check.message || "Working …"; waitPlexCheck(); }
      else missing("plex");
    }).catch(function () { waitPlexCheck(); });
  }, 1500);
}

function nfRow(i, ignored, plex) {
  return '<div class="nf"><div><div class="nm">' + esc(i.title) + '</div><div class="muted" style="font-size:13px">' + esc(i.library) + (i.note ? " · " + esc(i.note) : "") + "</div></div>" +
    '<div class="row">' + (ignored || plex ? "" : '<button class="btn small" data-match="' + esc(i.key) + '" data-folder="' + esc(i.title) + '">Match by hand</button>') +
    '<button class="btn small" data-ignore="' + esc(i.key) + '" data-on="' + (ignored ? "0" : "1") + '">' + (ignored ? "Show again" : "Hide") + "</button></div></div>";
}
