/* AniBox window · Check my setup (routes_setupcheck.py): tests every part of AniBox on this PC and shows a
   short report without names, addresses or keys, to save into Downloads or copy. Nothing runs until
   "Run the check" is clicked. Plain scripts sharing one page: loaded in order by index.html. */
"use strict";

settingsPanels.push(function (box) {
  if (box.previousElementSibling) box.style.marginTop = "18px";
  box.innerHTML = '<section class="panel"><h2>Check my setup</h2><p class="muted">Tests every part of AniBox on this PC: the player, ' +
    "this window, your folders, Plex, TVs, the internet and the Internet Archive cache. Then it writes a short report without your " +
    "names, addresses or keys, to send when something doesn't work. It only looks; nothing is changed.</p>" +
    '<a class="btn small primary" href="#/setup-check">Check my setup</a></section>';
});
homePanels.push(function (box) {  // only a small link, at the bottom of Home
  box.className = "sc-home";
  box.innerHTML = '<a href="#/setup-check">Something not working? Check my setup</a>';
  view.appendChild(box);
});
pageRoutes["setup-check"] = function () { setTab("settings"); setupCheckPage(); };

var scData = null;
var SC_MARK = { ok: "✓", note: "!", problem: "✗", skip: "–", waiting: "·", running: "" };
var SC_WORD = { ok: "fine", note: "to note", problem: "problem", skip: "not checked" };

function setupCheckPage() {
  clearTimeout(setupCheckPage.t);
  render(scHead() + '<div class="empty">Loading …</div>');
  api("/api/setupcheck").then(function (d) {
    scData = d;
    if (currentPage !== "setup-check") return;
    scDraw();
    if (d.job.state === "running") scPoll();
  }).catch(function (e) { render(scHead() + '<div class="empty">' + esc(e.message) + "</div>"); });
}
function scHead() {
  return '<div class="section" style="margin-top:0"><div><div class="kicker">Settings</div><h1 style="margin-top:6px">Check my setup</h1></div>' +
    '<a class="btn small" href="#/settings">Back to Settings</a></div>';
}

// ---------- what the window knows about itself (browser, app window, scale, size)
function scFacts() {
  var mm = function (q) { try { return window.matchMedia(q).matches; } catch (e) { return false; } };
  var f = {
    ua: navigator.userAgent || "", dpr: window.devicePixelRatio || 1, iw: window.innerWidth, ih: window.innerHeight,
    ow: window.outerWidth, oh: window.outerHeight, sw: screen.width, sh: screen.height,
    standalone: mm("(display-mode: standalone)"), minimal: mm("(display-mode: minimal-ui)"),
    locationbar: window.locationbar ? !!window.locationbar.visible : null, toolbar: window.toolbar ? !!window.toolbar.visible : null
  };
  var uad = navigator.userAgentData;
  if (!uad || !uad.getHighEntropyValues) return Promise.resolve(f);
  return uad.getHighEntropyValues(["fullVersionList", "platformVersion"]).then(function (h) {
    f.brands = (h.fullVersionList || []).map(function (b) { return b.brand + " " + b.version; });
    f.platformVersion = h.platformVersion || "";
    return f;
  }).catch(function () { return f; });
}

// ---------- the page
function scCounts(rows) {
  var c = { ok: 0, note: 0, problem: 0, skip: 0 };
  rows.forEach(function (r) { if (c[r.status] != null) c[r.status]++; });
  return c;
}
function scSummary(rows) {
  var c = scCounts(rows);
  return ["ok", "note", "problem", "skip"].filter(function (k) { return c[k] || k !== "skip"; }).map(function (k) {
    return '<span class="sc-sum ' + k + '">' + c[k] + " " + SC_WORD[k] + (k === "problem" && c[k] !== 1 ? "s" : "") + "</span>";
  }).join("");
}
function scProgress(d) {
  var job = d.job || {};
  if (job.state === "running") {
    var pct = job.total ? Math.round(100 * job.done / job.total) : 0;
    return '<p style="color:var(--acc);margin:14px 0 0">Checking … ' + (job.total ? job.done + " of " + job.total + " done" : "") + "</p>" +
      '<div class="progress"><i style="width:' + pct + '%"></i></div>';
  }
  if (job.state === "error") return '<div class="note">The check stopped: ' + esc(job.message) + "</div>";
  if (d.rows.length) {
    return '<div class="row" style="margin-top:14px"><span class="muted">Checked ' + esc(ago(job.finished)) +
      (job.version ? " with AniBox " + esc(job.version) : "") + ":</span>" + scSummary(d.rows) + "</div>";
  }
  return "";
}
function scRow(r) {
  var mark = r.status === "running" ? '<span class="sc-mark running" aria-label="running"></span>' :
    '<span class="sc-mark ' + r.status + '" aria-label="' + esc(SC_WORD[r.status] || r.status) + '">' + SC_MARK[r.status] + "</span>";
  return '<div class="sc-row">' + mark + '<div class="sc-body"><div class="sc-t">' + esc(r.title) +
    (r.seconds != null && r.status !== "skip" ? ' <span class="muted">' + (r.seconds < 1 ? Math.round(r.seconds * 1000) + " ms" : r.seconds.toFixed(1) + " s") + "</span>" : "") + "</div>" +
    (r.line ? '<div class="sc-line">' + esc(r.line) + "</div>" : r.status === "waiting" ? '<div class="sc-line muted">Waiting …</div>' : "") +
    (r.details || []).map(function (x) { return '<div class="sc-det">' + esc(x) + "</div>"; }).join("") +
    (r.fix ? '<div class="sc-fix">' + esc(r.fix) + "</div>" : "") + "</div></div>";
}
function scList(d) {
  if (!d.rows.length) return "";
  return d.groups.map(function (g) {
    var rows = d.rows.filter(function (r) { return r.group === g; });
    if (!rows.length) return "";
    return '<section class="panel sc-group"><h2>' + esc(g) + "</h2>" + rows.map(scRow).join("") + "</section>";
  }).join("");
}
function scDraw() {
  var d = scData, job = d.job || {}, running = job.state === "running", report = !running && d.report;
  var html = scHead() +
    '<p class="muted" style="max-width:860px">AniBox tests each part on this PC: its own folder, the player (it starts mpv for a second, ' +
    "without picture or sound), this window, your folders, Plex, TVs in your home network, the internet services it uses, the Internet " +
    "Archive cache and the phone remote. It only reads and looks; the one thing it writes is a small test file in its own cache folder, " +
    "deleted right away. Plex only gets questions, never changes. The report leaves out your names, addresses, keys and show names, " +
    "so you can send it as it is.</p>" +
    '<section class="panel"><div class="row">' +
    '<button class="btn primary" id="scGo"' + (running ? " disabled" : "") + ">" + (d.rows.length ? "Run again" : "Run the check") + "</button>" +
    '<button class="btn" id="scSave"' + (report ? "" : " disabled") + ' title="Saves the report as a text file in your Downloads folder">Save report</button>' +
    '<button class="btn" id="scCopy"' + (report ? "" : " disabled") + ">Copy report</button>" +
    '<button class="btn" id="scOpen">Open the Downloads folder</button></div>' +
    '<div id="scProg">' + scProgress(d) + "</div></section>" +
    '<div id="scList">' + scList(d) + "</div>" +
    (report ? '<section class="panel" style="margin-top:18px"><h2>The report</h2><p class="muted">Exactly what <b>Save report</b> and ' +
      "<b>Copy report</b> give. Anything personal is replaced, like <code>&lt;PC&gt;</code>, <code>%USERPROFILE%</code>, " +
      "<code>\\\\&lt;server&gt;\\&lt;share 1&gt;</code>, <code>&lt;drive 1&gt;</code>, <code>&lt;home network address&gt;</code> and <code>&lt;hidden&gt;</code>.</p>" +
      '<pre class="preview sc-report" id="scReport">' + esc(d.report) + "</pre></section>" : "");
  render(html);
  $("scGo").onclick = scStart;
  $("scSave").onclick = function () {
    post("/api/setupcheck/save").then(function (r) { toast("Saved in your Downloads folder as “" + r.name + "”."); }).catch(fail);
  };
  $("scCopy").onclick = function () { scCopy(scData.report); };
  $("scOpen").onclick = function () { post("/api/setupcheck/downloads").catch(fail); };
}
function scStart() {
  $("scGo").disabled = true;
  scFacts().then(function (f) { return post("/api/setupcheck/start", { window: f }); }).then(function (r) {
    scData.job = r.job; scData.rows = []; scData.report = "";
    if (currentPage !== "setup-check") return;
    scDraw(); scPoll();
  }).catch(function (e) { $("scGo").disabled = false; fail(e); });
}
function scPoll() {
  clearTimeout(setupCheckPage.t);
  setupCheckPage.t = setTimeout(function () {
    if (currentPage !== "setup-check") return;
    api("/api/setupcheck").then(function (d) {
      if (currentPage !== "setup-check") return;
      scData = d;
      if (d.job.state === "running") {
        $("scProg").innerHTML = scProgress(d);
        $("scList").innerHTML = scList(d);
        return scPoll();
      }
      scDraw();
      if (d.job.state === "done") toast("Done. The report is at the bottom of the page.");
    }).catch(function () { scPoll(); });
  }, 700);
}
function scCopy(text) {
  function fallback() {
    var ta = document.createElement("textarea"), done = false;
    ta.value = text; ta.setAttribute("readonly", ""); ta.style.position = "fixed"; ta.style.opacity = "0";
    document.body.appendChild(ta); ta.select();
    try { done = document.execCommand("copy"); } catch (e) { done = false; }
    ta.remove();
    if (done) toast("Copied. Paste it into your message.");
    else toast("Couldn't copy: select the text in the box and press Ctrl+C.", true);
  }
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(function () { toast("Copied. Paste it into your message."); }, fallback);
  } else fallback();
}
