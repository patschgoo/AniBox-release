/* AniBox window · Show and franchise pages: episodes, details, locks, missing entries.
   Plain scripts sharing one page: loaded in order by index.html. */
"use strict";

// ---------- Show
var showData = null;
// Plug-in points like homePanels: function (box) {} gets a <div> on a show's page (showData is the show)
// or on a franchise page (franchiseData is the franchise).
var showPanels = [], franchisePanels = [], franchiseData = null;
function show(id) {
  api("/api/show?id=" + encodeURIComponent(id)).then(function (d) {
    showData = d;
    var meta = [TYPE[d.type] || d.type, d.year, d.mal_episodes ? d.mal_episodes + " episodes on MyAnimeList" : "", d.files + " files", d.library].filter(Boolean);
    var nxt = d.next;
    var html = '<div class="showhead">' + posterHtml(d) + "<div>" +
      '<div class="kicker">' + esc(d.library) + "</div><h1>" + esc(d.title) + "</h1>" +
      (d.folder !== d.title ? '<div class="muted">Folder: ' + esc(d.folder) + "</div>" : "") +
      '<div class="meta">' + meta.map(function (m) { return "<span>" + esc(m) + "</span>"; }).join("") + '<button class="langbtn" id="langBtn" title="Audio and subtitle languages: change by hand">' + (d.badges && d.badges.length ? d.badges.map(esc).join(" · ") : "Languages?") + " ✎</button></div>" +
      (d.note ? '<div class="note">' + esc(d.note) + "</div>" : "") + lockHtml(d.lock) +
      '<div class="progress"><i style="width:' + (d.files ? Math.round(100 * d.watched / d.files) : 0) + '%"></i></div>' +
      '<div class="muted" style="margin:-8px 0 16px">' + d.watched + " of " + d.files + " watched</div>" +
      '<div class="row">' +
      (nxt ? '<button class="btn primary" id="playNext">▶&nbsp; ' + (nxt.position ? "Resume " : "Play ") + esc(nxt.label) + (nxt.position ? " from " + fmt(nxt.position) : "") + "</button>" : '<button class="btn primary" id="playFirst">▶&nbsp; Watch again</button>') +
      '<button class="btn" id="tvBtn" title="Play on CastApp TV or another TV in your network">Play on TV</button>' +
      '<button class="btn" id="markAll">' + (d.finished ? "Mark all unwatched" : "Mark all watched") + "</button>" +
      (d.malUrl ? '<a class="btn" href="' + esc(d.malUrl) + '" target="_blank" rel="noopener noreferrer">MyAnimeList ↗</a>' : "") +
      '<button class="btn" id="matchBtn" title="Pick the right MyAnimeList entry for this folder">' + (d.mal_id ? "Wrong match?" : "Match by hand") + "</button>" +
      '<button class="btn" id="openFolder" title="Show this folder in File Explorer">Open folder</button>' +
      '<button class="btn" id="moveBtn" title="' + (d.lock && d.lock.protect && d.lock.locked && !d.lock.unlocked ? "Unlock the show first to move or rename it" : "Move it to another library folder or rename it") + '">Move or rename …</button>' +
      "</div></div></div>" + '<div id="showExtra"></div>' + plexHtml(d) + '<div id="details"></div>' +
      '<div class="section"><h2>Episodes <small class="muted" id="epState" style="font:400 13px var(--body)"></small></h2><label class="search" style="max-width:320px"><input id="eq" type="search" placeholder="Find an episode" aria-label="Find an episode"></label></div>' +
      '<div class="eps" id="eps"></div>';
    if (d.missing && d.missing.length) {
      html += '<div class="section"><h2>Missing from this franchise</h2><a href="#/missing">Everything that\'s missing →</a></div><div class="panel"><table><thead><tr><th>Status</th><th>Title</th><th>Type</th><th class="num">Eps</th><th class="num">Year</th><th></th></tr></thead><tbody>' +
        d.missing.filter(function (m) { return !m.short; }).map(entryRow).join("") + "</tbody></table></div>";
    }
    render(html);
    runPanels(showPanels, "showExtra", d);
    drawEps();
    $("eq").addEventListener("input", drawEps);
    $("eps").addEventListener("click", function (e) {
      var row = e.target.closest(".ep"); if (!row) return;
      var key = row.getAttribute("data-key");
      if (e.target.closest("[data-again]")) {
        var ep = d.episodes.filter(function (x) { return x.key === key; })[0] || {};
        rewatchDialog({ show: d.id, key: key, label: ep.label || "", title: d.title, done: function () { show(id); } });
        return;
      }
      if (e.target.closest(".fold")) { post("/api/reveal", { show: d.id, key: key }).catch(fail); return; }
      if (e.target.closest(".tick")) {
        var seen = row.classList.contains("seen");
        post("/api/watched", { keys: [key], watched: !seen }).then(function () { show(id); }).catch(fail);
        return;
      }
      play({ key: key });
    });
    $("tvBtn").onclick = function () { tvDialog({ show: d.id }); };
    $("openFolder").onclick = function () { post("/api/reveal", { show: d.id }).catch(fail); };
    $("moveBtn").onclick = function () { moveDialog(d, function (newId) { location.hash = "#/show/" + encodeURIComponent(newId); }); };
    $("langBtn").onclick = function () { langDialog(d, function () { show(id); }); };
    api("/api/langs?id=" + encodeURIComponent(d.id)).then(function waitLangs(r) {
      if (!showData || showData.id !== d.id || currentPage !== "show") return;
      if ($("langBtn") && r.badges) $("langBtn").textContent = (r.badges.length ? r.badges.join(" · ") : "Languages?") + " ✎";
      if (r.state === "loading") setTimeout(function () { api("/api/langs?id=" + encodeURIComponent(d.id)).then(waitLangs).catch(function () {}); }, 1500);
    }).catch(function () {});
    if ($("lockBtn")) $("lockBtn").onclick = function () {
      var unlock = !d.lock.unlocked;
      if (unlock && !confirm("Unlock " + d.title + "? AniBox may then write info files (NFO) for its old episodes too, when you choose Write under Settings → Info files. Your video files are never changed.")) return;
      post("/api/lock", { show: d.id, unlock: unlock }).then(function () { toast(unlock ? "Unlocked." : "Locked again."); show(id); }).catch(fail);
    };
    loadEpisodeInfo(d.id);
    if ($("usePlexMatch")) $("usePlexMatch").onclick = function () {
      post("/api/match", { show: d.id, mal_id: this.getAttribute("data-mal") }).then(function (r) { toast("Matched to " + r.title); show(id); }).catch(fail);
    };
    $("matchBtn").onclick = function () { matchDialog(d.id, d.folder, d.manual, function () { show(id); }); };
    if (d.mal_id) details(d);
    if ($("playNext")) $("playNext").onclick = function () { play({ key: nxt.key }); };
    if ($("playFirst")) $("playFirst").onclick = function () { play({ key: d.episodes[0].key, fromStart: true }); };
    $("markAll").onclick = function () { post("/api/watched", { show: d.id, watched: !d.finished }).then(function () { show(id); }).catch(fail); };
  }).catch(function (e) { render('<div class="empty">' + esc(e.message) + ' · <a href="#/library">Back to the library</a></div>'); });
}
function details(d) {
  api("/api/details?id=" + encodeURIComponent(d.id)).then(function (r) {
    var box = $("details"); if (!box || !showData || showData.id !== d.id) return;
    var x = r.details;
    if (!x) {
      box.innerHTML = r.error ? '<div class="note">' + esc(r.error) + "</div>" : (d.hasClientId ? "" :
        '<p class="muted" style="margin-top:18px">Descriptions, scores and genres: add a free MyAnimeList Client ID in <a href="#/settings">Settings → MyAnimeList</a>.</p>');
      return;
    }
    var facts = [["Aired", [x.start_date, x.end_date].filter(Boolean).join(" – ")], ["Season", x.season], ["Episodes", x.num_episodes || ""], ["Studio", (x.studios || []).join(", ")],
      ["Source", x.source], ["Rating", x.rating], ["English title", x.title_en], ["Japanese", x.title_ja]].filter(function (f) { return f[1]; });
    box.innerHTML = '<div class="details"><div>' + (x.synopsis ? '<div class="syn">' + esc(x.synopsis) + "</div>" : '<p class="muted">No description on MyAnimeList.</p>') +
      '<div style="margin-top:12px">' + (x.genres || []).map(function (g) { return '<span class="tag">' + esc(g) + "</span>"; }).join("") + "</div></div>" +
      '<div class="panel" style="padding:16px">' + (x.mean ? '<div class="score">★ ' + esc(x.mean) + '</div><div class="muted" style="margin-bottom:12px">MyAnimeList score' + (x.rank ? " · #" + esc(x.rank) : "") + "</div>" : "") +
      "<dl>" + facts.map(function (f) { return "<dt>" + esc(f[0]) + "</dt><dd>" + esc(f[1]) + "</dd>"; }).join("") + "</dl></div></div>" +
      (r.error ? '<div class="note">' + esc(r.error) + "</div>" : "");
  }).catch(function () {});
}
// What your Plex library already had for this show (a copy, linked by file; locked shows keep it).
function plexHtml(d) {
  var p = d.plex;
  if (!p || !p.title) return "";
  var facts = [p.section + (p.legacy ? " (old MyAnimeList agent)" : ""), p.year, p.studio, p.contentRating, p.rating ? "★ " + p.rating : ""].filter(Boolean);
  var diff = p.malId && p.malId !== (d.mal_id || "") ?
    '<div class="note">Plex\'s match back then: <b>' + esc(p.malTitle || ("MAL " + p.malId)) + "</b> (MAL " + esc(p.malId) + "). AniBox matched " +
    (d.mal_id ? "<b>" + esc(d.title) + "</b> (MAL " + esc(d.mal_id) + ")" : "nothing") + '. <button class="btn small" id="usePlexMatch" data-mal="' + esc(p.malId) + '">Use Plex\'s match</button></div>' : "";
  return '<section class="panel plexpanel">' + (p.poster ? '<img class="pp" alt="" src="' + esc(p.poster) + '" onerror="this.remove()">' : "") +
    '<div><div class="kicker">From your Plex library ' + (p.locked ? "· locked" : "") + '</div><h3>' + esc(p.title) + (p.originalTitle && p.originalTitle !== p.title ? ' <span class="muted">· ' + esc(p.originalTitle) + "</span>" : "") + "</h3>" +
    '<div class="muted" style="font-size:13px">' + facts.map(esc).join(" · ") + (p.genres && p.genres.length ? " · " + p.genres.slice(0, 6).map(esc).join(", ") : "") + "</div>" +
    (p.summary ? '<p class="syn">' + esc(p.summary) + "</p>" : "") +
    '<div class="muted" style="font-size:12px">' + (p.locked ? "Kept as it was in Plex; AniBox doesn't change it while the show is locked. " : "") +
    (p.home ? "" : "In Plex this belongs to another show. ") + (p.others && p.others.length ? "Also in: " + p.others.map(esc).join(", ") + ". " : "") +
    "Copied " + esc(ago(p.fetched)) + ".</div>" + diff + "</div></section>";
}
function lockHtml(l) {
  if (!l || !l.protect || !l.locked) return "";
  if (l.unlocked) return '<div class="lock open"><span>🔓 Unlocked: AniBox may write info files for all ' + (l.locked + l.new) + ' episodes of this show.</span><button class="btn small" id="lockBtn">Lock again</button></div>';
  return '<div class="lock"><span>🔒 ' + l.locked + (l.locked === 1 ? " episode was" : " episodes were") + " already there and " + (l.locked === 1 ? "is" : "are") + " locked" +
    (l.new ? " · " + l.new + " new" : "") + '. AniBox never changes them; info files are only written for new episodes.</span><button class="btn small" id="lockBtn">Unlock this show</button></div>';
}
function loadEpisodeInfo(id) {
  api("/api/episode-info?id=" + encodeURIComponent(id)).then(function (r) {
    if (!showData || showData.id !== id || currentPage !== "show") return;
    showData.epinfo = r.episodes; drawEps();
    if ($("epState")) $("epState").textContent = r.state === "loading" ? "Loading episode titles …" : (r.error || "");
    if (r.state === "loading") setTimeout(function () { loadEpisodeInfo(id); }, 2000);
  }).catch(function () {});
}
function drawEps() {
  var q = ($("eq").value || "").trim().toLowerCase();
  var cur = state && state.player.active ? state.player.key : "";
  var info = showData.epinfo || {};
  var html = showData.episodes.filter(function (e) { var t = (info[e.key] || {}).title || ""; return !q || (e.label + " " + e.file + " " + t).toLowerCase().indexOf(q) >= 0; }).map(function (e) {
    var nr = e.number != null ? (e.season > 1 || e.season === 0 ? (e.season === 0 ? "SP" : e.season + "·") : "") + e.number : "·";
    var pct = e.watched ? 100 : e.percent;
    var x = info[e.key] || {};
    var tip = x.title ? (x.plot ? x.plot : "") + (x.source ? (x.plot ? "\n\n" : "") + "Title from " + x.source : "") : "Play";
    return '<div class="ep' + (e.watched ? " seen" : "") + (e.key === cur ? " cur" : "") + '" data-key="' + esc(e.key) + '" title="' + esc(tip) + '">' +
      '<div class="n">' + esc(nr) + '</div><div class="epmain">' + (x.image ? '<img class="th" loading="lazy" alt="" referrerpolicy="no-referrer" src="' + esc(x.image) + '" onerror="this.remove()">' : "") +
      '<div class="eptext"><div class="l">' + esc(e.label) + (x.title ? ' <span class="et">· ' + esc(x.title) + "</span>" : "") + (e.position && !e.watched ? ' <span class="muted">· ' + fmt(e.position) + "</span>" : "") +
      (e.watched && e.key !== cur ? rewatchButton() : "") +
      '</div><div class="f">' + (e.locked ? '<span title="Was already there: locked">🔒</span> ' : "") + esc(e.file) + (x.aired ? " · " + esc(x.aired) : "") + "</div></div></div>" +
      '<div class="pb"><i style="width:' + pct + '%"></i></div>' +
      '<button class="fold" aria-label="Show the file in its folder" title="Show the file in its folder"><svg viewBox="0 0 24 24"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg></button>' +
      '<button class="tick" aria-label="' + (e.watched ? "Mark as not watched" : "Mark as watched") + '" title="' + (e.watched ? "Watched (click to undo)" : "Mark as watched") + '">' + TICK + "</button></div>";
  }).join("");
  $("eps").innerHTML = html || '<div class="empty">No episode matches.</div>';
}
function franchise(key) {
  api("/api/franchise?key=" + encodeURIComponent(key)).then(function (d) {
    var html = '<div class="section" style="margin-top:0"><div><div class="kicker">Franchise</div><h1 style="margin-top:6px">' + esc(d.title) + "</h1>" +
      '<div class="muted">' + d.have + " of " + d.total + " entries on your drives" + (d.missing ? " · " + d.missing + " missing" : "") + "</div></div>" +
      '<a class="btn small" href="#/library">← Library</a></div>' +
      '<div class="grid">' + d.shows.map(cardHtml).join("") + "</div>" + '<div id="franchiseExtra"></div>' +
      '<div class="section"><h2>Everything in this franchise</h2><label class="check"><input type="checkbox" id="fs" checked> Hide short clips</label></div>' +
      '<div class="panel"><table><thead><tr><th>Status</th><th>Title</th><th>Type</th><th class="num">Eps</th><th class="num">Year</th><th></th></tr></thead><tbody>' +
      d.entries.map(entryRow).join("") + "</tbody></table></div>";
    document.body.classList.add("hide-short"); document.body.classList.remove("hide-have");
    render(html);
    franchiseData = d;
    runPanels(franchisePanels, "franchiseExtra");
    $("fs").onchange = function () { document.body.classList.toggle("hide-short", this.checked); };
  }).catch(function (e) { render('<div class="empty">' + esc(e.message) + ' · <a href="#/library">Back to the library</a></div>'); });
}
var LABEL = { owned: "Have", partial: "Incomplete", unsure: "Check", missing: "Missing", upcoming: "Not out yet" };
function entryRow(e) {
  var eps = e.episodes == null ? "" : (e.status === "partial" ? e.have + "/" + e.episodes : e.episodes);
  return '<tr class="st-' + e.status + (e.short ? " short" : "") + '"><td><span class="pill ' + e.status + '">' + LABEL[e.status] + "</span></td>" +
    "<td>" + esc(e.title) + (e.folder ? ' <span class="muted">· ' + esc(e.folder) + "</span>" : "") +
    (e.detail && e.status !== "owned" ? '<div class="muted" style="font-size:12px">' + esc(e.detail) + "</div>" : "") + "</td><td>" + esc(TYPE[e.type] || e.type) + '</td><td class="num">' + esc(eps) +
    '</td><td class="num">' + esc(e.year || "") + '</td><td><a href="' + esc(e.mal_url) + '" target="_blank" rel="noopener noreferrer">MAL ↗</a></td></tr>';
}

// Move or rename a show (only new or unlocked shows; routes_files.py). Preview first, then move.
function moveDialog(d, done) {
  if (d.lock && d.lock.protect && d.lock.locked && !d.lock.unlocked) {
    openModal('<div class="kicker">Move or rename</div><h2>' + esc(d.title) + "</h2><p>" + d.lock.locked + " episodes of this show were already there and are locked, so AniBox doesn't move or rename them. " +
      'Click <b>Unlock this show</b> on its page first if you want to change it.</p><div class="row" style="justify-content:flex-end"><button class="btn" data-close>OK</button></div>');
    return;
  }
  api("/api/settings").then(function (s) {
    var libs = Object.keys(s.libraries).filter(function (l) { return s.libraries[l].kind === s.libraries[d.library].kind; }).sort();
    openModal('<div class="kicker">Move or rename</div><h2>' + esc(d.title) + "</h2>" +
      '<div class="field"><div class="lbl">Library folder</div><select class="input" id="mvLib">' + libs.map(function (l) { return "<option" + (l === d.library ? " selected" : "") + ">" + esc(l) + "</option>"; }).join("") + "</select></div>" +
      '<div class="field"><div class="lbl">Folder name</div><input class="input" id="mvFolder" value="' + esc(d.folder) + '" style="min-width:360px"></div>' +
      '<label class="check"><input type="checkbox" id="mvRename"> Also rename the episode files to “<span id="mvEx">' + esc(d.folder) + "</span> 01”, “… 02” …</label>" +
      '<div id="mvPrev" class="muted" style="margin-top:12px"></div>' +
      '<div class="row" style="margin-top:16px;justify-content:flex-end"><button class="btn" data-close>Cancel</button><button class="btn" id="mvCheck">Show what changes</button><button class="btn primary" id="mvGo" disabled>Move</button></div>');
    function body() { return { show: d.id, library: $("mvLib").value, folder: $("mvFolder").value.trim(), rename: $("mvRename").checked }; }
    function invalidate() { $("mvGo").disabled = true; $("mvEx").textContent = $("mvFolder").value.trim(); }
    ["mvLib", "mvFolder", "mvRename"].forEach(function (id) { $(id).addEventListener("input", invalidate); $(id).addEventListener("change", invalidate); });
    $("mvCheck").onclick = function () {
      post("/api/move/preview", body()).then(function (r) {
        var bad = r.ops.filter(function (o) { return o.problem; });
        $("mvPrev").innerHTML = (r.ops.length ? '<div class="tw" style="max-height:36vh;overflow:auto"><table><tbody>' + r.ops.map(function (o) {
            return "<tr><td>" + esc(o.src.split(/[\\/]/).pop()) + '</td><td class="muted">→</td><td>' + esc(o.dst) + (o.problem ? '<div class="note">' + esc(o.problem) + "</div>" : "") + "</td></tr>";
          }).join("") + "</tbody></table></div>" : "Nothing changes.") +
          (r.legacy ? '<div class="note">This show is in one of your old Plex libraries (old MyAnimeList agent). Plex will see the moved files as gone and new ones, and its old scanner can\'t add them again. Your Plex details copy in AniBox stays.</div>' : "");
        $("mvGo").disabled = !r.ops.length || bad.length > 0;
      }).catch(fail);
    };
    $("mvGo").onclick = function () {
      post("/api/move/apply", body()).then(function (r) {
        closeModal(); toast("Moving …");
        (function wait() {
          api("/api/files/state").then(function (s2) {
            if (s2.job.state === "running") return setTimeout(wait, 800);
            toast(s2.job.errors && s2.job.errors.length ? s2.job.errors.length + " files couldn't be moved." : "Done. Undo is on the Add new videos page.");
            setTimeout(function () { done(r.newId); }, 1200);
          }).catch(fail);
        })();
      }).catch(fail);
    };
  }).catch(fail);
}
