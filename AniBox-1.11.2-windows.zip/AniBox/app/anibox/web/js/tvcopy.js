/* AniBox window · TV copies: converted copies of videos the TV can't play, Hi10P above all (routes_tvcopy.py).
   The show page's TV check gets "Make TV copies …" (media.js calls tvCopyCheck), Settings gets a panel.
   Plain scripts sharing one page: loaded in order by index.html. */
"use strict";

var tvc = { showTimer: 0, panelTimer: 0, needs: {} };

(function () {
  var st = document.createElement("style");
  st.textContent =
    ".tvc-row { margin-top: 10px; padding: 10px 0 0; border-top: 1px solid var(--line); }" +
    ".tvc-row .row { gap: 8px; }" +
    ".tvc-facts { display: grid; grid-template-columns: auto 1fr; gap: 6px 14px; font-size: 14px; margin: 12px 0; }" +
    ".tvc-facts dt { color: var(--muted); } .tvc-facts dd { margin: 0; overflow-wrap: anywhere; }" +
    ".tvc-list td { vertical-align: top; } .tvc-list td:first-child { width: 28px; }" +
    ".tvc-list .muted { font-size: 13px; }" +
    ".tvc-dir { margin-top: 6px; display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }" +
    ".tvc-dir .input { flex: 1; min-width: 220px; }" +
    ".tvc-job { padding: 10px 0; border-top: 1px solid var(--line); }" +
    ".tvc-job .meter { margin: 6px 0; }";
  document.head.appendChild(st);
})();

function tvcBytes(b) {
  if (b == null) return "?";
  if (b >= 1073741824) return (b / 1073741824).toFixed(b >= 10737418240 ? 0 : 1) + " GB";
  if (b >= 1048576) return Math.round(b / 1048576) + " MB";
  return Math.max(0, Math.round(b / 1024)) + " KB";
}
function tvcTime(s) {  // "about 1 h 20 min", "less than a minute"
  s = Math.round(s || 0);
  if (s < 60) return "less than a minute";
  var h = Math.floor(s / 3600), m = Math.round((s % 3600) / 60);
  if (m === 60) { h += 1; m = 0; }
  return "about " + (h ? h + " h" + (m ? " " + m + " min" : "") : m + " min");
}
function tvcCopies(n) { return n + " TV cop" + (n === 1 ? "y" : "ies"); }
function tvcJobLine(j) {
  var pct = Math.round(100 * (j.progress || 0));
  var bits = [pct + " %"];
  if (j.state === "paused") bits.push("paused");
  else if (j.speed) bits.push(j.speed.toFixed(1) + "× real time");
  if (j.eta != null && j.state !== "paused" && j.progress > 0.01) bits.push(tvcTime(j.eta) + " left");
  if (j.encoder) bits.push(j.encoder);
  return '<div class="tvc-job"><div><b>' + esc(j.title || "") + "</b> · " + esc(j.label || j.file || "") + "</div>" +
    '<div class="meter"><i style="width:' + pct + '%"></i></div><div class="muted" style="font-size:13px">' + esc(bits.join(" · ")) + "</div></div>";
}

// ---------- Show page: a line under "Plays on the TV?" (media.js calls this after drawing the check)
function tvCopyCheck(d, r) {
  tvc.needs[d.id] = (r.targets || []).some(function (t) { return t.level === "convert"; });
  tvcShowRow(d);
}
function tvcShowRow(d) {
  clearTimeout(tvc.showTimer);
  api("/api/tvcopy/show?id=" + encodeURIComponent(d.id)).then(function (s) {
    var box = $("tvCheck");
    if (!box || !mediaHere(d.id)) return;
    var old = $("tvcRow"); if (old) old.remove();
    var needs = tvc.needs[d.id];
    if (!needs && !s.copies.length && !s.jobs.length) return;
    var row = document.createElement("div"); row.id = "tvcRow"; row.className = "tvc-row";
    var ready = s.copies.filter(function (c) { return c.state === "ready"; });
    var html = '<div class="row" style="justify-content:space-between"><div><b>TV copies</b> <span class="muted">· ' +
      (ready.length ? tvcCopies(ready.length) + " ready; Play on TV sends them instead of the originals" :
        needs ? "AniBox can make a copy the TV plays (8-bit H.264) in its own folder; your files stay as they are" : "") +
      (s.outdated ? " · " + s.outdated + " outdated (the original changed)" : "") + "</span></div>" +
      '<div class="row">' + (needs && ready.length < (d.episodes || []).length ?
        '<button class="btn small' + (ready.length ? "" : " primary") + '" id="tvcMake">' + (ready.length ? "More TV copies …" : "Make TV copies …") + "</button>" : "") + "</div></div>";
    if (s.jobs.length) {
      var cur = s.jobs.filter(function (j) { return j.state === "running" || j.state === "paused"; })[0];
      var waiting = s.jobs.length - (cur ? 1 : 0);
      html += (cur ? tvcJobLine(cur) : "") + (waiting ? '<div class="muted" style="font-size:13px">' + waiting + " more waiting" + (s.paused ? " (paused)" : "") + "</div>" : "") +
        (s.message ? '<div class="note">' + esc(s.message) + "</div>" : "") +
        '<div class="row" style="margin-top:6px">' + (s.paused ? '<button class="btn small" data-tvc="resume">Resume</button>' : '<button class="btn small" data-tvc="pause">Pause</button>') +
        '<button class="btn small" data-tvc="cancel">Cancel</button><a class="btn small" href="#/settings">All TV copies →</a></div>';
    }
    if (s.copies.length) {
      html += '<details style="margin-top:8px"><summary class="muted" style="cursor:pointer">The copies (' + s.copies.length + ")</summary>" +
        '<div class="tw" style="padding:6px 0 0"><table><tbody>' + s.copies.map(function (c) {
          return "<tr><td>" + esc(c.label) + '</td><td class="muted" style="overflow-wrap:anywhere">' + esc(c.copy) + '</td><td class="muted">' + tvcBytes(c.size) +
            (c.state !== "ready" ? " · " + esc(c.state === "outdated" ? "outdated" : "file missing") : "") +
            '</td><td><button class="btn small" data-tvc-remove="' + esc(c.key) + '" title="Remove this copy (AniBox\'s own file; the original stays)">Remove</button></td></tr>';
        }).join("") + "</tbody></table></div></details>";
    }
    row.innerHTML = html;
    box.appendChild(row);
    if ($("tvcMake")) $("tvcMake").onclick = function () { tvCopyDialog(d); };
    row.querySelectorAll("[data-tvc]").forEach(function (b) {
      b.onclick = function () {
        var what = b.getAttribute("data-tvc");
        if (what === "cancel" && !confirm("Stop making TV copies? The copy being made is deleted (only that unfinished file); copies already made stay.")) return;
        post("/api/tvcopy/" + what, what === "cancel" ? { id: "all" } : {}).then(function () { tvcShowRow(d); }).catch(fail);
      };
    });
    row.querySelectorAll("[data-tvc-remove]").forEach(function (b) {
      b.onclick = function () {
        if (!confirm("Remove this TV copy? It's AniBox's own file in its TV copies folder; the original video stays as it is.")) return;
        post("/api/tvcopy/remove", { show: d.id, key: b.getAttribute("data-tvc-remove") }).then(function (x) {
          toast(x.removed ? "TV copy removed." : x.kept ? "Kept: the copy changed since AniBox made it." : "Nothing to remove.");
          tvcShowRow(d);
        }).catch(fail);
      };
    });
    if (s.jobs.length) tvc.showTimer = setTimeout(function () { tvcShowRow(d); }, s.paused ? 4000 : 1500);
  }).catch(function () {});
}

// ---------- "Make TV copies": preview first, then the queue
function tvCopyDialog(d) {
  openModal('<div class="kicker">TV copies</div><h2>Make TV copies of ' + esc(d.title) + "</h2>" +
    '<p class="muted">The Shield\'s hardware (and phones) can\'t decode 10-bit H.264 (“Hi10P”), common in older anime releases; Plex then converts it slowly on the Shield, and CastApp TV can\'t play it. ' +
    "AniBox can make a copy the TV plays directly: 8-bit H.264, at most 1080p, with every audio track, subtitle track (styled ASS stays styled), chapter and font of the original. " +
    "The copies go into their own folder, never next to your videos, so nothing in your anime folders changes. Play on TV then sends the copy.</p>" +
    '<div id="tvcBody" class="muted">Looking at the episodes …</div>' +
    '<div class="row" style="margin-top:16px;justify-content:flex-end"><button class="btn" data-close>Close</button><button class="btn primary" id="tvcGo" disabled>Make copies</button></div>');
  var plan = null;
  function picked() {
    return Array.prototype.filter.call($("modalBox").querySelectorAll("[data-tvc-key]"), function (x) { return x.checked; }).map(function (x) { return x.getAttribute("data-tvc-key"); });
  }
  function totals() {
    if (!plan || !$("tvcGo")) return;
    var keys = picked(), est = 0, secs = 0;
    plan.items.forEach(function (it) { if (keys.indexOf(it.key) >= 0) { est += it.est || 0; secs += it.duration || 0; } });
    if ($("tvcEst")) $("tvcEst").textContent = keys.length ? "about " + tvcBytes(est) + " (" + tvcBytes(plan.free) + " free there)" : "–";
    if ($("tvcTime")) $("tvcTime").textContent = keys.length && plan.speed ? tvcTime(secs / plan.speed) + (plan.measured ? " (from your last copies)" : " (a first guess; AniBox learns this PC's speed)") : "–";
    $("tvcGo").disabled = !keys.length || !!plan.problem || !plan.encoder;
    $("tvcGo").textContent = keys.length ? "Make " + tvcCopies(keys.length) : "Make copies";
  }
  function draw(p) {
    plan = p;
    var body = $("tvcBody"); if (!body) return;
    body.classList.remove("muted");
    if (!p.ffmpeg) {
      body.innerHTML = '<div class="note">TV copies need ffmpeg. <a href="#/settings">Download ffmpeg</a> under Settings → Player, then try again.</div>';
      return;
    }
    var offer = p.items.filter(function (it) { return it.offer; });
    var ready = p.items.filter(function (it) { return it.state === "ready"; });
    var fine = p.items.filter(function (it) { return !it.offer && it.state !== "ready"; });
    var enc = p.encoder ? esc(p.encoder.name) + (p.encoder.note ? ' <span class="muted">· ' + esc(p.encoder.note) + "</span>" : "") : esc(p.encoderError || "–");
    body.innerHTML = (offer.length ? "<p><b>" + plural(offer.length, "episode") + " can't play directly on the TV.</b> Tick the ones to copy.</p>" :
        "<p><b>Nothing to copy.</b> " + (ready.length ? "Every episode that needs one has a TV copy." : "Every episode plays directly on the TV.") + "</p>") +
      (offer.length ? '<div class="tw" style="max-height:34vh;overflow:auto"><table class="tvc-list"><tbody>' + offer.map(function (it) {
        return '<tr title="' + esc(it.why) + '"><td><input type="checkbox" data-tvc-key="' + esc(it.key) + '" checked aria-label="Copy ' + esc(it.file) + '"></td><td>' + esc(it.file) +
          '<div class="muted">' + esc(it.video) + (it.state === "outdated" ? " · its copy is outdated (the original changed)" : "") + "</div></td>" +
          '<td class="num muted">about ' + tvcBytes(it.est) + "</td></tr>";
      }).join("") + "</tbody></table></div>" : "") +
      (ready.length || fine.length ? '<p class="muted" style="font-size:13px;margin:8px 0 0">' + [ready.length ? tvcCopies(ready.length) + " ready already" : "", fine.length ? plural(fine.length, "episode") + " play directly" : ""].filter(Boolean).join(" · ") + "</p>" : "") +
      (offer.length ? '<dl class="tvc-facts"><dt>Copies go to</dt><dd><code>' + esc(p.folder) + "</code><br><span class=\"muted\">as " + esc("<library>\\<show>\\<same name>.mkv") + " · change it in Settings → TV copies</span></dd>" +
        "<dt>Made with</dt><dd>" + enc + "</dd><dt>Sound</dt><dd>" + (p.audio === "aac" ? "DTS and TrueHD become AAC stereo" : "DTS and TrueHD become Dolby Digital (AC3, keeps 5.1)") + "; AAC, AC3, E-AC3, MP3, FLAC and Opus stay as they are</dd>" +
        '<dt>Size</dt><dd id="tvcEst"></dd><dt>Time</dt><dd id="tvcTime"></dd></dl>' : "") +
      (p.problem ? '<div class="note">' + esc(p.problem) + ' <a href="#/settings">Settings → TV copies</a></div>' : "") +
      (offer.length && !p.roomOk ? '<div class="note">There may not be enough room in that folder for all of them. AniBox checks before each copy and pauses if the drive gets full.</div>' : "") +
      (offer.length ? '<p class="muted" style="font-size:13px">One file at a time, at low priority, so the PC stays usable. You can pause or cancel any time (Settings → TV copies); Cancel deletes only the unfinished copy. Undo on the History page or on this show removes the copies again.</p>' : "");
    body.querySelectorAll("[data-tvc-key]").forEach(function (c) { c.onchange = totals; });
    totals();
  }
  post("/api/tvcopy/preview", { show: d.id }).then(function wait() {
    api("/api/tvcopy/preview?id=" + encodeURIComponent(d.id)).then(function (p) {
      if (!$("tvcBody")) return;
      if (p.state === "loading") { $("tvcBody").textContent = "Looking at the episodes … " + p.done + " of " + p.total; setTimeout(wait, 700); return; }
      if (p.state === "error") { $("tvcBody").innerHTML = '<div class="note">' + esc(p.error) + "</div>"; return; }
      draw(p);
    }).catch(fail);
  }).catch(fail);
  $("tvcGo").onclick = function () {
    $("tvcGo").disabled = true;
    post("/api/tvcopy/start", { show: d.id, token: plan.token, keys: picked() }).then(function (r) {
      closeModal();
      toast(tvcCopies(r.queued) + " queued. AniBox makes them one at a time; you can keep using it.");
      tvcShowRow(d);
    }).catch(function (e) { $("tvcGo").disabled = false; fail(e); });
  };
}

// ---------- Settings → TV copies
settingsPanels.push(function (box) {
  box.innerHTML = '<section class="panel" style="margin-top:18px"><h2>TV copies</h2>' +
    '<p class="muted">Copies of videos the TV can\'t play as they are (mostly 10-bit H.264, “Hi10P”), made on this PC with ffmpeg when you click <b>Make TV copies</b> on a show. ' +
    "They go into their own folder, never next to your videos. Play on TV sends the copy instead of the original. Only files AniBox made and lists are ever deleted; anything else in the folder stays.</p>" +
    '<div id="tvcBox" class="muted">Loading …</div></section>';
  tvcPanel(true);
});
function tvcPanel(full) {
  clearTimeout(tvc.panelTimer);
  api("/api/tvcopy").then(function (st) {
    var box = $("tvcBox");
    if (!box || currentPage !== "settings") return;
    if (full || !$("tvcDir")) tvcForm(box, st);
    tvcInfo(st);
    if (st.current || st.detecting || (st.queue.length && !st.paused)) tvc.panelTimer = setTimeout(function () { tvcPanel(false); }, 1500);
  }).catch(function (e) { var box = $("tvcBox"); if (box) box.textContent = e.message; });
}
function tvcForm(box, st) {
  box.className = "";
  var opt = function (v, label, cur) { return '<option value="' + v + '"' + (v === cur ? " selected" : "") + ">" + esc(label) + "</option>"; };
  box.innerHTML =
    '<div class="field" style="display:block"><div class="lbl">Folder for the copies<small>' + (st.folderSetting ? "Your choice." : "The standard folder in AniBox's data folder.") +
    " Copies are named like the original: <code>&lt;library&gt;\\&lt;show&gt;\\&lt;same name&gt;.mkv</code>. Not inside a library folder (they would show up as extra episodes) or the Add new videos folder.</small></div>" +
    '<div class="tvc-dir"><input class="input" id="tvcDir" value="' + esc(st.folder) + '" spellcheck="false" aria-label="Folder for the copies" title="Type or paste a folder, then press Enter">' +
    '<button class="btn small" id="tvcPick">Change …</button>' + (st.folderSetting ? '<button class="btn small" id="tvcStd">Standard folder</button>' : "") +
    '<button class="btn small" id="tvcOpen">Open folder</button></div><div id="tvcProblem"></div></div>' +
    '<div class="field"><div class="lbl">Made with<small id="tvcEncInfo"></small></div><select class="select" id="tvcEnc" aria-label="Encoder">' +
    opt("auto", "Automatic (graphics card if it works)", st.choice) + opt("nvidia", "NVIDIA graphics (NVENC)", st.choice) + opt("intel", "Intel graphics (Quick Sync)", st.choice) +
    opt("amd", "AMD graphics (AMF)", st.choice) + opt("cpu", "The processor (x264, slower)", st.choice) + '</select><button class="btn small" id="tvcTest">Test again</button></div>' +
    '<div class="field"><div class="lbl">Sound the TV can\'t play<small>DTS, TrueHD and a few rarer formats. Every other track (AAC, AC3, E-AC3, MP3, FLAC, Opus) is copied as it is, with its language.</small></div>' +
    '<select class="select" id="tvcAudio" aria-label="Sound">' + opt("ac3", "Dolby Digital (AC3, keeps 5.1)", st.audio) + opt("aac", "AAC stereo (smaller)", st.audio) + "</select></div>" +
    '<div class="field"><div class="lbl">Copies<small id="tvcUse"></small></div><button class="btn small danger" id="tvcRemoveAll">Remove all TV copies</button></div>' +
    '<div id="tvcQueue"></div>' +
    '<details class="guide"><summary>Use the copies in Plex too</summary><ol><li>Choose a copies folder on one of the Shield\'s drives, outside the folders AniBox reads.</li>' +
    "<li>In Plex, add a new TV library with the folder <code>&lt;copies folder&gt;\\Anime</code> (the library's name inside it).</li>" +
    "<li>Plex then plays the copies without converting. AniBox changes nothing in Plex itself.</li></ol></details>";
  var saveDir = function (v) { tvcSave({ dir: v }); };
  $("tvcDir").onkeydown = function (e) { if (e.key === "Enter") this.blur(); };
  $("tvcDir").onchange = function () { saveDir(this.value.trim()); };
  $("tvcPick").onclick = function () {
    toast("A folder window opens (it may be behind this one) …");
    post("/api/pick-folder").then(function (r) { if (r.path) saveDir(r.path); }).catch(fail);
  };
  if ($("tvcStd")) $("tvcStd").onclick = function () { saveDir(""); };
  $("tvcOpen").onclick = function () { post("/api/tvcopy/open").catch(fail); };
  $("tvcEnc").onchange = function () { tvcSave({ encoder: this.value }); };
  $("tvcAudio").onchange = function () { tvcSave({ audio: this.value }); };
  $("tvcTest").onclick = function () { post("/api/tvcopy/detect").then(function () { $("tvcEncInfo").textContent = "Testing …"; setTimeout(function () { tvcPanel(false); }, 800); }).catch(fail); };
  $("tvcRemoveAll").onclick = function () {
    post("/api/tvcopy/remove-all", { check: true }).then(function (c) {
      if (!c.copies) { toast("There are no TV copies."); return; }
      if (!confirm("Remove all " + tvcCopies(c.copies) + " (" + tvcBytes(c.bytes) + ")? Only files AniBox made and lists are deleted; your original videos and anything else in the folder stay.")) return;
      post("/api/tvcopy/remove-all").then(function (r) {
        toast((r.removed || 0) + " removed" + (r.kept ? ", " + r.kept + " kept because they changed" : "") + ".");
        tvcPanel(false);
      }).catch(fail);
    }).catch(fail);
  };
}
function tvcInfo(st) {
  if ($("tvcProblem")) $("tvcProblem").innerHTML = st.problem ? '<div class="note">' + esc(st.problem) + "</div>" : "";
  var e = st.encoder, info = "";
  if (!st.ffmpeg) info = "Needs ffmpeg (Settings → Player → Download ffmpeg).";
  else if (st.detecting) info = "Testing the graphics card …";
  else if (e) {
    var short = { nvidia: "NVIDIA", intel: "Intel", amd: "AMD" };
    var tried = Object.keys(e.tested || {}).filter(function (k) { return k !== e.kind && !e.tested[k].ok; });
    var said = tried.map(function (k) { return short[k] + ": " + e.tested[k].said; }).join("\n");
    info = "Uses " + e.name + "." + (e.note ? " " + e.note : tried.length ? " No " + tried.map(function (k) { return short[k]; }).join(", ").replace(/, ([^,]*)$/, " or $1") +
      " graphics encoder works on this PC." : "");
    if ($("tvcEncInfo")) $("tvcEncInfo").title = said;
  } else info = "AniBox tests which one works the first time it makes a copy (a 1-second test).";
  if ($("tvcEncInfo")) $("tvcEncInfo").textContent = info;
  if ($("tvcUse")) $("tvcUse").textContent = (st.copies ? tvcCopies(st.copies) + ", " + tvcBytes(st.bytes) : "No TV copies yet") + " · " + tvcBytes(st.free) + " free on that drive.";
  if ($("tvcRemoveAll")) $("tvcRemoveAll").disabled = !st.copies || !!st.current;
  var q = $("tvcQueue"); if (!q) return;
  var html = "";
  if (st.current || st.queue.length) {
    html += '<div class="field" style="display:block"><div class="lbl">Making copies' + (st.paused ? " · paused" : "") + "<small>" + (st.queue.length ? st.queue.length + " waiting after this one." : "") + "</small></div>" +
      (st.current ? tvcJobLine(st.current) : "") + (st.message ? '<div class="note">' + esc(st.message) + "</div>" : "") +
      (st.queue.length ? '<div class="muted" style="font-size:13px">' + st.queue.slice(0, 6).map(function (j) { return esc((j.title || "") + " · " + (j.label || j.file)); }).join("<br>") + (st.queue.length > 6 ? "<br>…" : "") + "</div>" : "") +
      '<div class="row" style="margin-top:8px">' + (st.paused ? '<button class="btn small primary" data-tvcq="resume">Resume</button>' : '<button class="btn small" data-tvcq="pause">Pause</button>') +
      '<button class="btn small" data-tvcq="cancel">Cancel all</button></div></div>';
  }
  var recent = (st.recent || []).filter(function (j) { return j.state === "failed"; }).slice(0, 3);
  if (recent.length) html += '<div class="note">' + recent.map(function (j) { return esc((j.title || "") + " · " + (j.label || j.file) + ": " + j.error); }).join("<br>") + "</div>";
  q.innerHTML = html;
  q.querySelectorAll("[data-tvcq]").forEach(function (b) {
    b.onclick = function () {
      var what = b.getAttribute("data-tvcq");
      if (what === "cancel" && !confirm("Stop making TV copies? The copy being made is deleted (only that unfinished file); copies already made stay.")) return;
      post("/api/tvcopy/" + what, what === "cancel" ? { id: "all" } : {}).then(function () { tvcPanel(false); }).catch(fail);
    };
  });
}
function tvcSave(b) {
  return post("/api/tvcopy/settings", b).then(function () { toast("Saved"); tvcPanel(true); }).catch(function (e) { fail(e); tvcPanel(true); });
}
