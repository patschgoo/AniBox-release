/* AniBox window · Series and movie info from TMDB (routes_tmdb.py): the Settings panel, the box on a show
   page and "Wrong match?". Only for series and movies (anime has MyAnimeList) and only with your own key.
   The window never talks to TMDB itself; AniBox asks and serves the posters.
   Plain scripts sharing one page: loaded in order by index.html. */
"use strict";

var TMDB_KIND = { tv: "Series", movie: "Movie" };

// ---------- Settings → Series and movie info (TMDB)
function tmdbSettings(box) {
  box.innerHTML = '<section class="panel" id="tmdbPanel"><h2>Series and movie info (TMDB)</h2><div class="muted">…</div></section>';
  api("/api/tmdb").then(function (d) { tmdbDrawSettings(box, d); }).catch(function (e) { box.querySelector(".muted").textContent = e.message; });
}
function tmdbDrawSettings(box, d) {
  if (!box.isConnected) return;
  var j = d.job || {}, c = d.counts || {};
  var running = j.state === "running";
  var html = '<section class="panel" id="tmdbPanel"><h2>Series and movie info (TMDB)</h2>' +
    '<p class="muted">Optional: posters, descriptions, genres and episode titles for your <b>series and movies</b> (anime gets its info from MyAnimeList). ' +
    "They come from TMDB, a free movie and TV database. TMDB needs a free key of your own:</p>" +
    '<ol class="muted tmdb-steps"><li>Make a free account on <a href="https://www.themoviedb.org/signup" target="_blank" rel="noopener noreferrer">themoviedb.org ↗</a> and log in (on a computer, not a phone).</li>' +
    '<li>Open <a href="https://www.themoviedb.org/settings/api" target="_blank" rel="noopener noreferrer">Settings → API ↗</a> and ask for an API key for personal use. TMDB asks a few short questions about your app: “AniBox, my own video player” is enough.</li>' +
    "<li>Copy the <b>API Read Access Token</b> (the long one) and paste it here. The shorter “API Key” works too.</li></ol>" +
    '<div class="field"><div class="lbl">Your TMDB key<small>' + (d.hasKey ? "Saved (" + esc(d.keyHint) + "). Paste a new one to replace it." : "Not set: AniBox doesn't ask TMDB anything.") + "</small></div>" +
    '<div class="row"><input class="input wide" id="tmdbKey" type="password" placeholder="Paste your key here" autocomplete="off" spellcheck="false" aria-label="TMDB key">' +
    '<button class="btn small primary" id="tmdbSave">Save</button>' + (d.hasKey ? '<button class="btn small" id="tmdbRemove">Remove</button>' : "") + "</div></div>";
  if (d.hasKey) {
    html += '<div class="field"><div class="lbl">Your series and movies<small>' + (d.shows ? plural(d.shows, "series and movie folder") + " · " + c.found + " found on TMDB" +
      (c.notFound ? " · " + c.notFound + " not found (use “Wrong match?” on its page)" : "") + (c.open ? " · " + c.open + " not looked up yet" : "") :
      "None yet. Libraries count as series or movies under Libraries to show.") + "</small></div>" +
      '<div class="row"><button class="btn small" id="tmdbFetch"' + (running || !d.shows ? " disabled" : "") + ">Get info now</button>" +
      '<button class="btn small" id="tmdbRefresh"' + (running || !d.shows ? " disabled" : "") + ' title="Ask TMDB again for everything, also what was fetched less than 30 days ago">Fetch everything again</button></div></div>' +
      (j.message ? '<div class="' + (j.state === "error" ? "note" : "muted") + '" style="margin:6px 0">' + esc(j.message) + (running && j.total ? " " + j.done + " of " + j.total + "." : "") + "</div>" : "");
  }
  html += '<p class="muted" style="font-size:13px">AniBox sends TMDB only the names of your series and movie folders (to find them) and then asks for their info. ' +
    "Posters are fetched by AniBox and kept on this PC for 30 days. Your files stay as they are.</p>" +
    '<p class="muted" style="font-size:13px">' + esc(d.attribution) + "</p></section>";
  box.innerHTML = html;
  $("tmdbSave").onclick = function () {
    var v = $("tmdbKey").value.trim();
    if (!v) { toast("Paste your key first.", true); return; }
    this.disabled = true;
    post("/api/tmdb/key", { key: v }).then(function (r) { toast(r.message); tmdbSettings(box); }).catch(function (e) { fail(e); tmdbSettings(box); });
  };
  $("tmdbKey").onkeydown = function (e) { if (e.key === "Enter") $("tmdbSave").click(); };
  if ($("tmdbRemove")) $("tmdbRemove").onclick = function () {
    if (!confirm("Remove your TMDB key? AniBox then stops asking TMDB, and series and movies show no TMDB info.")) return;
    post("/api/tmdb/key", { key: "" }).then(function (r) { toast(r.message); tmdbSettings(box); }).catch(fail);
  };
  [["tmdbFetch", false], ["tmdbRefresh", true]].forEach(function (b) {
    if ($(b[0])) $(b[0]).onclick = function () {
      post("/api/tmdb/fetch", { refresh: b[1] }).then(function () { tmdbSettings(box); }).catch(fail);
    };
  });
  clearTimeout(tmdbDrawSettings.t);
  if (running) tmdbDrawSettings.t = setTimeout(function () {
    if (currentPage === "settings" && box.isConnected) api("/api/tmdb").then(function (d2) { tmdbDrawSettings(box, d2); }).catch(function () {});
  }, 1500);
}
settingsPanels.push(tmdbSettings);

// ---------- show page: "From TMDB" (description, genres, year) for series and movies
function tmdbShowPanel(box, d) {
  api("/api/tmdb/show?id=" + encodeURIComponent(d.id)).then(function (r) {
    if (!box.isConnected || !showData || showData.id !== d.id) return;
    if (!r.applies || !r.hasKey) { box.innerHTML = ""; return; }
    var x = r.details, m = r.match || {};
    var html = "";
    if (x) {
      var facts = [TMDB_KIND[x.kind], x.year, x.runtime ? x.runtime + " min" : "",
        x.kind === "tv" && x.seasons && x.seasons.length ? plural(x.seasons.filter(function (s) { return s.n > 0; }).length, "season") + " on TMDB" : "", x.status].filter(Boolean);
      html = '<section class="panel plexpanel tmdbpanel"><div><div class="kicker">From TMDB' + (m.manual ? " · picked by hand" : "") + "</div>" +
        "<h3>" + esc(x.title) + (x.original && x.original !== x.title ? ' <span class="muted">· ' + esc(x.original) + "</span>" : "") + "</h3>" +
        '<div class="muted" style="font-size:13px">' + facts.map(esc).join(" · ") + "</div>" +
        (x.tagline ? '<p class="muted" style="font-style:italic;margin:8px 0 0">' + esc(x.tagline) + "</p>" : "") +
        (x.overview ? '<p class="syn">' + esc(x.overview) + "</p>" : '<p class="muted">TMDB has no description for this.</p>') +
        '<div style="margin:6px 0 10px">' + (x.genres || []).map(function (g) { return '<span class="tag">' + esc(g) + "</span>"; }).join("") + "</div>" +
        '<div class="row"><a class="btn small" href="' + esc(x.url) + '" target="_blank" rel="noopener noreferrer">TMDB ↗</a><button class="btn small" data-tmdb-match>Wrong match?</button></div>' +
        '<div class="muted" style="font-size:12px;margin-top:10px">' + esc(r.attribution) + "</div></div></section>";
      var head = view.querySelector(".showhead .poster");
      if (x.posterUrl && head && !head.querySelector("img")) head.insertAdjacentHTML("beforeend", '<img alt="" src="' + esc(x.posterUrl) + '" onerror="this.remove()">');
    } else if (r.state === "loading") {
      html = '<section class="panel tmdbpanel"><div class="kicker">TMDB</div><p class="muted">Looking up “' + esc(r.query) + "” on TMDB …</p></section>";
    } else if (m && !m.id && (m.tried || m.manual)) {
      html = '<section class="panel tmdbpanel"><div class="kicker">TMDB</div><p class="muted">' + (m.manual ? "Marked by hand: not on TMDB." : "TMDB doesn't seem to know “" + esc(r.query) + (r.year ? " (" + r.year + ")" : "") + "”.") +
        '</p><button class="btn small" data-tmdb-match>' + (m.manual ? "Change" : "Find it by hand") + "</button></section>";
    }
    if (r.error) html += '<div class="note">' + esc(r.error) + "</div>";
    box.innerHTML = html;
    var b = box.querySelector("[data-tmdb-match]");
    if (b) b.onclick = function () { tmdbMatchDialog(d, r, function () { show(d.id); }); };
    if (r.state === "loading") setTimeout(function () { if (box.isConnected) tmdbShowPanel(box, d); }, 1500);
  }).catch(function () { box.innerHTML = ""; });
}
showPanels.push(tmdbShowPanel);

// ---------- "Wrong match?": search TMDB and pick the right entry
function tmdbMatchDialog(d, r, done) {
  var kind = (r.match && r.match.kind) || r.kind;
  openModal('<div class="kicker">TMDB · match by hand</div><h2>' + esc(d.folder) + "</h2>" +
    '<p class="muted">Search TMDB by title (add the year like “Title (2019)” to narrow it down). AniBox remembers your choice; the folder and its files stay exactly as they are.</p>' +
    '<div class="row" style="margin-bottom:10px"><div class="seg" id="tmKind"><button data-k="tv"' + (kind === "tv" ? ' class="on"' : "") + '>Series</button><button data-k="movie"' + (kind === "movie" ? ' class="on"' : "") + ">Movie</button></div></div>" +
    '<form id="tmForm" autocomplete="off"><label class="search" style="max-width:none"><input id="tmQ" type="search" placeholder="Title" value="' + esc(r.query + (r.year ? " (" + r.year + ")" : "")) + '"></label></form>' +
    '<div class="results" id="tmRes"></div>' +
    '<div class="row" style="margin-top:18px;justify-content:space-between"><div class="row">' +
    '<button class="btn small" id="tmNone">Not on TMDB</button>' + (r.match && r.match.manual ? '<button class="btn small" id="tmAuto">Back to automatic</button>' : "") +
    '</div><button class="btn small" data-close>Cancel</button></div>');
  function send(body) {
    body.show = d.id;
    post("/api/tmdb/match", body).then(function () {
      closeModal(); toast(body.auto ? "Back to the automatic match." : body.none ? "Marked as not on TMDB." : "Matched. Loading the info …");
      if (done) done();
    }).catch(fail);
  }
  function search() {
    var q = $("tmQ").value.trim(); if (!q) { $("tmRes").innerHTML = ""; return; }
    $("tmRes").innerHTML = '<div class="muted">Searching TMDB …</div>';
    api("/api/tmdb/search?kind=" + kind + "&q=" + encodeURIComponent(q)).then(function (s) {
      if (!$("tmRes")) return;
      $("tmRes").innerHTML = s.results.map(function (x) {
        var cur = r.match && r.match.id === x.id && r.match.kind === x.kind;
        return '<div class="result"><div><div class="t">' + esc(x.title) + (x.original && x.original !== x.title ? ' <span class="muted">· ' + esc(x.original) + "</span>" : "") + (cur ? ' <span class="tag">now</span>' : "") + "</div>" +
          '<div class="s">' + [TMDB_KIND[x.kind], x.year].filter(Boolean).map(esc).join(" · ") + ' · <a href="' + esc(x.url) + '" target="_blank" rel="noopener noreferrer">open ↗</a>' +
          (x.overview ? '<div style="margin-top:4px">' + esc(x.overview.length > 180 ? x.overview.slice(0, 180) + " …" : x.overview) + "</div>" : "") + "</div></div>" +
          '<button class="btn small primary" data-tm="' + x.id + '">Use this</button></div>';
      }).join("") || '<div class="muted">Nothing found. Try fewer words, or the other kind (Series / Movie).</div>';
    }).catch(function (e) { if ($("tmRes")) $("tmRes").innerHTML = '<div class="note">' + esc(e.message) + "</div>"; });
  }
  $("tmForm").onsubmit = function (e) { e.preventDefault(); search(); };
  $("tmKind").onclick = function (e) {
    var b = e.target.closest("[data-k]"); if (!b) return;
    kind = b.getAttribute("data-k");
    this.querySelectorAll("[data-k]").forEach(function (x) { x.classList.toggle("on", x === b); });
    search();
  };
  $("tmRes").onclick = function (e) { var b = e.target.closest("[data-tm]"); if (b) send({ id: Number(b.getAttribute("data-tm")), kind: kind }); };
  $("tmNone").onclick = function () { send({ none: true }); };
  if ($("tmAuto")) $("tmAuto").onclick = function () { send({ auto: true }); };
  search();
}
