/* AniBox window · Folder watching (routes_watchfolders.py): "3 new videos in Downloads → Add them" on Home and
   the Library page, and the settings for it. AniBox only looks; nothing moves until you click Add.
   Plain scripts sharing one page: loaded in order by index.html. */
"use strict";

var watchState = null, watchSeen = -1;

function watchNoteHtml(s) {
  var w = s && s.inbox;
  if (!w || !w.enabled || !w.count) return "";
  var names = (w.files || []).slice(0, 3).join(", ") + (w.count > 3 ? ", …" : "");
  return '<div class="banner" id="watchNote"><div style="min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="' + esc((w.files || []).join("\n")) + '"><b>' +
    plural(w.count, "new video") + " in " + esc(w.where) + "</b>" +
    ' <span class="muted">· ' + esc(names) + "</span></div>" +
    '<div class="row" style="flex-wrap:nowrap"><a class="btn small primary" href="#/import">Add them →</a><button class="btn small" data-watch-later title="Hide these until other videos come">Not now</button></div></div>';
}
function watchWire(el) {
  var b = el && el.querySelector("[data-watch-later]");
  if (b) b.onclick = function () {
    post("/api/watch/dismiss").then(function (s) { watchState = s; watchSeen = s.inbox.count; var n = $("watchNote"); if (n) n.remove(); }).catch(fail);
  };
}
// Home (homePanels: a box above "Continue watching")
homePanels.push(function (box) {
  box.id = "watchHome";
  function draw() {
    if (!document.body.contains(box)) return;
    box.innerHTML = watchNoteHtml(watchState);
    watchWire(box);
  }
  draw();
  watchPoll().then(draw);
});
// Library page: the same notice above the sections (drawn whenever the page is drawn)
function watchLibrary() {
  if (currentPage !== "library" || $("watchNote")) return;
  var head = view.querySelector(".libhead");
  var html = watchNoteHtml(watchState);
  if (!head || !html) return;
  head.insertAdjacentHTML("beforebegin", html);
  watchWire($("watchNote").parentNode);
}
new MutationObserver(watchLibrary).observe(view, { childList: true });

function watchPoll() {
  return api("/api/watch").then(function (s) {
    var n = s.inbox.enabled ? s.inbox.count : 0;
    if (watchSeen >= 0 && n > watchSeen && currentPage !== "import") toast(plural(n - watchSeen, "new video") + " in " + s.inbox.where + ". Library → Add new videos.");
    watchSeen = n;
    watchState = s;
    var note = $("watchNote"), html = watchNoteHtml(s);
    if (note && !html) note.remove();
    else if (note && html) { note.outerHTML = html; watchWire($("watchNote").parentNode); }
    else if (!note && html) {
      if (currentPage === "library") watchLibrary();
      else if ($("watchHome")) { $("watchHome").innerHTML = html; watchWire($("watchHome")); }
    }
    if (currentPage === "settings") watchSettingsInfo(s);
    return s;
  }).catch(function () {});
}
setInterval(watchPoll, 30000);
watchPoll();

// Settings → Watching for new videos
settingsPanels.push(function (box) {
  var s = (settingsData && settingsData.settings) || {};
  var on = s.watch_inbox !== false;
  box.innerHTML = '<section class="panel" style="margin-top:18px"><h2>Watching for new videos</h2>' +
    '<p class="muted">While AniBox is open it can notice new videos by itself. It only looks; nothing is moved or renamed until you click <b>Add</b>.</p>' +
    '<div class="field"><div class="lbl">New videos in the inbox<small>Every 30 seconds AniBox looks at your “Add new videos” folder (Downloads, unless you chose others). ' +
    "When finished videos are there (not still downloading), Home and the Library say so.</small></div>" +
    '<button class="switch' + (on ? " on" : "") + '" id="watchInbox" role="switch" aria-checked="' + on + '" aria-label="Notice new videos in the inbox"></button></div>' +
    '<div class="field"><div class="lbl">Rescan the library by itself<small>Every this many minutes, a quick rescan of your library folders (0 = off). Never while something plays. ' +
    'New episodes it finds count as new, as with every scan.</small><small id="watchRescanInfo"></small></div>' +
    '<input class="input num" type="number" min="0" max="1440" step="5" id="watchRescan" value="' + esc(s.auto_rescan_minutes || 0) + '" aria-label="Minutes between automatic rescans"></div></section>';
  $("watchInbox").onclick = function () {
    var b = this, v = !b.classList.contains("on");
    save("watch_inbox", v).then(function () { b.classList.toggle("on", v); b.setAttribute("aria-checked", v); watchPoll(); });
  };
  $("watchRescan").onchange = function () {
    var v = Math.max(0, parseInt(this.value, 10) || 0);
    if (v && v < 5) v = 5;
    this.value = v;
    save("auto_rescan_minutes", v).then(watchPoll);
  };
  watchPoll();
});
function watchSettingsInfo(s) {
  var el = $("watchRescanInfo"); if (!el) return;
  var r = s.rescan || {};
  el.textContent = !r.minutes ? "" : r.waiting === "playing" ? "Due now; waits until playback stops." :
    (r.last ? "Last automatic rescan " + ago(r.last) + ". " : "") + (r.next ? "Next in about " + Math.max(1, Math.round((r.next - Date.now() / 1000) / 60)) + " min." : "");
}
