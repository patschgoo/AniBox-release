/* AniBox window · Series playlists of Internet Archive videos (iaplaylists.py): the list, the editor
   (make one, pick series and items) and a playlist's own page. archive.js sends #/archive/series/… here:
   #/archive/series, #/archive/series/new[/<item>], #/archive/series/<id>, #/archive/series/<id>/edit[/<item>].
   Episode rows carry data-ia-key, and iaCacheDecorate(list) (the cache, if there) adds its badges to them.
   Plain scripts sharing one page: loaded in order by index.html. */
"use strict";

var iaPl = { page: null, edit: null, q: "", hideWatched: false, showHidden: false, preview: null, order: null, dragKey: "", n: 0, pt: 0 };
var PL_SORTS = [["date", "Air date"], ["episode", "Season & episode"], ["name", "File name"], ["added", "Added"], ["manual", "Manual"]];
var PL_HINT = { date: "By the date in the file name. Episodes without a date go to the end.",
  episode: "By S01E01, S01E02 … in the file name. Episodes without a number go to the end.",
  name: "By file name, A to Z (2 before 10).", added: "In the order they came into the playlist.",
  manual: "Your own order. It stays as it is; new episodes go to the end, marked “new”." };
var PL_EYE = '<svg viewBox="0 0 24 24"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>';
var PL_EYE_OFF = '<svg viewBox="0 0 24 24"><path d="M3 3l18 18M10.6 5.1A10.6 10.6 0 0 1 12 5c6.4 0 10 7 10 7a17 17 0 0 1-3.2 4.1M6.6 6.6C3.9 8.4 2 12 2 12s3.6 7 10 7c1.7 0 3.2-.5 4.5-1.2"/></svg>';

function plEnc(s) { return encodeURIComponent(s); }
function plSortLabel(s) { var f = PL_SORTS.filter(function (x) { return x[0] === s; })[0]; return f ? f[1] : s; }

// ---------- router (archive.js)
function iaSeries(parts) {
  clearTimeout(iaPl.pt);
  var a = decodeURIComponent(parts[0] || ""), b = parts[1] || "";
  if (a === "new") return plEditor("", decodeURIComponent(parts.slice(1).join("/")));
  if (a && b === "edit") return plEditor(a, decodeURIComponent(parts.slice(2).join("/")));
  if (a) return plPage(a);
  return plList();
}

// ---------- all playlists
function plList() {
  render(iaHead("series") + '<div id="plNotice"></div>' +
    '<div class="section" style="margin-top:0"><div><h2>Series playlists</h2><div class="muted" style="margin-top:4px">Episodes from one or more archive.org items, in the order they aired. They play straight from archive.org.</div></div>' +
    '<a class="btn primary" href="#/archive/series/new">New series playlist</a></div><div id="plList"><div class="empty">Loading …</div></div>');
  iaWireHead();
  iaPoll();
  api("/api/ia/playlists").then(function (r) {
    if (!$("plList")) return;
    if (r.notice) $("plNotice").innerHTML = '<div class="note">' + esc(r.notice) + "</div>";
    $("plList").innerHTML = r.playlists.length ? '<div class="grid ia-grid">' + r.playlists.map(plCard).join("") + "</div>" : plIntroHtml();
  }).catch(function (e) { if ($("plList")) $("plList").innerHTML = '<div class="note">' + esc(e.message) + "</div>"; });
}
function plIntroHtml() {
  return '<section class="panel" style="max-width:820px"><h2>Make your first series playlist</h2>' +
    '<p class="muted">Many archive.org items hold a whole season or a year of a show. A series playlist puts their episodes in order, ' +
    "even from several items: for example two shows of the same year, mixed by the date they aired.</p>" +
    '<ol class="pl-steps"><li>Give it a name and paste one or more archive.org links.</li><li>AniBox groups the videos by series (the part of the file name before a date or S01E01). Tick the ones you want.</li>' +
    "<li>Pick the order: by air date, season &amp; episode, file name, or your own.</li></ol>" +
    '<p class="muted">Tip: on any item page, click <b>Make a series playlist</b>.</p><a class="btn primary" href="#/archive/series/new">New series playlist</a></section>';
}
function plCard(p) {
  var pct = p.episodes ? Math.round(100 * p.watched / p.episodes) : 0;
  var nx = p.next ? (p.next.position ? "Go on: " : "Next: ") + p.next.label : p.episodes ? "All watched" : "Nothing to play";
  return '<a class="card" href="#/archive/series/' + plEnc(p.id) + '"><div class="poster ph"><div class="ini">' + esc(p.name) + "</div>" +
    (p.img ? '<img loading="lazy" alt="" src="' + esc(p.img) + '" onerror="this.remove()">' : "") +
    (p.items.length > 1 ? '<span class="stack">' + p.items.length + " items</span>" : "") +
    (p.episodes && p.watched >= p.episodes ? '<span class="done">Watched</span>' : pct ? '<div class="bar0"><i style="width:' + pct + '%"></i></div>' : "") + "</div>" +
    '<div class="t">' + esc(p.name) + '</div><div class="s">' + esc(plural(p.episodes, "episode") + " · " + p.watched + "/" + p.episodes + " · " + p.sortLabel) + "</div>" +
    '<div class="s">' + esc(nx) + "</div></a>";
}

// ---------- making one, or changing its series and items
function plEditor(pid, addItem) {
  var back = pid ? "#/archive/series/" + plEnc(pid) : "#/archive/series";
  render('<div class="row" style="margin-bottom:18px"><a class="btn small" href="' + back + '">← Back</a></div>' +
    '<div class="kicker">Internet Archive · Series playlist</div><h1 style="margin:6px 0 20px" id="plTitle">' + (pid ? "Series and items" : "New series playlist") + "</h1>" +
    '<div class="pl-edit"><div class="pl-col">' +
    '<section class="panel"><h2>Name</h2><div class="row" style="margin-top:10px"><input class="input wide" id="plName" maxlength="120" placeholder="e.g. Friday Fights 2008" aria-label="Name of the playlist"></div></section>' +
    '<section class="panel"><h2>archive.org items</h2><p class="muted">AniBox reads each item and groups its videos by series: the part of the file name before a date or S01E01. ' +
    "Tick the series that go in; the others never slip in later. “Show as” is the name AniBox uses for it (e.g. “Raw” instead of a long name).</p>" +
    '<div id="plItems"></div><div class="pl-add"><textarea class="input pl-links" id="plLinks" spellcheck="false" placeholder="Paste archive.org links or item names, one per line" aria-label="archive.org links"></textarea>' +
    '<div class="row"><button class="btn" id="plAdd">Add</button><span class="muted" id="plAddMsg"></span></div></div></section></div>' +
    '<div class="pl-col"><section class="panel pl-sticky"><h2>Order</h2><div class="chips" id="plSort" style="margin:12px 0 6px">' +
    PL_SORTS.map(function (s) { return '<button type="button" class="chip" data-sort="' + s[0] + '">' + s[1] + "</button>"; }).join("") + "</div>" +
    '<p class="muted" id="plSortHint" style="margin:4px 0 12px"></p><div class="lbl" style="font-weight:600;margin-bottom:6px">Preview</div><div id="plPreview" class="pl-prev"><div class="muted">Add an item to see the order.</div></div>' +
    '<div class="row" style="margin-top:16px"><button class="btn primary" id="plSave">' + (pid ? "Save" : "Make the playlist") + '</button><a class="btn" href="' + back + '">Cancel</a></div></section></div></div>');
  var start = function (e) {
    iaPl.edit = e; iaPl.edit.sort0 = e.sort;
    $("plName").value = e.name || "";
    if (pid) $("plTitle").textContent = e.name + " · series and items";
    plDrawItems(); plDrawSort();
    if (addItem) plScan([addItem]); else plPreviewSoon();
  };
  if (pid) api("/api/ia/playlists/edit?id=" + plEnc(pid)).then(start).catch(function (e) { render('<div class="note">' + esc(e.message) + ' · <a href="#/archive/series">Series playlists</a></div>'); });
  else start({ id: "", name: "", sort: "date", items: [] });
  $("plAdd").onclick = function () { var t = $("plLinks").value.trim(); if (!t) return toast("Paste an archive.org link first.", true); plScan(t); };
  $("plLinks").onkeydown = function (e) { if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) $("plAdd").click(); };
  $("plSort").onclick = function (e) {
    var b = e.target.closest("[data-sort]"); if (!b || !iaPl.edit) return;
    iaPl.edit.sort = b.getAttribute("data-sort"); iaPl.edit.sortChosen = true; plDrawSort(); plPreviewSoon();
  };
  $("plItems").onchange = plItemsChanged;
  $("plItems").oninput = function (e) { if (e.target.matches("[data-disp]")) plItemsChanged(e); };
  $("plItems").onclick = function (e) {
    var r = e.target.closest("[data-remove]"); if (!r) return;
    var id = r.getAttribute("data-remove");
    iaPl.edit.items = iaPl.edit.items.filter(function (it) { return it.id !== id; });
    plDrawItems(); plPreviewSoon();
  };
  $("plSave").onclick = plSaveEditor;
}
// A new playlist starts with the order that fits its files: dates, else S01E01, else the file names.
function plAutoSort() {
  var e = iaPl.edit; if (e.id || e.sortChosen) return;
  var dated = 0, numbered = 0;
  e.items.forEach(function (it) { (it.series || []).forEach(function (s) { if (s.on) { dated += s.dated || 0; numbered += s.numbered || 0; } }); });
  e.sort = dated && dated >= numbered ? "date" : numbered ? "episode" : "name";
  plDrawSort();
}
function plDrawSort() {
  var s = iaPl.edit.sort;
  $("plSort").querySelectorAll("[data-sort]").forEach(function (b) { b.classList.toggle("on", b.getAttribute("data-sort") === s); });
  $("plSortHint").textContent = PL_HINT[s] || "";
}
function plScan(links) {
  $("plAdd").disabled = true; $("plAddMsg").textContent = "Reading from archive.org …";
  post("/api/ia/playlists/scan", { links: links }).then(function (r) {
    var msgs = [], added = 0;
    r.items.forEach(function (it) {
      if (it.error && !(it.series || []).length) { msgs.push(it.id + ": " + it.error); return; }
      if (iaPl.edit.items.some(function (x) { return x.id === it.id; })) { msgs.push(it.id + " is in the list already."); return; }
      iaPl.edit.items.push(it); added++;
    });
    if (added) $("plLinks").value = "";
    if (!$("plName").value.trim() && iaPl.edit.items.length) $("plName").value = iaPl.edit.items[0].title;
    $("plAddMsg").textContent = msgs.join(" ");
    plDrawItems(); plAutoSort(); plPreviewSoon();
  }).catch(function (e) { $("plAddMsg").textContent = e.message; }).then(function () { if ($("plAdd")) $("plAdd").disabled = false; });
}
function plDrawItems() {
  var items = iaPl.edit.items;
  $("plItems").innerHTML = items.length ? items.map(function (it, i) {
    return '<div class="pl-item"><div class="pl-itemhead"><div class="pl-thumb ph"><img alt="" src="/ia/thumb/' + plEnc(it.id) + '" onerror="this.remove()"></div>' +
      '<div class="pl-itemtext"><div class="t">' + esc(it.title) + '</div><div class="muted">' + esc(it.id) + " · " + plural(it.videos || 0, "video") + (it.gone ? " · no longer on archive.org" : "") + "</div></div>" +
      '<button class="btn small danger" data-remove="' + esc(it.id) + '" title="Take this item out of the playlist (what you watched stays watched)">Remove</button></div>' +
      (it.series.length ? '<div class="tw"><table class="pl-series"><thead><tr><th></th><th>Series in the file names</th><th>Show as</th><th class="num">Episodes</th><th>Aired</th></tr></thead><tbody>' +
        it.series.map(function (s, j) {
          var dates = s.first ? (s.first === s.last ? "<span>" + esc(s.first) + "</span>" : "<span>" + esc(s.first) + " –</span> <span>" + esc(s.last) + "</span>") : "no dates";
          return '<tr class="' + (s.on ? "" : "off") + '"><td><input type="checkbox" data-on="' + i + ":" + j + '"' + (s.on ? " checked" : "") + ' aria-label="Put ' + esc(s.name) + ' in"></td>' +
            '<td class="pl-sname">' + esc(s.name) + '<div class="muted" title="' + esc(s.sample) + '">' + esc(s.sample) + "</div></td>" +
            '<td><input class="input small" data-disp="' + i + ":" + j + '" value="' + esc(s.display) + '" maxlength="120" aria-label="Show ' + esc(s.name) + ' as"></td>' +
            '<td class="num">' + s.count + '</td><td class="muted pl-dates">' + dates + "</td></tr>";
        }).join("") + "</tbody></table></div>" : '<div class="note">This item has no videos AniBox can play.</div>') + "</div>";
  }).join("") : '<div class="muted" style="margin:6px 0 14px">No items yet.</div>';
}
function plItemsChanged(e) {
  var t = e.target, ref = t.getAttribute("data-on") || t.getAttribute("data-disp");
  if (!ref) return;
  var ij = ref.split(":"), s = iaPl.edit.items[+ij[0]].series[+ij[1]];
  if (t.hasAttribute("data-on")) { s.on = t.checked; t.closest("tr").classList.toggle("off", !s.on); plAutoSort(); } else s.display = t.value;
  plPreviewSoon();
}
function plBody() {
  return iaPl.edit.items.filter(function (it) { return (it.series || []).length; }).map(function (it) {
    return { id: it.id, series: it.series.map(function (s) { return { name: s.name, display: (s.display || "").trim() || s.name, on: !!s.on }; }) };
  });
}
function plPreviewSoon() { clearTimeout(plPreviewSoon.t); plPreviewSoon.t = setTimeout(plPreview, 250); }
function plPreview() {
  var box = $("plPreview"); if (!box || !iaPl.edit) return;
  var body = plBody();
  if (!body.length) { box.innerHTML = '<div class="muted">Add an item to see the order.</div>'; return; }
  var n = ++iaPl.n;
  post("/api/ia/playlists/preview", { id: iaPl.edit.id || "", sort: iaPl.edit.sort, items: body }).then(function (r) {
    if (n !== iaPl.n || !$("plPreview")) return;
    $("plPreview").innerHTML = plPreviewHtml(r.episodes, iaPl.edit.sort);
  }).catch(function (e) { if (n === iaPl.n && $("plPreview")) $("plPreview").innerHTML = '<div class="muted">' + esc(e.message) + "</div>"; });
}
function plPreviewHtml(eps, sort) {
  if (!eps.length) return '<div class="muted">Nothing ticked yet.</div>';
  var max = 400, n = 0, shown = eps.filter(function (e) { return !e.hidden; });
  var odd = shown.filter(function (e) { return e.unplaced; }).length, hidden = eps.length - shown.length;
  return '<div class="muted" style="font-size:13px;margin-bottom:6px">' + plural(shown.length, "episode") +
    (odd ? " · " + odd + (sort === "date" ? " without a date" : " without S01E01") + " at the end" : "") + (hidden ? " · " + hidden + " hidden" : "") + "</div>" +
    eps.slice(0, max).map(function (e) {
      return '<div class="pl-pv' + (e.unplaced ? " odd" : "") + (e.hidden || !e.online ? " dim" : "") + '"><span class="n">' + (e.hidden ? "·" : ++n) + '</span><span class="l">' + esc(e.label) +
        (e.unplaced ? ' <span class="pl-tag odd">' + (sort === "date" ? "No date" : "No number") + "</span>" : "") + (e.new ? ' <span class="pl-tag new">new</span>' : "") +
        (e.hidden ? ' <span class="pl-tag">Hidden</span>' : "") + (!e.online ? ' <span class="pl-tag gone">No longer online</span>' : "") +
        '</span><span class="f" title="' + esc(e.file) + '">' + esc(e.file) + "</span></div>";
    }).join("") + (eps.length > max ? '<div class="muted" style="padding:8px">… and ' + (eps.length - max) + " more</div>" : "");
}
function plSaveEditor() {
  var e = iaPl.edit, name = $("plName").value.trim(), body = plBody();
  if (!name) { toast("Give the playlist a name.", true); $("plName").focus(); return; }
  if (!body.length) return toast("Add at least one archive.org item.", true);
  $("plSave").disabled = true;
  var done = function (r) { toast(e.id ? "Saved." : "Playlist made."); location.hash = "#/archive/series/" + plEnc(r.playlist.id); };
  var req = e.id ? post("/api/ia/playlists/save", { id: e.id, name: name, items: body }).then(function (r) {
    return e.sort !== e.sort0 ? post("/api/ia/playlists/sort", { id: e.id, sort: e.sort }) : r;
  }) : post("/api/ia/playlists/create", { name: name, sort: e.sort, items: body });
  req.then(done).catch(function (x) { fail(x); if ($("plSave")) $("plSave").disabled = false; });
}

// ---------- one playlist
function plPage(pid) {
  render('<div class="empty">Loading …</div>');
  iaPl.preview = null; iaPl.order = null;
  plLoad(pid);
}
function plLoad(pid) {
  return api("/api/ia/playlists/one?id=" + plEnc(pid)).then(function (d) {
    if (currentPage !== "archive") return;
    var same = iaPl.page && iaPl.page.id === d.id && $("plEps");
    iaPl.page = d;
    if (same) { plDrawHead(); plDrawList(); } else plDraw();
  }).catch(function (e) { render('<div class="row" style="margin-bottom:18px"><a class="btn small" href="#/archive/series">← Series playlists</a></div><div class="note">' + esc(e.message) + "</div>"); });
}
function plDraw() {
  var d = iaPl.page;
  render('<div class="row" style="margin-bottom:18px"><a class="btn small" href="#/archive/series">← Series playlists</a></div><div id="plHead"></div>' +
    '<div class="section"><h2>Episodes</h2></div>' +
    '<div class="toolbar pl-tools"><label class="search" style="max-width:340px"><input id="plQ" type="search" placeholder="Find by name or date (e.g. 2008-01)" aria-label="Find an episode" value="' + esc(iaPl.q) + '"></label>' +
    '<label class="check"><input type="checkbox" id="plHideW"' + (iaPl.hideWatched ? " checked" : "") + "> Hide watched</label>" +
    '<label class="check"><input type="checkbox" id="plShowH"' + (iaPl.showHidden ? " checked" : "") + '> Show hidden <span class="muted" id="plHidN"></span></label>' +
    '<span class="pl-gap"></span><label class="muted" for="plSortSel">Order</label><select class="select" id="plSortSel" aria-label="Order">' +
    PL_SORTS.map(function (s) { return '<option value="' + s[0] + '">' + s[1] + "</option>"; }).join("") + "</select>" +
    '<button class="btn small" id="plOrderBtn" title="Move episodes up and down, or drag them">Change the order</button></div>' +
    '<div id="plBanner"></div><div class="eps pl-eps" id="plEps"></div>');
  plDrawHead(); plDrawList();
  $("plQ").oninput = function () { iaPl.q = this.value; plDrawList(); };
  $("plHideW").onchange = function () { iaPl.hideWatched = this.checked; plDrawList(); };
  $("plShowH").onchange = function () { iaPl.showHidden = this.checked; plDrawList(); };
  $("plSortSel").onchange = function () { plSortPreview(this.value); };
  $("plOrderBtn").onclick = function () { iaPl.preview = null; iaPl.order = plVisible(true).map(function (e) { return e.key; }); plDrawList(); };
  $("plEps").addEventListener("click", plListClick);
  $("plEps").addEventListener("dragstart", function (e) { var r = e.target.closest("[data-ia-key]"); if (!r || !iaPl.order) return; iaPl.dragKey = r.getAttribute("data-ia-key"); e.dataTransfer.effectAllowed = "move"; try { e.dataTransfer.setData("text/plain", iaPl.dragKey); } catch (x) {} r.classList.add("dragging"); });
  $("plEps").addEventListener("dragover", function (e) { var r = e.target.closest("[data-ia-key]"); if (!r || !iaPl.order) return; e.preventDefault(); plDragMark(r, e); });
  $("plEps").addEventListener("dragleave", function (e) { var r = e.target.closest("[data-ia-key]"); if (r) r.classList.remove("drop-before", "drop-after"); });
  $("plEps").addEventListener("drop", function (e) {
    var r = e.target.closest("[data-ia-key]"); if (!r || !iaPl.order || !iaPl.dragKey) return;
    e.preventDefault();
    var to = r.getAttribute("data-ia-key"), after = r.classList.contains("drop-after");
    plMove(iaPl.dragKey, to, after);
  });
  $("plEps").addEventListener("dragend", function () { iaPl.dragKey = ""; plDrawList(); });
}
function plDrawHead() {
  var d = iaPl.page, nx = d.next, box = $("plHead"); if (!box) return;
  var pct = d.episodes ? Math.round(100 * d.watched / d.episodes) : 0;
  var meta = [plural(d.episodes, "episode"), plural(d.items.length, "archive.org item"), "Order: " + d.sortLabel];
  if (d.hidden) meta.push(d.hidden + " hidden");
  if (d.gone) meta.push(d.gone + " no longer online");
  if (d.new) meta.push(d.new + " new");
  var playable = d.list.some(function (e) { return e.playable; });
  box.innerHTML = '<div class="showhead ia-head"><div class="poster ph"><div class="ini">' + esc(d.name) + "</div>" + (d.img ? '<img alt="" src="' + esc(d.img) + '" onerror="this.remove()">' : "") + "</div><div>" +
    '<div class="kicker">Internet Archive · Series playlist</div><h1>' + esc(d.name) + "</h1>" +
    '<div class="meta">' + meta.map(function (m) { return "<span>" + esc(m) + "</span>"; }).join("") + "</div>" +
    '<div class="muted" style="font-size:14px">From ' + d.items.map(function (it) { return '<a href="#/archive/item/' + plEnc(it.id) + '">' + esc(it.title) + "</a>" + (it.gone ? " (no longer on archive.org)" : ""); }).join(", ") +
    (d.checked ? " · read " + esc(ago(d.checked)) : "") + "</div>" +
    '<div class="progress"><i style="width:' + pct + '%"></i></div><div class="muted" style="margin:-8px 0 16px">' + d.watched + " of " + d.episodes + " watched</div>" +
    '<div class="row">' + (nx ? '<button class="btn primary" id="plPlay">▶&nbsp; ' + (nx.position ? "Continue " + esc(nx.label) + " from " + fmt(nx.position) : "Play " + esc(nx.label)) + "</button>" :
      playable ? '<button class="btn primary" id="plAgain">▶&nbsp; Watch again</button>' : "") +
    '<a class="btn" href="#/archive/series/' + plEnc(d.id) + '/edit" title="Tick other series, give them names, add more archive.org items">Series and items …</a>' +
    '<button class="btn" id="plRename">Rename</button>' +
    '<button class="btn" id="plRefresh" title="Read the items on archive.org again and find new episodes">Refresh</button>' +
    '<button class="btn danger" id="plDelete">Delete</button></div></div></div>';
  if ($("plPlay")) $("plPlay").onclick = function () { play({ show: d.show, key: nx.key }); };
  if ($("plAgain")) $("plAgain").onclick = function () {
    var ep = d.list.filter(function (e) { return e.playable; })[0];
    if (ep) play({ show: d.show, key: ep.key, fromStart: true });
  };
  $("plRename").onclick = plRename;
  $("plRefresh").onclick = plRefresh;
  if (typeof streamTvHead === "function") streamTvHead(box, d);  // Play on TV (stream.js)
  $("plDelete").onclick = function () {
    if (!confirm("Delete the series playlist “" + d.name + "”? Only the list goes: what you watched stays watched, and nothing on archive.org or your drives changes.")) return;
    post("/api/ia/playlists/delete", { id: d.id }).then(function () { toast("Playlist deleted."); location.hash = "#/archive/series"; }).catch(fail);
  };
  if ($("plSortSel")) $("plSortSel").value = iaPl.preview ? iaPl.preview.sort : d.sort;
  if ($("plHidN")) $("plHidN").textContent = d.hidden ? "(" + d.hidden + ")" : "";
}
function plDateWords(d) {
  if (!d) return "";
  var p = d.split("-");
  return d + " " + p.join(".") + " " + p[2] + "." + p[1] + "." + p[0] + " " + (+p[2]) + "." + (+p[1]) + "." + p[0] + " " + p[1] + "/" + p[2] + "/" + p[0];
}
function plVisible(forOrder) {
  var d = iaPl.page, q = (iaPl.q || "").trim().toLowerCase();
  return d.list.filter(function (e) {
    if (e.hidden && (forOrder || !iaPl.showHidden)) return false;
    if (forOrder) return true;
    if (iaPl.hideWatched && e.watched) return false;
    return !q || (e.label + " " + e.file + " " + e.display + " " + e.sxe + " " + plDateWords(e.date)).toLowerCase().indexOf(q) >= 0;
  });
}
function plRowHtml(e, mode) {
  var cur = state && state.player.active && state.player.key === e.key && state.player.showId === iaPl.page.show;
  var pct = e.watched ? 100 : e.duration ? Math.min(100, Math.round(100 * e.position / e.duration)) : 0;
  var sort = iaPl.preview ? iaPl.preview.sort : iaPl.page.sort;
  var tags = (e.new ? '<span class="pl-tag new">new</span>' : "") + (e.unplaced ? '<span class="pl-tag odd">' + (sort === "date" ? "No date" : "No number") + "</span>" : "") +
    (!e.online ? '<span class="pl-tag gone">No longer online</span>' : "") + (e.hidden ? '<span class="pl-tag">Hidden</span>' : "");
  var facts = [e.file, e.size != null ? iaSize(e.size) : "", e.length ? fmt(e.length) : "", e.height ? e.height + "p" : ""].filter(Boolean).join(" · ");
  var tip = !e.online && !e.playable ? "This file is no longer on archive.org." : e.hidden ? "Hidden. Show it again to play it." :
    e.watched ? "Watched. Click to play it again." : e.position >= 30 ? "Go on from " + fmt(e.position) : "Play";
  var cls = "ep pl-ep" + (e.watched ? " seen" : "") + (cur ? " cur" : "") + (!e.online ? " gone" : "") + (e.hidden ? " hid" : "") + (mode ? " ordering" : "");
  var right = mode ? '<button class="pl-mv" data-mv="-1" aria-label="Move up" title="Move up">↑</button><button class="pl-mv" data-mv="1" aria-label="Move down" title="Move down">↓</button>' :
    '<button class="fold pl-hide" aria-label="' + (e.hidden ? "Show again" : "Hide") + '" title="' + (e.hidden ? "Show this episode again" : "Hide this episode") + '">' + (e.hidden ? PL_EYE : PL_EYE_OFF) + "</button>" +
    '<button class="tick" aria-label="' + (e.watched ? "Mark as not watched" : "Mark as watched") + '" title="' + (e.watched ? "Watched (click to undo)" : "Mark as watched") + '">' + TICK + "</button>";
  return '<div class="' + cls + '" data-ia-key="' + esc(e.key) + '" title="' + esc(tip) + '"' + (mode ? ' draggable="true"' : "") + ">" +
    '<div class="n">' + (mode ? '<span class="pl-grip" aria-hidden="true">⋮⋮</span>' : esc(e.nr != null ? e.nr : "·")) + "</div>" +
    '<div class="epmain"><div class="eptext"><div class="l">' + esc(e.label) + (e.position && !e.watched ? ' <span class="muted">· ' + fmt(e.position) + "</span>" : "") + " " + tags +
    (e.watched && !mode ? rewatchButton() : "") +
    ' <span class="pl-cache" data-ia-cache></span></div>' +  // the cache's badge and Keep button go here (iacache.js)
    '<div class="f" title="' + esc(facts) + '">' + esc(facts) + "</div></div></div>" +
    '<div class="pb"><i style="width:' + pct + '%"></i></div>' + right + "</div>";
}
function plDrawList() {
  var d = iaPl.page, box = $("plEps"), banner = $("plBanner"); if (!box) return;
  var byKey = {};
  d.list.forEach(function (e) { byKey[e.key] = e; });
  var rows, mode = "";
  if (iaPl.order) {
    mode = "order";
    rows = iaPl.order.map(function (k) { return byKey[k]; }).filter(Boolean);
    banner.innerHTML = '<div class="banner"><div><b>Change the order</b> <span class="muted">· drag the episodes, or use ↑ ↓. ' +
      (d.sort === "manual" ? "" : "Saving makes the order manual: it then stays as it is, and new episodes go to the end, marked “new”.") +
      '</span></div><div class="row"><button class="btn small primary" id="plOrdSave">Save</button><button class="btn small" id="plOrdDrop">Discard</button></div></div>';
    $("plOrdSave").onclick = function () {
      post("/api/ia/playlists/order", { id: d.id, keys: iaPl.order }).then(function () { iaPl.order = null; toast("Your order is saved."); plLoad(d.id); }).catch(fail);
    };
    $("plOrdDrop").onclick = function () { iaPl.order = null; plDrawList(); };
  } else if (iaPl.preview) {
    var pv = iaPl.preview;
    rows = pv.episodes.map(function (p) { var e = byKey[p.key]; return e ? Object.assign({}, e, { label: p.label, unplaced: p.unplaced, nr: p.hidden ? null : e.nr }) : null; })
      .filter(function (e) { return e && (iaPl.showHidden || !e.hidden); });
    var n = 0;
    rows.forEach(function (e) { if (!e.hidden) e.nr = ++n; });
    banner.innerHTML = '<div class="banner"><div><b>Preview: ' + esc(plSortLabel(pv.sort)) + '</b> <span class="muted">· ' + esc(PL_HINT[pv.sort] || "") + " This is how the order will look.</span></div>" +
      '<div class="row"><button class="btn small primary" id="plSortSave">Save</button><button class="btn small" id="plSortDrop">Discard</button></div></div>';
    $("plSortSave").onclick = function () {
      if (d.sort === "manual" && pv.sort !== "manual" && !confirm("Back to an automatic order? Your own order is lost.")) return;
      post("/api/ia/playlists/sort", { id: d.id, sort: pv.sort }).then(function () { iaPl.preview = null; toast("Order: " + plSortLabel(pv.sort)); plLoad(d.id); }).catch(fail);
    };
    $("plSortDrop").onclick = function () { iaPl.preview = null; $("plSortSel").value = d.sort; plDrawList(); };
  } else {
    banner.innerHTML = "";
    rows = plVisible(false);
  }
  ["plQ", "plHideW"].forEach(function (id) { if ($(id)) $(id).disabled = !!mode; });
  if ($("plOrderBtn")) $("plOrderBtn").hidden = !!mode || !!iaPl.preview;
  box.innerHTML = rows.length ? rows.map(function (e) { return plRowHtml(e, mode); }).join("") :
    '<div class="empty">' + (d.list.length ? "No episode matches." : "No episodes. Tick a series under “Series and items”.") + "</div>";
  if (window.iaCacheDecorate) iaCacheDecorate(box);  // the cache's badges and Keep buttons (if it's there)
}
function plSortPreview(sort) {
  var d = iaPl.page;
  if (sort === d.sort) { iaPl.preview = null; plDrawList(); return; }
  iaPl.order = null;
  post("/api/ia/playlists/preview", { id: d.id, sort: sort }).then(function (r) {
    if (!iaPl.page || iaPl.page.id !== d.id) return;
    iaPl.preview = { sort: sort, episodes: r.episodes }; plDrawList();
  }).catch(fail);
}
function plListClick(e) {
  var row = e.target.closest("[data-ia-key]"); if (!row || !iaPl.page) return;
  var d = iaPl.page, key = row.getAttribute("data-ia-key"), ep = d.list.filter(function (x) { return x.key === key; })[0];
  if (!ep) return;
  var mv = e.target.closest("[data-mv]");
  if (mv) { plStep(key, +mv.getAttribute("data-mv")); return; }
  if (iaPl.order) return;
  if (e.target.closest("[data-again]")) {  // Watch again / start again from here (rewatch.js)
    rewatchDialog({ show: d.show, key: key, label: ep.label, title: d.name, done: function () { plLoad(d.id); } });
    return;
  }
  if (e.target.closest("button, a") && !e.target.closest(".pl-hide, .tick")) return;  // the cache's own buttons
  if (e.target.closest(".pl-hide")) {
    post("/api/ia/playlists/hide", { id: d.id, keys: [key], hidden: !ep.hidden }).then(function () { toast(ep.hidden ? "Shown again." : "Hidden. “Show hidden” shows it again."); plLoad(d.id); }).catch(fail);
    return;
  }
  if (e.target.closest(".tick")) {
    post("/api/ia/playlists/watched", { id: d.id, keys: [key], watched: !ep.watched }).then(function () { plLoad(d.id); }).catch(fail);
    return;
  }
  if (iaPl.preview) return;
  if (ep.hidden) return toast("Hidden. Show it again to play it.");
  if (!ep.playable) return toast("This file is no longer on archive.org.", true);
  play({ show: d.show, key: key });
}
function plStep(key, step) {
  var o = iaPl.order, i = o.indexOf(key), j = i + step;
  if (i < 0 || j < 0 || j >= o.length) return;
  o.splice(i, 1); o.splice(j, 0, key);
  plDrawList();
  var r = $("plEps").querySelector('[data-ia-key="' + (window.CSS && CSS.escape ? CSS.escape(key) : key) + '"]');
  if (r) r.scrollIntoView({ block: "nearest" });
}
function plDragMark(r, e) {
  var box = r.getBoundingClientRect(), after = e.clientY > box.top + box.height / 2;
  $("plEps").querySelectorAll(".drop-before, .drop-after").forEach(function (x) { if (x !== r) x.classList.remove("drop-before", "drop-after"); });
  r.classList.toggle("drop-after", after); r.classList.toggle("drop-before", !after);
}
function plMove(from, to, after) {
  var o = iaPl.order;
  if (from === to) return;
  var i = o.indexOf(from); if (i < 0) return;
  o.splice(i, 1);
  var j = o.indexOf(to); if (j < 0) { o.splice(i, 0, from); return; }
  o.splice(after ? j + 1 : j, 0, from);
  iaPl.dragKey = "";
  plDrawList();
}
function plRename() {
  var d = iaPl.page;
  openModal('<div class="kicker">Series playlist</div><h2>Rename</h2><div class="row" style="margin:14px 0"><input class="input wide" id="plNewName" maxlength="120" value="' + esc(d.name) + '" aria-label="New name"></div>' +
    '<div class="row"><button class="btn primary" id="plNameOk">Save</button><button class="btn" data-close>Cancel</button></div>');
  var go = function () {
    var name = $("plNewName").value.trim(); if (!name) return toast("Give the playlist a name.", true);
    post("/api/ia/playlists/rename", { id: d.id, name: name }).then(function () { closeModal(); plLoad(d.id); }).catch(fail);
  };
  $("plNameOk").onclick = go;
  $("plNewName").onkeydown = function (e) { if (e.key === "Enter") go(); };
  $("plNewName").select();
}
function plRefresh() {
  var d = iaPl.page, b = $("plRefresh");
  b.disabled = true; b.textContent = "Reading archive.org …";
  post("/api/ia/playlists/refresh", { id: d.id }).then(function (r) {
    var parts = [];
    if (r.new) parts.push(plural(r.new, "new episode"));
    if (r.gone) parts.push(r.gone + " no longer online");
    if (r.back) parts.push(r.back + " back online");
    if (r.switched) parts.push(r.switched + " switched to a better file");
    if (r.newSeries.length) parts.push("new series in the files: " + r.newSeries.join(", ") + " (tick it under Series and items)");
    toast((parts.length ? parts.join(" · ") : "Nothing new.") + (r.errors.length ? " · " + r.errors.join(" ") : ""), !!r.errors.length);
    plLoad(d.id);
  }).catch(fail).then(function () { if ($("plRefresh")) { $("plRefresh").disabled = false; $("plRefresh").textContent = "Refresh"; } });
}

// ---------- on an item page (archive.js): make a series playlist from it, or add it to one
function playlistItemButtons(box, it) {
  if (!box || !it.files.some(function (f) { return f.kind === "video"; })) return;
  box.innerHTML = '<a class="btn" href="#/archive/series/new/' + plEnc(it.id) + '" title="Put this item\'s episodes in order, by air date or season &amp; episode">Make a series playlist</a>';
  api("/api/ia/playlists?item=" + plEnc(it.id)).then(function (r) {
    if (!box.isConnected) return;
    var mine = {}, html = "";
    r.withItem.forEach(function (p) { mine[p.id] = true; });
    var others = r.playlists.filter(function (p) { return !mine[p.id]; });
    if (others.length) html += '<select class="select" id="plAddTo" aria-label="Add to a series playlist"><option value="">Add to a series playlist …</option>' +
      others.map(function (p) { return '<option value="' + esc(p.id) + '">' + esc(p.name) + "</option>"; }).join("") + "</select>";
    if (r.withItem.length) html += '<span class="muted" style="font-size:14px">In ' + r.withItem.map(function (p) { return '<a href="#/archive/series/' + plEnc(p.id) + '">' + esc(p.name) + "</a>"; }).join(", ") + "</span>";
    box.insertAdjacentHTML("beforeend", html);
    if ($("plAddTo")) $("plAddTo").onchange = function () { if (this.value) location.hash = "#/archive/series/" + plEnc(this.value) + "/edit/" + plEnc(it.id); };
  }).catch(function () {});
}
