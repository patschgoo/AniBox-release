/* AniBox window · Router and start (loaded last).
   Plain scripts sharing one page: loaded in order by index.html. */
"use strict";

// ---------- router
function route() {
  var h = location.hash.replace(/^#\/?/, "") || "home";
  var parts = h.split("/"), page = parts[0];
  currentPage = page;
  setTab(page === "show" || page === "franchise" || page === "import" ? "library" : page);
  if (!$("modal").hidden) closeModal();
  if (page === "home") return home();
  if (page === "library") return library();
  if (page === "show") return show(decodeURIComponent(parts.slice(1).join("/")));
  if (page === "franchise") return franchise(decodeURIComponent(parts.slice(1).join("/")));
  if (page === "missing") return missing(parts[1]);
  if (page === "import") return importPage();
  if (page === "archive") return archive(parts.slice(1));
  if (page === "settings") return settings();
  if (pageRoutes[page]) return pageRoutes[page](parts.slice(1));
  location.hash = "#/home";
}
window.addEventListener("hashchange", route);


poll().then(route, route);
setTimeout(loop, 1000);
