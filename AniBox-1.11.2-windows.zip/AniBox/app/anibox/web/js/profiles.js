/* AniBox window · Profiles ("Who's watching?"): picking one at start, the avatar in the top bar that
   switches, Settings → Profiles, and leaving out the pages a kids profile can't use (AniBox itself
   refuses them too; this only keeps the window tidy).
   Plain scripts sharing one page: loaded in order by index.html (before main.js). */
"use strict";

var pf = { data: null };
var PF_LABELS = { audio_langs: "audio languages", sub_langs: "subtitle languages", subs: "subtitles on/off",
  skip_openings: "skipping openings", skip_endings: "skipping endings", autoplay: "next episode automatically",
  still_watching_after: "“Still watching?”" };
var PF_LOCK = '<svg class="pf-lockico" viewBox="0 0 24 24" aria-label="PIN"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>';

function pfFace(p) {
  if (p.emoji) return p.emoji;
  var ch = Array.from((p.name || "?").trim())[0] || "?";
  return ch.toUpperCase();
}
function pfAvatar(p, cls) {
  return '<span class="pf-av ' + (cls || "") + '" style="--pfc:' + esc(p.color || "#7FD3FF") + '" aria-hidden="true">' + esc(pfFace(p)) + "</span>";
}
function pfCurrent() { return pf.data ? pf.data.profiles.filter(function (p) { return p.active; })[0] : null; }

function pfLoad() {
  return api("/api/profiles").then(function (d) { pf.data = d; pfApply(); return d; });
}
function pfApply() {
  var d = pf.data; if (!d) return;
  document.body.classList.toggle("pf-kids", !!d.restricted);
  document.body.classList.toggle("pf-noarchive", !d.archive);
  var btn = $("pfBtn"), cur = pfCurrent();
  if (btn && cur) {
    btn.hidden = d.profiles.length < 2;
    btn.innerHTML = pfAvatar(cur, "small");
    btn.title = cur.name + " · switch profile";
    btn.setAttribute("aria-label", "Profile: " + cur.name + ". Switch profile");
  }
  if (d.ask) pfStart();
  if (pfBlockedPage()) location.hash = "#/home";
}

// Pages a kids profile doesn't get (the server says no to their data anyway).
function pfBlockedPage() {
  var d = pf.data; if (!d || !d.restricted) return false;
  var parts = location.hash.replace(/^#\/?/, "").split("/"), page = parts[0];
  if (["settings", "import", "history", "health", "lists"].indexOf(page) >= 0) return true;
  if (page === "missing" && parts[1] === "plex") return true;
  return page === "archive" && !d.archive;
}
window.addEventListener("hashchange", function (e) {
  if (!pfBlockedPage()) return;
  e.stopImmediatePropagation();  // main.js's router comes after this one
  toast("That isn't part of this profile.", true);
  location.hash = "#/home";
});

// ---------- "Who's watching?"
function pfTiles(d) {
  return '<div class="pf-tiles">' + d.profiles.map(function (p) {
    return '<button class="pf-tile' + (p.active ? " on" : "") + '" data-pf="' + esc(p.id) + '">' + pfAvatar(p, "big") +
      '<span class="pf-name">' + esc(p.name) + (p.pin ? " " + PF_LOCK : "") + "</span>" +
      (p.restricted ? '<span class="pf-tag">Kids</span>' : "") + "</button>";
  }).join("") + "</div>";
}
function pfStart() {
  var el = $("pfStart");
  if (!el) { el = document.createElement("div"); el.id = "pfStart"; el.className = "pf-start"; el.setAttribute("role", "dialog"); el.setAttribute("aria-modal", "true"); el.setAttribute("aria-label", "Who's watching?"); document.body.appendChild(el); }
  el.hidden = false;
  document.body.classList.add("pf-picking");
  el.innerHTML = '<div class="pf-who"><svg class="logo" viewBox="0 0 32 32" aria-hidden="true"><rect x="3" y="7" width="26" height="19" rx="5" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M11 3.5l5 3.5 5-3.5" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M14 12.5v8l6.5-4z" fill="currentColor"/></svg>' +
    "<h1>Who's watching?</h1>" + pfTiles(pf.data) + '<div class="pf-padslot" id="pfPadStart"></div></div>';
  pfWireTiles(el, $("pfPadStart"), function () { el.hidden = true; document.body.classList.remove("pf-picking"); });
  var first = el.querySelector(".pf-tile.on") || el.querySelector(".pf-tile"); if (first) first.focus();
}
function pfSwitcher() {
  pfLoad().then(function (d) {
    if (d.ask) return;  // the start screen is showing already
    openModal('<div class="pf-who in-modal"><h2>Who\'s watching?</h2>' + (d.restricted ? '<p class="muted">Switching from this profile needs a grown-up\'s PIN.</p>' : "") +
      pfTiles(d) + '<div class="pf-padslot" id="pfPadModal"></div><div class="row" style="justify-content:center;margin-top:14px">' +
      (d.restricted ? "" : '<a class="btn small" href="#/settings" data-close>Manage profiles</a>') + '<button class="btn small" data-close>Cancel</button></div></div>');
    pfWireTiles($("modalBox"), $("pfPadModal"), closeModal);
  }).catch(fail);
}
// #/profiles: the same as a page (e.g. a link from elsewhere); the avatar in the top bar opens it as a dialog.
pageRoutes["profiles"] = function () {
  setTab("");
  pfLoad().then(function (d) {
    render('<div class="pf-who" style="margin:40px auto"><h1>Who\'s watching?</h1>' + pfTiles(d) + '<div class="pf-padslot" id="pfPadPage"></div></div>');
    pfWireTiles(view, $("pfPadPage"), function () { if (location.hash === "#/profiles") location.hash = "#/home"; });
  }).catch(fail);
};
function pfWireTiles(root, padSlot, close) {
  root.querySelectorAll("[data-pf]").forEach(function (b) {
    b.onclick = function () {
      var p = pf.data.profiles.filter(function (x) { return x.id === b.getAttribute("data-pf"); })[0];
      if (!p) return;
      if (p.pin) { root.querySelector(".pf-tiles").hidden = true; pfPinPad(padSlot, p, p.pin, function () { root.querySelector(".pf-tiles").hidden = false; }, close); return; }
      pfSwitch(p, "", close).catch(fail);
    };
  });
}
function pfSwitch(p, pin, close) {
  return post("/api/profiles/switch", { id: p.id, pin: pin }).then(function (d) {
    var was = pf.data && pfCurrent() ? pfCurrent().id : "";
    pf.data = d; close(); pfApply();
    if (was !== d.active) toast("Hi, " + p.name + "!");
    route(); poll();
    return d;
  });
}
function pfPinPad(slot, p, kind, back, close) {
  var val = "";
  slot.innerHTML = '<div class="pf-pad"><div class="pf-padhead">' + pfAvatar(p) + "<div><b>" + esc(p.name) + '</b><div class="muted">' +
    (kind === "grownup" ? "Enter a grown-up's PIN" : "Enter the PIN") + "</div></div></div>" +
    '<div class="pf-dots" aria-hidden="true"></div><div class="pf-msg" role="status"></div><div class="pf-keys">' +
    ["1", "2", "3", "4", "5", "6", "7", "8", "9", "back", "0", "ok"].map(function (k) {
      if (k === "back") return '<button class="pf-key soft" data-k="del" aria-label="Delete a digit">⌫</button>';
      if (k === "ok") return '<button class="pf-key ok" data-k="ok" aria-label="OK">OK</button>';
      return '<button class="pf-key" data-k="' + k + '">' + k + "</button>";
    }).join("") + '</div><button class="btn small" data-k="cancel">Back</button></div>';
  var dots = slot.querySelector(".pf-dots"), msg = slot.querySelector(".pf-msg");
  function draw() { var n = Math.max(4, val.length); dots.innerHTML = Array.apply(null, Array(n)).map(function (_, i) { return '<i class="' + (i < val.length ? "on" : "") + '"></i>'; }).join(""); }
  function done() { document.removeEventListener("keydown", keys, true); }
  function press(k) {
    if (k === "cancel") { done(); slot.innerHTML = ""; back(); return; }
    if (k === "del") val = val.slice(0, -1);
    else if (k === "ok") {
      if (val.length < 4) { msg.textContent = "A PIN has 4 to 8 digits."; return; }
      var tried = val; val = ""; draw(); msg.textContent = "Checking …";
      pfSwitch(p, tried, function () { done(); close(); }).catch(function (e) {
        msg.textContent = e.message; slot.querySelector(".pf-dots").classList.remove("shake"); void dots.offsetWidth; dots.classList.add("shake");
      });
      return;
    } else if (val.length < 8) val += k;
    msg.textContent = ""; draw();
  }
  function keys(e) {
    if (!slot.isConnected || !slot.querySelector(".pf-pad")) { done(); return; }
    if (/^[0-9]$/.test(e.key)) press(e.key);
    else if (e.key === "Backspace") press("del");
    else if (e.key === "Enter") press("ok");
    else if (e.key === "Escape") press("cancel");
    else return;
    e.preventDefault(); e.stopPropagation();
  }
  document.addEventListener("keydown", keys, true);
  slot.querySelectorAll("[data-k]").forEach(function (b) { b.onclick = function () { press(b.getAttribute("data-k")); }; });
  draw();
  var ok = slot.querySelector('[data-k="1"]'); if (ok) ok.focus();
}

// ---------- Settings → Profiles
settingsPanels.push(function (box) {
  var holder = box.parentNode; if (holder && holder.firstChild !== box) holder.insertBefore(box, holder.firstChild);
  box.style.marginBottom = "18px";
  box.innerHTML = '<section class="panel"><h2>Profiles</h2><div id="pfList" class="muted">Loading …</div></section>';
  pfLoad().then(pfPanel).catch(function (e) { $("pfList").textContent = e.message; });
});
function pfPanel() {
  var d = pf.data, el = $("pfList"); if (!el || d.restricted) return;
  el.className = "";
  el.innerHTML = '<p class="muted">Everyone in the house can have their own profile: their own watched marks and resume points, Continue watching, statistics, ' +
    "audio and subtitle choice per show, and " + d.perProfile.map(function (k) { return PF_LABELS[k] || k; }).join(", ") +
    ". The library, the other settings, locks and matches are shared. With two or more profiles AniBox asks “Who's watching?” when it starts.</p>" +
    (d.pinWarning ? '<div class="note">There\'s a kids profile, but no grown-up profile has a PIN yet, so it can switch to any profile. Give your own profile a PIN.</div>' : "") +
    '<div class="pf-rows">' + d.profiles.map(function (p) {
      var r = p.restrictions || {}, tags = [];
      if (p.active) tags.push('<span class="pf-tag on">Active</span>');
      if (p.hasPin) tags.push('<span class="pf-tag">PIN</span>');
      if (r.restricted) tags.push('<span class="pf-tag kids">Kids</span>');
      var what = r.restricted ? [(r.libraries.length ? "Only " + r.libraries.join(", ") : "All libraries"), (r.hideAdult ? "no adult anime" : "adult anime shown"),
        (r.archive ? "Internet Archive" : "no Internet Archive")].join(" · ") : "Can open Settings";
      var lists = Object.keys(d.listOwners || {}).filter(function (s) { return d.listOwners[s] === p.id; }).map(function (s) { return s === "mal" ? "MyAnimeList" : "AniList"; });
      return '<div class="pf-row">' + pfAvatar(p) + '<div class="pf-rowtext"><b>' + esc(p.name) + "</b> " + tags.join("") +
        '<div class="muted">' + esc(what) + " · " + plural(p.watched || 0, "episode") + " watched" + (lists.length ? " · syncs " + esc(lists.join(" and ")) : "") + "</div></div>" +
        '<div class="row"><button class="btn small" data-pf-edit="' + esc(p.id) + '">Edit</button>' +
        (p.main ? "" : '<button class="btn small danger" data-pf-del="' + esc(p.id) + '">Delete</button>') + "</div></div>";
    }).join("") + "</div>" +
    '<div class="row" style="margin-top:14px"><button class="btn small primary" id="pfAdd"' + (d.profiles.length >= d.max ? " disabled" : "") + ">Add a profile</button>" +
    '<span class="muted" style="font-size:13px">A MyAnimeList or AniList connection syncs only what the profile that connected it watches.</span></div>';
  $("pfAdd").onclick = function () { pfEdit(null); };
  el.querySelectorAll("[data-pf-edit]").forEach(function (b) { b.onclick = function () { pfEdit(pfById(b.getAttribute("data-pf-edit"))); }; });
  el.querySelectorAll("[data-pf-del]").forEach(function (b) {
    b.onclick = function () {
      var p = pfById(b.getAttribute("data-pf-del"));
      if (!p || !confirm("Delete the profile “" + p.name + "”? Its watched marks and resume points (" + plural(p.watched || 0, "episode") + " watched) are removed too. This can't be undone.")) return;
      post("/api/profiles/delete", { id: p.id }).then(function (r) { pf.data = r; pfApply(); pfPanel(); toast("Profile deleted."); }).catch(fail);
    };
  });
  pfMarkSettings();
}
function pfById(id) { return pf.data.profiles.filter(function (p) { return p.id === id; })[0]; }
// The settings each profile has for itself get a small mark on the Settings page.
function pfMarkSettings() {
  if (!pf.data || pf.data.profiles.length < 2) return;
  var cur = pfCurrent();
  pf.data.perProfile.forEach(function (k) {
    var c = view.querySelector('[data-sw="' + k + '"], [data-num="' + k + '"], [data-text="' + k + '"], [data-sel="' + k + '"]');
    var lbl = c && c.closest(".field") ? c.closest(".field").querySelector(".lbl") : null;
    if (lbl && !lbl.querySelector(".pf-own")) lbl.insertAdjacentHTML("beforeend", ' <span class="pf-own" title="Each profile has its own">' + esc(cur ? cur.name : "This profile") + "</span>");
  });
}
function pfEdit(p) {
  var d = pf.data, isNew = !p;
  var r = p ? p.restrictions : { restricted: false, libraries: [], hideAdult: true, archive: false };
  var color = p ? p.color : d.colors[d.profiles.length % d.colors.length];
  var other = p && p.hasPin && !p.active && !r.restricted;  // another grown-up's PIN: only with that PIN
  openModal("<h2>" + (isNew ? "Add a profile" : "Edit " + esc(p.name)) + "</h2>" +
    '<div class="pf-edit"><div class="pf-preview" id="pfPrev"></div><div style="flex:1">' +
    '<div class="field"><div class="lbl">Name</div><input class="input" id="pfName" maxlength="30" value="' + esc(p ? p.name : "") + '" placeholder="e.g. Mia"></div>' +
    '<div class="field"><div class="lbl">Colour</div><div class="pf-colors">' + d.colors.map(function (c) {
      return '<button class="pf-color' + (c === color ? " on" : "") + '" data-color="' + c + '" style="--pfc:' + c + '" aria-label="Colour ' + c + '"></button>'; }).join("") + "</div></div>" +
    '<div class="field"><div class="lbl">Emoji<small>Shown instead of the first letter of the name. Empty = the letter.</small></div><input class="input" id="pfEmoji" maxlength="8" style="width:90px;text-align:center" value="' + esc(p ? p.emoji : "") + '" placeholder="🙂"></div>' +
    '<div class="field"><div class="lbl">PIN<small>' + (p && p.hasPin ? "This profile has a PIN. Type a new one to change it." : "4 to 8 digits, asked when someone picks this profile. Optional.") + "</small></div>" +
    '<div class="row">' + (other ? '<input class="input" id="pfOld" type="password" inputmode="numeric" maxlength="8" placeholder="Current PIN" style="width:120px">' : "") +
    '<input class="input" id="pfPin" type="password" inputmode="numeric" maxlength="8" placeholder="New PIN" style="width:110px"><input class="input" id="pfPin2" type="password" inputmode="numeric" maxlength="8" placeholder="Again" style="width:100px">' +
    (p && p.hasPin ? '<label class="check"><input type="checkbox" id="pfNoPin"> Remove the PIN</label>' : "") + "</div></div>" +
    (p && p.main ? '<p class="muted" style="font-size:13px">This is the first profile: it always can open Settings, so it can\'t be a kids profile.</p>' :
      '<div class="field"><div class="lbl">Kids profile<small>Can\'t open Settings, change anything shared or switch to another profile without a grown-up\'s PIN.</small></div><button class="switch' + (r.restricted ? " on" : "") + '" id="pfKids" role="switch" aria-label="Kids profile"></button></div>' +
      '<div id="pfKidsBox"' + (r.restricted ? "" : " hidden") + '><div class="lbl" style="margin:6px 0">Only these libraries <small class="muted">(none ticked = all)</small></div><div class="pf-libs">' +
      (d.libraries.length ? d.libraries.map(function (l) { return '<label class="check"><input type="checkbox" data-pf-lib="' + esc(l) + '"' + (r.libraries.indexOf(l) >= 0 ? " checked" : "") + "> " + esc(l) + "</label>"; }).join("") : '<span class="muted">Scan your folders first.</span>') + "</div>" +
      '<div class="field"><div class="lbl">Hide adult anime<small>Entries the anime lists tag Hentai or Erotica, and ones MyAnimeList rates Rx. Folders AniBox couldn\'t match to MyAnimeList can\'t be checked: “Only these libraries” is the sure way.</small></div><button class="switch' + (r.hideAdult ? " on" : "") + '" id="pfAdult" role="switch" aria-label="Hide adult anime"></button></div>' +
      '<div class="field"><div class="lbl">Internet Archive tab<small>Off: the tab and its videos are hidden for this profile.</small></div><button class="switch' + (r.archive ? " on" : "") + '" id="pfIa" role="switch" aria-label="Internet Archive tab"></button></div></div>') +
    '</div></div><div class="pf-msg" id="pfEditMsg"></div><div class="row" style="justify-content:flex-end;margin-top:10px"><button class="btn" data-close>Cancel</button><button class="btn primary" id="pfSave">' + (isNew ? "Add" : "Save") + "</button></div>");
  function prev() { $("pfPrev").innerHTML = pfAvatar({ name: $("pfName").value || "?", emoji: $("pfEmoji").value.trim(), color: color }, "big"); }
  $("pfName").oninput = prev; $("pfEmoji").oninput = prev; prev();
  $("modalBox").querySelectorAll("[data-color]").forEach(function (b) {
    b.onclick = function () { color = b.getAttribute("data-color"); $("modalBox").querySelectorAll("[data-color]").forEach(function (x) { x.classList.toggle("on", x === b); }); prev(); };
  });
  ["pfKids", "pfAdult", "pfIa"].forEach(function (id) {
    if ($(id)) $(id).onclick = function () { this.classList.toggle("on"); if (id === "pfKids") $("pfKidsBox").hidden = !this.classList.contains("on"); };
  });
  $("pfSave").onclick = function () {
    var pin = $("pfPin").value.trim(), pin2 = $("pfPin2").value.trim(), msg = $("pfEditMsg");
    if (pin && !/^[0-9]{4,8}$/.test(pin)) { msg.textContent = "A PIN has 4 to 8 digits."; return; }
    if (pin !== pin2) { msg.textContent = "The two PINs aren't the same."; return; }
    var body = { id: p ? p.id : "", name: $("pfName").value.trim(), color: color, emoji: $("pfEmoji").value.trim() };
    if (pin) body.pin = pin;
    if ($("pfNoPin") && $("pfNoPin").checked && !pin) body.removePin = true;
    if ($("pfOld")) body.oldPin = $("pfOld").value.trim();
    if ($("pfKids")) body.restrictions = { restricted: $("pfKids").classList.contains("on"), hideAdult: $("pfAdult").classList.contains("on"), archive: $("pfIa").classList.contains("on"),
      libraries: Array.prototype.filter.call($("modalBox").querySelectorAll("[data-pf-lib]"), function (x) { return x.checked; }).map(function (x) { return x.getAttribute("data-pf-lib"); }) };
    if (!body.name) { msg.textContent = "Give the profile a name."; return; }
    this.disabled = true;
    var btn = this;
    post("/api/profiles/save", body).then(function (r) { pf.data = r; closeModal(); pfApply(); pfPanel(); toast(isNew ? "Profile added." : "Saved."); })
      .catch(function (e) { btn.disabled = false; msg.textContent = e.message; });
  };
  $("pfName").focus();
}

// ---------- start
if ($("pfBtn")) $("pfBtn").onclick = pfSwitcher;
pfLoad().catch(function () {});
