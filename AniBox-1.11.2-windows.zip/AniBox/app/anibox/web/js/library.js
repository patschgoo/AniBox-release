/* AniBox window · Library page: cards, filters (library, watched, language, subtitle type), franchises.
   Plain scripts sharing one page: loaded in order by index.html. */
"use strict";

// ---------- Library
var libData = null;
function library() {
  var grouped = libFilter.group === "franchises";
  api(grouped ? "/api/franchises" : "/api/library").then(function (d) {
    libData = { shows: grouped ? d.items : d.shows, libraries: d.libraries, kinds: d.kinds || {} };
    if (grouped && libFilter.kind !== "anime") libFilter.kind = "anime";  // franchises are an anime thing
    var count = function (k) { return grouped ? 0 : libData.shows.filter(function (c) { return k === "all" || c.kind === k || (k === "movies" && c.kind === "movie"); }).length; };
    var sections = [["anime", "Anime"], ["series", "Series"], ["movies", "Movies"], ["all", "Everything"]].filter(function (k) { return grouped ? k[0] === "anime" : k[0] === "all" || count(k[0]); });
    if (!sections.some(function (k) { return k[0] === libFilter.kind; })) libFilter.kind = sections[0] ? sections[0][0] : "all";
    render('<div class="libhead"><div class="seg big" id="kinds">' + sections.map(function (k) {
        return '<button data-k="' + k[0] + '"' + (libFilter.kind === k[0] ? ' class="on"' : "") + ">" + k[1] + (grouped ? "" : ' <span class="n">' + count(k[0]) + "</span>") + "</button>";
      }).join("") + '</div><div class="row">' + libraryLinks.map(function (l) { return '<a class="btn small" href="' + esc(l.href) + '">' + esc(l.label) + "</a>"; }).join("") + '<a class="btn small" href="#/import" id="addNew">Add new videos<span class="badge" id="addCount" hidden></span></a></div></div>' +
      '<div class="chips" id="atypes" style="margin:-6px 0 16px"></div>' +
      '<div class="toolbar"><div class="seg" id="group"><button data-g="shows"' + (grouped ? "" : ' class="on"') + '>Shows</button><button data-g="franchises"' + (grouped ? ' class="on"' : "") + ' title="Seasons, OVAs and movies of one franchise together">Franchises</button></div><label class="search"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#93A0AF" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>' +
      '<input id="q" type="search" placeholder="Search your library" value="' + esc(libFilter.q) + '" aria-label="Search"></label>' +
      '<div class="chips" id="libs"></div><div class="chips" id="modes"></div><div class="chips" id="langs"></div><div class="chips" id="subtypes"></div></div><div class="grid" id="grid"></div>');
    var inKind = function (c) { return libFilter.kind === "all" || c.kind === libFilter.kind || (libFilter.kind === "movies" && c.kind === "movie") || (grouped && libFilter.kind === "anime"); };
    var libs = [""].concat(d.libraries.filter(function (l) { return grouped || libData.shows.some(function (c) { return c.library === l && inKind(c); }); }));
    if (libFilter.lib && libs.indexOf(libFilter.lib) < 0) libFilter.lib = "";
    var ATYPES = [["", "All"], ["tv", "Series"], ["movie", "Movies"], ["ova", "OVAs"], ["special", "Specials"], ["ona", "ONAs"], ["music", "Music videos"]];
    var present = {}; libData.shows.forEach(function (c) { if (c.kind === "anime") present[c.atype] = (present[c.atype] || 0) + 1; });
    $("atypes").innerHTML = libFilter.kind === "anime" && !grouped ? ATYPES.filter(function (a) { return !a[0] || present[a[0]]; }).map(function (a) {
      return '<button class="chip' + (libFilter.atype === a[0] ? " on" : "") + '" data-at="' + a[0] + '">' + a[1] + (a[0] ? " · " + present[a[0]] : "") + "</button>"; }).join("") : "";
    $("atypes").addEventListener("click", function (e) { var b = e.target.closest("[data-at]"); if (!b) return; libFilter.atype = b.getAttribute("data-at"); library(); });
    $("kinds").addEventListener("click", function (e) { var b = e.target.closest("[data-k]"); if (!b) return; libFilter.kind = b.getAttribute("data-k"); libFilter.atype = ""; library(); });
    api("/api/import/count").then(function (r) { if (r.count && $("addCount")) { $("addCount").textContent = r.count; $("addCount").hidden = false; } }).catch(function () {});
    $("libs").innerHTML = libs.map(function (l) { return '<button class="chip' + (libFilter.lib === l ? " on" : "") + '" data-lib="' + esc(l) + '">' + esc(l || "All") + "</button>"; }).join("");
    var modes = [["all", "Everything"], ["watching", "Watching"], ["new", "Not started"], ["done", "Watched"]];
    var langs = [["", "Any language"], ["ja", "Japanese"], ["dub-de", "German dub"], ["dub-en", "English dub"], ["sub-de", "German subs"], ["sub-en", "English subs"]];
    var subs = [["", "Any subtitles"], ["hard", "Burned in"], ["ass", "Styled (ASS)"], ["plain", "Plain text (SRT)"], ["image", "Image (PGS, VobSub)"], ["warn", "May not show on the TV"], ["none", "No subtitles"], ["tv", "May need converting"]];
    $("langs").innerHTML = langs.map(function (m) { return '<button class="chip' + (libFilter.lang === m[0] ? " on" : "") + '" data-lang="' + m[0] + '">' + m[1] + "</button>"; }).join("");
    $("subtypes").innerHTML = subs.map(function (m) { return '<button class="chip' + (libFilter.sub === m[0] ? " on" : "") + '" data-sub="' + m[0] + '"' + (m[0] === "warn" ? ' title="Styled or picture subtitles that the Plex app on the Shield, many TVs and Chromecast can\'t show as they are"' : "") + (m[0] === "tv" ? ' title="Shows the TV check found that Plex on the Shield has to convert or CastApp TV can\'t play (open a show, or Settings → Check every show)"' : "") + ">" + m[1] + "</button>"; }).join("");
    $("subtypes").addEventListener("click", function (e) { var b = e.target.closest("[data-sub]"); if (!b) return; libFilter.sub = b.getAttribute("data-sub"); library(); });
    $("langs").addEventListener("click", function (e) { var b = e.target.closest("[data-lang]"); if (!b) return; libFilter.lang = b.getAttribute("data-lang"); library(); });
    $("modes").innerHTML = modes.map(function (m) { return '<button class="chip' + (libFilter.mode === m[0] ? " on" : "") + '" data-mode="' + m[0] + '">' + m[1] + "</button>"; }).join("");
    $("q").addEventListener("input", function () { libFilter.q = this.value; drawGrid(); });
    $("group").addEventListener("click", function (e) { var b = e.target.closest("[data-g]"); if (!b) return; libFilter.group = b.getAttribute("data-g"); library(); });
    $("libs").addEventListener("click", function (e) { var b = e.target.closest("[data-lib]"); if (!b) return; libFilter.lib = b.getAttribute("data-lib"); library(); });
    $("modes").addEventListener("click", function (e) { var b = e.target.closest("[data-mode]"); if (!b) return; libFilter.mode = b.getAttribute("data-mode"); library(); });
    drawGrid();
    $("q").focus();
  }).catch(fail);
}
function drawGrid() {
  var q = libFilter.q.trim().toLowerCase().split(/\s+/).filter(Boolean);
  var grouped = libFilter.group === "franchises";
  var list = libData.shows.filter(function (c) {
    if (!grouped && libFilter.kind !== "all" && c.kind !== libFilter.kind && !(libFilter.kind === "movies" && c.kind === "movie")) return false;
    if (!grouped && libFilter.kind === "anime" && libFilter.atype && c.atype !== libFilter.atype) return false;
    if (libFilter.lib && c.library !== libFilter.lib && (c.libraries || []).indexOf(libFilter.lib) < 0) return false;
    if (libFilter.mode === "watching" && !(c.started && !c.finished)) return false;
    if (libFilter.mode === "new" && c.started) return false;
    if (libFilter.mode === "done" && !c.finished) return false;
    var lf = libFilter.lang, au = c.audio || [], su = c.subs || [];
    if (lf === "dub-de" && au.indexOf("de") < 0) return false;
    if (lf === "dub-en" && au.indexOf("en") < 0) return false;
    if (lf === "ja" && au.indexOf("ja") < 0) return false;
    if (lf === "sub-de" && su.indexOf("de") < 0) return false;
    if (lf === "sub-en" && su.indexOf("en") < 0) return false;
    var sf = libFilter.sub, ty = c.subtypes || [];
    var has = function (list) { return ty.some(function (t) { return list.indexOf(t) >= 0; }); };
    if (sf === "hard" && !has(["hard"])) return false;
    if (sf === "ass" && !has(["ass"])) return false;
    if (sf === "plain" && !has(["srt", "vtt", "text"])) return false;
    if (sf === "image" && !has(["pgs", "vobsub"])) return false;
    if (sf === "warn" && !c.subWarn) return false;
    if (sf === "none" && (ty.length || su.length)) return false;
    if (sf === "tv" && !c.tvWarn) return false;  // the TV check (media.js)
    var hay = (c.title + " " + (c.folder || "")).toLowerCase();
    return q.every(function (w) { return hay.indexOf(w) >= 0; });
  });
  $("grid").innerHTML = list.length ? list.map(cardHtml).join("") : '<div class="empty">Nothing matches.</div>';
}
