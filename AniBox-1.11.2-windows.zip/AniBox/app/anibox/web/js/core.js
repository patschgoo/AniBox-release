/* AniBox window · Shared helpers: talking to AniBox, small formatters, cards, page rendering.
   Plain scripts sharing one page: loaded in order by index.html. */
"use strict";

var $ = function (id) { return document.getElementById(id); };
var view = $("view");
var state = null, lastScanState = "", currentPage = "", libFilter = { q: "", lib: "", mode: "all", group: "shows", lang: "", sub: "", kind: "anime", atype: "" };
var PLAY = '<path d="M8 4.5v15l12-7.5z"/>', PAUSE = '<rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="5" width="4" height="14" rx="1"/>';
var TYPE = { TV: "TV", MOVIE: "Movie", OVA: "OVA", ONA: "ONA", SPECIAL: "Special", MUSIC: "Music", UNKNOWN: "?" };
var TICK = '<svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';

// ---------- helpers
function esc(t) { return String(t == null ? "" : t).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
function fmt(s) {
  s = Math.max(0, Math.floor(s || 0));
  var h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60;
  return (h ? h + ":" + (m < 10 ? "0" : "") + m : m) + ":" + (x < 10 ? "0" : "") + x;
}
function ago(t) {
  if (!t) return "never";
  var d = Date.now() / 1000 - t;
  if (d < 90) return "just now";
  if (d < 3600) return Math.round(d / 60) + " min ago";
  if (d < 86400) return Math.round(d / 3600) + " h ago";
  return Math.round(d / 86400) + " days ago";
}
// Plug-in points for pages and panels (each feature's own script adds to them):
// pageRoutes["name"] = function (parts) {} for #/name/...; settingsPanels / homePanels: function (box) {}
// get a <div> of their own on the Settings / Home page; libraryLinks: {href, label} buttons on the Library page.
var pageRoutes = {}, settingsPanels = [], homePanels = [], libraryLinks = [];
function runPanels(list, holderId, arg) {
  var holder = $(holderId); if (!holder) return;
  list.forEach(function (fn) { var box = document.createElement("div"); holder.appendChild(box); try { fn(box, arg); } catch (e) { box.textContent = e.message; } });
}
function plural(n, word) { return n.toLocaleString() + " " + word + (n === 1 ? "" : "s"); }
function toast(t, err) {
  var el = $("toast"); el.textContent = t; el.className = "toast on" + (err ? " err" : "");
  clearTimeout(toast.h); toast.h = setTimeout(function () { el.className = "toast"; }, err ? 6000 : 3000);
}
function api(path) {
  return fetch(path, { cache: "no-store" }).then(function (r) {
    return r.json().then(function (j) { if (!r.ok) throw new Error(j.error || r.statusText); return j; });
  });
}
function post(path, body) {
  return fetch(path, { method: "POST", headers: { "Content-Type": "application/json", "X-AniBox": "1" }, body: JSON.stringify(body || {}) })
    .then(function (r) { return r.json().then(function (j) { if (!r.ok || j.ok === false) { var e = new Error(j.error || r.statusText); e.reason = j.reason || ""; throw e; } return j; }); });
}
function fail(e) { toast(e.message || String(e), true); }
function posterHtml(c, cls, badge) {
  var pct = c.files ? Math.round(100 * c.watched / c.files) : 0;
  var img = c.poster ? '<img loading="lazy" alt="" src="' + esc(c.poster) + '" onerror="this.remove()">' : "";
  return '<div class="poster ph ' + (cls || "") + '"><div class="ini">' + esc(c.title) + "</div>" + img + (badge ? '<span class="stack">' + esc(badge) + "</span>" : "") +
    (c.finished ? '<span class="done">Watched</span>' : "") +
    (c.started && !c.finished ? '<div class="bar0"><i style="width:' + pct + '%"></i></div>' : "") + "</div>";
}
function cardHtml(c) {
  if (c.kind === "franchise") {
    return '<a class="card" href="#/franchise/' + encodeURIComponent(c.key) + '">' + posterHtml(c, "", c.shows > 1 ? c.shows + " parts" : "") +
      '<div class="t">' + esc(c.title) + '</div><div class="s">' + c.have + " of " + c.total + " entries" + (c.missing ? " · " + c.missing + " missing" : "") + " · " + c.watched + "/" + c.files + "</div></a>";
  }
  var sub = c.next && c.started ? c.next.label : [c.library, c.year, TYPE[c.type] || c.type].filter(Boolean).join(" · ");
  return '<a class="card" href="#/show/' + encodeURIComponent(c.id) + '">' + posterHtml(c) +
    '<div class="t">' + esc(c.title) + '</div><div class="s">' + esc(sub) + " · " + c.watched + "/" + c.files + "</div>" + badgeHtml(c.badges) + "</a>";
}
function badgeHtml(b) { return b && b.length ? '<div class="bd">' + b.slice(0, 3).map(function (x) { return "<span>" + esc(x) + "</span>"; }).join("") + "</div>" : ""; }

function play(body) {
  if (typeof dock !== "undefined") dock.wantBig = true;  // started from a page: show the big player
  return post("/api/play", body).then(function () { toast("Starting the player …"); poll(); }).catch(fail);
}
function setTab(name) {
  Array.prototype.forEach.call(document.querySelectorAll(".tabs a"), function (a) { a.classList.toggle("on", a.getAttribute("data-tab") === name); });
}
function render(html) { view.innerHTML = html; view.style.animation = "none"; void view.offsetWidth; view.style.animation = ""; }

// ---------- Update from a zip in Downloads (selfupdate.py)
function localUpdateBanner(u) {
  if (!u) return "";
  return '<div class="banner"><div><b>AniBox ' + esc(u.version) + ' is in your Downloads</b> <span class="muted">· ' + esc(u.name) +
    ". AniBox closes, puts the new version in place and opens again by itself. Your library, progress and settings stay.</span></div>" +
    '<button class="btn small primary" data-update-now="' + esc(u.version) + '">Update now</button></div>';
}
function updateResultBanner(r) {
  if (!r) return "";
  return '<div class="banner' + (r.ok ? "" : " warn") + '"><div><b>' + esc(r.message || "") + "</b></div>" +
    '<button class="btn small" data-update-ok>OK</button></div>';
}
function wireUpdateButtons() {
  view.querySelectorAll("[data-update-download]").forEach(function (b) {
    b.onclick = function () {
      b.disabled = true;
      post("/api/update/download").then(function () {
        toast("Downloading the new version …");
        (function wait() {
          api("/api/settings").then(function (s) {
            var d = (s.update || {}).download || {};
            if (d.state === "running") return setTimeout(wait, 1000);
            if (d.state === "error") { toast(d.error, true); b.disabled = false; return; }
            toast("Downloaded and checked. Click Update now."); route();
          }).catch(fail);
        })();
      }).catch(function (e) { b.disabled = false; fail(e); });
    };
  });
  view.querySelectorAll("[data-update-now]").forEach(function (b) { b.onclick = function () { startUpdate(b.getAttribute("data-update-now")); }; });
  view.querySelectorAll("[data-update-ok]").forEach(function (b) {
    b.onclick = function () { post("/api/update/dismiss").then(function () { b.closest(".banner").remove(); }).catch(fail); };
  });
}
function startUpdate(version) {
  if (state && state.player && state.player.running && !confirm("An episode is playing. AniBox saves where you are, then closes for the update. Go on?")) return;
  if (!confirm("Update AniBox to " + version + "? AniBox closes and opens again by itself in about a minute.")) return;
  post("/api/update/install").then(function (r) {
    render('<div class="empty"><h2>Updating to AniBox ' + esc(r.version) + " …</h2><p>AniBox is closing and opens again by itself in a new window. You can close this one.</p>" +
      '<p class="muted" id="updWait">Waiting for the new version …</p></div>');
    var tries = 0;
    (function wait() {
      fetch("/api/ping", { cache: "no-store" }).then(function (x) { return x.json(); }).then(function (p) {
        if (p.version === r.version) { $("updWait").textContent = "AniBox " + r.version + " is running."; window.close(); return; }
        throw new Error("not yet");
      }).catch(function () {
        if (++tries > 90) { $("updWait").textContent = "This is taking long. Start AniBox again; if the update didn't work, AniBox went back to the old version and says why."; return; }
        setTimeout(wait, 2000);
      });
    })();
  }).catch(fail);
}
