/* AniBox window · New episodes (Home), Statistics page (#/stats), watch order of franchises and
   "Next in this franchise" on a show's page. Uses the plug-in points in core.js and show.js.
   Plain scripts sharing one page: loaded in order by index.html. */
"use strict";

// ---------- small formatters
function whenAired(ts) {
  if (!ts) return "";
  var d = Date.now() / 1000 - ts;
  if (d < 3600) return "just now";
  if (d < 86400) return Math.round(d / 3600) + " h ago";
  if (d < 2 * 86400) return "yesterday";
  if (d < 45 * 86400) return Math.round(d / 86400) + " days ago";
  return "on " + new Date(ts * 1000).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
}
function whenNext(ts) {
  var d = new Date(ts * 1000), now = new Date();
  var time = d.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
  var days = Math.round((new Date(d.getFullYear(), d.getMonth(), d.getDate()) - new Date(now.getFullYear(), now.getMonth(), now.getDate())) / 86400000);
  if (days === 0) return "today at " + time;
  if (days === 1) return "tomorrow at " + time;
  return "on " + d.toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short" }) + " at " + time;
}
function epRange(r) { return r[0] === r[1] ? String(r[0]) : r[0] + "–" + r[1]; }
function epList(nums) {
  if (nums.length === 1) return "Episode " + nums[0];
  var rs = [];
  nums.forEach(function (n) { var l = rs[rs.length - 1]; if (l && n === l[1] + 1) l[1] = n; else rs.push([n, n]); });
  return "Episodes " + rs.map(epRange).join(", ");
}
function hours(h) { return h >= 100 ? Math.round(h).toLocaleString() : (Math.round(h * 10) / 10).toLocaleString(); }
function miniPoster(url, title) {
  return '<div class="poster ph ins-p"><div class="ini">' + esc(title) + "</div>" + (url ? '<img loading="lazy" alt="" src="' + esc(url) + '" onerror="this.remove()">' : "") + "</div>";
}

// ---------- Home: New episodes
function airingText(n) {
  var r = n.missing, last = r[r.length - 1];
  var out;
  if (n.missingCount === 1) out = "Episode " + last[1] + (n.latestMissing ? " is out" : " isn't on your drives");
  else if (r.length === 1) out = "Episodes " + epRange(r[0]) + " are out";
  else out = n.missingCount.toLocaleString() + " episodes are out (" + r.slice(0, 4).map(epRange).join(", ") + (r.length > 4 ? ", …" : "") + ")";
  if (n.latestMissing && n.airedAt) out += " (" + (n.missingCount > 1 ? "the latest " : "") + whenAired(n.airedAt) + ")";
  if (n.waitingAll) return esc(out) + ' · waiting in Downloads → <a href="#/import">Add new videos</a>';
  if (n.waiting.length) return esc(out) + " · " + esc(epList(n.waiting)) + ' waiting in Downloads → <a href="#/import">Add new videos</a>, the rest not on your drives';
  return esc(out) + (n.missingCount === 1 && !n.latestMissing ? "" : " · not on your drives");
}
function airingRow(n) {
  var href = "#/show/" + encodeURIComponent(n.show);
  return '<div class="ins-row' + (n.waiting.length ? " waiting" : "") + '"><a href="' + href + '" tabindex="-1" aria-hidden="true">' + miniPoster(n.poster, n.title) + "</a>" +
    '<div class="ins-main"><a class="t" href="' + href + '">' + esc(n.title) + "</a>" + (n.watching ? ' <span class="tag">Watching</span>' : "") +
    '<div class="s">' + airingText(n) + "</div>" +
    (n.next ? '<div class="s2">Next: Episode ' + n.next.episode + " " + esc(whenNext(n.next.airingAt)) + "</div>" : "") + "</div></div>";
}
function drawAiring(box, tries) {
  api("/api/airing").then(function (d) {
    if (!box.isConnected) return;
    if (d.state === "loading" && (tries || 0) < 60) setTimeout(function () { drawAiring(box, (tries || 0) + 1); }, 2000);
    if (!d.enabled || (!d.items.length && !d.upcoming.length)) { box.innerHTML = ""; return; }  // nothing new, or offline: nothing shown
    var html = '<div class="section"><h2>New episodes</h2><div class="row"><span class="muted" style="font-size:13px">' +
      (d.state === "loading" ? "Checking …" : d.checked ? "Checked " + esc(ago(d.checked)) : "") + '</span><button class="btn small" data-air-check' + (d.state === "loading" ? " disabled" : "") + ">Check now</button></div></div>";
    if (d.items.length) html += '<div class="ins-list">' + d.items.map(airingRow).join("") + "</div>";
    if (d.upcoming.length) {
      html += '<div class="ins-soon"><span class="muted">Coming up:</span> ' + d.upcoming.slice(0, 8).map(function (n) {
        return '<a href="#/show/' + encodeURIComponent(n.show) + '">' + esc(n.title) + "</a> " + '<span class="muted">· Episode ' + n.next.episode + " " + esc(whenNext(n.next.airingAt)) + "</span>";
      }).join('<span class="sep">·</span>') + "</div>";
    }
    html += '<p class="muted ins-note">Air dates from AniList. Only the MyAnimeList numbers of shows you\'re watching or that are still airing are sent.</p>';
    box.innerHTML = '<div class="ins-home">' + html + "</div>";
    var b = box.querySelector("[data-air-check]");
    if (b) b.onclick = function () { b.disabled = true; post("/api/airing/check").then(function () { setTimeout(function () { drawAiring(box, 0); }, 800); }).catch(fail); };
  }).catch(function () { box.innerHTML = ""; });
}
homePanels.push(function (box) { drawAiring(box, 0); });

settingsPanels.push(function (box) {
  var s = (settingsData && settingsData.settings) || {};
  box.innerHTML = '<section class="panel"><h2>New episodes</h2><p class="muted">For the shows you\'re watching and the ones still airing, Home says when a new episode is out and whether it\'s on your drives or waiting in Downloads. The air dates come from AniList (free, no account); AniBox only sends the MyAnimeList numbers of those shows, at most every 2 hours.</p>' +
    field("New-episode notices", "Shown on Home. Off: AniBox doesn't ask AniList at all.", sw("airing_notices", s.airing_notices !== false)) + "</section>";
});

// ---------- Statistics page
libraryLinks.push({ href: "#/stats", label: "Statistics" });
var MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
function barList(rows, unit) {
  if (!rows.length) return '<p class="muted">Nothing yet.</p>';
  var max = Math.max.apply(null, rows.map(function (r) { return r[unit]; })) || 1;
  return '<div class="ins-bars">' + rows.map(function (r) {
    var tip = r.label + ": " + hours(r.hours) + " hours · " + plural(r.episodes, "episode") + " · " + plural(r.shows, "show");
    return '<div class="ins-bar" title="' + esc(tip) + '"><div class="lbl">' + esc(r.label) + '</div><div class="track"><i style="width:' + Math.max(1, 100 * r[unit] / max) + '%"></i></div>' +
      '<div class="val">' + (unit === "hours" ? hours(r.hours) + " h" : r.episodes.toLocaleString()) + "</div></div>";
  }).join("") + "</div>";
}
function monthChart(months) {
  var max = Math.max.apply(null, months.map(function (m) { return m.hours; }));
  var peak = months.reduce(function (b, m, i) { return m.hours > months[b].hours ? i : b; }, 0);
  if (!max) return '<p class="muted">No watched episodes in the last 12 months.</p>';
  return '<div class="ins-cols" role="img" aria-label="Hours watched per month">' + months.map(function (m, i) {
    var p = m.month.split("-"), name = MONTHS[Number(p[1]) - 1], label = name + " " + p[0];
    var show = i === peak || i === months.length - 1;
    return '<div class="col" title="' + esc(label + ": " + hours(m.hours) + " hours · " + plural(m.episodes, "episode")) + '">' +
      '<div class="v">' + (show && m.hours ? hours(m.hours) + " h" : "") + '</div><div class="stick"><i style="height:' + (m.hours ? Math.max(2, 100 * m.hours / max) : 0) + '%"></i></div>' +
      '<div class="m">' + esc(name) + (p[1] === "01" || i === 0 ? "<small>" + esc(p[0]) + "</small>" : "") + "</div></div>";
  }).join("") + "</div>";
}
function statsPage() {
  setTab("library");
  api("/api/stats").then(function (d) {
    var t = d.totals, st = d.streak;
    var html = '<div class="section" style="margin-top:0"><div><div class="kicker">Statistics</div><h1 style="margin-top:6px">What you\'ve watched</h1>' +
      '<div class="muted">From AniBox\'s watch progress for the libraries you show. Episodes you marked by hand, or copied from Plex, count on the day you did that.</div></div>' +
      '<a class="btn small" href="#/library">← Library</a></div>';
    if (!t.episodes) {
      render(html + '<div class="empty">Nothing watched yet. Play an episode (or mark some as watched) and come back.</div>');
      return;
    }
    html += '<div class="stats" style="margin-top:8px">' +
      '<div class="stat"><b>' + hours(t.hours) + "</b>hours watched" + (t.estimated ? ' <span class="muted" title="' + esc(plural(t.estimated, "episode") + " had no length saved (marked by hand or copied from Plex); AniBox used the show's usual episode length.") + '">(about)</span>' : "") + "</div>" +
      '<div class="stat"><b>' + t.episodes.toLocaleString() + "</b>episodes watched</div>" +
      '<div class="stat"><b>' + t.started.toLocaleString() + "</b>shows started</div>" +
      '<div class="stat"><b>' + t.finished.toLocaleString() + "</b>shows finished</div>" +
      '<div class="stat"><b>' + st.current + "</b>" + (st.current === 1 ? "day" : "days") + " in a row" + (st.current && !st.today ? ' <span class="muted">(until yesterday)</span>' : "") + "</div>" +
      '<div class="stat"><b>' + st.longest + "</b>longest streak (days)</div></div>";
    html += '<div class="section"><h2>Last 12 months</h2><span class="muted">Hours watched per month</span></div><section class="panel">' + monthChart(d.months) + "</section>";
    html += '<div class="ins-grid"><section class="panel"><h3>By section</h3>' + barList(d.kinds, "hours") + "</section>" +
      '<section class="panel"><h3>Anime by type</h3>' + barList(d.types, "hours") + "</section>" +
      '<section class="panel"><h3>Genres</h3>' + (d.genres.length ? barList(d.genres, "episodes") +
        '<p class="muted ins-note">Episodes watched. From MyAnimeList details AniBox has loaded (' + d.genresKnown + " of " + d.genreShows + " anime you started).</p>" :
        '<p class="muted">Genres come from MyAnimeList: add a free Client ID in <a href="#/settings">Settings → MyAnimeList</a>, then open a show\'s page once to load its details.</p>') + "</section></div>";
    html += '<div class="section"><h2>Most watched</h2></div><section class="panel">' + (function () {
      var max = d.top.length ? d.top[0].hours || 1 : 1;
      return '<div class="ins-bars wide">' + d.top.map(function (s) {
        return '<a class="ins-bar" href="#/show/' + encodeURIComponent(s.id) + '" title="' + esc(s.title + ": " + hours(s.hours) + " hours · " + s.episodes + " of " + s.files + " episodes") + '">' +
          '<div class="lbl">' + esc(s.title) + (s.finished ? ' <span class="pill owned">Finished</span>' : "") + '</div><div class="track"><i style="width:' + Math.max(1, 100 * s.hours / max) + '%"></i></div><div class="val">' + hours(s.hours) + " h</div></a>";
      }).join("") + "</div>";
    })() + "</section>";
    var fin = d.finishedThisYear;
    html += '<div class="section"><h2>Finished in ' + d.year + ' <small class="muted" style="font:400 14px var(--body)">' + fin.length + "</small></h2></div>" +
      (fin.length ? '<div class="shelf">' + fin.map(function (s) {
        return '<a class="card" href="#/show/' + encodeURIComponent(s.id) + '">' + posterHtml({ title: s.title, poster: s.poster, finished: true, files: s.episodes, watched: s.episodes }) +
          '<div class="t">' + esc(s.title) + '</div><div class="s">' + esc(new Date(s.when * 1000).toLocaleDateString("en-GB", { day: "numeric", month: "short" })) + "</div></a>";
      }).join("") + "</div>" : '<p class="muted">No show finished this year yet.</p>');
    render(html);
  }).catch(fail);
}
pageRoutes["stats"] = statsPage;

// ---------- Franchise page: Watch order
var WATCH = { watched: ["owned", "Watched"], partly: ["partial", "Partly watched"], unwatched: ["unsure", "Not started"] };
var HAVE = { missing: ["missing", "Not on your drives"], upcoming: ["upcoming", "Not out yet"], partial: ["partial", "Incomplete"] };
function orderRow(e, upNext) {
  var w = e.watch ? WATCH[e.watch] : HAVE[e.have] || HAVE.missing;
  var extra = e.watch && e.have === "partial" ? ' <span class="pill partial">Incomplete</span>' : "";
  var meta = [TYPE[e.type] || e.type, [e.season, e.year].filter(Boolean).join(" "), e.episodes ? plural(e.episodes, "episode") : ""].filter(Boolean).join(" · ");
  var title = e.show ? '<a href="#/show/' + encodeURIComponent(e.show) + '">' + esc(e.title) + "</a>" : esc(e.title);
  return '<div class="ins-step' + (e.short ? " short" : "") + (upNext ? " next" : "") + (e.watch ? "" : " gone") + '">' +
    '<div class="n">' + (e.step || "·") + "</div>" + miniPoster(e.poster, e.title) +
    '<div class="ins-main"><div class="t">' + title + (e.optional ? ' <span class="tag">' + (e.short ? "Short clip" : "Optional") + "</span>" : "") + (upNext ? ' <span class="tag on">Up next</span>' : "") + "</div>" +
    '<div class="s2">' + esc(meta) + (e.watch === "partly" && e.files ? " · " + e.watched + " of " + e.files + " watched" : "") + "</div></div>" +
    '<div class="ins-side"><span class="pill ' + w[0] + '">' + w[1] + "</span>" + extra +
    (e.show ? "" : ' <a class="muted" href="' + esc(e.mal_url) + '" target="_blank" rel="noopener noreferrer">MAL ↗</a>') + "</div></div>";
}
franchisePanels.push(function (box) {
  var key = franchiseData && franchiseData.key;
  if (!key) return;
  api("/api/watch-order?key=" + encodeURIComponent(key)).then(function (d) {
    if (!box.isConnected || !d.entries.length) return;
    var todo = d.entries.filter(function (e) { return !e.short && e.watch !== "watched" && e.have !== "upcoming"; });
    var up = todo.filter(function (e) { return !e.optional; })[0] || todo[0];  // the main story before OVAs and specials
    var shorts = d.entries.filter(function (e) { return e.short; }).length;
    box.innerHTML = '<div class="section"><h2>Watch order</h2>' + (shorts ? '<label class="check"><input type="checkbox" id="woShort"> Show short clips (' + shorts + ")</label>" : "") + "</div>" +
      '<p class="muted" style="margin:-6px 0 12px">In release order (the anime lists link the parts but don\'t say which comes first, so the air date decides). Optional: OVAs, specials and music videos.</p>' +
      '<div class="panel ins-order hide-short" id="woList">' + d.entries.map(function (e) { return orderRow(e, e === up); }).join("") + "</div>";
    var cb = box.querySelector("#woShort");
    if (cb) cb.onchange = function () { box.querySelector("#woList").classList.toggle("hide-short", !this.checked); };
  }).catch(function () {});
});

// ---------- Show page: Next in this franchise
showPanels.push(function (box) {
  var d = showData;
  if (!d || !d.mal_id) return;
  api("/api/next-in-franchise?id=" + encodeURIComponent(d.id)).then(function (r) {
    if (!box.isConnected || !showData || showData.id !== d.id || !r.key || r.steps < 2) return;
    var link = '<a href="#/franchise/' + encodeURIComponent(r.key) + '">Watch order of ' + esc(r.title) + " →</a>";
    var n = r.next;
    if (!r.finished || !n) {
      box.innerHTML = '<p class="muted ins-part">' + (r.step ? "Part " + r.step + " of " + r.steps + " · " : "") + link + "</p>";
      return;
    }
    var what = [TYPE[n.type] || n.type, n.year, n.episodes ? plural(n.episodes, "episode") : ""].filter(Boolean).join(" · ");
    var state = n.show ? (n.watch === "partly" ? "You started it" : "On your drives") : n.have === "upcoming" ? "Not out yet" : "Not on your drives";
    box.innerHTML = '<section class="panel ins-next">' + miniPoster(n.poster, n.title) + '<div class="ins-main"><div class="kicker">' + (n.after ? "Next in this franchise" : "Still to watch in this franchise") + "</div>" +
      "<h3>" + esc(n.title) + "</h3>" + '<div class="s2">' + esc(what) + (n.optional ? " · optional" : "") + " · " + esc(state) + "</div>" +
      '<div class="row" style="margin-top:10px">' + (n.show ? '<a class="btn small primary" href="#/show/' + encodeURIComponent(n.show) + '">Open</a>' :
        '<a class="btn small" href="' + esc(n.mal_url) + '" target="_blank" rel="noopener noreferrer">MyAnimeList ↗</a>') + link + "</div></div></section>";
  }).catch(function () {});
});
