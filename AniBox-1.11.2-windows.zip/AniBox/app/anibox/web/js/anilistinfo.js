/* AniBox window · AniList extras (routes_anilistinfo.py): a banner above a show's (and a franchise's) header,
   genres and tags, the trailer and where it streams, characters with their voice actors and the main staff.
   Settings → AniList extras switches it off and can load every show in the background.
   Pictures come from AniList's picture server, always without a referrer. The trailer opens in your
   browser on YouTube/Dailymotion (nothing of theirs is loaded inside AniBox).
   Plain scripts sharing one page: loaded in order by index.html. */
"use strict";

var alMemo = {};  // show id -> the last answer, so a page drawn again shows its banner at once

function alImg(src, cls) {
  return src ? '<img class="' + (cls || "") + '" loading="lazy" alt="" referrerpolicy="no-referrer" src="' + esc(src) + '" onerror="this.remove()">' : "";
}
function alInitials(name) { return esc(String(name || "").split(/\s+/).filter(Boolean).map(function (w) { return w.charAt(0); }).join("").slice(0, 2)); }

// A wide picture above the header, fading into the page. ``before`` is the header element.
function alBanner(before, url) {
  if (!before || !url || !before.parentNode) return;
  var prev = before.previousElementSibling;
  if (prev && prev.classList.contains("al-banner")) {
    if (prev.getAttribute("data-src") === url) return;
    prev.remove();
  }
  var b = document.createElement("div");
  b.className = "al-banner";
  b.setAttribute("data-src", url);
  b.setAttribute("aria-hidden", "true");
  var img = document.createElement("img");
  img.alt = ""; img.referrerPolicy = "no-referrer"; img.decoding = "async";
  img.onload = function () { b.classList.add("on"); };
  img.onerror = function () { b.remove(); before.classList.remove("al-over"); };
  img.src = url;
  b.appendChild(img);
  before.parentNode.insertBefore(b, before);
  before.classList.add("al-over");
}

// ---------- show page
showPanels.push(function (box, d) {
  if (!d || !d.mal_id) return;
  box.className = "al-box";
  if (box.parentNode) box.parentNode.insertBefore(box, box.parentNode.firstChild);  // genres and tags right below the header
  if (alMemo[d.id]) alDraw(box, d, alMemo[d.id]);
  alLoad(box, d, 0);
});
function alLoad(box, d, tries) {
  api("/api/anilist/show?id=" + encodeURIComponent(d.id)).then(function (r) {
    if (!box.isConnected || !showData || showData.id !== d.id) return;
    if (!r.enabled) { alMemo = {}; alClear(box); return; }
    if (r.info) { alMemo[d.id] = r; alDraw(box, d, r); }
    if ((r.state === "loading" || r.refreshing) && tries < 20) setTimeout(function () { alLoad(box, d, tries + 1); }, 1500);
  }).catch(function () {});
}
function alClear(box) {
  box.innerHTML = "";
  ["alCastBox", "alTrailer"].forEach(function (id) { if ($(id)) $(id).remove(); });
  var b = view.querySelector(".al-banner"); if (b) b.remove();
}
function alDraw(box, d, r) {
  var x = r.info, head = view.querySelector(".showhead");
  if (head && x.banner) alBanner(head, x.banner);
  // the trailer next to the MyAnimeList button (opens in your browser)
  var row = head && head.querySelector(".row");
  if (row && x.trailer && !$("alTrailer")) {
    var a = document.createElement("a");
    a.className = "btn"; a.id = "alTrailer"; a.target = "_blank"; a.rel = "noopener noreferrer"; a.href = x.trailer.url;
    a.title = "Opens the trailer on " + x.trailer.name + " in your browser";
    a.innerHTML = '<svg class="al-play" viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5.5v13l10.5-6.5z"/></svg>Trailer ↗';
    var mal = row.querySelector('a[href*="myanimelist.net"]');
    row.insertBefore(a, mal ? mal.nextSibling : $("matchBtn"));
  }
  box.innerHTML = alLineHtml(x);
  var sp = box.querySelector("[data-al-spoil]");
  if (sp) sp.onclick = function () {
    var on = box.classList.toggle("al-spoil-on");
    sp.textContent = on ? "Hide spoilers" : "Show spoilers (" + sp.getAttribute("data-al-spoil") + ")";
  };
  alCast(d, r);
}
function alLineHtml(x) {
  var top = x.tags.filter(function (t) { return t.rank >= 50 && !t.spoiler; }).slice(0, 8);
  var spoil = x.tags.filter(function (t) { return t.rank >= 50 && t.spoiler; });
  var pills = x.genres.map(function (g) { return '<span class="tag al-genre">' + esc(g) + "</span>"; }).join("") +
    top.map(function (t) { return '<span class="tag" title="' + esc(t.rank + " % fitting, say AniList's users") + '">' + esc(t.name) + "</span>"; }).join("") +
    spoil.map(function (t) { return '<span class="tag al-spoiler" title="Spoiler">' + esc(t.name) + "</span>"; }).join("") +
    (spoil.length ? '<button class="al-spoilbtn" data-al-spoil="' + spoil.length + '">Show spoilers (' + spoil.length + ")</button>" : "");
  var facts = [x.score ? '<span title="AniList\'s average score">★ ' + x.score + " %</span>" : "", x.season ? esc(x.season) : "", x.studios.length ? esc(x.studios.join(", ")) : ""].filter(Boolean);
  var links = x.links.map(function (l) { return '<a href="' + esc(l.url) + '" target="_blank" rel="noopener noreferrer"' + (l.type === "stream" ? ' title="Streams it"' : "") + ">" + esc(l.site) + " ↗</a>"; });
  if (x.url) links.push('<a href="' + esc(x.url) + '" target="_blank" rel="noopener noreferrer">AniList ↗</a>');
  return (pills ? '<div class="al-pills">' + pills + "</div>" : "") +
    '<div class="al-facts muted"><span class="al-src">AniList</span>' + facts.concat(links).join('<span class="sep">·</span>') + "</div>";
}

// characters and voice actors, then the main staff: after the description, before the episodes
function alCast(d, r) {
  var x = r.info, holder = $("alCastBox");
  if (!x.characters.length && !x.staff.length) { if (holder) holder.remove(); return; }
  if (!holder) {
    holder = document.createElement("div"); holder.id = "alCastBox";
    var after = $("details") || $("showExtra");
    if (!after) return;
    after.parentNode.insertBefore(holder, after.nextSibling);
  }
  var have = r.castOrder.filter(function (l) { return x.characters.some(function (c) { return c.va[l] && c.va[l].length; }); });
  var lang = have.indexOf(r.cast) >= 0 ? r.cast : have[0] || "ja";
  var seg = have.length > 1 ? '<div class="seg" id="alCastSeg" role="group" aria-label="Cast language">' + have.map(function (l) {
    return '<button data-cast="' + l + '"' + (l === lang ? ' class="on"' : "") + ">" + esc(r.castNames[l]) + "</button>";
  }).join("") + "</div>" : "";
  holder.innerHTML = (x.characters.length ? '<div class="section"><h2>Characters &amp; voice actors</h2>' + seg + "</div>" +
    '<div class="al-cast">' + x.characters.map(function (c) { return alPersonHtml(c, lang); }).join("") + "</div>" : "") +
    (x.staff.length ? '<p class="al-staff">' + x.staff.map(function (p) { return "<b>" + esc(p.roles.join(" & ")) + "</b> " + esc(p.name); }).join('<span class="sep">·</span>') + "</p>" : "");
  var s = $("alCastSeg");
  if (s) s.onclick = function (e) {
    var b = e.target.closest("[data-cast]"); if (!b) return;
    r.cast = b.getAttribute("data-cast");
    Object.keys(alMemo).forEach(function (k) { alMemo[k].cast = r.cast; });
    alCast(d, r);
    post("/api/anilist/cast", { lang: r.cast }).catch(function () {});
  };
}
function alPersonHtml(c, lang) {
  var va = (c.va[lang] || [])[0];
  return '<div class="al-ch" title="' + esc(c.name + (c.role ? " · " + c.role : "") + (va ? "\nVoice: " + va.name : "")) + '">' +
    '<div class="al-pics"><div class="al-face ph"><span>' + alInitials(c.name) + "</span>" + alImg(c.image) + "</div>" +
    (va ? '<div class="al-va ph"><span>' + alInitials(va.name) + "</span>" + alImg(va.image) + "</div>" : "") + "</div>" +
    '<div class="t">' + esc(c.name) + '</div><div class="s">' + esc(c.role || "") + "</div>" +
    (va ? '<div class="v">' + esc(va.name) + "</div>" : "") + "</div>";
}

// ---------- franchise page: the banner of its first show
franchisePanels.push(function (box) {
  var d = franchiseData;
  if (!d || !d.shows) return;
  var shows = d.shows.filter(function (c) { return c.mal_id; }).slice(0, 2);
  (function next(i) {
    if (i >= shows.length) return;
    api("/api/anilist/show?id=" + encodeURIComponent(shows[i].id)).then(function (r) {
      if (!box.isConnected || franchiseData !== d) return;
      if (r.info && r.info.banner) alBanner(view.firstElementChild, r.info.banner);
      else if (r.enabled && r.state !== "loading") next(i + 1);
    }).catch(function () {});
  })(0);
});

// ---------- Settings → AniList extras
settingsPanels.push(function (box) {
  var s = (settingsData && settingsData.settings) || {};
  if (box.previousElementSibling) box.style.marginTop = "18px";
  box.innerHTML = '<section class="panel"><h2>AniList extras</h2><p class="muted">On each anime\'s page: a banner, the characters and their voice actors, the main staff, genres and tags, the trailer and where it streams. ' +
    "From AniList (free, no account). AniBox only sends the show's AniList number, when you open its page, and keeps the answer for 14 days. The pictures load from AniList's picture server; the trailer opens on YouTube or Dailymotion in your browser.</p>" +
    field("Load extra info from AniList", "Off: AniBox doesn't ask AniList and the pages show none of it.", sw("anilist_info", s.anilist_info !== false)) +
    '<div class="field"><div class="lbl">Voice actors<small>Which cast a show page shows first. Automatic follows your audio languages (Settings → Audio and subtitles).</small></div>' +
    '<select class="select" id="alCastSel">' + [["", "Automatic"], ["ja", "Japanese"], ["de", "German"], ["en", "English"]].map(function (o) {
      return '<option value="' + o[0] + '"' + ((s.anilist_cast || "") === o[0] ? " selected" : "") + ">" + o[1] + "</option>";
    }).join("") + "</select></div>" +
    '<div class="field" style="display:block"><div class="lbl">Load all<small>Loads the extras of every anime in your library now, slowly (about 15 a minute) so AniList isn\'t flooded. ' +
    "Smart collections need them for genres and tags. Keep AniBox open meanwhile; what's loaded stays when you stop.</small></div><div id=\"alAll\" class=\"muted\" style=\"margin-top:8px\">…</div></div></section>";
  $("alCastSel").onchange = function () { post("/api/anilist/cast", { lang: this.value }).then(function () { toast("Saved"); alMemo = {}; }).catch(fail); };
  alAllDraw();
});
function alAllDraw() {
  var el = $("alAll"); if (!el) return;
  api("/api/anilist/status").then(function (r) {
    if (!$("alAll")) return;
    var j = r.job, running = j.state === "running";
    var have = r.cached.toLocaleString() + " of " + r.total.toLocaleString() + " anime in your library have AniList extras on this PC.";
    var line = running ? "Loading " + (j.done + 1 > j.total ? j.total : j.done + 1) + " of " + j.total + " …" + (j.total - j.done > 1 ? " about " + Math.max(1, Math.round((j.total - j.done) * 4.2 / 60)) + " min left" : "") :
      j.state === "done" ? "Done: " + plural(j.done - j.failed, "show") + " loaded" + (j.failed ? ", " + j.failed + " failed" : "") + "." :
      j.state === "cancelled" ? "Stopped after " + plural(j.done, "show") + "." : j.state === "error" ? j.error : "";
    el.innerHTML = '<div class="row"><span>' + esc(have) + "</span>" +
      (running ? '<button class="btn small" id="alCancel">Cancel</button>' : '<button class="btn small" id="alGo"' + (r.enabled && r.cached < r.total ? "" : " disabled") + ">Load all</button>") + "</div>" +
      (running ? '<div class="progress" style="margin:10px 0 4px"><i style="width:' + (j.total ? Math.round(100 * j.done / j.total) : 0) + '%"></i></div>' : "") +
      (line ? '<div style="margin-top:6px">' + esc(line) + "</div>" : "") + (r.enabled ? "" : '<div style="margin-top:6px">Switched off above.</div>');
    if ($("alGo")) $("alGo").onclick = function () { this.disabled = true; post("/api/anilist/load-all").then(alAllDraw).catch(fail); };
    if ($("alCancel")) $("alCancel").onclick = function () { this.disabled = true; post("/api/anilist/cancel").then(function () { setTimeout(alAllDraw, 400); }).catch(fail); };
    if (running) setTimeout(alAllDraw, 2000);
  }).catch(function (e) { el.textContent = e.message; });
}
