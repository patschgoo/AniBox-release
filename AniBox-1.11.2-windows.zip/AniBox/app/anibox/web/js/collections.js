/* AniBox window · Your own collections (routes_collections.py): Library → Collections (#/collections), a
   collection's page (#/collections/<id>), "Add to collection …" on a show's page, pinned rows on Home.
   Hand-picked collections keep your order (drag or ↑↓); smart ones are a saved filter that fills itself.
   Deleting a collection only deletes the list: never a show, a file or watch progress.
   Plain scripts sharing one page: loaded in order by index.html. */
"use strict";

var colOpts = null;  // the smart editor's choices (libraries, genres, tags), loaded when needed
var COL_SECTIONS = [["", "Any"], ["anime", "Anime"], ["series", "Series"], ["movies", "Movies"]];
var COL_ATYPES = [["", "Any type"], ["tv", "Series"], ["movie", "Movies"], ["ova", "OVAs"], ["special", "Specials"], ["ona", "ONAs"], ["music", "Music videos"]];
var COL_WATCHED = [["", "Any"], ["unwatched", "Not started"], ["watching", "Watching"], ["finished", "Watched"]];
var COL_LANGS = [["", "Any language"], ["ja", "Japanese"], ["dub-de", "German dub"], ["dub-en", "English dub"], ["sub-de", "German subs"], ["sub-en", "English subs"]];

libraryLinks.push({ href: "#/collections", label: "Collections" });
pageRoutes["collections"] = function (parts) {
  setTab("library");
  if (parts[0]) colPage(decodeURIComponent(parts[0])); else colList();
};

function colEnc(s) { return encodeURIComponent(s); }
function colOptions(list, value) {
  return list.map(function (o) { return '<option value="' + esc(o[0]) + '"' + (String(value || "") === o[0] ? " selected" : "") + ">" + esc(o[1]) + "</option>"; }).join("");
}
function colSeg(name, list, value) {
  return '<div class="seg" data-seg="' + name + '">' + list.map(function (o) { return '<button type="button" data-v="' + esc(o[0]) + '"' + ((value || "") === o[0] ? ' class="on"' : "") + ">" + esc(o[1]) + "</button>"; }).join("") + "</div>";
}
// A show's card, or a series playlist's (it opens the playlist page).
function colCardHtml(c) {
  if (c.kind !== "playlist") return cardHtml(c);
  var nx = c.next ? (c.next.position ? "Go on: " : "Next: ") + c.next.label : "Series playlist";
  return '<a class="card" href="#/archive/series/' + colEnc(c.playlist) + '">' + posterHtml(c, "", "Internet Archive") +
    '<div class="t">' + esc(c.title) + '</div><div class="s">' + esc(nx) + " · " + c.watched + "/" + c.files + "</div></a>";
}
function colCoverHtml(c) {
  var img = c.cover ? '<img loading="lazy" alt="" referrerpolicy="no-referrer" src="' + esc(c.cover) + '" onerror="this.remove()">' : "";
  return '<div class="poster ph' + (c.coverKind === "banner" ? " col-banner" : "") + '"><div class="ini">' + esc(c.name) + "</div>" + img +
    (c.kind === "smart" ? '<span class="stack" title="Fills itself from your library">Smart</span>' : "") +
    (c.count && c.finished >= c.count ? '<span class="done">Watched</span>' : "") + "</div>";
}

// ---------- all collections
function colList() {
  render('<div class="section" style="margin-top:0"><div><div class="kicker">Library</div><h1 style="margin-top:6px">Collections</h1>' +
    '<div class="muted" style="margin-top:4px">Your own groups of shows: hand-picked in your order, or smart ones that fill themselves (“unwatched anime movies”, “Fantasy from the 2010s”).</div></div>' +
    '<div class="row"><a class="btn small" href="#/library">← Library</a><button class="btn primary" id="colNew">New collection</button></div></div><div id="colNotice"></div><div id="colGrid"><div class="empty">Loading …</div></div>');
  $("colNew").onclick = function () { colNewDialog(); };
  api("/api/collections").then(function (r) {
    if (!$("colGrid")) return;
    if (r.notice) $("colNotice").innerHTML = '<div class="note">' + esc(r.notice) + "</div>";
    $("colGrid").innerHTML = r.collections.length ? '<div class="grid col-grid">' + r.collections.map(function (c) {
      var sub = plural(c.count, "show") + (c.finished ? " · " + c.finished + " watched" : "") + (c.pinned ? " · on Home" : "");
      return '<a class="card colcard" href="#/collections/' + colEnc(c.id) + '">' + colCoverHtml(c) +
        '<div class="t">' + esc(c.name) + '</div><div class="s">' + esc(sub) + "</div></a>";
    }).join("") + "</div>" : colIntroHtml();
    if ($("colNew2")) $("colNew2").onclick = function () { colNewDialog(); };
  }).catch(function (e) { if ($("colGrid")) $("colGrid").innerHTML = '<div class="note">' + esc(e.message) + "</div>"; });
}
function colIntroHtml() {
  return '<section class="panel" style="max-width:820px"><h2>Make your first collection</h2>' +
    '<ul class="col-intro"><li><b>Hand-picked:</b> you choose the shows (any library, and Internet Archive series playlists) and put them in your order. On a show\'s page, click <b>Add to collection …</b></li>' +
    "<li><b>Smart:</b> a saved filter that keeps itself up to date: section, anime type, library, year, watched or not, language, and genres and tags from AniList.</li>" +
    "<li>Pin a collection to see it as a row on Home. Deleting one only deletes the list; your shows and progress stay.</li></ul>" +
    '<button class="btn primary" id="colNew2">New collection</button></section>';
}
function colNewDialog(show) {
  openModal('<div class="kicker">New collection</div><h2>' + (show ? "With " + esc(show.title) : "What kind?") + "</h2>" +
    '<div class="field"><div class="lbl">Name</div><input class="input wide" id="cnName" maxlength="120" placeholder="Comfort shows"></div>' +
    '<div class="field"><div class="lbl">Description <small>Optional</small></div><input class="input wide" id="cnDesc" maxlength="1000"></div>' +
    (show ? "" : '<div class="col-kinds"><label class="col-kind"><input type="radio" name="cnKind" value="hand" checked><b>Hand-picked</b><span class="muted">You choose the shows and their order.</span></label>' +
      '<label class="col-kind"><input type="radio" name="cnKind" value="smart"><b>Smart</b><span class="muted">A saved filter that fills itself and stays up to date.</span></label></div>') +
    '<div class="row" style="margin-top:16px;justify-content:flex-end"><button class="btn" data-close>Cancel</button><button class="btn primary" id="cnGo">Create</button></div>');
  $("cnName").onkeydown = function (e) { if (e.key === "Enter") $("cnGo").click(); };
  $("cnGo").onclick = function () {
    var kindEl = document.querySelector('input[name="cnKind"]:checked'), kind = kindEl ? kindEl.value : "hand";
    var body = { name: $("cnName").value, description: $("cnDesc").value, kind: kind };
    if (show) body.show = show.id;
    post("/api/collections/create", body).then(function (r) {
      closeModal();
      if (show) { toast("Added to " + r.collection.name + "."); colShowLine(); return; }
      location.hash = "#/collections/" + colEnc(r.collection.id);
      setTimeout(function () { if (kind === "smart") colRulesDialog(r.collection); else colAddDialog(r.collection.id); }, 300);
    }).catch(fail);
  };
}

// ---------- one collection
var colData = null;
function colPage(id) {
  api("/api/collections/one?id=" + colEnc(id)).then(function (d) {
    colData = d;
    var smart = d.kind === "smart";
    var meta = [plural(d.count, "show"), d.finished ? d.finished + " watched" : "", d.started > d.finished ? (d.started - d.finished) + " in progress" : "",
      smart ? "Sorted by " + (d.sorts.filter(function (s) { return s.id === d.sort; })[0] || {}).label : ""].filter(Boolean);
    // a banner cover fills the header (sharp, darkened); the poster beside it is then the first show's
    var banner = d.coverKind === "banner", first = d.cards.filter(function (c) { return c.poster; })[0];
    var side = banner ? Object.assign({}, d, { cover: first ? first.poster : "", coverKind: "poster" }) : d;
    var html = '<section class="hero col-hero' + (banner ? " col-hero-banner" : "") + '">' + (d.cover ? '<div class="bg" style="background-image:url(\'' + esc(d.cover) + '\')"></div>' : "") + colCoverHtml(side) +
      '<div><div class="kicker">' + (smart ? "Smart collection" : "Collection") + '</div><h1>' + esc(d.name) + "</h1>" +
      (d.description ? '<div class="sub">' + esc(d.description) + "</div>" : "") +
      '<div class="meta">' + meta.map(function (m) { return "<span>" + esc(m) + "</span>"; }).join("") + "</div>" +
      '<div class="row">' + (smart ? '<button class="btn primary" id="colRules">Change the rules …</button>' : '<button class="btn primary" id="colAdd">Add shows …</button><button class="btn" id="colArrange"' + (d.count + d.missing > 1 ? "" : " disabled") + ">Arrange …</button>") +
      '<button class="btn" id="colEdit">Edit …</button><button class="btn" id="colPin">' + (d.pinned ? "Unpin from Home" : "Pin to Home") + "</button>" +
      '<button class="btn danger" id="colDel">Delete</button><a class="btn" href="#/collections">All collections</a></div></div></section>';
    if (d.missingItems.length) {
      html += '<div class="note">' + plural(d.missingItems.length, "show") + " of this collection " + (d.missingItems.length === 1 ? "isn't" : "aren't") + " in your library right now (a drive that isn't connected, or the folder was moved or renamed): " +
        d.missingItems.map(function (m) { return "<b>" + esc(m.title || m.id) + '</b> <button class="btn small" data-col-drop="' + esc(m.id) + '">Remove</button>'; }).join(" · ") + "</div>";
    }
    if (smart && d.unknown) {
      html += '<div class="note">' + plural(d.unknown, "show") + " might fit too, but AniBox has no genres and tags for " + (d.unknown === 1 ? "it" : "them") + " yet. " +
        (d.infoEnabled ? 'Open their pages, or use <a href="#/settings">Settings → AniList extras → Load all</a>.' : 'AniList extras are switched off in <a href="#/settings">Settings</a>.') + "</div>";
    }
    html += d.cards.length ? '<div class="grid" style="margin-top:24px">' + d.cards.map(colCardHtml).join("") + "</div>" :
      '<div class="empty">' + (smart ? "Nothing in your library fits these rules right now." : "No shows yet. Click <b>Add shows …</b>, or <b>Add to collection …</b> on a show's page.") + "</div>";
    render(html);
    if ($("colRules")) $("colRules").onclick = function () { colRulesDialog(d); };
    if ($("colAdd")) $("colAdd").onclick = function () { colAddDialog(d.id); };
    if ($("colArrange")) $("colArrange").onclick = function () { colArrangeDialog(d); };
    $("colEdit").onclick = function () { colEditDialog(d); };
    $("colPin").onclick = function () {
      post("/api/collections/update", { id: d.id, pinned: !d.pinned }).then(function () { toast(d.pinned ? "Not on Home anymore." : "Pinned: it's a row on Home now."); colPage(d.id); }).catch(fail);
    };
    $("colDel").onclick = function () {
      if (!confirm("Delete the collection “" + d.name + "”? Only the list goes; your shows, files and watch progress stay as they are.")) return;
      post("/api/collections/delete", { id: d.id }).then(function () { toast("Collection deleted."); location.hash = "#/collections"; }).catch(fail);
    };
    view.querySelectorAll("[data-col-drop]").forEach(function (b) {
      b.onclick = function () { post("/api/collections/remove", { id: d.id, show: b.getAttribute("data-col-drop") }).then(function () { colPage(d.id); }).catch(fail); };
    });
  }).catch(function (e) { render('<div class="empty">' + esc(e.message) + ' · <a href="#/collections">All collections</a></div>'); });
}
function colEditDialog(d) {
  var choices = [["", "The first show's poster"]];
  d.cards.forEach(function (c) {
    if (c.poster) choices.push([JSON.stringify({ show: c.id, kind: "poster" }), "Poster: " + c.title]);
    if (d.banners[c.id]) choices.push([JSON.stringify({ show: c.id, kind: "banner" }), "AniList banner: " + c.title]);
  });
  var cur = d.coverChoice ? JSON.stringify({ show: d.coverChoice.show, kind: d.coverChoice.kind }) : "";
  openModal('<div class="kicker">Edit collection</div><h2>' + esc(d.name) + "</h2>" +
    '<div class="field"><div class="lbl">Name</div><input class="input wide" id="ceName" maxlength="120" value="' + esc(d.name) + '"></div>' +
    '<div class="field"><div class="lbl">Description <small>Optional</small></div><input class="input wide" id="ceDesc" maxlength="1000" value="' + esc(d.description) + '"></div>' +
    '<div class="field"><div class="lbl">Cover</div><select class="input" id="ceCover" style="max-width:380px">' + colOptions(choices, cur) + "</select></div>" +
    '<div class="row" style="margin-top:16px;justify-content:flex-end"><button class="btn" data-close>Cancel</button><button class="btn primary" id="ceGo">Save</button></div>');
  $("ceGo").onclick = function () {
    var v = $("ceCover").value;
    post("/api/collections/update", { id: d.id, name: $("ceName").value, description: $("ceDesc").value, cover: v ? JSON.parse(v) : null })
      .then(function () { closeModal(); toast("Saved"); colPage(d.id); }).catch(fail);
  };
}

// ---------- hand-picked: add shows, arrange
function colAddDialog(id) {
  openModal('<div class="kicker">Add shows</div><h2>Pick shows for this collection</h2>' +
    '<label class="search" style="max-width:none;margin:10px 0 12px"><input id="caQ" type="search" placeholder="Find a show or a series playlist" aria-label="Find a show"></label>' +
    '<div class="col-pick" id="caList"><div class="muted">Loading …</div></div>' +
    '<div class="row" style="margin-top:14px;justify-content:flex-end"><button class="btn primary" data-close>Done</button></div>');
  var shows = [], inside = {};
  function draw() {
    var q = ($("caQ").value || "").toLowerCase().split(/\s+/).filter(Boolean);
    var list = shows.filter(function (s) { var hay = (s.title + " " + s.folder + " " + s.library).toLowerCase(); return q.every(function (w) { return hay.indexOf(w) >= 0; }); });
    $("caList").innerHTML = list.slice(0, 80).map(function (s) {
      return '<div class="col-row"><div class="col-thumb ph">' + (s.poster ? '<img loading="lazy" alt="" src="' + esc(s.poster) + '" onerror="this.remove()">' : "") + "</div>" +
        '<div class="col-main"><div class="t">' + esc(s.title) + '</div><div class="s muted">' + esc([s.library, s.year].filter(Boolean).join(" · ")) + "</div></div>" +
        '<button class="btn small' + (inside[s.id] ? " on" : "") + '" data-ca="' + esc(s.id) + '">' + (inside[s.id] ? "✓ Added" : "Add") + "</button></div>";
    }).join("") + (list.length > 80 ? '<div class="muted" style="padding:8px">' + (list.length - 80) + " more: type a few letters to find them.</div>" : "") +
      (list.length ? "" : '<div class="muted" style="padding:8px">Nothing matches.</div>');
  }
  Promise.all([api("/api/collections/candidates"), api("/api/collections/one?id=" + colEnc(id))]).then(function (rs) {
    shows = rs[0].shows;
    rs[1].cards.forEach(function (c) { inside[c.id] = true; });
    rs[1].missingItems.forEach(function (m) { inside[m.id] = true; });
    if ($("caQ")) { draw(); $("caQ").addEventListener("input", draw); $("caQ").focus(); }
  }).catch(fail);
  $("caList").onclick = function (e) {
    var b = e.target.closest("[data-ca]"); if (!b) return;
    var sid = b.getAttribute("data-ca"), add = !inside[sid];
    b.disabled = true;
    post(add ? "/api/collections/add" : "/api/collections/remove", { id: id, show: sid }).then(function () {
      inside[sid] = add; draw();
    }).catch(function (x) { b.disabled = false; fail(x); });
  };
  colOnClose(function () { if (currentPage === "collections") colPage(id); });
}
function colArrangeDialog(d) {
  var rows = d.cards.map(function (c) { return { id: c.id, title: c.title, poster: c.poster, sub: c.library } })
    .concat(d.missingItems.map(function (m) { return { id: m.id, title: m.title || m.id, poster: "", sub: "Not in your library right now" }; }));
  openModal('<div class="kicker">Arrange</div><h2>' + esc(d.name) + '</h2><p class="muted">Drag the shows, or use ↑ and ↓. ✕ takes a show out of the collection (only out of the list).</p>' +
    '<div class="col-pick col-order" id="coList">' + rows.map(function (r) {
      return '<div class="col-row" draggable="true" data-id="' + esc(r.id) + '"><span class="col-grip" aria-hidden="true">⋮⋮</span><div class="col-thumb ph">' + (r.poster ? '<img alt="" src="' + esc(r.poster) + '" onerror="this.remove()">' : "") + "</div>" +
        '<div class="col-main"><div class="t">' + esc(r.title) + '</div><div class="s muted">' + esc(r.sub || "") + "</div></div>" +
        '<button class="ib" data-mv="-1" aria-label="Up" title="Up">↑</button><button class="ib" data-mv="1" aria-label="Down" title="Down">↓</button><button class="ib" data-rm aria-label="Take out" title="Take out of the collection">✕</button></div>';
    }).join("") + "</div>" +
    '<div class="row" style="margin-top:16px;justify-content:flex-end"><button class="btn" data-close>Cancel</button><button class="btn primary" id="coGo">Save the order</button></div>');
  var list = $("coList"), drag = null, removed = [];
  list.onclick = function (e) {
    var row = e.target.closest(".col-row"); if (!row) return;
    var mv = e.target.closest("[data-mv]");
    if (mv) {
      if (mv.getAttribute("data-mv") === "-1" && row.previousElementSibling) list.insertBefore(row, row.previousElementSibling);
      else if (mv.getAttribute("data-mv") === "1" && row.nextElementSibling) list.insertBefore(row.nextElementSibling, row);
      mv.focus();
    } else if (e.target.closest("[data-rm]")) { removed.push(row.getAttribute("data-id")); row.remove(); }
  };
  list.addEventListener("dragstart", function (e) { drag = e.target.closest(".col-row"); if (!drag) return; drag.classList.add("drag"); e.dataTransfer.effectAllowed = "move"; e.dataTransfer.setData("text/plain", drag.getAttribute("data-id")); });
  list.addEventListener("dragover", function (e) {
    if (!drag) return; e.preventDefault();
    var over = e.target.closest(".col-row"); if (!over || over === drag) return;
    var r = over.getBoundingClientRect();
    list.insertBefore(drag, e.clientY > r.top + r.height / 2 ? over.nextSibling : over);
  });
  list.addEventListener("dragend", function () { if (drag) drag.classList.remove("drag"); drag = null; });
  $("coGo").onclick = function () {
    var ids = Array.prototype.map.call(list.querySelectorAll(".col-row"), function (r) { return r.getAttribute("data-id"); });
    removed.reduce(function (p, sid) { return p.then(function () { return post("/api/collections/remove", { id: d.id, show: sid }); }); }, Promise.resolve())
      .then(function () { return post("/api/collections/order", { id: d.id, items: ids }); })
      .then(function () { closeModal(); toast("Saved"); colPage(d.id); }).catch(fail);
  };
}
// run fn once when the dialog closes (any way: Done, Esc, clicking beside it)
function colOnClose(fn) {
  var m = $("modal"), obs = new MutationObserver(function () { if (m.hidden) { obs.disconnect(); fn(); } });
  obs.observe(m, { attributes: true, attributeFilter: ["hidden"] });
}

// ---------- smart: the rules
function colRulesDialog(c) {
  var r = Object.assign({ kind: "", atype: "", library: "", watched: "", lang: "", text: "", genres: [], tags: [], match: "all", yearFrom: null, yearTo: null }, c.rules || {});
  var sort = c.sort || "title";
  openModal('<div class="kicker">Smart collection</div><h2>' + esc(c.name) + '</h2><p class="muted">Shows that fit all of these rules are in the collection, now and later. Leave a rule on “Any” to not use it.</p><div id="crBody" class="muted">Loading …</div>');
  (colOpts ? Promise.resolve(colOpts) : api("/api/collections/options")).then(function (o) {
    colOpts = o;
    if (!$("crBody")) return;
    var gl = o.genres.map(function (g) { return '<button type="button" class="chip' + (r.genres.indexOf(g[0]) >= 0 ? " on" : "") + '" data-g="' + esc(g[0]) + '">' + esc(g[0]) + ' <span class="n">' + g[1] + "</span></button>"; }).join("");
    $("crBody").className = "";
    $("crBody").innerHTML =
      '<div class="field"><div class="lbl">Section</div>' + colSeg("kind", COL_SECTIONS, r.kind) + "</div>" +
      '<div class="field" id="crAtypeRow"><div class="lbl">Anime type</div><select class="input" id="crAtype">' + colOptions(COL_ATYPES, r.atype) + "</select></div>" +
      '<div class="field"><div class="lbl">Library</div><select class="input" id="crLib">' + colOptions([["", "Any library"]].concat(o.libraries.map(function (l) { return [l, l]; })), r.library) + "</select></div>" +
      '<div class="field"><div class="lbl">Watched</div>' + colSeg("watched", COL_WATCHED, r.watched) + "</div>" +
      '<div class="field"><div class="lbl">Language</div><select class="input" id="crLang">' + colOptions(COL_LANGS, r.lang) + "</select></div>" +
      '<div class="field"><div class="lbl">Year<small>' + (o.years.length ? "Your library: " + o.years[0] + "–" + o.years[1] : "") + '</small></div><input class="input num" id="crY0" type="number" placeholder="from" value="' + esc(r.yearFrom || "") + '"> <span class="muted">to</span> <input class="input num" id="crY1" type="number" placeholder="to" value="' + esc(r.yearTo || "") + '"></div>' +
      '<div class="field"><div class="lbl">Title contains</div><input class="input" id="crText" value="' + esc(r.text) + '" placeholder="e.g. Gundam"></div>' +
      '<div class="field" style="display:block"><div class="lbl">Genres and tags<small>From AniList: ' + o.known.toLocaleString() + " of " + o.anime.toLocaleString() + " anime in your library have them on this PC" +
        (o.infoEnabled ? (o.known < o.anime ? " (Settings → AniList extras → Load all for the rest)" : "") : " (AniList extras are switched off in Settings)") + ". Only those shows can match a genre or tag.</small></div>" +
      (gl ? '<div class="chips" id="crGenres" style="margin:10px 0">' + gl + "</div>" : '<p class="muted">No genres known yet.</p>') +
      '<div class="row"><input class="input" id="crTag" list="crTagList" placeholder="Add a tag, e.g. Time Travel" style="flex:1"><datalist id="crTagList">' + o.tags.map(function (t) { return '<option value="' + esc(t[0]) + '">' + t[1] + "</option>"; }).join("") + "</datalist>" +
      '<button type="button" class="btn small" id="crTagAdd">Add tag</button></div><div class="chips" id="crTags" style="margin-top:8px"></div>' +
      '<div class="row" style="margin-top:10px"><span class="muted">A show needs</span>' + colSeg("match", [["all", "all of them"], ["any", "any of them"]], r.match) + "</div></div>" +
      '<div class="field"><div class="lbl">Sort by</div><select class="input" id="crSort">' + colOptions(o.sorts.map(function (s) { return [s.id, s.label]; }), sort) + "</select></div>" +
      '<div class="col-preview" id="crPrev"></div>' +
      '<div class="row" style="margin-top:16px;justify-content:flex-end"><button class="btn" data-close>Cancel</button><button class="btn primary" id="crGo">Save</button></div>';
    function drawTags() {
      $("crTags").innerHTML = r.tags.map(function (t) { return '<button type="button" class="chip on" data-tag="' + esc(t) + '" title="Remove">' + esc(t) + " ✕</button>"; }).join("");
    }
    function rules() {
      return { kind: r.kind, atype: r.kind === "" || r.kind === "anime" ? $("crAtype").value : "", library: $("crLib").value, watched: r.watched,
        lang: $("crLang").value, text: $("crText").value, genres: r.genres, tags: r.tags, match: r.match,
        yearFrom: $("crY0").value ? Number($("crY0").value) : null, yearTo: $("crY1").value ? Number($("crY1").value) : null };
    }
    var n = 0;
    function preview() {
      clearTimeout(preview.t);
      preview.t = setTimeout(function () {
        var mine = ++n;
        post("/api/collections/preview", { rules: rules(), sort: $("crSort").value }).then(function (p) {
          if (mine !== n || !$("crPrev")) return;
          $("crPrev").innerHTML = "<b>" + plural(p.count, "show") + " fit" + (p.count === 1 ? "s" : "") + "</b>" + (p.unknown ? ' <span class="muted">· ' + p.unknown + " more might, once AniBox has their genres and tags</span>" : "") +
            (p.cards.length ? '<div class="col-strip">' + p.cards.map(function (x) { return '<div class="poster ph" title="' + esc(x.title) + '"><div class="ini">' + esc(x.title) + "</div>" + (x.poster ? '<img loading="lazy" alt="" src="' + esc(x.poster) + '" onerror="this.remove()">' : "") + "</div>"; }).join("") + "</div>" : "");
        }).catch(function (e) { if ($("crPrev")) $("crPrev").textContent = e.message; });
      }, 200);
    }
    function addTag() {
      var t = $("crTag").value.trim();
      if (t && r.tags.map(function (x) { return x.toLowerCase(); }).indexOf(t.toLowerCase()) < 0) { r.tags.push(t); drawTags(); preview(); }
      $("crTag").value = "";
    }
    $("crAtypeRow").hidden = !(r.kind === "" || r.kind === "anime");
    drawTags();
    $("crBody").addEventListener("click", function (e) {
      var b = e.target.closest("[data-seg] [data-v]");
      if (b) {
        var seg = b.closest("[data-seg]"), name = seg.getAttribute("data-seg");
        r[name] = b.getAttribute("data-v");
        seg.querySelectorAll("button").forEach(function (x) { x.classList.toggle("on", x === b); });
        if (name === "kind") $("crAtypeRow").hidden = !(r.kind === "" || r.kind === "anime");
        preview(); return;
      }
      var g = e.target.closest("[data-g]");
      if (g) {
        var name2 = g.getAttribute("data-g"), i = r.genres.indexOf(name2);
        if (i >= 0) r.genres.splice(i, 1); else r.genres.push(name2);
        g.classList.toggle("on", i < 0); preview(); return;
      }
      var t = e.target.closest("[data-tag]");
      if (t) { r.tags = r.tags.filter(function (x) { return x !== t.getAttribute("data-tag"); }); drawTags(); preview(); }
    });
    ["crAtype", "crLib", "crLang", "crSort"].forEach(function (k) { $(k).onchange = preview; });
    ["crY0", "crY1", "crText"].forEach(function (k) { $(k).oninput = preview; });
    $("crTagAdd").onclick = addTag;
    $("crTag").onkeydown = function (e) { if (e.key === "Enter") { e.preventDefault(); addTag(); } };
    $("crTag").onchange = function () { if (o.tags.some(function (x) { return x[0] === $("crTag").value; })) addTag(); };
    $("crGo").onclick = function () {
      post("/api/collections/update", { id: c.id, rules: rules(), sort: $("crSort").value }).then(function () { closeModal(); toast("Saved"); colPage(c.id); }).catch(fail);
    };
    preview();
  }).catch(fail);
}

// ---------- show page: "Add to collection …" and the collections it's in
showPanels.push(function (box, d) {
  if (!d) return;
  box.id = "colShowBox";
  var extra = box.parentNode, al = extra && extra.querySelector(".al-box");  // right below the header (and AniList's line)
  if (extra) extra.insertBefore(box, al ? al.nextSibling : extra.firstChild);
  var row = view.querySelector(".showhead .row");
  if (row && !$("colAddBtn")) {
    var b = document.createElement("button");
    b.className = "btn"; b.id = "colAddBtn"; b.textContent = "Add to collection …"; b.title = "Put this show in one of your own collections";
    b.onclick = function () { colPickDialog(d); };
    row.insertBefore(b, $("openFolder") || null);
  }
  colShowLine();
});
function colShowLine() {
  var box = $("colShowBox"), d = showData; if (!box || !d) return;
  api("/api/collections/for-show?id=" + colEnc(d.id)).then(function (r) {
    if (!box.isConnected || !showData || showData.id !== d.id) return;
    var mine = r.collections.filter(function (c) { return c.in; });
    box.className = mine.length ? "lists-line col-line" : "";
    box.innerHTML = mine.length ? '<span class="muted">In your collections: ' + mine.map(function (c) { return '<a href="#/collections/' + colEnc(c.id) + '">' + esc(c.name) + "</a>"; }).join(", ") + "</span>" : "";
  }).catch(function () {});
}
function colPickDialog(d) {
  openModal('<div class="kicker">Add to collection</div><h2>' + esc(d.title) + '</h2><div id="cpList" class="col-pick"><div class="muted">Loading …</div></div>' +
    '<div class="row" style="margin-top:14px;justify-content:space-between"><button class="btn" id="cpNew">New collection with this show …</button><button class="btn primary" data-close>Done</button></div>');
  function draw() {
    api("/api/collections/for-show?id=" + colEnc(d.id)).then(function (r) {
      if (!$("cpList")) return;
      $("cpList").innerHTML = r.collections.length ? r.collections.map(function (c) {
        return '<label class="col-row col-check"><input type="checkbox" data-cp="' + esc(c.id) + '"' + (c.in ? " checked" : "") + '><div class="col-main"><div class="t">' + esc(c.name) + '</div><div class="s muted">' + plural(c.count, "show") + "</div></div></label>";
      }).join("") : '<p class="muted">No hand-picked collections yet. Make one with this show.</p>';
    }).catch(fail);
  }
  $("cpList").onchange = function (e) {
    var cb = e.target.closest("[data-cp]"); if (!cb) return;
    post(cb.checked ? "/api/collections/add" : "/api/collections/remove", { id: cb.getAttribute("data-cp"), show: d.id })
      .then(function () { toast(cb.checked ? "Added." : "Taken out."); colShowLine(); }).catch(function (x) { cb.checked = !cb.checked; fail(x); });
  };
  $("cpNew").onclick = function () { colNewDialog(d); };
  draw();
}

// ---------- Home: a row per pinned collection
homePanels.push(function (box) {
  api("/api/collections/home").then(function (r) {
    if (!box.isConnected || !r.rows.length) return;
    var stats = view.querySelector(".stats");  // below Continue watching and Recently added
    if (stats) stats.parentNode.insertBefore(box, stats);
    box.innerHTML = r.rows.map(function (row) {
      return '<div class="section"><h2>' + esc(row.name) + ' <small class="muted" style="font:400 13px var(--body)">' + (row.kind === "smart" ? "Smart collection · " : "Collection · ") + plural(row.count, "show") + "</small></h2>" +
        '<a href="#/collections/' + colEnc(row.id) + '">All →</a></div><div class="shelf">' + row.cards.map(colCardHtml).join("") + "</div>";
    }).join("");
  }).catch(function () {});
});
