/* AniBox window · Add new videos: sort downloads into the library folders (routes_files.py).
   AniBox proposes; the user checks and edits; nothing moves before "Move into library"; Undo puts it back.
   Plain scripts sharing one page: loaded in order by index.html. */
"use strict";

var importData = null;
function importPage() {
  render('<div class="empty">Looking for new videos …</div>');
  api("/api/import").then(function (d) { importData = d; drawImport(); }).catch(function (e) { render('<div class="empty">' + esc(e.message) + "</div>"); });
}

function drawImport() {
  var d = importData, busy = d.job && d.job.state === "running";
  var html = '<div class="section" style="margin-top:0"><div><div class="kicker">Add new videos</div><h1 style="margin-top:6px">Sort new videos into your library</h1></div><a class="btn small" href="#/library">Back to the library</a></div>' +
    '<p class="muted" style="max-width:860px">AniBox looks for videos in ' + d.roots.map(function (r) { return "<b>" + esc(r) + "</b>"; }).join(", ") +
    ', recognizes them and suggests where they go and what they\'re called, the way your library already names things. Check the list and change what you like. Nothing changes before you click the button at the bottom, and <b>Undo</b> puts everything back. Files that are already in your library are never touched.</p>' +
    '<div class="row" style="margin:12px 0 20px"><button class="btn small" id="impRoot">Look in another folder …</button>' +
    '<label class="muted">When adding: <select class="input" id="impMode"><option value="move"' + (d.mode === "move" ? " selected" : "") + '>Move (the download leaves the Downloads folder)</option><option value="copy"' + (d.mode === "copy" ? " selected" : "") + ">Copy (keep the download too)</option></select></label>" +
    '<button class="btn small" id="impAgain">Look again</button></div>' +
    '<section class="panel" style="padding:14px 18px"><label class="check"><input type="checkbox" id="impNfo"' + (d.writeNfo ? " checked" : "") + '> Afterwards, write info files (.nfo) for the new episodes, for your Plex NFO library</label>' +
    '<div class="row" style="margin-top:8px"><span class="muted">Then ask Plex to scan:</span> <select class="input small" id="impPlex"><option value="">Don\'t ask Plex</option></select> <span class="muted" id="impPlexNote"></span></div></section>';
  if (busy) html += '<section class="panel"><b>' + esc(d.job.label) + " …</b> " + d.job.done + " of " + d.job.files + " files" + ((d.job.after || []).length ? " · " + esc(d.job.after[d.job.after.length - 1]) : "") +
    (d.job.total ? " · " + Math.round(100 * d.job.bytes / d.job.total) + " %" : "") + '<div class="progress" style="margin-top:10px"><i style="width:' + (d.job.total ? Math.round(100 * d.job.bytes / d.job.total) : 0) + '%"></i></div><p class="muted">' + esc(d.job.current || "") + "</p></section>";
  if (d.undo && !busy) html += '<div class="banner"><div><b>Last change:</b> ' + d.undo.files + " files (" + esc(d.undo.example) + ", " + esc(ago(d.undo.time)) + ')</div><button class="btn small" id="impUndo">Undo</button></div>';
  if (!d.items.length) html += '<section class="panel"><h2>Nothing new</h2><p class="muted">No videos waiting in ' + d.roots.map(esc).join(", ") + ". Downloads that are still running show up once they're finished.</p></section>";
  html += d.items.map(itemHtml).join("");
  if (d.items.length) html += '<div class="row" style="margin:20px 0 40px"><button class="btn primary" id="impGo"' + (busy ? " disabled" : "") + ">" + (d.mode === "copy" ? "Copy" : "Move") + ' into library</button><span class="muted" id="impSum"></span></div>';
  render(html);
  wireImport();
  if (busy) setTimeout(function () { if (currentPage === "import") refreshJob(); }, 1000);
}

function itemHtml(it) {
  var where = it.new_show ?
    'New folder in <select class="input" data-f="library">' + importData.libraries.map(function (l) { return '<option' + (l === it.library ? " selected" : "") + ">" + esc(l) + "</option>"; }).join("") +
      '</select> named <input class="input" data-f="folder" value="' + esc(it.folder) + '" style="min-width:320px">' :
    'Into your folder <b>' + esc(it.library + "\\" + it.folder + (it.season_dir ? "\\" + it.season_dir : "")) + "</b>";
  return '<section class="panel imp" data-id="' + esc(it.id) + '"><div class="imp-head">' +
    '<label class="check"><input type="checkbox" data-f="include" checked></label>' +
    (it.poster ? '<img class="imp-poster" src="' + esc(it.poster) + '" alt="" onerror="this.remove()">' : '<div class="imp-poster ph"></div>') +
    '<div class="imp-title"><div class="kicker">' + esc(it.mal_id ? [TYPE[it.type] || it.type, it.year, it.episodes ? plural(it.episodes, "episode") : ""].filter(Boolean).join(" · ") : "Not recognized") + "</div>" +
    "<h3>" + esc(it.title) + (it.mal_id ? ' <a class="muted" style="font-size:13px" href="https://myanimelist.net/anime/' + esc(it.mal_id) + '" target="_blank" rel="noopener noreferrer">MAL ↗</a>' : "") + "</h3>" +
    '<div class="muted" style="font-size:13px">From ' + esc(it.source) + "</div>" +
    (it.note ? '<div class="note">' + esc(it.note) + "</div>" : "") + it.flags.map(function (f) { return '<div class="note">' + esc(f) + "</div>"; }).join("") +
    '</div><button class="btn small" data-match="' + esc(it.id) + '" data-q="' + esc(it.guess) + '">Change title</button></div>' +
    '<div class="imp-where">' + where + "</div>" +
    '<div class="tw"><table><thead><tr><th></th><th>Now</th><th></th><th>New name</th></tr></thead><tbody>' + it.files.map(function (f) {
      return '<tr data-src="' + esc(f.src) + '"><td><input type="checkbox" data-f="file"' + (f.include ? " checked" : "") + '></td><td class="imp-old" title="' + esc(f.rel) + '">' + esc(f.name) +
        (f.flag ? '<div class="muted" style="font-size:12px">' + esc(f.flag) + "</div>" : "") + '</td><td class="muted">→</td><td><input class="input" data-f="name" value="' + esc(f.new_name) + '"></td></tr>';
    }).join("") + "</tbody></table></div></section>";
}

function collectImport() {
  return Array.prototype.map.call(view.querySelectorAll(".imp"), function (sec) {
    var it = importData.items.filter(function (x) { return x.id === sec.getAttribute("data-id"); })[0];
    var lib = sec.querySelector('[data-f="library"]'), folder = sec.querySelector('[data-f="folder"]');
    return {
      id: it.id, include: sec.querySelector('[data-f="include"]').checked, mal_id: it.mal_id, season_dir: it.season_dir,
      library: lib ? lib.value : it.library, folder: folder ? folder.value.trim() : it.folder,
      files: Array.prototype.map.call(sec.querySelectorAll("tr[data-src]"), function (tr) {
        return { src: tr.getAttribute("data-src"), include: tr.querySelector('[data-f="file"]').checked, new_name: tr.querySelector('[data-f="name"]').value.trim() };
      })
    };
  });
}

function wireImport() {
  $("impAgain").onclick = importPage;
  api("/api/import/plex-sections").then(function (r) {
    var sel = $("impPlex"); if (!sel) return;
    if (!r.signedIn) { $("impPlexNote").textContent = "Sign in to Plex first (Settings → Your Plex library)."; sel.disabled = true; return; }
    if (r.error) { $("impPlexNote").textContent = r.error; return; }
    r.sections.forEach(function (s) { var o = document.createElement("option"); o.value = s.key; o.textContent = s.title; if (s.key === r.chosen) o.selected = true; sel.appendChild(o); });
    $("impPlexNote").textContent = r.old && r.old.length ? "Your old libraries (" + r.old.join(", ") + ") are never scanned." : "";
  }).catch(function () {});
  $("impMode").onchange = function () { post("/api/settings", { import_mode: this.value }).then(importPage).catch(fail); };
  $("impRoot").onclick = function () {
    post("/api/pick-folder").then(function (r) { if (r.path) return post("/api/settings", { inbox_folders: [r.path] }).then(importPage); }).catch(fail);
  };
  if ($("impUndo")) $("impUndo").onclick = function () {
    if (!confirm("Put the last added or moved files back where they were?")) return;
    post("/api/files/undo").then(function (r) { toast(r.undone + " files are back" + (r.problems.length ? "; " + r.problems.length + " couldn't be moved back" : "") + "."); importPage(); }).catch(fail);
  };
  view.querySelectorAll("[data-match]").forEach(function (b) {
    b.onclick = function () {
      pickTitle(b.getAttribute("data-q"), function (mal) {
        post("/api/import/match", { id: b.getAttribute("data-match"), mal_id: mal }).then(function (it) {
          importData.items = importData.items.map(function (x) { return x.id === it.id ? it : x; });
          drawImport();
        }).catch(fail);
      });
    };
  });
  if ($("impGo")) $("impGo").onclick = function () {
    var items = collectImport(), mode = $("impMode").value;
    post("/api/import/apply", { preview: true, items: items }).then(function (p) {
      var ok = p.ops.filter(function (o) { return !o.problem; }), bad = p.ops.filter(function (o) { return o.problem; });
      if (!ok.length) { toast(bad.length ? bad[0].problem : "Nothing chosen.", true); return; }
      openModal('<div class="kicker">Check</div><h2>' + (mode === "copy" ? "Copy " : "Move ") + ok.length + " files into your library?</h2>" +
        '<div class="tw" style="max-height:46vh;overflow:auto"><table><tbody>' + p.ops.map(function (o) {
          return "<tr><td>" + esc(o.dst) + (o.problem ? '<div class="note">' + esc(o.problem) + " Skipped.</div>" : "") + "</td></tr>";
        }).join("") + "</tbody></table></div>" +
        '<div class="row" style="margin-top:16px;justify-content:flex-end"><button class="btn" data-close>Cancel</button><button class="btn primary" id="impYes">Yes, ' + (mode === "copy" ? "copy" : "move") + "</button></div>");
      $("impYes").onclick = function () {
        closeModal();
        post("/api/import/apply", { mode: mode, items: items, write_nfo: $("impNfo").checked, plex_section: $("impPlex").value })
          .then(function () { toast("Adding the files …"); refreshJob(); }).catch(fail);
      };
    }).catch(fail);
  };
}

function refreshJob() {
  api("/api/files/state").then(function (s) {
    if (s.job.state === "running") { importData.job = s.job; drawImport(); return; }
    if (s.job.errors && s.job.errors.length) toast(s.job.errors.length + " files couldn't be added: " + s.job.errors[0].error, true);
    else if (s.job.state === "done") toast("Done: " + s.job.moved + " files are in your library." + ((s.job.after || []).length ? " " + s.job.after.join(" ") : ""));
    importPage();
  }).catch(fail);
}

// Search MyAnimeList titles and hand the chosen entry's number to done(mal_id) ("" = not on MAL).
function pickTitle(query, done) {
  openModal('<div class="kicker">Which title is it?</div><h2>Pick the MyAnimeList entry</h2>' +
    '<label class="search" style="max-width:none"><input id="pq" type="search" placeholder="Title, alternative title or MAL number" value="' + esc(query || "") + '"></label>' +
    '<div class="results" id="pres"></div><div class="row" style="margin-top:18px;justify-content:space-between"><button class="btn small" id="pNone">Not on MyAnimeList</button><button class="btn small" data-close>Cancel</button></div>');
  function search() {
    var q = $("pq").value.trim(), m = q.match(/myanimelist\.net\/anime\/(\d+)/); if (m) q = m[1];
    if (!q) { $("pres").innerHTML = ""; return; }
    api("/api/search?q=" + encodeURIComponent(q)).then(function (d) {
      if (!$("pres")) return;
      $("pres").innerHTML = d.results.map(function (r) {
        return '<div class="result"><div><div class="t">' + esc(r.title) + '</div><div class="s">' + [TYPE[r.type] || r.type, r.year, r.episodes ? r.episodes + " eps" : "", "MAL " + r.mal_id].filter(Boolean).map(esc).join(" · ") +
          '</div></div><button class="btn small primary" data-mal="' + esc(r.mal_id) + '">Use this</button></div>';
      }).join("") || '<div class="muted">No title found. Try fewer words.</div>';
    }).catch(fail);
  }
  $("pq").addEventListener("input", function () { clearTimeout(search.t); search.t = setTimeout(search, 250); });
  $("pres").addEventListener("click", function (e) { var b = e.target.closest("[data-mal]"); if (b) { closeModal(); done(b.getAttribute("data-mal")); } });
  $("pNone").onclick = function () { closeModal(); done(""); };
  search();
}
