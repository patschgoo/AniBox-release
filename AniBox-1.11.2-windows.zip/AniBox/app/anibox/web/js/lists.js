/* AniBox window · Your anime lists (MyAnimeList, AniList): the Lists page (#/lists), a list badge on the
   cards, a line on the show page, and Settings → Your anime lists (user names, connect, sync).
   Plain scripts sharing one page: loaded in order by index.html (after core.js, library.js, show.js
   and settings.js, before main.js). */
"use strict";

var LIST_NAMES = { mal: "MyAnimeList", anilist: "AniList" };
var LIST_SHORT = { mal: "MAL", anilist: "AniList" };
var LIST_STATUS = { watching: "Watching", completed: "Completed", on_hold: "On hold", dropped: "Dropped", plan_to_watch: "Plan to watch" };
var listsBadges = null, listsData = null, listsFilter = "";

(function () {
  var css = ".card .lb{font-size:11px;font-weight:600;margin-top:5px;color:var(--muted)}" +
    ".lb.watching,.lsst.watching{color:var(--acc)}.lb.completed,.lsst.completed{color:var(--green)}.lb.on_hold,.lsst.on_hold{color:var(--gold)}" +
    ".lb.dropped,.lsst.dropped{color:var(--red)}.lb.plan_to_watch,.lsst.plan_to_watch{color:var(--violet)}" +
    ".lists-line{display:flex;gap:16px;flex-wrap:wrap;margin:4px 0 12px;font-size:14px}.lists-line .muted b{color:var(--soft);font-weight:600}" +
    ".lists-sec{margin-top:22px}.lists-sec h2 small{font:400 13px var(--body);color:var(--muted);margin-left:6px}" +
    ".lists-tbl td{font-size:13.5px;vertical-align:top}.lists-tbl td.num{white-space:nowrap}.lists-tbl th.num{text-align:right}.lists-acct{margin:6px 0 4px}" +
    ".lists-log{max-height:260px;overflow:auto;margin-top:8px}.lists-log td{font-size:12.5px}.lists-sub{margin:18px 0 4px}";
  var st = document.createElement("style"); st.textContent = css; document.head.appendChild(st);
})();

function listsDescribe(status, progress, episodes, rewatching) {
  var of = episodes ? "/" + episodes : "";
  if (rewatching) return "Rewatching " + progress + of;
  if (status === "completed") return "Completed";
  if (status === "plan_to_watch" && !progress) return "Plan to watch";
  return (LIST_STATUS[status] || status) + " " + progress + of;
}
function listsRanges(nums) {
  var out = [], i = 0;
  nums = nums.slice().sort(function (a, b) { return a - b; });
  while (i < nums.length) {
    var j = i; while (j + 1 < nums.length && nums[j + 1] === nums[j] + 1) j++;
    out.push(i === j ? String(nums[i]) : nums[i] + "–" + nums[j]); i = j + 1;
  }
  return out.join(", ");
}

// ---------- the badge on the cards (from the list copies AniBox keeps; no waiting for the sites)
function listsLoadBadges() {
  api("/api/lists/badges").then(function (b) {
    var had = !!listsBadges; listsBadges = b;
    if (!had && currentPage === "library" && typeof drawGrid === "function" && typeof libData !== "undefined" && libData && $("grid")) drawGrid();
  }).catch(function () {});
}
(function () {
  var baseCard = cardHtml;
  cardHtml = function (c) {
    var html = baseCard(c);
    if (!listsBadges || c.kind === "franchise" || !c.mal_id) return html;
    var src = listsBadges.primary, list = listsBadges[src];
    var e = list && list[c.mal_id];
    if (!e) return html;
    var badge = '<div class="lb ' + esc(e[0]) + '">' + esc(LIST_SHORT[src] + " · " + listsDescribe(e[0], e[1], e[2], e[3])) + "</div>";
    return html.replace(/<\/a>$/, badge + "</a>");
  };
})();
window.addEventListener("hashchange", function () {
  var page = (location.hash.replace(/^#\/?/, "") || "home").split("/")[0];
  if (page === "library" || page === "home") listsLoadBadges();
});
listsLoadBadges();

// ---------- the show page: one line per list
showPanels.push(function (box) {
  var d = showData; if (!d || !d.mal_id) return;
  api("/api/lists/show?id=" + encodeURIComponent(d.id)).then(function (r) {
    if (!showData || showData.id !== d.id || !r.lines.length) return;
    box.className = "lists-line";
    box.innerHTML = r.lines.map(function (l) {
      var txt = "<b>" + esc(l.name) + ":</b> " + esc(l.text);
      return '<span class="muted">' + (l.url ? '<a href="' + esc(l.url) + '" target="_blank" rel="noopener noreferrer" style="color:inherit">' + txt + "</a>" : txt) + "</span>";
    }).join("");
  }).catch(function () {});
});

// ---------- the Lists page
libraryLinks.push({ href: "#/lists", label: "Your lists" });
pageRoutes["lists"] = function (parts) { setTab("library"); listsPage(parts[0] || "", false); };

function listsPage(src, refresh) {
  api("/api/lists?source=" + encodeURIComponent(src) + (refresh ? "&refresh=1" : "")).then(function (d) {
    if (currentPage !== "lists") return;
    listsData = d;
    var s = d.sources[d.source], loading = s.state && s.state.state === "loading";
    var html = '<div class="libhead"><div><div class="kicker">Library</div><h1 style="margin:4px 0 0">Your lists</h1></div><div class="row">' +
      '<div class="seg big" id="lsSrc">' + ["mal", "anilist"].map(function (k) {
        return '<button data-src="' + k + '"' + (k === d.source ? ' class="on"' : "") + ">" + LIST_NAMES[k] + "</button>"; }).join("") + "</div>" +
      (s.configured ? '<button class="btn small" id="lsRefresh"' + (loading ? " disabled" : "") + ">Refresh</button>" : "") +
      '<a class="btn small" href="#/settings">Settings</a></div></div>';
    if (!s.configured) {
      html += '<section class="panel"><h2>Add your ' + esc(LIST_NAMES[d.source]) + ' user name</h2><p class="muted">In <a href="#/settings">Settings → Your anime lists</a>. AniBox then reads your public list and compares it with your drives. ' +
        (d.source === "mal" ? "Reading a MyAnimeList list also needs the free Client ID (Settings → MyAnimeList)." : "AniList needs nothing else for a public profile.") + "</p></section>";
      render(html);
      listsWireHead(d);
      return;
    }
    var err = s.state && s.state.state === "error" ? '<div class="note">' + esc(s.state.message) + "</div>" : "";
    html += '<p class="muted" style="margin:-6px 0 14px">' + (s.connected ? "Your" : esc(s.user) + "'s") + " " + esc(LIST_NAMES[d.source]) + " list" +
      (s.fetched ? " · " + s.count.toLocaleString() + (s.count === 1 ? " entry" : " entries") + " · read " + esc(ago(s.fetched)) : "") +
      (loading ? ' · <span style="color:var(--acc)">reading it now …</span>' : "") + "</p>" + err;
    if (!s.fetched) {
      html += loading ? '<div class="empty">Reading your list …</div>' : "";
      render(html);
      listsWireHead(d);
      if (loading) listsWait(d.source);
      return;
    }
    var sec = d.sections;
    // 1: on the list, not on the drives
    var counts = {}; sec.notOnDrives.forEach(function (e) { counts[e.status] = (counts[e.status] || 0) + 1; });
    var nod = sec.notOnDrives.filter(function (e) { return !listsFilter || e.status === listsFilter; });
    html += '<div class="section lists-sec"><h2>On your list but not on your drives<small>' + sec.notOnDrives.length + "</small></h2></div>" +
      (sec.notOnDrives.length ? '<div class="chips" id="lsChips" style="margin-bottom:10px">' + [["", "All"], ["watching", "Watching"], ["plan_to_watch", "Plan to watch"], ["completed", "Completed"]].filter(function (c) { return !c[0] || counts[c[0]]; }).map(function (c) {
        return '<button class="chip' + (listsFilter === c[0] ? " on" : "") + '" data-f="' + c[0] + '">' + c[1] + " · " + (c[0] ? counts[c[0]] : sec.notOnDrives.length) + "</button>"; }).join("") + "</div>" +
        '<div class="panel"><table class="lists-tbl"><thead><tr><th>Title</th><th>On your list</th><th class="num">Episodes</th></tr></thead><tbody>' +
        nod.map(function (e) {
          var url = d.source === "mal" ? "https://myanimelist.net/anime/" + e.mal_id : e.anilist_id ? "https://anilist.co/anime/" + e.anilist_id : "";
          return "<tr><td>" + (url ? '<a href="' + esc(url) + '" target="_blank" rel="noopener noreferrer">' + esc(e.title) + "</a>" : esc(e.title)) + (e.mal_id ? "" : ' <span class="muted">(not on MyAnimeList)</span>') +
            '</td><td class="lsst ' + esc(e.status) + '">' + esc(e.text) + '</td><td class="num">' + (e.episodes || "?") + "</td></tr>";
        }).join("") + "</tbody></table></div>" : '<p class="muted">Nothing: everything you watch or plan to watch is on your drives.</p>');
    // 2: watched on the list, not in AniBox
    html += '<div class="section lists-sec"><h2>Watched on your list but not in AniBox<small>' + sec.behind.length + "</small></h2>" +
      (sec.behind.length ? '<button class="btn small primary" id="lsMark">Mark these as watched in AniBox</button>' : "") + "</div>" +
      (sec.behind.length ? '<p class="muted" style="margin-top:-6px">Your list says you watched further than AniBox knows. AniBox can mark those episodes as watched here. It only ever marks; nothing is un-marked, and your files and your list stay as they are.</p>' +
        '<div class="panel"><table class="lists-tbl"><thead><tr><th><input type="checkbox" id="lsAll" checked aria-label="All"></th><th>Show</th><th>On your list</th><th>In AniBox</th><th>Would mark</th></tr></thead><tbody>' +
        sec.behind.map(function (b) {
          return '<tr><td><input type="checkbox" data-mark="' + esc(b.show) + '" checked aria-label="' + esc(b.title) + '"></td><td><a href="#/show/' + encodeURIComponent(b.show) + '">' + esc(b.title) + '</a><div class="muted" style="font-size:12px">' + esc(b.library + " · " + b.folder) + "</div></td>" +
            "<td>" + esc(b.list) + "</td><td>" + b.watched + " of " + b.files + " watched</td><td>" + plural(b.episodes.length, "episode") + ' <span class="muted">(' + esc(listsRanges(b.episodes.map(function (e) { return e.number; }))) + ")</span></td></tr>";
        }).join("") + "</tbody></table></div>" : '<p class="muted">Nothing: AniBox knows everything your list says you watched.</p>');
    // 3: in AniBox, not on the list
    html += '<div class="section lists-sec"><h2>In AniBox but not on your list<small>' + sec.notOnList.length + "</small></h2></div>" +
      (sec.notOnList.length ? '<div class="panel"><table class="lists-tbl"><thead><tr><th>Title</th><th>Folder</th><th class="num">Watched</th><th></th></tr></thead><tbody>' +
        sec.notOnList.map(function (x) {
          var link = d.source === "mal" ? "https://myanimelist.net/anime/" + x.mal_id : "https://anilist.co/search/anime?search=" + encodeURIComponent(x.title);
          return '<tr><td><a href="#/show/' + encodeURIComponent(x.shows[0].id) + '">' + esc(x.title) + "</a>" + (x.year ? ' <span class="muted">' + esc(x.year) + "</span>" : "") + '</td><td class="muted">' +
            x.shows.map(function (s2) { return esc(s2.library + " · " + s2.folder); }).join("<br>") + '</td><td class="num">' + x.watched + " of " + x.files +
            '</td><td><a href="' + esc(link) + '" target="_blank" rel="noopener noreferrer">' + esc(LIST_NAMES[d.source]) + " ↗</a></td></tr>";
        }).join("") + "</tbody></table></div>" : '<p class="muted">Nothing: every show AniBox recognized is on your list.</p>');
    render(html);
    listsWireHead(d);
    if ($("lsChips")) $("lsChips").addEventListener("click", function (e) { var b = e.target.closest("[data-f]"); if (!b) return; listsFilter = b.getAttribute("data-f"); listsPage(d.source, false); });
    if ($("lsAll")) $("lsAll").onchange = function () { var on = this.checked; view.querySelectorAll("[data-mark]").forEach(function (c) { c.checked = on; }); };
    if ($("lsMark")) $("lsMark").onclick = function () { listsMarkDialog(d); };
    if (loading) listsWait(d.source);
  }).catch(fail);
}
function listsWireHead(d) {
  $("lsSrc").addEventListener("click", function (e) { var b = e.target.closest("[data-src]"); if (!b) return; listsFilter = ""; location.hash = "#/lists/" + b.getAttribute("data-src"); });
  if ($("lsRefresh")) $("lsRefresh").onclick = function () { listsPage(d.source, true); };
}
function listsWait(src) {  // the list is being read: look again without redrawing until it's done
  setTimeout(function () {
    if (currentPage !== "lists") return;
    api("/api/lists?source=" + encodeURIComponent(src)).then(function (d) {
      if (currentPage !== "lists" || d.source !== src) return;
      if (d.sources[src].state.state === "loading") listsWait(src); else { listsPage(src, false); listsBadges = null; listsLoadBadges(); }
    }).catch(function () {});
  }, 1500);
}
function listsMarkDialog(d) {
  var picked = Array.prototype.filter.call(view.querySelectorAll("[data-mark]"), function (c) { return c.checked; }).map(function (c) { return c.getAttribute("data-mark"); });
  if (!picked.length) { toast("Tick at least one show.", true); return; }
  var rows = d.sections.behind.filter(function (b) { return picked.indexOf(b.show) >= 0; });
  var total = rows.reduce(function (n, b) { return n + b.episodes.length; }, 0);
  openModal('<div class="kicker">Mark as watched in AniBox</div><h2>' + plural(total, "episode") + " in " + plural(rows.length, "show") + "</h2>" +
    '<p class="muted">These episodes get a tick in AniBox, because your ' + esc(LIST_NAMES[d.source]) + " list counts them as watched. Nothing is un-marked, and your files and your list don't change.</p>" +
    '<div class="preview" style="white-space:normal;max-height:300px">' + rows.map(function (b) {
      var labels = b.episodes.map(function (e) { return e.label; });
      return "<div style=\"margin-bottom:8px\"><b>" + esc(b.title) + '</b> <span class="muted">(' + esc(b.folder) + ")</span><br>" + esc(labels.slice(0, 14).join(", ") + (labels.length > 14 ? " and " + (labels.length - 14) + " more" : "")) + "</div>";
    }).join("") + "</div>" +
    '<div class="row" style="margin-top:16px;justify-content:flex-end"><button class="btn small" data-close>Cancel</button><button class="btn small primary" id="lsMarkGo">Mark ' + plural(total, "episode") + "</button></div>");
  $("lsMarkGo").onclick = function () {
    this.disabled = true;
    post("/api/lists/mark", { source: d.source, shows: picked }).then(function (r) {
      closeModal(); toast(plural(r.marked, "episode") + " marked as watched."); listsPage(d.source, false);
    }).catch(function (e) { closeModal(); fail(e); });
  };
}

// ---------- Settings → Your anime lists
settingsPanels.push(function (box) {
  var s = (settingsData && settingsData.settings) || {};
  function input(key, ph) { return '<input class="input wide" data-ls="' + key + '" value="' + esc(s[key] || "") + '" placeholder="' + esc(ph) + '" autocomplete="off" spellcheck="false">'; }
  box.innerHTML = '<section class="panel" id="listsPanel"><h2>Your anime lists</h2><p class="muted">Compare your MyAnimeList or AniList list with your drives under Library → <a href="#/lists">Your lists</a>, and see your list status on every show. Reading a public list only needs your user name. Sending what you watch to your list needs a sign-in, and AniBox shows you every change first.</p>' +
    '<h3 class="lists-sub">MyAnimeList</h3>' +
    field("User name", "Your list on myanimelist.net. Reading it uses the Client ID from the MyAnimeList section above.", input("mal_username", "User name")) +
    '<div id="lsAcct-mal" class="lists-acct"></div>' +
    '<h3 class="lists-sub">AniList</h3>' +
    field("User name", "Your profile on anilist.co. A public profile needs no sign-in to read.", input("anilist_username", "User name")) +
    field("Client ID", "Only for sending what you watch: the ID of your own AniList app (see the steps below).", input("anilist_client_id", "Client ID")) +
    '<div id="lsAcct-anilist" class="lists-acct"></div>' +
    '<h3 class="lists-sub">For both</h3>' +
    '<div class="field"><div class="lbl">When I watch a finished show again: count it as a rewatch<small>Off: AniBox leaves shows that are Completed on your list alone. On: watching one again marks it as a rewatch there, and finishing it adds one to your rewatch count.</small></div>' +
    '<button class="switch' + (s.lists_rewatch ? " on" : "") + '" id="lsRewatch" role="switch" aria-checked="' + (s.lists_rewatch ? "true" : "false") + '" aria-label="Count it as a rewatch"></button></div>' +
    '<div class="field"><div class="lbl">Show first<small>Which list the badges on the cards and the Lists page use.</small></div><select class="select" id="lsSource">' +
    [["", "Automatic"], ["mal", "MyAnimeList"], ["anilist", "AniList"]].map(function (o) { return '<option value="' + o[0] + '"' + ((s.lists_source || "") === o[0] ? " selected" : "") + ">" + o[1] + "</option>"; }).join("") + "</select></div>" +
    "</section>";
  box.querySelectorAll("[data-ls]").forEach(function (inp) {
    inp.onchange = function () { save(inp.getAttribute("data-ls"), inp.value.trim()).then(function () { listsBadges = null; listsLoadBadges(); listsAccounts(); }).catch(function () {}); };
  });
  $("lsRewatch").onclick = function () { var b = this, v = !b.classList.contains("on"); save("lists_rewatch", v).then(function () { b.classList.toggle("on", v); b.setAttribute("aria-checked", v ? "true" : "false"); }).catch(function () {}); };
  $("lsSource").onchange = function () { save("lists_source", this.value).then(function () { listsBadges = null; listsLoadBadges(); }).catch(function () {}); };
  listsAccounts();
});

function listsGuide(src, a) {
  if (src === "mal") {
    return '<details class="guide"><summary>Step by step: let AniBox update your MyAnimeList list</summary><ol>' +
      '<li>On myanimelist.net open your API settings: Profile → Account settings → API (<a href="https://myanimelist.net/apiconfig" target="_blank" rel="noopener noreferrer">myanimelist.net/apiconfig</a>).</li>' +
      "<li>Edit the app whose Client ID is in the MyAnimeList section above (or click <b>Create ID</b> for a new one and copy its Client ID there).</li>" +
      "<li>Set <b>App Type</b> to <b>other</b>. That kind of app has no Client Secret, and AniBox doesn't need one.</li>" +
      "<li>Set <b>App Redirect URL</b> to exactly <code>" + esc(a.redirect) + "</code> (only this one line). The other fields can be anything, for example App Name “AniBox” and Homepage URL <code>http://127.0.0.1</code>.</li>" +
      "<li>Save. The Client ID stays the same.</li>" +
      "<li>Here: click <b>Connect</b>, then <b>Open MyAnimeList</b>, sign in and click <b>Allow</b>. The browser comes back to AniBox and says “Connected”.</li></ol>" +
      '<p class="muted">Connecting changes nothing on your list. Sync stays off until you turn it on and say OK to the changes.' + (a.redirect.indexOf(":43210/") < 0 ? " <b>AniBox runs on another port than usual right now, so the address above is different. If you registered the usual one, close the other program that uses port 43210 and start AniBox again.</b>" : "") + "</p></details>";
  }
  return '<details class="guide"><summary>Step by step: let AniBox update your AniList list</summary><ol>' +
    '<li>On anilist.co open Settings → Developer (<a href="https://anilist.co/settings/developer" target="_blank" rel="noopener noreferrer">anilist.co/settings/developer</a>) and click <b>Create New Client</b>.</li>' +
    "<li>Name: <b>AniBox</b>. Redirect URL: exactly <code>" + esc(a.redirect) + "</code>. Save.</li>" +
    "<li>Copy the <b>ID</b> (a number) into Client ID above. The secret isn't needed.</li>" +
    "<li>Here: click <b>Connect</b>, then <b>Open AniList</b>, sign in and click <b>Approve</b>. The browser comes back to AniBox and says “Connected”.</li></ol>" +
    '<p class="muted">Connecting changes nothing on your list. Sync stays off until you turn it on and say OK to the changes. AniList\'s sign-in lasts a year; then you connect again.</p></details>';
}
function listsAccounts() {
  api("/api/lists/accounts").then(function (r) {
    var again = false;
    ["mal", "anilist"].forEach(function (src) {
      var box = $("lsAcct-" + src); if (!box) return;
      var a = r.accounts[src], name = LIST_NAMES[src], html = "";
      if (a.problem) html += '<div class="note">' + esc(a.problem) + "</div>";
      if (!a.connected) {
        html += '<div class="field"><div class="lbl">Send what you watch<small>' + (a.hasClientId ? "Connect your " + name + " account first. Connecting itself changes nothing on your list." :
          src === "mal" ? "Needs the Client ID from the MyAnimeList section above, and the steps below." : "Needs the Client ID above (see the steps below).") + "</small></div>" +
          '<button class="btn small" data-lsconnect="' + src + '"' + (a.hasClientId ? "" : " disabled") + ">Connect …</button></div>" +
          '<div id="lsOpen-' + src + '"></div>' + listsGuide(src, a);
        if (a.signingIn) again = true;
      } else {
        html += '<div class="field"><div class="lbl">Connected as ' + esc(a.user) + "<small>AniBox reads this account's own list (also when it's private)." + (a.encrypted ? " The sign-in is kept encrypted for your Windows user." : "") + "</small></div>" +
          '<button class="btn small danger" data-lsdisconnect="' + src + '">Disconnect</button></div>';
        if (!a.sync) {
          html += '<div class="field"><div class="lbl">Sync: off<small>Nothing is written to your list. Turn it on to send the episodes you finish in AniBox. You see every change first.</small></div>' +
            '<button class="btn small primary" data-lssync="' + src + '" data-on="1">Turn on …</button></div>';
        } else {
          html += '<div class="field"><div class="lbl">Sync: on' + (a.since ? " since " + esc(new Date(a.since * 1000).toLocaleDateString()) : "") +
            "<small>When you finish an episode, AniBox updates that show on your list: the episode count goes up, Plan to watch becomes Watching, the last episode makes it Completed, and a show that isn't on your list yet is added. It never lowers your progress, never removes entries and never changes scores." +
            (a.queued ? " " + plural(a.queued, "update") + " waiting to be sent." : "") + (a.sending ? " " + esc(a.sending) : "") + "</small></div>" +
            '<div class="row"><button class="btn small" data-lssync="' + src + '">Sync now …</button><button class="btn small" data-lsoff="' + src + '">Turn off</button></div></div>';
          if (a.queued || a.sending) again = true;
        }
        if (a.log.length) {
          html += '<details' + (a.sync ? " open" : "") + '><summary class="muted">Last changes on your ' + esc(name) + " list</summary><div class=\"lists-log\"><table><tbody>" + a.log.map(function (l) {
            var what = l.result === "sent" ? esc(l.from) + " → <b>" + esc(l.to) + "</b>" : l.result === "skipped" ? '<span class="muted">Not changed: ' + esc(l.message) + "</span>" : '<span style="color:var(--red)">Failed: ' + esc(l.message) + "</span>";
            return '<tr><td class="muted" style="white-space:nowrap">' + esc(ago(l.t)) + "</td><td>" + esc(l.title) + "</td><td>" + what + "</td></tr>";
          }).join("") + "</tbody></table></div></details>";
        }
      }
      box.innerHTML = html;
    });
    var panel = $("listsPanel"); if (!panel) return;
    panel.querySelectorAll("[data-lsconnect]").forEach(function (b) { b.onclick = function () { listsConnect(b.getAttribute("data-lsconnect")); }; });
    panel.querySelectorAll("[data-lsdisconnect]").forEach(function (b) {
      b.onclick = function () {
        var src = b.getAttribute("data-lsdisconnect");
        if (!confirm("Disconnect " + LIST_NAMES[src] + "? AniBox forgets the sign-in and stops sending updates. Nothing on your list changes.")) return;
        post("/api/lists/disconnect", { source: src }).then(function () { toast("Disconnected."); listsAccounts(); }).catch(fail);
      };
    });
    panel.querySelectorAll("[data-lssync]").forEach(function (b) { b.onclick = function () { listsSyncDialog(b.getAttribute("data-lssync"), !!b.getAttribute("data-on")); }; });
    panel.querySelectorAll("[data-lsoff]").forEach(function (b) {
      b.onclick = function () {
        post("/api/lists/sync/off", { source: b.getAttribute("data-lsoff") }).then(function () { toast("Sync is off. Nothing more is sent."); listsAccounts(); }).catch(fail);
      };
    });
    clearTimeout(listsAccounts.t);
    if (again) listsAccounts.t = setTimeout(function () { if (currentPage === "settings") listsAccounts(); }, 2000);
  }).catch(function (e) { var b = $("lsAcct-mal"); if (b) b.textContent = e.message; });
}
function listsConnect(src) {
  post("/api/lists/connect", { source: src }).then(function (r) {
    var box = $("lsOpen-" + src); if (!box) return;
    box.innerHTML = '<p>Now open ' + esc(LIST_NAMES[src]) + ', sign in and allow AniBox. This page notices by itself when it\'s done.</p>' +
      '<a class="btn small primary" href="' + esc(r.url) + '" target="_blank" rel="noopener noreferrer">Open ' + esc(LIST_NAMES[src]) + " ↗</a>";
    clearTimeout(listsAccounts.t);
    listsAccounts.t = setTimeout(function () { if (currentPage === "settings") listsAccounts(); }, 2000);
  }).catch(fail);
}
function listsSyncDialog(src, turnOn) {
  var name = LIST_NAMES[src];
  openModal('<div class="kicker">' + esc(name) + '</div><h2>' + (turnOn ? "Turn on sync?" : "Sync now?") + '</h2><p class="muted">Reading your list and comparing it with what you watched in AniBox …</p>');
  post("/api/lists/sync/preview", { source: src }).then(function (p) {
    if ($("modal").hidden) return;
    var n = p.changes.length, these = n === 1 ? "this change" : "these " + plural(n, "change");
    var html = '<div class="kicker">' + esc(name) + " · " + esc(p.user) + "</div><h2>" + (turnOn ? "Turn on sync?" : "Sync now?") + "</h2>" +
      (n ? "<p>AniBox would make " + these + " on your list now:</p>" +
        '<div class="preview" style="white-space:normal;max-height:300px;padding:0"><table class="lists-tbl"><thead><tr><th>Show</th><th>Now</th><th>After</th></tr></thead><tbody>' +
        p.changes.map(function (c) { return "<tr><td>" + esc(c.title) + "</td><td>" + esc(c.from) + "</td><td><b>" + esc(c.to) + "</b></td></tr>"; }).join("") + "</tbody></table></div>" :
        "<p>Your list already matches what you watched in AniBox: nothing to change right now.</p>") +
      (p.same ? '<p class="muted">' + plural(p.same, "other show") + (p.same === 1 ? " is" : " are") + " already as far on your list as in AniBox (or further), or completed there.</p>" : "") +
      (p.skipped.length ? '<details><summary class="muted">' + plural(p.skipped.length, "show") + " left alone</summary><p class=\"muted\" style=\"font-size:13px\">" + p.skipped.map(function (x) { return esc(x.title) + ": " + esc(x.why); }).join("<br>") + "</p></details>" : "") +
      '<p class="muted">' + (turnOn ? "From then on, when you finish an episode, AniBox updates that show on your list the same way (and adds it if it isn't there yet). " : "") +
      "AniBox never lowers your progress, never removes entries and never changes scores.</p>" +
      '<div class="row" style="margin-top:16px;justify-content:flex-end"><button class="btn small" data-close>Cancel</button>' +
      (turnOn ? (n ? '<button class="btn small" id="lsOnOnly">Turn on, only for new episodes</button><button class="btn small primary" id="lsOnAll">Turn on and make ' + these + "</button>" : '<button class="btn small primary" id="lsOnOnly">Turn on</button>') :
        (n ? '<button class="btn small primary" id="lsNow">Make ' + these + "</button>" : "")) + "</div>";
    $("modalBox").innerHTML = html;
    function go(body, msg) {
      post("/api/lists/sync/apply", Object.assign({ source: src }, body)).then(function () { closeModal(); toast(msg); listsAccounts(); }).catch(function (e) { closeModal(); fail(e); });
    }
    if ($("lsOnAll")) $("lsOnAll").onclick = function () { go({ turnOn: true, token: p.token }, "Sync is on. Sending " + plural(n, "change") + " …"); };
    if ($("lsOnOnly")) $("lsOnOnly").onclick = function () { go({ turnOn: true }, "Sync is on for the episodes you finish from now on."); };
    if ($("lsNow")) $("lsNow").onclick = function () { go({ token: p.token }, "Sending " + plural(n, "change") + " …"); };
  }).catch(function (e) { closeModal(); fail(e); });
}
