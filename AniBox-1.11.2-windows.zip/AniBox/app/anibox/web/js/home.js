/* AniBox window · Home page: continue watching, recently added, update notice.
   Plain scripts sharing one page: loaded in order by index.html. */
"use strict";

// ---------- Home
function home() {
  api("/api/home").then(function (d) {
    if (!d.hasFolders) {
      render('<div class="welcome"><div class="kicker">Welcome</div><h1 style="margin:8px 0 10px">Your anime, in one place</h1>' +
        '<p class="muted">AniBox shows the anime folders on your drives as a library, plays them with mpv and remembers where you stopped. It only reads your folders; it never changes them.</p>' +
        '<div class="steps"><div class="step"><b>1</b>Add the folders with your anime (for example the Shield\'s drives).</div>' +
        '<div class="step"><b>2</b>AniBox reads them and matches every folder to MyAnimeList.</div>' +
        '<div class="step"><b>3</b>Click a show and press Play. AniBox remembers the rest.</div></div>' +
        '<a class="btn primary" href="#/settings">Add your anime folders</a></div>');
      return;
    }
    var html = updateResultBanner(d.updateResult) + localUpdateBanner(d.localUpdate) + (d.localUpdate ? "" : updateBanner(d.update)) + '<div id="homeExtra"></div>';
    var c = d.continue;
    if (c.length) {
      var f = c[0], pct = f.files ? Math.round(100 * f.watched / f.files) : 0;
      html += '<section class="hero">' + (f.poster ? '<div class="bg" style="background-image:url(\'' + esc(f.poster) + '\')"></div>' : "") +
        posterHtml(f) + '<div><div class="kicker">Continue watching</div><h1>' + esc(f.title) + "</h1>" +
        '<div class="sub">' + esc(f.next.label) + (f.next.position ? " · from " + fmt(f.next.position) : "") + " · " + f.watched + " of " + f.files + " watched</div>" +
        '<div class="progress"><i style="width:' + pct + '%"></i></div>' +
        '<div class="row"><button class="btn primary" data-play="' + esc(f.id) + '">▶&nbsp; ' + (f.next.position ? "Resume" : "Play") + " " + esc(f.next.label) + "</button>" +
        '<a class="btn" href="#/show/' + encodeURIComponent(f.id) + '">All episodes</a></div></div></section>';
      if (c.length > 1) html += '<div class="section"><h2>Also watching</h2></div><div class="shelf">' + c.slice(1).map(cardHtml).join("") + "</div>";
    } else if (d.counts.shows) {
      html += '<section class="panel"><div class="kicker">Ready</div><h1 style="margin:6px 0">Pick something to watch</h1><p class="muted">Your library has ' +
        d.counts.shows + ' shows. Open the <a href="#/library">Library</a> and press Play on any of them.</p></section>';
    } else {
      html += '<section class="panel"><h2>No shows yet</h2><p class="muted">Scan your folders in <a href="#/settings">Settings</a>.</p></section>';
    }
    if (d.recent.length) html += '<div class="section"><h2>Recently added</h2><a href="#/library">Whole library →</a></div><div class="shelf">' + d.recent.map(cardHtml).join("") + "</div>";
    html += '<div class="stats"><div class="stat"><b>' + d.counts.shows + '</b>shows and movies</div><div class="stat"><b>' + d.counts.episodes.toLocaleString() +
      '</b>episode files</div><div class="stat"><b>' + d.counts.matched + '</b>matched to MyAnimeList</div><div class="stat"><b>' + esc(ago(d.scannedAt)) + "</b>last scan</div></div>";
    render(html);
    wireUpdateButtons();
    runPanels(homePanels, "homeExtra");
  }).catch(fail);
}

function updateBanner(u) {
  if (!u || !u.newer) return "";
  var dl = u.download || {}, running = dl.state === "running";
  return '<div class="banner"><div><b>AniBox ' + esc(u.latest) + ' is out</b> <span class="muted">· you have ' + esc(u.current) +
    (running ? ". Downloading … " + (dl.total ? Math.round(100 * dl.bytes / dl.total) + " %" : "") : dl.state === "error" ? ". The download didn't work: " + esc(dl.error) :
      ". AniBox downloads it into your Downloads folder and checks it; then click Update now.") + "</span>" +
    (u.notes ? '<div class="muted" style="font-size:13px;margin-top:4px;white-space:pre-line">' + esc(u.notes.slice(0, 400)) + "</div>" : "") + "</div>" +
    (u.canDownload ? '<button class="btn small primary" data-update-download' + (running ? " disabled" : "") + ">Download</button>" :
      '<a class="btn small" href="' + esc(u.page) + '" target="_blank" rel="noopener noreferrer">Open the release page ↗</a>') + "</div>";
}
