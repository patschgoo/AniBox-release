"""Internet Archive videos played straight from archive.org (stream.py): lists for the window.

Playing itself goes through ``/api/play`` with a ``ia:<identifier>/<file>`` key, like an episode.

Part of the App class (see server.py); the methods use the App's attributes.
"""

from __future__ import annotations

from . import stream
from .apierror import ApiError
from .iarchive import valid_id


class RoutesStreamMixin:
    GET_ROUTES = {
        "/api/stream/continue": "_stream_continue",
        "/api/stream/progress": "_stream_progress",
    }

    def _stream_init(self) -> None:
        self.streams = stream.IaStreams(self.ia_client, self.data_dir, self.store)
        self.player.streams = self.streams
        self.tv.streams = self.streams  # Play on TV for them too (tvstream.py)

    def _stream_continue(self, query: dict) -> dict:
        try:
            limit = max(1, min(48, int(query.get("limit") or 12)))
        except ValueError:
            limit = 12
        return {"items": self.streams.continue_watching(limit)}

    def _stream_progress(self, query: dict) -> dict:
        ident = query.get("id", "")
        if not valid_id(ident):
            raise ApiError("That isn't an archive.org item name.")
        return {"files": self.streams.progress_for(ident)}
