"""Update AniBox from a zip in the Downloads folder ("Update now").

1. ``find_update``: look in the Downloads folder for ``AniBox-<version>-windows.zip`` files (also
   "AniBox-1.6.0-windows (1).zip", the way browsers name a second download), check each one (its
   version comes from inside the zip, not from the file name) and pick the newest that is newer than
   this AniBox.
2. ``SelfUpdate.install``: unpack it into ``<data>/update/staging``, copy this AniBox's Python and
   ``update_apply.py`` next to it, start that helper and close AniBox. The helper swaps the program
   files once AniBox is gone, starts the new version, and puts the old one back if the new one
   doesn't start (see update_apply.py).
3. ``SelfUpdate.take_result``: what happened, shown once after the restart.

Only the program files change. Your data (``%LOCALAPPDATA%\\AniBox``, or the ``data`` folder in
portable mode) is never touched, and AniBox never downloads anything for this by itself.
"""

from __future__ import annotations

import json
import logging
import os
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path
from typing import Dict, Optional, Tuple

from . import __version__

log = logging.getLogger("anibox")

ZIP_NAME_RE = re.compile(r"^AniBox-[0-9][0-9.]*-windows(?: ?\(\d+\))?\.zip$", re.IGNORECASE)
VERSION_RE = re.compile(r"""__version__\s*=\s*["']([0-9]+(?:\.[0-9]+)+)["']""")
TOP = "AniBox/"
MAX_UNPACKED = 400 * 1024 * 1024  # the package is ~40 MB unpacked; anything far bigger isn't ours


class UpdateError(Exception):
    pass


def version_tuple(v: str) -> Tuple[int, ...]:
    return tuple(int(x) for x in re.findall(r"\d+", v or "0"))


def downloads_dir() -> Path:
    """The user's Downloads folder (where Windows really keeps it, even if it was moved)."""
    override = os.environ.get("ANIBOX_DOWNLOADS")
    if override:
        return Path(override)
    if os.name == "nt":
        try:
            import ctypes
            import uuid
            from ctypes import wintypes
            folder_id = uuid.UUID("{374DE290-123F-4565-9164-39C4925E467B}")  # FOLDERID_Downloads
            guid = (ctypes.c_byte * 16).from_buffer_copy(folder_id.bytes_le)
            out = ctypes.c_wchar_p()
            shell32, ole32 = ctypes.windll.shell32, ctypes.windll.ole32
            shell32.SHGetKnownFolderPath.argtypes = [ctypes.c_void_p, wintypes.DWORD, wintypes.HANDLE,
                                                    ctypes.POINTER(ctypes.c_wchar_p)]
            if shell32.SHGetKnownFolderPath(ctypes.byref(guid), 0, None, ctypes.byref(out)) == 0:
                path = out.value
                ole32.CoTaskMemFree(out)
                if path:
                    return Path(path)
        except Exception:  # fall back to the usual place
            pass
    return Path.home() / "Downloads"


def read_package(path: Path) -> dict:
    """Check that ``path`` is an AniBox package and return ``{"path", "name", "version", "size", "mtime"}``."""
    try:
        with zipfile.ZipFile(path) as z:
            infos = z.infolist()
            names = {i.filename for i in infos}
            total = 0
            for i in infos:
                n = i.filename
                if not n.startswith(TOP) or n.startswith("/") or "\\" in n or ".." in n.split("/") or ":" in n:
                    raise UpdateError(f"{path.name} contains an unexpected file ({n}).")
                total += i.file_size
            if total > MAX_UNPACKED:
                raise UpdateError(f"{path.name} is much bigger than an AniBox package.")
            for needed in ("AniBox/AniBox.bat", "AniBox/app/anibox/__init__.py", "AniBox/app/anibox/__main__.py"):
                if needed not in names:
                    raise UpdateError(f"{path.name} isn't an AniBox package ({needed[len(TOP):]} is missing).")
            m = VERSION_RE.search(z.read("AniBox/app/anibox/__init__.py").decode("utf-8", "replace"))
    except zipfile.BadZipFile:
        raise UpdateError(f"{path.name} is damaged or not finished downloading.")
    except OSError as exc:
        raise UpdateError(f"Couldn't read {path.name}: {exc}")
    if not m:
        raise UpdateError(f"{path.name} has no version number.")
    st = path.stat()
    return {"path": str(path), "name": path.name, "version": m.group(1), "size": st.st_size, "mtime": st.st_mtime}


_cache: Dict[Tuple[str, float, int], object] = {}


def find_update(folder: Path, current: str = __version__) -> dict:
    """``{"folder", "found": newest newer package or None, "skipped": [{"name", "why"}]}``."""
    out = {"folder": str(folder), "found": None, "skipped": []}
    try:
        files = [p for p in folder.iterdir() if p.is_file() and ZIP_NAME_RE.match(p.name)]
    except OSError:
        return out
    best = None
    for p in files:
        st = p.stat()
        key = (str(p), st.st_mtime, st.st_size)
        info = _cache.get(key)
        if info is None:
            try:
                info = read_package(p)
            except UpdateError as exc:
                info = exc
            _cache[key] = info
        if isinstance(info, UpdateError):
            out["skipped"].append({"name": p.name, "why": str(info)})
        elif version_tuple(info["version"]) <= version_tuple(current):
            out["skipped"].append({"name": p.name, "why": f"version {info['version']} isn't newer than this one"})
        elif best is None or (version_tuple(info["version"]), info["mtime"]) > (version_tuple(best["version"]), best["mtime"]):
            best = info
    out["found"] = best
    return out


def unpack(package: Path, target: Path) -> Path:
    """Unpack the package's ``AniBox/`` folder into ``target`` (emptied first). Returns that folder."""
    if target.exists():
        shutil.rmtree(target)
    target.mkdir(parents=True)
    read_package(package)  # checked again: the file could have changed since it was found
    with zipfile.ZipFile(package) as z:
        root = target.resolve()
        for info in z.infolist():
            dest = (target / info.filename).resolve()
            if root not in dest.parents and dest != root:
                raise UpdateError(f"{package.name} contains an unexpected file ({info.filename}).")
            if info.is_dir():
                dest.mkdir(parents=True, exist_ok=True)
                continue
            dest.parent.mkdir(parents=True, exist_ok=True)
            with z.open(info) as src, open(dest, "wb") as fh:
                shutil.copyfileobj(src, fh)
    return target / "AniBox"


class SelfUpdate:
    def __init__(self, program_dir: Path, data_dir: Path, port: int):
        self.program_dir = Path(program_dir)
        self.work = Path(data_dir) / "update"
        self.log_file = Path(data_dir) / "logs" / "update.log"
        self.port = port
        self.state = {"state": "idle"}

    # -- can this copy update itself? ------------------------------------------------------------

    def why_not(self) -> str:
        """"" if "Update now" can work here, else the reason (shown in Settings)."""
        p = self.program_dir
        if (p / ".git").exists():
            return "This AniBox is a developer copy (a git folder); update it with git instead."
        if not (p / "AniBox.bat").is_file() or not (p / "app" / "anibox").is_dir():
            return "AniBox isn't in its usual program folder, so it can't replace itself."
        if not os.access(p, os.W_OK):
            return f"Windows doesn't let AniBox change its program folder ({p})."
        return ""

    def status(self) -> dict:
        found = find_update(downloads_dir())
        return {"current": __version__, "folder": found["folder"], "found": found["found"],
                "skipped": found["skipped"], "why_not": self.why_not(), "state": self.state,
                "program": str(self.program_dir)}

    # -- the update ------------------------------------------------------------------------------

    def _runner(self) -> Path:
        """A Python that isn't inside the program folder (that one gets replaced)."""
        exe = Path(sys.executable)
        if os.name == "nt" and exe.name.lower() == "python.exe" and (exe.parent / "pythonw.exe").is_file():
            exe = exe.parent / "pythonw.exe"  # no console window
        try:
            inside = self.program_dir.resolve() in exe.resolve().parents
        except OSError:
            inside = True
        if not inside:
            return exe
        runner = self.work / "runner"
        if runner.exists():
            shutil.rmtree(runner, ignore_errors=True)
        shutil.copytree(exe.parent, runner, ignore=shutil.ignore_patterns("__pycache__"))
        return runner / exe.name

    def install(self, start: Optional[list] = None, pid: Optional[int] = None) -> dict:
        """Prepare everything and start the helper. The caller closes AniBox right after."""
        reason = self.why_not()
        if reason:
            raise UpdateError(reason)
        found = find_update(downloads_dir())["found"]
        if not found:
            raise UpdateError("No newer AniBox zip in your Downloads folder.")
        self.state = {"state": "preparing", "version": found["version"]}
        self.work.mkdir(parents=True, exist_ok=True)
        self.log_file.parent.mkdir(parents=True, exist_ok=True)
        staging = unpack(Path(found["path"]), self.work / "staging")
        helper = self.work / "update_apply.py"
        shutil.copy2(Path(__file__).with_name("update_apply.py"), helper)
        result = self.work / "result.json"
        if result.exists():
            result.unlink()
        cmd = [str(self._runner()), str(helper), "--program", str(self.program_dir), "--staging", str(staging),
               "--old-version", __version__, "--new-version", found["version"], "--pid", str(pid if pid is not None else os.getpid()),
               "--port", str(self.port), "--result", str(result), "--log", str(self.log_file)]
        if start:
            cmd += ["--start"] + list(start)
        log.info("Updating from %s to %s with %s (helper: %s)", __version__, found["version"], found["name"], cmd[0])
        if os.name == "nt":
            flags = 0x00000008 | 0x00000200 | 0x08000000  # DETACHED_PROCESS | NEW_PROCESS_GROUP | NO_WINDOW
            subprocess.Popen(cmd, cwd=str(self.work), creationflags=flags, close_fds=True)
        else:
            subprocess.Popen(cmd, cwd=str(self.work), start_new_session=True, close_fds=True)
        self.state = {"state": "restarting", "version": found["version"]}
        return {"ok": True, "version": found["version"], "name": found["name"]}

    def take_result(self) -> Optional[dict]:
        """The helper's report from the last update, once (then it's gone)."""
        result = self.work / "result.json"
        try:
            data = json.loads(result.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None
        try:
            result.unlink()
            for leftover in ("staging", "runner"):
                shutil.rmtree(self.work / leftover, ignore_errors=True)
        except OSError:
            pass
        log.info("Last update: %s", data.get("message"))
        return data
