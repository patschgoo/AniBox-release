"""The Internet Archive cache (iacache.py): its settings panel, the state badges and Keep buttons.

Streams play through the cache by themselves (a url hook and a play hook on ``self.streams``); these
routes are only for the AniBox window, never the phone remote.

Part of the App class (see server.py); the methods use the App's attributes.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path

from . import iacache
from .apierror import ApiError
from .shortcut import open_folder

log = logging.getLogger("anibox.server")

NUMBERS = {"gb": ("ia_cache_gb", 1, 100000), "connections": ("ia_cache_connections", 1, 32),
           "ahead": ("ia_cache_ahead", 0, 10)}


class RoutesIaCacheMixin:
    GET_ROUTES = {
        "/api/iacache": "_iacache_get",
    }
    POST_ROUTES = {
        "/api/iacache/states": "_iacache_states",
        "/api/iacache/keep": "_iacache_keep",
        "/api/iacache/action": "_iacache_action",
        "/api/iacache/settings": "_iacache_settings",
        "/api/iacache/empty": "_iacache_empty",
        "/api/iacache/open": "_iacache_open",
    }

    def _iacache_init(self) -> None:
        """After the window's server got its port: an App that couldn't start never loads anything."""
        self.iacache = iacache.IaCache(self.data_dir, self.store, self.streams, self.ia_client,
                                       keep_root=self._ia_dir, stopping=self._stopping)
        self.streams.url_hooks.append(self.iacache.url_hook)
        self.streams.play_hooks.append(self.iacache.play_hook)
        self.iacache.wrap_mpv_options()
        self.iacache.resume()  # keeping and loading ahead from last time go on

    def _iacache_get(self, query: dict) -> dict:
        return self.iacache.info()

    def _iacache_key(self, body: dict) -> str:
        key = body.get("key")
        if not isinstance(key, str) or not iacache.split_key(key) or not iacache.split_key(key)[1]:
            raise ApiError("That isn't an Internet Archive video.")
        return key

    def _iacache_states(self, body: dict) -> dict:
        keys = body.get("keys")
        if not isinstance(keys, list) or len(keys) > 5000 or not all(isinstance(k, str) for k in keys):
            raise ApiError("Send a list of video keys.")
        s = self.iacache.settings()
        return {"states": self.iacache.states(keys), "enabled": s["enabled"], "keepDir": s["keepDir"]}

    def _iacache_keep(self, body: dict) -> dict:
        key = self._iacache_key(body)
        try:
            st = self.iacache.keep(key, bool(body.get("keep", True)), str(body.get("title") or ""))
        except ValueError as exc:
            raise ApiError(str(exc))
        return {"ok": True, "state": st}

    def _iacache_action(self, body: dict) -> dict:
        key = self._iacache_key(body)
        try:
            st = self.iacache.action(key, str(body.get("action") or ""))
        except KeyError as exc:
            raise ApiError(str(exc.args[0]) if exc.args else "Not found", 404)
        except ValueError as exc:
            raise ApiError(str(exc))
        return {"ok": True, "state": st}

    def _iacache_settings(self, body: dict) -> dict:
        changes = {}
        if "enabled" in body:
            changes["ia_cache"] = bool(body["enabled"])
        for field, setting in (("dir", "ia_cache_dir"), ("keepDir", "ia_keep_dir")):
            if field in body:
                path = str(body.get(field) or "").strip().strip('"')
                if path and not os.path.isabs(path):
                    raise ApiError("Type a full folder path, e.g. D:\\AniBox cache.")
                changes[setting] = path
        for field, (setting, low, high) in NUMBERS.items():
            if field in body:
                try:
                    changes[setting] = max(low, min(high, int(body[field])))
                except (TypeError, ValueError):
                    raise ApiError("That must be a number.")
        if changes:
            self.store.update_settings(changes)
            log.info("Internet Archive cache settings changed: %s", ", ".join(sorted(changes)))
            self.iacache.settings_changed()  # a smaller limit: cleaned up right away
        return self.iacache.info()

    def _iacache_empty(self, body: dict) -> dict:
        return {"ok": True, **self.iacache.empty(), "info": self.iacache.info()}

    def _iacache_open(self, body: dict) -> dict:
        s = self.iacache.settings()
        what = str(body.get("what") or "cache")
        if what not in ("cache", "keep"):
            raise ApiError("Unknown folder")
        folder = Path(s["dir"] if what == "cache" else s["keepDir"])
        folder.mkdir(parents=True, exist_ok=True)  # the folder itself; nothing in it changes
        open_folder(folder)
        return {"ok": True}
