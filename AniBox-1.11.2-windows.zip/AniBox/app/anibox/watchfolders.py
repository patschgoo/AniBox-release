"""Folder watching: while AniBox runs, it notices new videos by itself.

Two parts, both only while AniBox is open (they stop when it closes) and both only read:

- **The inbox** (setting ``watch_inbox``, on by default): every 30 seconds AniBox looks at the
  "Add new videos" folders (setting ``inbox_folders``, else Downloads). Cheap polling, no extra
  libraries: a folder is listed again only when its modified time changed (and every few minutes
  anyway); the video files in it are checked with a ``stat``. A video counts once it is finished:
  at least 1 MB, not written to for 20 seconds, the same size as the last look, and no ``.part`` /
  ``.crdownload`` next to it (the same rules as importer.scan_inbox). Home and the Library page
  then say "3 new videos in Downloads → Add them". Videos AniBox already copied into the library
  don't count; "Not now" hides the ones there are now (until others come).
- **The library folders** (setting ``auto_rescan_minutes``, 0 = off, the default): a quick rescan
  every N minutes, never while something plays (it waits until playback stops). Network shares
  reuse unchanged folders through the scan cache, so this is light. New episodes it finds are
  "new" (not locked), as with every scan.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Optional, Set, Tuple

import anibox  # noqa: F401  (makes anibox_check importable)
from anibox_check.folders import VIDEO_EXTENSIONS

from .importer import MAX_DEPTH, MIN_SIZE, SETTLE_SECONDS, SKIP_DIRS, _inside, _partial

log = logging.getLogger("anibox.watch")

POLL_SECONDS = 30  # the inbox
TICK_SECONDS = 5
FULL_LIST_EVERY = 10  # every 10th look lists every folder again (in case a folder time didn't change)
STATE_FILE = "watch-inbox.json"
SHOWN_FILES = 8
MIN_RESCAN_MINUTES = 5


def rescan_minutes(settings: dict) -> int:
    """``auto_rescan_minutes``: 0 = off; otherwise at least every 5 minutes, at most once a day."""
    try:
        minutes = int(settings.get("auto_rescan_minutes") or 0)
    except (TypeError, ValueError):
        return 0
    return 0 if minutes <= 0 else max(MIN_RESCAN_MINUTES, min(1440, minutes))


def _key(path: str) -> str:
    return os.path.normcase(os.path.abspath(path))


class InboxWatcher:
    """Finished videos in the inbox folders, found by polling."""

    def __init__(self, state_path: Path):
        self.state_path = Path(state_path)
        self._dirs: Dict[str, Tuple[float, List[str], List[str], Set[str]]] = {}  # dir -> (mtime, subdirs, videos, names)
        self._sizes: Dict[str, int] = {}  # video -> size at the last look
        self.ready: List[dict] = []
        self.polls = 0
        self.listed = 0  # folders listed at the last look (the rest were unchanged)
        self.dismissed: Dict[str, int] = {}  # normcase(path) -> size when "Not now" was clicked
        try:
            data = json.loads(self.state_path.read_text(encoding="utf-8"))
            if isinstance(data, dict) and isinstance(data.get("dismissed"), dict):
                self.dismissed = {str(k): int(v) for k, v in data["dismissed"].items() if isinstance(v, int)}
        except (OSError, ValueError):
            pass

    def poll(self, roots: Iterable[str], exclude: Iterable[str] = (), added: Iterable[str] = (),
             now: Optional[float] = None) -> List[dict]:
        """Look once. Returns the finished videos (``{"path", "name", "size", "mtime", "root"}``, newest first)."""
        now = time.time() if now is None else now
        self.polls += 1
        full = self.polls % FULL_LIST_EVERY == 1
        exclude = [e for e in exclude if e]
        added_keys = {_key(a) for a in added}
        seen: Set[str] = set()
        files: List[Tuple[str, str, Set[str], str]] = []
        self.listed = 0
        for root in roots:
            if not root or not os.path.isdir(root) or _inside(root, exclude):
                continue
            self._walk(root, root, 0, exclude, full, files, seen)
        for d in list(self._dirs):
            if d not in seen:
                del self._dirs[d]
        ready, sizes = [], {}
        for path, name, names, root in files:
            try:
                st = os.stat(path)
            except OSError:
                continue
            prev = self._sizes.get(path)
            sizes[path] = st.st_size
            if st.st_size < MIN_SIZE or now - st.st_mtime < SETTLE_SECONDS or _partial(path, names):
                continue
            if prev is not None and prev != st.st_size:
                continue  # still growing
            if _key(path) in added_keys:
                continue  # AniBox already copied it into the library
            ready.append({"path": path, "name": name, "size": st.st_size, "mtime": st.st_mtime, "root": root})
        self._sizes = sizes
        ready.sort(key=lambda r: r["mtime"], reverse=True)
        self.ready = ready
        return ready

    def _walk(self, root: str, path: str, depth: int, exclude: List[str], full: bool,
              files: List[Tuple[str, str, Set[str], str]], seen: Set[str]) -> None:
        try:
            mtime = os.stat(path).st_mtime
        except OSError:
            return
        seen.add(path)
        cached = self._dirs.get(path)
        if cached and not full and cached[0] == mtime:
            subdirs, videos, names = cached[1], cached[2], cached[3]
        else:
            subdirs, videos, names = [], [], set()
            try:
                with os.scandir(path) as it:
                    for entry in it:
                        try:
                            is_dir = entry.is_dir(follow_symlinks=False)
                        except OSError:
                            continue
                        if is_dir:
                            if not entry.name.startswith(".") and entry.name.lower() not in SKIP_DIRS \
                                    and not _inside(entry.path, exclude):
                                subdirs.append(entry.name)
                        else:
                            names.add(entry.name)
                            if os.path.splitext(entry.name)[1].lower() in VIDEO_EXTENSIONS:
                                videos.append(entry.name)
            except OSError:
                return
            self._dirs[path] = (mtime, subdirs, videos, names)
            self.listed += 1
        for v in videos:
            files.append((os.path.join(path, v), v, names, root))
        if depth < MAX_DEPTH:
            for d in subdirs:
                self._walk(root, os.path.join(path, d), depth + 1, exclude, full, files, seen)

    def pending(self) -> List[dict]:
        """Finished videos you haven't said "Not now" to."""
        return [r for r in self.ready if self.dismissed.get(_key(r["path"])) != r["size"]]

    def dismiss(self) -> int:
        """"Not now": hide the videos there are now (a new one, or a changed one, shows up again)."""
        now_there = {_key(r["path"]): r["size"] for r in self.ready}
        n = len(self.pending())
        self.dismissed = now_there  # older entries for files that are gone are dropped
        try:
            self.state_path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.state_path.with_name(self.state_path.name + ".tmp")
            tmp.write_text(json.dumps({"dismissed": self.dismissed}, ensure_ascii=False), encoding="utf-8")
            os.replace(tmp, self.state_path)
        except OSError as exc:
            log.warning("Couldn't save %s: %s", self.state_path, exc)
        return n


class FolderWatch:
    """The schedule: the inbox every 30 s, the library every N minutes (never while something plays)."""

    def __init__(self, data_dir: Path, settings: Callable[[], dict], inbox_roots: Callable[[], List[str]],
                 exclude: Callable[[], List[str]], added: Callable[[], Iterable[str]], playing: Callable[[], bool],
                 busy: Callable[[], bool], rescan: Callable[[], bool], clock: Callable[[], float] = time.time):
        self.inbox = InboxWatcher(Path(data_dir) / STATE_FILE)
        self.settings = settings
        self.inbox_roots = inbox_roots
        self.exclude = exclude
        self.added = added
        self.playing = playing
        self.busy = busy
        self.rescan = rescan
        self.clock = clock
        self.started = clock()
        self.next_inbox = 0.0
        self.checked = 0.0
        self.last_rescan = self.started
        self.rescans = 0
        self.waiting = ""  # why the due rescan waits: "playing" | "busy"
        self._last_count = -1
        self._lock = threading.Lock()

    def tick(self, now: Optional[float] = None) -> None:
        now = self.clock() if now is None else now
        s = self.settings()
        if s.get("watch_inbox", True) and now >= self.next_inbox:
            self.check_inbox(now)
        minutes = rescan_minutes(s)
        if minutes > 0 and now - self.last_rescan >= minutes * 60:
            self._rescan_now(now, minutes)
        elif minutes <= 0:
            self.waiting = ""

    def check_inbox(self, now: Optional[float] = None) -> List[dict]:
        now = self.clock() if now is None else now
        with self._lock:
            self.next_inbox = now + POLL_SECONDS
            roots = [r for r in self.inbox_roots() if r]
            try:
                self.inbox.poll(roots, self.exclude(), self.added(), now)
            except Exception:
                log.exception("Folder watching: looking at %s failed", roots)
            pending = self.inbox.pending()
            if self._last_count >= 0 and len(pending) > self._last_count:
                log.info("Folder watching: %d new video(s) waiting in %s (e.g. %s)", len(pending), self.where(roots),
                         pending[0]["name"])
            elif self._last_count < 0 and pending:
                log.info("Folder watching: %d video(s) waiting in %s", len(pending), self.where(roots))
            self._last_count = len(pending)
            self.checked = now
            return pending

    def _rescan_now(self, now: float, minutes: int) -> None:
        if self.playing():
            if self.waiting != "playing":
                log.info("Automatic rescan waits: something is playing")
            self.waiting = "playing"
            return
        if self.busy():
            self.waiting = "busy"
            return
        self.waiting = ""
        self.last_rescan = now
        if not self.settings().get("folders"):
            return
        started = self.rescan()
        if started:
            self.rescans += 1
            log.info("Automatic rescan of the library folders (every %d min)", minutes)

    def dismiss(self) -> int:
        with self._lock:
            n = self.inbox.dismiss()
            self._last_count = len(self.inbox.pending())
        log.info("Folder watching: %d new video(s) hidden until others come (Not now)", n)
        return n

    @staticmethod
    def where(roots: List[str]) -> str:
        roots = [r for r in roots if r]
        if len(roots) == 1:
            return os.path.basename(os.path.normpath(roots[0])) or roots[0]
        return "your inbox folders"

    def status(self) -> dict:
        s = self.settings()
        minutes = rescan_minutes(s)
        pending = self.inbox.pending() if s.get("watch_inbox", True) else []
        return {
            "inbox": {"enabled": bool(s.get("watch_inbox", True)), "count": len(pending),
                      "files": [p["name"] for p in pending[:SHOWN_FILES]], "where": self.where(self.inbox_roots()),
                      "checked": self.checked},
            "rescan": {"minutes": minutes, "last": self.last_rescan if self.rescans else 0.0,
                       "next": self.last_rescan + minutes * 60 if minutes > 0 else 0.0, "waiting": self.waiting,
                       "count": self.rescans},
        }

    def run(self, stop: threading.Event) -> None:
        log.info("Folder watching started")
        while not stop.wait(TICK_SECONDS):
            try:
                self.tick()
            except Exception:
                log.exception("Folder watching failed")
        log.info("Folder watching stopped")
