"""A desktop shortcut for AniBox (Windows), so you don't have to find AniBox.bat each time.

Creates "AniBox.lnk" on your desktop (the desktop folder Windows reports, also when it lives in
OneDrive). It starts AniBox without a console window. Nothing else on the PC is changed.
"""

from __future__ import annotations

import logging
import os
import subprocess
import sys
from pathlib import Path

from .paths import PROGRAM_DIR

log = logging.getLogger("anibox.shortcut")


def _ps_quote(text: str) -> str:
    return "'" + str(text).replace("'", "''") + "'"


def pythonw() -> str:
    exe = Path(sys.executable)
    candidate = exe.with_name("pythonw.exe")
    return str(candidate if candidate.is_file() else exe)


def create_desktop_shortcut() -> str:
    """Returns the path of the new shortcut. Raises RuntimeError with a readable message."""
    if not sys.platform.startswith("win"):
        raise RuntimeError("Desktop shortcuts are made on Windows only.")
    app_dir = PROGRAM_DIR / "app"
    icon = Path(__file__).resolve().parent / "web" / "anibox.ico"
    script = (
        "$d = [Environment]::GetFolderPath('Desktop'); "
        "$p = Join-Path $d 'AniBox.lnk'; "
        "$s = (New-Object -ComObject WScript.Shell).CreateShortcut($p); "
        f"$s.TargetPath = {_ps_quote(pythonw())}; "
        "$s.Arguments = '-m anibox'; "
        f"$s.WorkingDirectory = {_ps_quote(app_dir)}; "
        f"$s.IconLocation = {_ps_quote(str(icon) + ',0')}; "
        "$s.Description = 'AniBox: your anime library'; "
        "$s.Save(); Write-Output $p"
    )
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", script],
                           capture_output=True, timeout=30, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise RuntimeError(f"Windows couldn't make the shortcut ({exc}).") from exc
    out = r.stdout.decode("utf-8", "replace").strip()
    if r.returncode != 0 or not out:
        log.warning("Shortcut failed: %s", r.stderr.decode("utf-8", "replace")[:500])
        raise RuntimeError("Windows couldn't make the shortcut.")
    log.info("Desktop shortcut created: %s", out)
    return out.splitlines()[-1]


def open_folder(path: Path) -> None:
    """Show a folder in File Explorer (or the file manager)."""
    path = Path(path)
    if not path.is_dir():
        raise RuntimeError("That folder doesn't exist (yet).")
    if sys.platform.startswith("win"):
        os.startfile(str(path))  # type: ignore[attr-defined]
    elif sys.platform == "darwin":
        subprocess.Popen(["open", str(path)])
    else:
        subprocess.Popen(["xdg-open", str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def show_file(path: Path) -> None:
    """Open the file's folder in File Explorer with the file selected."""
    path = Path(path)
    if not path.exists():
        raise RuntimeError("That file isn't there anymore.")
    if sys.platform.startswith("win"):
        subprocess.Popen(f'explorer /select,"{path}"')
    else:
        open_folder(path.parent)


def pick_folder(title: str = "", new_folder: bool = False) -> str:
    """Let the user choose a folder in the normal Windows dialog. "" if they cancel.

    ``title`` replaces the dialog's text; ``new_folder`` shows its "Make New Folder" button."""
    if sys.platform.startswith("win"):
        script = (
            "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; "
            "Add-Type -AssemblyName System.Windows.Forms; "
            "$o = New-Object System.Windows.Forms.Form -Property @{TopMost = $true; ShowInTaskbar = $false}; "
            "$f = New-Object System.Windows.Forms.FolderBrowserDialog; "
            f"$f.Description = {_ps_quote(title or 'Choose a folder with videos for AniBox (a Shield drive, a NAS, a USB disk, any folder)')}; "
            f"$f.ShowNewFolderButton = ${'true' if new_folder else 'false'}; "
            "if ($f.ShowDialog($o) -eq [System.Windows.Forms.DialogResult]::OK) { [Console]::Out.Write($f.SelectedPath) }"
        )
        cmd = ["powershell", "-NoProfile", "-NonInteractive", "-STA", "-ExecutionPolicy", "Bypass", "-Command", script]
    else:
        code = ("import sys, tkinter, tkinter.filedialog as d; r = tkinter.Tk(); r.withdraw(); "
                "print(d.askdirectory(title=sys.argv[1]) or '', end='')")
        cmd = [sys.executable, "-c", code, title or "Choose a folder for AniBox"]
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=900, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise RuntimeError("The folder window couldn't open. Type or paste the folder instead.") from exc
    if r.returncode != 0:
        log.warning("Folder picker failed: %s", r.stderr.decode("utf-8", "replace")[:300])
        raise RuntimeError("The folder window couldn't open. Type or paste the folder instead.")
    return r.stdout.decode("utf-8", "replace").strip()
