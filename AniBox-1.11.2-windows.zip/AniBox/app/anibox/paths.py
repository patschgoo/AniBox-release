"""Where AniBox keeps its own files. Nothing is ever written next to your videos."""

from __future__ import annotations

import os
from pathlib import Path

import anibox  # noqa: F401  (makes anibox_check importable)
from anibox_check.home import PROGRAM_DIR, home_dir, is_portable  # noqa: F401


def data_dir() -> Path:
    """``<AniBox data folder>/app``: settings, watch progress, library cache, posters, logs.

    ``ANIBOX_DATA`` overrides it (tests and experiments).
    """
    override = os.environ.get("ANIBOX_DATA")
    path = Path(override) if override else home_dir() / "app"
    path.mkdir(parents=True, exist_ok=True)
    return path


def web_dir() -> Path:
    return Path(__file__).resolve().parent / "web"
