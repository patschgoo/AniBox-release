"""Download ffmpeg and ffprobe for Windows (once, on request, about 114 MB).

Needed only for "Make TV-friendly subtitles" (to take a subtitle track out of an MKV file) and for
the exact "Plays on the TV?" check (bit depth, profiles). Same pattern as mpvsetup.py: a pinned
build, checked against a fixed checksum, unpacked into %LOCALAPPDATA%\\AniBox\\ffmpeg.

The build: Gyan Doshi's "essentials" release build of FFmpeg 9.1 for Windows (x64, GPL), from its
GitHub release (github.com/GyanD/codexffmpeg, tag 9.1), the same file gyan.dev links as the current
release. Its SHA-256 equals the one gyan.dev publishes next to it
(gyan.dev/ffmpeg/builds/packages/ffmpeg-9.1-essentials_build.zip.sha256). Only ``ffmpeg.exe`` and
``ffprobe.exe`` are taken out of the zip.

On Linux and macOS AniBox uses ``ffmpeg``/``ffprobe`` from the system (package manager).
"""

from __future__ import annotations

import hashlib
import logging
import shutil
import sys
import tempfile
import threading
import urllib.request
import zipfile
from pathlib import Path
from typing import Dict, Optional

log = logging.getLogger("anibox.ffmpeg")

IS_WINDOWS = sys.platform.startswith("win")

VERSION = "9.1"
ASSET = f"ffmpeg-{VERSION}-essentials_build.zip"
SHA256 = "b9bbbb3acece000cbeec994f856649354e52c773807841e78908374b24d658fd"
SIZE = 119467219
URL = f"https://github.com/GyanD/codexffmpeg/releases/download/{VERSION}/{ASSET}"
PROGRAMS = ("ffmpeg", "ffprobe")
MAX_UNPACKED = 400_000_000  # each program is about 110 MB


def _exe(name: str) -> str:
    return name + (".exe" if IS_WINDOWS else "")


def find_tools(data_dir: Path, setting: str = "") -> Dict[str, Optional[str]]:
    """{"ffmpeg": path or None, "ffprobe": path or None}.

    Order: the folder typed in Settings (``ffmpeg_path``: the folder or ffmpeg.exe itself), the copy
    AniBox downloaded (``<data>/ffmpeg``), then the system PATH.
    """
    out: Dict[str, Optional[str]] = {}
    places = []
    setting = (setting or "").strip().strip('"')
    if setting:
        p = Path(setting)
        places.append(p.parent if p.suffix.lower() == ".exe" or p.is_file() else p)
    places.append(Path(data_dir).parent / "ffmpeg")
    for name in PROGRAMS:
        found = None
        for folder in places:
            candidate = folder / _exe(name)
            if candidate.is_file():
                found = str(candidate)
                break
        out[name] = found or shutil.which(name)
    return out


class FfmpegSetup:
    def __init__(self, data_dir: Path, url: str = URL, sha256: str = SHA256, size: int = SIZE):
        self.target = Path(data_dir).parent / "ffmpeg"
        self.url = url
        self.sha256 = sha256
        self.size = size
        self.status = {"state": "idle", "received": 0, "total": size, "message": ""}
        self._thread = None

    def start(self, force: bool = False) -> bool:
        """Start the download in the background. ``force`` lets tests run it on Linux too."""
        if self.status["state"] == "running":
            return False
        if not IS_WINDOWS and not force:
            self.status = {"state": "error", "received": 0, "total": self.size,
                           "message": "The automatic download is for Windows. Install ffmpeg with your package manager."}
            return False
        self.status = {"state": "running", "received": 0, "total": self.size, "message": "Downloading ffmpeg …"}
        self._thread = threading.Thread(target=self._run, daemon=True, name="anibox-ffmpeg-setup")
        self._thread.start()
        return True

    def wait(self, timeout: float = 60) -> None:
        if self._thread:
            self._thread.join(timeout)

    def _run(self) -> None:
        tmp = Path(tempfile.mkdtemp(prefix="anibox-ffmpeg-"))
        try:
            archive = tmp / ASSET
            self.download(archive)
            self.status["message"] = "Unpacking …"
            unpack = tmp / "unpacked"
            unpack.mkdir()
            self.unpack(archive, unpack)
            if self.target.exists():
                shutil.rmtree(self.target)
            shutil.copytree(unpack, self.target)
            self.status.update(state="done", message="ffmpeg is ready.")
            log.info("ffmpeg %s installed in %s", VERSION, self.target)
        except Exception as exc:
            log.exception("ffmpeg setup failed")
            self.status.update(state="error", message=f"Couldn't set up ffmpeg: {exc}")
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    @staticmethod
    def unpack(archive: Path, dest: Path) -> None:
        """Only ffmpeg.exe and ffprobe.exe from the zip's ``bin`` folder, nothing else."""
        wanted = {"ffmpeg.exe": None, "ffprobe.exe": None}
        with zipfile.ZipFile(archive) as z:
            for info in z.infolist():
                parts = info.filename.replace("\\", "/").split("/")
                if len(parts) >= 2 and parts[-2] == "bin" and parts[-1].lower() in wanted and not info.is_dir():
                    if info.file_size > MAX_UNPACKED:
                        raise RuntimeError(f"{parts[-1]} in the download is too big.")
                    wanted[parts[-1].lower()] = info
            missing = [n for n, i in wanted.items() if i is None]
            if missing:
                raise RuntimeError(f"{', '.join(missing)} wasn't in the download.")
            for name, info in wanted.items():
                with z.open(info) as src, open(dest / name, "wb") as out:
                    shutil.copyfileobj(src, out, 1 << 20)

    def download(self, dest: Path) -> None:
        req = urllib.request.Request(self.url, headers={"User-Agent": "AniBox"})
        digest = hashlib.sha256()
        with urllib.request.urlopen(req, timeout=120) as resp, open(dest, "wb") as out:
            total = int(resp.headers.get("Content-Length") or self.size)
            self.status["total"] = total
            while True:
                chunk = resp.read(1 << 20)
                if not chunk:
                    break
                out.write(chunk)
                digest.update(chunk)
                self.status["received"] += len(chunk)
                if self.status["received"] > self.size * 2:
                    raise RuntimeError("the download is much bigger than expected.")
        if digest.hexdigest().lower() != self.sha256.lower():
            raise RuntimeError("the download is damaged (checksum doesn't match). Try again.")
