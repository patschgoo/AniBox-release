"""Copy what Plex knows about your shows and episodes into AniBox (read-only, linked, locked).

Why this matters: five of the Plex libraries (Anime, OVA's, One Piece, Anime (ger dub), Anime
Movies) were matched by Fribb's MyAnimeList agent. That agent died with the Shield's plug-in
framework in 2024, and the Jikan API it used is gone too, so their titles, summaries, genres,
posters and MyAnimeList IDs can't be downloaded again. They only live on in Plex's database, which
sits on an SD card that has needed repairs several times. This module makes a copy inside AniBox's
own data folder before anything happens to it.

Read-only: every request is an HTTP GET (the Library Check's GET-only client, plus plain GETs for
poster images on the same server). Nothing on the Plex server can change: no matches, metadata,
watch states, settings, Refresh or Fix Match. Nothing is written next to the videos either; the copy
is one JSON file in AniBox's data folder (plus, if wanted, a folder of poster images).

The steps, each usable on its own:

1. ``fetch_details``: read every TV-type library: shows (with their full tag lists), episodes
   (with every file they play) and, optionally, each show's poster.
2. ``link``: hang every Plex show and episode on the AniBox show and episode whose *file* it is
   (``plexhistory.match_keys``, by the end of the path), so the copy doesn't depend on titles or on
   AniBox's own MyAnimeList matching.
3. ``save_snapshot`` / ``load_snapshot``: one versioned JSON file, written atomically.
4. ``diff_mal``: shows where the old agent's MyAnimeList ID differs from AniBox's ("which one is
   right?").
5. ``merge_snapshots``: copy again later without replacing anything that's locked.

"Linked, locked" for the app:

- *Linked*: the details belong to AniBox's show/episode keys (``<library>\\<folder>\\<file>``),
  found through the files, not through titles.
- *Locked*: for shows whose episodes are locked ("protect the old, allow the new"), the app shows
  Plex's copied details as the show's details and never overwrites them: not with MyAnimeList
  API data, not with Kitsu titles, and not with a later copy from Plex (``merge_snapshots`` keeps
  the first copy of locked episodes and only adds new ones). Newer data may replace them only after
  the user unlocks the show. AniBox never writes any of it back to Plex.
"""

from __future__ import annotations

import copy
import hashlib
import http.client
import json
import os
import re
import socket
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Callable, Dict, Iterable, List, NamedTuple, Optional, Set, Tuple

import anibox  # noqa: F401  (makes anibox_check importable)
from anibox_check.ids import MAL, external_ids, parse_guid
from anibox_check.plex import TYPE_SHOW, PlexAuthError, PlexError

from .plexhistory import _Reader as _HistoryReader
from .plexhistory import match_keys

SNAPSHOT_FORMAT = "anibox-plex-details"
SNAPSHOT_VERSION = 1
MODERN_AGENT_PREFIX = "tv.plex.agents."  # Plex's own agents and custom providers; anything else is legacy
DETAIL_BATCH = 50  # shows per /library/metadata/<k1,k2,...> request (for the full tag lists)
POSTER_TIMEOUT = 20.0
MAX_POSTER_BYTES = 15_000_000
POSTER_GIVE_UP = 10  # failed poster downloads in a row: stop and try the rest next time
POSTER_EXTS = (".jpg", ".png", ".webp", ".gif")

# Copied as Plex sends them (Plex's own names), when present.
SHOW_FIELDS = (
    "guid", "title", "originalTitle", "titleSort", "summary", "tagline", "year", "originallyAvailableAt",
    "studio", "contentRating", "rating", "ratingImage", "audienceRating", "audienceRatingImage",
    "userRating", "thumb", "art", "theme", "leafCount", "childCount", "addedAt", "updatedAt",
)
SHOW_TAGS = (("Genre", "genres"), ("Collection", "collections"), ("Label", "labels"), ("Country", "countries"))
EPISODE_FIELDS = (
    "guid", "grandparentTitle", "parentIndex", "index", "title", "originalTitle", "titleSort", "summary",
    "originallyAvailableAt", "year", "contentRating", "rating", "audienceRating", "thumb", "duration",
    "addedAt", "updatedAt",
)
_KEY_FIELDS = ("ratingKey", "grandparentRatingKey", "parentRatingKey")

LogFn = Callable[[str], None]


class _Section(NamedTuple):
    key: str
    title: str
    agent: str
    scanner: str
    language: str
    locations: List[str]

    @property
    def legacy(self) -> bool:
        return is_legacy_agent(self.agent)

    def as_dict(self) -> dict:
        return {"key": self.key, "title": self.title, "agent": self.agent, "legacy": self.legacy,
                "scanner": self.scanner, "language": self.language, "locations": list(self.locations)}


def is_legacy_agent(agent: str) -> bool:
    """True for libraries on a legacy agent (Fribb's MyAnimeList, HAMA, ...), whose data can't be fetched again.

    Modern agents and custom providers are named ``tv.plex.agents.*``. An unknown (empty) agent
    counts as legacy, so it is protected rather than not.
    """
    return not str(agent or "").startswith(MODERN_AGENT_PREFIX)


# -- reading Plex (GET only) ---------------------------------------------------------------------


class _Reader(_HistoryReader):
    """``plexhistory``'s GET-only reader (introduces itself as AniBox), plus what this module needs."""

    def server_info(self) -> dict:
        try:
            mc = self._get("/").get("MediaContainer") or {}
        except PlexAuthError:
            raise
        except PlexError:
            mc = self.identity()  # no friendly name there, but the id and version
        return {"name": str(mc.get("friendlyName") or self.base_url),
                "machine_id": str(mc.get("machineIdentifier") or ""), "version": str(mc.get("version") or "")}

    def show_sections(self) -> List[_Section]:
        data = self._get("/library/sections")
        out = []
        for d in (data.get("MediaContainer") or {}).get("Directory") or []:
            if not isinstance(d, dict) or d.get("type") != "show":
                continue
            locations = [str(loc.get("path")) for loc in d.get("Location") or [] if isinstance(loc, dict) and loc.get("path")]
            out.append(_Section(str(d.get("key")), str(d.get("title") or ""), str(d.get("agent") or ""),
                                str(d.get("scanner") or ""), str(d.get("language") or ""), locations))
        return out

    def shows(self, section_key: str) -> List[dict]:
        items = self._paged(f"/library/sections/{section_key}/all", {"type": TYPE_SHOW, "includeGuids": 1})
        return [m for m in items if isinstance(m, dict)]

    def metadata(self, rating_keys: List[str]) -> Optional[List[dict]]:
        """Full metadata of several items in one GET, or None if Plex answered with an error.

        Raises when Plex can't be reached at all (no point asking again for every show).
        """
        path = "/library/metadata/" + ",".join(urllib.parse.quote(k, safe="") for k in rating_keys)
        try:
            data = self._get(path, {"includeGuids": 1})
        except PlexAuthError:
            raise
        except PlexError as exc:
            if isinstance(exc.__cause__, urllib.error.HTTPError):
                return None
            raise
        return [m for m in (data.get("MediaContainer") or {}).get("Metadata") or [] if isinstance(m, dict)]

    def image(self, path: str) -> bytes:
        """One image from the Plex server (GET; the token goes in a header, never in the address)."""
        req = urllib.request.Request(self.base_url + path, method="GET")
        req.add_header("Accept", "image/*")
        req.add_header("X-Plex-Token", self.token)
        for name, value in self._identity.items():
            req.add_header(name, value)
        try:
            with urllib.request.urlopen(req, timeout=POSTER_TIMEOUT) as resp:
                data = resp.read(MAX_POSTER_BYTES + 1)
        except urllib.error.HTTPError as exc:
            if exc.code in (401, 403):
                raise PlexAuthError(f"Plex rejected the sign-in (HTTP {exc.code}).") from exc
            raise PlexError(f"Plex answered HTTP {exc.code} for a poster") from exc
        except (urllib.error.URLError, socket.timeout, ConnectionError, http.client.HTTPException) as exc:
            raise PlexError(f"Poster not loaded ({getattr(exc, 'reason', None) or exc})") from exc
        if len(data) > MAX_POSTER_BYTES:
            raise PlexError("Poster too big")
        return data


# -- turning Plex's answers into plain records ---------------------------------------------------


def _natural(text) -> tuple:
    return tuple(int(p) if p.isdigit() else p for p in re.split(r"(\d+)", str(text or "")) if p)


def _copy_fields(item: dict, names: Iterable[str]) -> dict:
    out = {}
    for name in names:
        value = item.get(name)
        if value is None or value == "" or isinstance(value, (dict, list)):
            continue
        out[name] = value
    return out


def _tags(item: dict, name: str) -> List[str]:
    return [str(t["tag"]) for t in item.get(name) or [] if isinstance(t, dict) and t.get("tag")]


def _show_fields(item: dict, section: _Section) -> dict:
    out = _copy_fields(item, SHOW_FIELDS)
    out["ratingKey"] = str(item.get("ratingKey") or "")
    for plex_name, name in SHOW_TAGS:
        tags = _tags(item, plex_name)
        if tags:
            out[name] = tags
    roles = [{k: str(r[p]) for p, k in (("tag", "name"), ("role", "role"), ("thumb", "thumb")) if r.get(p)}
             for r in item.get("Role") or [] if isinstance(r, dict) and r.get("tag")]
    if roles:
        out["roles"] = roles
    ratings = [{k: r[k] for k in ("image", "value", "type") if r.get(k) is not None}
               for r in item.get("Rating") or [] if isinstance(r, dict)]
    if any(ratings):
        out["ratings"] = [r for r in ratings if r]
    guids = [str(g["id"]) for g in item.get("Guid") or [] if isinstance(g, dict) and g.get("id")]
    if guids:
        out["guids"] = guids
    ids, modes = external_ids([str(item.get("guid") or "")] + guids)
    if ids:
        out["ids"] = {kind: sorted(values, key=_natural) for kind, values in sorted(ids.items())}
    if modes:
        out["modes"] = sorted(modes)
    locations = [str(loc["path"]) for loc in item.get("Location") or [] if isinstance(loc, dict) and loc.get("path")]
    if locations:
        out["locations"] = locations
    # Fields someone edited by hand in Plex (Plex locks them against its own refreshes).
    edited = [str(f["name"]) for f in item.get("Field") or [] if isinstance(f, dict) and f.get("locked") and f.get("name")]
    if edited:
        out["lockedFields"] = edited
    out.update(section=section.title, section_key=section.key, agent=section.agent, legacy=section.legacy)
    return out


def _episode_fields(item: dict, section_key: str) -> dict:
    out = {k: str(item[k]) for k in _KEY_FIELDS if item.get(k) not in (None, "")}
    out.update(_copy_fields(item, EPISODE_FIELDS))
    files: List[str] = []
    # Several Media = versions of the episode; several Parts = the episode split into files.
    for media in item.get("Media") or []:
        if not isinstance(media, dict):
            continue
        for part in media.get("Part") or []:
            if isinstance(part, dict) and part.get("file") and str(part["file"]) not in files:
                files.append(str(part["file"]))
    out["files"] = files
    out["section_key"] = section_key
    return out


def _mal_id(fields: dict) -> Optional[str]:
    """The MyAnimeList ID Plex has for a show: from the legacy GUID first (Fribb's agent), else the Guid list."""
    parsed = parse_guid(str(fields.get("guid") or ""))
    if parsed and parsed.kind == MAL:
        return parsed.ident
    found = (fields.get("ids") or {}).get(MAL) or []
    return str(found[0]) if found else None


# -- fetching --------------------------------------------------------------------------------------


def _add_full_details(reader: _Reader, fields: List[dict], section: _Section, say: LogFn) -> int:
    """Replace the list view's shortened tag lists (Plex sends only the first few genres/roles there)
    with the full ones from ``/library/metadata``. Returns how many shows kept the short lists."""
    by_key = {f["ratingKey"]: f for f in fields if f.get("ratingKey")}
    keys = list(by_key)
    short = 0
    for start in range(0, len(keys), DETAIL_BATCH):
        batch = keys[start:start + DETAIL_BATCH]
        items = reader.metadata(batch)
        if items is None and len(batch) > 1:
            items = []
            for key in batch:  # this server doesn't take several keys at once; one by one
                items.extend(reader.metadata([key]) or [])
            if not items:
                say(f"{section.title}: Plex gave no full details; keeping the short lists.")
                return short + len(keys) - start
        got: Set[str] = set()
        for item in items or []:
            target = by_key.get(str(item.get("ratingKey") or ""))
            if target is None:
                continue
            full = _show_fields(item, section)
            target.update({k: v for k, v in full.items() if v not in (None, "", [], {})})
            got.add(target["ratingKey"])
        short += len(set(batch) - got)
    return short


def _poster_name(rating_key: str, thumb: str) -> str:
    safe = re.sub(r"[^0-9A-Za-z]", "", rating_key) or "x"
    m = re.fullmatch(r"/library/metadata/\d+/thumb/(\d+)", thumb.split("?", 1)[0])
    # The number at the end changes when Plex's poster changes, so a new poster gets a new file
    # and the old one stays.
    return f"{safe}-{m.group(1)}" if m else f"{safe}-{hashlib.sha1(thumb.encode('utf-8')).hexdigest()[:12]}"


def _image_ext(data: bytes) -> Optional[str]:
    if data.startswith(b"\xff\xd8\xff"):
        return ".jpg"
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return ".png"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return ".webp"
    if data[:6] in (b"GIF87a", b"GIF89a"):
        return ".gif"
    return None


def _save_posters(reader: _Reader, shows: List[dict], folder: Path, say: LogFn) -> dict:
    """Each show's poster once (``<ratingKey>-<stamp>.jpg``); errors are counted, never fatal."""
    counts = {"saved": 0, "already": 0, "failed": 0, "skipped": 0}
    todo: List[Tuple[dict, str, str]] = []
    for fields in shows:
        thumb = str(fields.get("thumb") or "")
        if not thumb:
            continue
        if not thumb.startswith("/") or thumb.startswith("//"):
            counts["skipped"] += 1  # an image on another site: the token is never sent anywhere else
            continue
        name = _poster_name(fields["ratingKey"], thumb)
        existing = next((name + ext for ext in POSTER_EXTS if (folder / (name + ext)).is_file()), None)
        if existing:
            fields["poster"] = existing
            counts["already"] += 1
        else:
            todo.append((fields, thumb, name))
    if todo:
        folder.mkdir(parents=True, exist_ok=True)
    in_a_row = 0
    for n, (fields, thumb, name) in enumerate(todo, 1):
        try:
            data = reader.image(thumb)
            ext = _image_ext(data)
            if not ext:
                raise PlexError("Plex sent something that isn't an image")
            tmp = folder / (name + ".part")
            tmp.write_bytes(data)
            os.replace(tmp, folder / (name + ext))
            fields["poster"] = name + ext
            counts["saved"] += 1
            in_a_row = 0
        except Exception as exc:  # one bad poster must not cost the details already read
            counts["failed"] += 1
            in_a_row += 1
            if isinstance(exc, PlexAuthError) or in_a_row >= POSTER_GIVE_UP:
                counts["failed"] += len(todo) - n
                say(f"Stopped saving posters ({exc}). The rest are tried next time.")
                break
        if n % 25 == 0 or n == len(todo):
            say(f"Posters: {n} of {len(todo)}")
    return counts


def fetch_details(server_url: str, token: str, client_id: str, sections: Optional[Iterable] = None,
                  posters_dir=None, log: Optional[LogFn] = None) -> dict:
    """Everything Plex knows about the shows and episodes of its TV-type libraries. GET only.

    ``sections``: library keys to read (default: every TV-type library; movie libraries are always
    skipped). ``posters_dir``: if given, each show's poster is saved there once, from the Plex
    server itself (``<ratingKey>-<stamp>.jpg``; files already there are not loaded again; errors
    are counted and skipped). ``log`` gets progress messages for the window.

    Returns ``{"fetched": unix time, "server": name, "machine_id", "server_version",
    "sections": [{"key", "title", "agent", "legacy", "scanner", "language", "locations", "shows": n,
    "episodes": n}], "shows": [show], "episodes": [episode], "posters": counts or None}``.

    A show has Plex's own fields (``ratingKey``, ``guid``, ``title``, ``originalTitle``,
    ``titleSort``, ``summary``, ``year``, ``studio``, ``contentRating``, ``rating``,
    ``audienceRating``, ``thumb``, ``art``, ``leafCount``, ``addedAt``, ``updatedAt`` ...; missing
    ones are left out) plus ``genres``/``collections``/``labels``/``countries``/``roles``
    (full lists), ``guids`` (the modern Guid list), ``ids`` (``{"mal": ["52991"], "tvdb": [...],
    "anidb", "tmdb", "imdb", ...}``, parsed like the Library Check does), ``modes``, ``locations``
    (the show's folders), ``lockedFields`` (edited by hand in Plex), ``section``, ``section_key``,
    ``agent``, ``legacy`` (``agent`` isn't ``tv.plex.agents.*``) and ``poster`` (file name in
    ``posters_dir``, once saved).

    An episode has ``ratingKey``, ``grandparentRatingKey``, ``parentRatingKey``, ``parentIndex``
    (season), ``index``, ``title``, ``summary``, ``originallyAvailableAt``, ``thumb``, ``duration``,
    ``guid`` ..., ``files`` (every part of every version, Plex's paths) and ``section_key``.

    Blocks for a while (it waits for a sleeping Shield), so run it off the UI's thread. Raises
    ``PlexAuthError`` (sign in again), ``PlexError`` (not reachable or not Plex) or ``ValueError``
    (unusable address).
    """
    say = log or (lambda message: None)
    reader = _Reader(server_url, token, client_id)
    info = reader.server_info()
    wanted = None if sections is None else {str(s) for s in sections}
    chosen = [s for s in reader.show_sections() if wanted is None or s.key in wanted]
    shows: List[dict] = []
    episodes: List[dict] = []
    rows: List[dict] = []
    for n, section in enumerate(chosen, 1):
        say(f"Reading '{section.title}' ({n} of {len(chosen)}) ...")
        fields = [_show_fields(m, section) for m in reader.shows(section.key)]
        short = _add_full_details(reader, fields, section, say)
        if short:
            say(f"{section.title}: {short} show(s) without full details (short lists kept).")
        count = 0
        for page, done, total in reader.episode_pages(section.key):
            for ep in page:
                episodes.append(_episode_fields(ep, section.key))
                count += 1
            if total:
                say(f"{section.title}: {min(done, total)} of {total} episodes")
        shows.extend(fields)
        rows.append(dict(section.as_dict(), shows=len(fields), episodes=count))
    posters = None
    if posters_dir is not None:
        posters = _save_posters(reader, shows, Path(posters_dir), say)
    say(f"Read {len(shows)} shows and {len(episodes)} episodes from Plex.")
    return {"fetched": time.time(), "server": info["name"], "machine_id": info["machine_id"],
            "server_version": info["version"], "sections": rows, "shows": shows, "episodes": episodes,
            "posters": posters}


# -- linking to AniBox's shows ---------------------------------------------------------------------


def _record(ep: dict, file: Optional[str] = None) -> dict:
    out = {k: v for k, v in ep.items() if k != "section_key"}
    if file is not None:
        out["file"] = file  # the Plex file that is this AniBox episode
    return out


def _orphan_show(ep: dict, sections: Dict[str, dict]) -> dict:
    """A show for episodes whose show wasn't in the list (Plex hiccup): what the episode says."""
    section = sections.get(str(ep.get("section_key") or "")) or {}
    agent = str(section.get("agent") or "")
    return {"ratingKey": str(ep.get("grandparentRatingKey") or ""), "title": str(ep.get("grandparentTitle") or ""),
            "section": str(section.get("title") or ""), "section_key": str(ep.get("section_key") or ""),
            "agent": agent, "legacy": is_legacy_agent(agent)}


def link(details: dict, shows: List[dict]) -> dict:
    """Attach ``fetch_details``' shows and episodes to AniBox's shows. Pure: reads and writes nothing.

    ``shows`` are AniBox show dicts (``{"id": "<library>\\<folder>", "episodes": [{"key": ...}]}``);
    pass all of them, not only the libraries picked in Settings. Plex files are paired with episode
    keys by ``plexhistory.match_keys``; each Plex show then belongs to the AniBox show that most of
    its episodes landed in (its "home").

    Returns the snapshot::

        {"format", "version", "fetched", "linked", "server", "machine_id", "server_version",
         "sections": [...],
         "shows": {anibox_show_id: {
             "plex": {show fields}, "mal_id": "52991" or None, "home": True,
             "episodes": {anibox_episode_key: {episode fields, "file": Plex path, "more": [...]}},
             "unmatched": [episode fields],   # only at home: episodes whose files AniBox doesn't have
             "others": [{"plex", "mal_id", "home", "episodes", "unmatched"}]}},
         "unlinked": [{"title", "section", "rating_key", "files": n, "reason", "example",
                       "plex": {show fields}, "mal_id", "episodes": [episode fields]}],
         "conflicts": [...], "counts": {...}}

    The main Plex show of an AniBox show is the one at home there, from a legacy library (its data
    can't be fetched again) and with the most episodes there. ``others`` holds more Plex shows with
    files in the same folder: usually a second library over the same folders (not a conflict).
    ``home: False`` means the Plex show is mostly in another AniBox show, so its show details and
    MyAnimeList ID belong there. ``more``: further Plex episodes in the same file ("01-02.mkv").

    Conflicts: ``{"kind": "split", "rating_key", "title", "section", "home", "shows": {id: n}}``
    (one Plex show over several AniBox shows) and ``{"kind": "merged", "show", "section",
    "chosen", "plex": [{"rating_key", "title", "episodes": n}]}`` (several Plex shows of one
    library in one AniBox show).
    """
    sections = {str(s.get("key")): s for s in details.get("sections") or []}
    key_show: Dict[str, str] = {}
    order: Dict[str, int] = {}
    show_order: Dict[str, int] = {}
    for show in shows:
        show_order.setdefault(show["id"], len(show_order))
        for ep in show.get("episodes") or []:
            key = ep.get("key")
            if key and key not in key_show:
                key_show[key] = show["id"]
                order[key] = len(order)

    plex: Dict[str, dict] = {}
    for fields in details.get("shows") or []:
        plex.setdefault(str(fields.get("ratingKey") or ""), fields)
    eps: List[dict] = details.get("episodes") or []
    by_show: Dict[str, List[int]] = {}
    for i, ep in enumerate(eps):
        rk = str(ep.get("grandparentRatingKey") or "")
        if rk not in plex:
            plex[rk] = _orphan_show(ep, sections)
        by_show.setdefault(rk, []).append(i)

    entries = [{"file": f, "ep": i} for i, ep in enumerate(eps) for f in ep.get("files") or []]
    matched, unmatched_files = match_keys(entries, list(key_show))
    # Plex show -> AniBox show -> episode key -> [(Plex episode, Plex file)]
    landed: Dict[str, Dict[str, Dict[str, List[Tuple[int, str]]]]] = {}
    linked_eps: Set[int] = set()
    for key, entry in matched:
        i = entry["ep"]
        rk = str(eps[i].get("grandparentRatingKey") or "")
        slot = landed.setdefault(rk, {}).setdefault(key_show[key], {}).setdefault(key, [])
        if all(i != j for j, _ in slot):
            slot.append((i, entry["file"]))
        linked_eps.add(i)

    def n_eps(rk: str, sid: str) -> int:
        return len({i for slot in landed[rk][sid].values() for i, _ in slot})

    home = {rk: min(where, key=lambda sid: (-n_eps(rk, sid), show_order.get(sid, 0), sid))
            for rk, where in landed.items()}

    def ep_order(i: int) -> tuple:
        ep = eps[i]
        return (_natural(ep.get("parentIndex")), _natural(ep.get("index")), i)

    def block(rk: str, sid: str) -> dict:
        out_eps: Dict[str, dict] = {}
        for key in sorted(landed[rk][sid], key=order.__getitem__):
            slot = sorted(landed[rk][sid][key], key=lambda x: ep_order(x[0]))
            rec = _record(eps[slot[0][0]], slot[0][1])
            if len(slot) > 1:
                rec["more"] = [_record(eps[i], f) for i, f in slot[1:]]
            out_eps[key] = rec
        b = {"plex": plex[rk], "mal_id": _mal_id(plex[rk]), "home": home[rk] == sid, "episodes": out_eps}
        if home[rk] == sid:
            left = [_record(eps[i]) for i in sorted(by_show.get(rk, []), key=ep_order) if i not in linked_eps]
            if left:
                b["unmatched"] = left
        return b

    here: Dict[str, List[str]] = {}
    for rk, where in landed.items():
        for sid in where:
            here.setdefault(sid, []).append(rk)

    out_shows: Dict[str, dict] = {}
    conflicts: List[dict] = []
    for sid in sorted(here, key=lambda s: (show_order.get(s, 0), s)):
        ranked = sorted(here[sid], key=lambda rk: (home[rk] != sid, not plex[rk].get("legacy"), -n_eps(rk, sid),
                                                   _natural(plex[rk].get("section_key")), _natural(rk)))
        entry = block(ranked[0], sid)
        if len(ranked) > 1:
            entry["others"] = [block(rk, sid) for rk in ranked[1:]]
        out_shows[sid] = entry
        per_section: Dict[str, List[str]] = {}
        for rk in ranked:
            per_section.setdefault(str(plex[rk].get("section_key") or ""), []).append(rk)
        for section_key, rks in per_section.items():
            if len(rks) > 1:
                conflicts.append({
                    "kind": "merged", "show": sid, "section": str(plex[rks[0]].get("section") or ""),
                    "chosen": rks[0],
                    "plex": [{"rating_key": rk, "title": str(plex[rk].get("title") or ""), "episodes": n_eps(rk, sid)}
                             for rk in rks],
                })
    for rk, where in landed.items():
        if len(where) > 1:
            conflicts.append({
                "kind": "split", "rating_key": rk, "title": str(plex[rk].get("title") or ""),
                "section": str(plex[rk].get("section") or ""), "home": home[rk],
                "shows": {sid: n_eps(rk, sid) for sid in sorted(where, key=lambda s: (show_order.get(s, 0), s))},
            })

    unlinked: List[dict] = []
    for rk, fields in plex.items():
        if rk in landed:
            continue
        mine = sorted(by_show.get(rk, []), key=ep_order)
        files = [f for i in mine for f in eps[i].get("files") or []]
        unlinked.append({
            "title": str(fields.get("title") or ""), "section": str(fields.get("section") or ""), "rating_key": rk,
            "files": len(files), "example": files[0] if files else "",
            "reason": ("Its files aren't in AniBox's library (folder not scanned, or renamed)" if files
                       else "Plex lists no files for it"),
            "plex": fields, "mal_id": _mal_id(fields), "episodes": [_record(eps[i]) for i in mine],
        })
    unlinked.sort(key=lambda u: (_natural(u["plex"].get("section_key")), u["title"].casefold(), _natural(u["rating_key"])))

    covered = {k for e in out_shows.values() for b in [e] + e.get("others", []) for k in b["episodes"]}
    counts = {
        "plex_shows": len(plex), "plex_episodes": len(eps), "linked_shows": len(out_shows),
        "linked_episodes": len(covered), "unlinked_shows": len(unlinked), "unmatched_files": len(unmatched_files),
    }
    return {
        "format": SNAPSHOT_FORMAT, "version": SNAPSHOT_VERSION,
        "fetched": details.get("fetched"), "linked": time.time(),
        "server": details.get("server"), "machine_id": details.get("machine_id"),
        "server_version": details.get("server_version"), "sections": details.get("sections") or [],
        "shows": out_shows, "unlinked": unlinked, "conflicts": conflicts, "counts": counts,
    }


# -- keeping it ----------------------------------------------------------------------------------


def load_snapshot(path) -> Optional[dict]:
    """The saved snapshot, or None (no file, damaged, not a snapshot, or from a newer AniBox)."""
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    if not isinstance(data, dict) or data.get("format") != SNAPSHOT_FORMAT:
        return None
    version = data.get("version")
    if not isinstance(version, int) or isinstance(version, bool) or not 1 <= version <= SNAPSHOT_VERSION:
        return None
    shows = data.get("shows")
    if not isinstance(shows, dict) or not all(isinstance(e, dict) for e in shows.values()):
        return None
    if not isinstance(data.get("unlinked", []), list) or not isinstance(data.get("conflicts", []), list):
        return None
    return data


def save_snapshot(path, snapshot: dict) -> None:
    """Write the snapshot atomically (temporary file, then replace).

    A file there that can't be read back (damaged, or from a newer AniBox) is never overwritten:
    it is renamed to ``<name>.unreadable-<time>`` first, because it may be the only copy left.
    """
    path = Path(path)
    data = dict(snapshot)
    data["format"] = SNAPSHOT_FORMAT
    data.setdefault("version", SNAPSHOT_VERSION)
    text = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and load_snapshot(path) is None:
        stamp = time.strftime("%Y%m%d-%H%M%S")
        aside = path.with_name(f"{path.name}.unreadable-{stamp}")
        n = 1
        while aside.exists():
            n += 1
            aside = path.with_name(f"{path.name}.unreadable-{stamp}-{n}")
        os.replace(path, aside)
    tmp = path.with_name(path.name + ".part")
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(text)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, path)


def merge_snapshots(old: Optional[dict], new: dict, locked: Iterable[str]) -> dict:
    """A fresh copy from Plex that keeps the first copy of everything locked.

    ``locked``: the episode keys that are locked right now (for every show, ``Library.lock_view(show)
    ["keys"]``: locked and the show not unlocked). Rules, per AniBox show:

    - with locked episodes in ``old``: the show's details (``plex``, ``mal_id``, ``others``) stay as
      first copied, the locked episodes keep their old records (even if Plex has lost them), and
      only episodes that aren't locked take the new records (Plex episodes AniBox has no file for
      yet are added to ``unmatched``). ``kept`` says since when.
    - otherwise: the new copy (or its absence) stands.

    Plex shows that were unlinked before and are gone from the new copy stay listed (``kept``), so
    a Plex database that lost them doesn't take the backup with it.
    """
    if not old:
        return new
    locked = set(locked)
    out = dict(new)
    shows = dict(new.get("shows") or {})
    for sid, before in (old.get("shows") or {}).items():
        blocks = [before] + list(before.get("others") or [])
        if not any(k in locked for b in blocks for k in b.get("episodes") or {}):
            continue
        entry = copy.deepcopy(before)
        episodes = {k: v for k, v in (before.get("episodes") or {}).items() if k in locked}
        after = shows.get(sid)
        for k, v in ((after or {}).get("episodes") or {}).items():
            if k not in locked:
                episodes[k] = v
        entry["episodes"] = episodes
        known = {str(e.get("ratingKey")) for e in entry.get("unmatched") or []}
        fresh = [e for e in (after or {}).get("unmatched") or [] if str(e.get("ratingKey")) not in known]
        if fresh:
            entry["unmatched"] = list(entry.get("unmatched") or []) + fresh
        entry["kept"] = before.get("kept") or old.get("fetched")
        shows[sid] = entry
    out["shows"] = shows

    def ident(u: dict) -> Tuple[str, str]:
        return (str(u.get("section") or ""), str(u.get("title") or ""))

    seen = {ident(u) for u in new.get("unlinked") or []}
    seen |= {(str(b["plex"].get("section") or ""), str(b["plex"].get("title") or ""))
             for e in (new.get("shows") or {}).values() for b in [e] + list(e.get("others") or [])
             if isinstance(b.get("plex"), dict)}
    unlinked = list(new.get("unlinked") or [])
    for u in old.get("unlinked") or []:
        if ident(u) not in seen:
            unlinked.append(dict(u, kept=u.get("kept") or old.get("fetched")))
    out["unlinked"] = unlinked
    return out


def diff_mal(snapshot: dict, shows: List[dict]) -> List[dict]:
    """Shows where Plex's MyAnimeList ID (from the old agent) isn't AniBox's current ``mal_id``.

    For the "which one is right?" check: ``kind`` is ``"different"`` (both have one) or
    ``"only_plex"`` (AniBox didn't recognize the folder, Plex's old agent did). Shows Plex has no
    MyAnimeList ID for are left out. Only Plex shows at home in that AniBox show count.
    Each item: ``{"show", "folder", "title", "kind", "plex_mal_id", "anibox_mal_id", "manual",
    "plex_title", "section", "legacy"}``.
    """
    entries = (snapshot or {}).get("shows") or {}
    out: List[dict] = []
    for show in shows:
        entry = entries.get(show.get("id"))
        if not entry:
            continue
        block = next((b for b in [entry] + list(entry.get("others") or [])
                      if b.get("home", True) and b.get("mal_id")), None)
        if block is None:
            continue
        theirs = str(block["mal_id"])
        ours = str(show["mal_id"]) if show.get("mal_id") else None
        if theirs == ours:
            continue
        fields = block.get("plex") or {}
        out.append({
            "show": show["id"], "folder": show.get("folder") or "", "title": show.get("title") or "",
            "kind": "different" if ours else "only_plex", "plex_mal_id": theirs, "anibox_mal_id": ours,
            "manual": bool(show.get("manual")), "plex_title": str(fields.get("title") or ""),
            "section": str(fields.get("section") or ""), "legacy": bool(fields.get("legacy")),
        })
    out.sort(key=lambda d: d["show"].casefold())
    return out
