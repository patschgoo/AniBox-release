"""Add new videos: find them in Downloads (or other inbox folders), recognize them and propose where
they go in the library and what they're called.

Proposals follow the user's own layout: one folder per MyAnimeList entry named with the MAL title,
episodes inside as "<Title> NN.ext" (movies too: "<Title> 01.ext"). When the show already has a folder,
new episodes go into that folder and follow the names already there. Nothing moves here: the user
checks and edits the list, and fileops.py does the moving.
"""

from __future__ import annotations

import hashlib
import os
import re
import time
from collections import Counter
from typing import Dict, Iterable, List, Optional, Tuple

import anibox  # noqa: F401  (makes anibox_check importable)
from anibox_check.folders import VIDEO_EXTENSIONS, episode_number

from .fileops import safe_name
from .languages import from_names

PARTIAL = (".part", ".crdownload", ".!qb", ".!ut", ".tmp", ".partial", ".download", ".anibox-part", ".opdownload")
MIN_SIZE = 1024 * 1024  # smaller "videos" are samples or broken
SETTLE_SECONDS = 20  # files changed more recently may still be downloading
MAX_DEPTH = 3
SKIP_DIRS = {"$recycle.bin", "system volume information", "node_modules", "sample", "samples"}

_BRACKETS = re.compile(r"\[[^\]]*\]|\{[^}]*\}")
_TECH = re.compile(r"\((?=[^)]*(?:\d{3,4}p|x26[45]|h\.?26[45]|hevc|avc|10.?bit|bd|blu.?ray|web|dvd|dual|multi|aac|flac|opus|ac3|eng|ger|jpn|sub|dub|raw|batch|complete))[^)]*\)", re.I)
_MARKERS = [
    re.compile(r"\bS\d{1,2}\s?E\d{1,4}\b", re.I),
    re.compile(r"\s-\s*\d{1,4}(?:v\d)?(?:\s|$)"),
    re.compile(r"(?:^|\s)(?:E|EP|Ep|Episode|Folge)\s?\.?\d{1,4}\b", re.I),
    re.compile(r"\s\d{1,4}(?:v\d)?\s*$"),
    re.compile(r"\b(?:Season|Staffel|S)\s?\d{1,2}\s*$", re.I),
]
_TAIL_WORDS = re.compile(r"\b(?:1080p|720p|480p|2160p|4k|x26[45]|hevc|web-?dl|webrip|bdrip|blu-?ray|complete|batch|uncensored|dual audio|multi)\b.*$", re.I)


def guess_title(name: str) -> str:
    """The show title in a release name: "[Group] Sousou no Frieren - 05 (1080p) [ABCD].mkv" -> "Sousou no Frieren"."""
    stem, ext = os.path.splitext(name)
    if ext.lower() not in VIDEO_EXTENSIONS:
        stem = name
    s = _BRACKETS.sub(" ", stem)
    s = _TECH.sub(" ", s)
    if " " not in s.strip() and (s.count(".") >= 2 or s.count("_") >= 2):
        s = re.sub(r"[._]", " ", s)  # Scene.Style.Names
    s = s.replace("_", " ")
    s = re.sub(r"\s+", " ", s).strip()
    s = _TAIL_WORDS.sub("", s).strip()
    cut = len(s)
    for rx in _MARKERS:
        m = rx.search(s)
        if m and 0 < m.start() < cut:
            cut = m.start()
    s = s[:cut]
    return re.sub(r"\s+", " ", s).strip(" -_.,")


def _partial(path: str, names: set) -> bool:
    low = path.lower()
    if low.endswith(PARTIAL):
        return True
    base = os.path.basename(path)
    return any((base + p) in names for p in PARTIAL)


def _inside(path: str, roots: Iterable[str]) -> bool:
    p = os.path.normcase(os.path.abspath(path))
    for r in roots:
        r = os.path.normcase(os.path.abspath(r)).rstrip("\\/")
        if p == r or p.startswith(r + os.sep):
            return True
    return False


def scan_inbox(roots: Iterable[str], exclude: Iterable[str] = (), now: Optional[float] = None) -> List[dict]:
    """Video files in the inbox folders, grouped: everything in one sub folder is one group, loose files
    are grouped by their title. Folders that AniBox already scans as a library are skipped."""
    now = time.time() if now is None else now
    exclude = [e for e in exclude if e]
    groups: Dict[Tuple[str, str], dict] = {}
    for root in roots:
        if not root or not os.path.isdir(root) or _inside(root, exclude):
            continue
        base_depth = os.path.abspath(root).rstrip("\\/").count(os.sep)
        for dirpath, dirnames, filenames in os.walk(root):
            depth = os.path.abspath(dirpath).count(os.sep) - base_depth
            dirnames[:] = [d for d in dirnames if not d.startswith(".") and d.lower() not in SKIP_DIRS
                           and not _inside(os.path.join(dirpath, d), exclude) and depth < MAX_DEPTH]
            names = set(filenames)
            rel = os.path.relpath(dirpath, root)
            top = "" if rel == "." else rel.split(os.sep)[0]
            for f in filenames:
                if os.path.splitext(f)[1].lower() not in VIDEO_EXTENSIONS:
                    continue
                path = os.path.join(dirpath, f)
                try:
                    st = os.stat(path)
                except OSError:
                    continue
                if st.st_size < MIN_SIZE or now - st.st_mtime < SETTLE_SECONDS or _partial(path, names):
                    continue
                if top:
                    key, guess = (root, top), guess_title(top) or guess_title(f)
                else:
                    guess = guess_title(f)
                    key = (root, "\x00" + guess.casefold())
                g = groups.setdefault(key, {"id": hashlib.sha1(("|".join(key)).encode("utf-8")).hexdigest()[:12],
                                            "root": root, "folder": os.path.join(root, top) if top else "",
                                            "guess": guess, "files": []})
                g["files"].append({"src": path, "name": f, "rel": os.path.relpath(path, os.path.join(root, top) if top else root),
                                   "size": st.st_size, "mtime": st.st_mtime})
    out = list(groups.values())
    for g in out:
        g["files"].sort(key=lambda x: x["rel"].casefold())
        if not g["guess"] and g["files"]:
            g["guess"] = guess_title(g["files"][0]["name"])
    out.sort(key=lambda g: max(f["mtime"] for f in g["files"]), reverse=True)
    return out


_NAME_RE = re.compile(r"^(?P<prefix>.*?)(?P<sep>\s-\s|\s|_)(?P<num>\d{1,4})(?P<rest>\s.*)?$")


def name_pattern(files: Iterable[str], fallback_prefix: str) -> Tuple[str, str, int]:
    """(prefix, separator, digits) of the names already in a folder, e.g. ("Sousou no Frieren", " ", 2)."""
    seen = Counter()
    for f in files:
        stem = os.path.splitext(os.path.basename(f))[0]
        m = _NAME_RE.match(stem)
        if m and m.group("prefix").strip():
            seen[(m.group("prefix"), m.group("sep"), len(m.group("num")))] += 1
    if seen:
        return seen.most_common(1)[0][0]
    return fallback_prefix, " ", 2


def new_name(prefix: str, sep: str, digits: int, number: int, ext: str) -> str:
    return safe_name(f"{prefix}{sep}{number:0{digits}d}") + ext.lower()


class Proposer:
    """Turns inbox groups into proposals, using what AniBox knows about the library."""

    def __init__(self, library, settings: dict):
        self.library = library
        self.settings = settings
        self.titles = library.datasets().titles
        self.matcher = library.matcher()
        self.shows = library.shows(all_libraries=True)
        self.roots = library.library_roots()
        protected = [p.casefold() for p in settings.get("protected") or []]
        self.targets = {n for n, r in self.roots.items() if r and r[0][1] > 0 and n.casefold() not in protected
                        and library.library_kind(n) == "anime"}

    def default_library(self, mal_type: str, dub_de: bool) -> Optional[str]:
        """The anime library that already holds most entries of this type (TV/ONA, MOVIE, OVA/SPECIAL)."""
        group = {"TV": "TV", "ONA": "TV", "MOVIE": "MOVIE", "OVA": "OVA", "SPECIAL": "OVA", "MUSIC": "OVA"}.get(mal_type or "", "TV")
        german = re.compile(r"\bger|german|deutsch", re.I)
        counts: Counter = Counter()
        total: Counter = Counter()
        for sh in self.shows:
            lib = sh["library"]
            if lib not in self.targets or bool(german.search(lib)) != dub_de:
                continue
            total[lib] += 1
            t = {"ONA": "TV", "SPECIAL": "OVA", "MUSIC": "OVA"}.get(sh.get("type") or "", sh.get("type") or "")
            if t == group:
                counts[lib] += 1
        if counts:
            return max(counts, key=lambda lib: (counts[lib], total[lib], lib))
        if total:
            return max(total, key=lambda lib: (total[lib], lib))
        return next(iter(sorted(self.targets)), None)

    def propose(self, group: dict, mal_id: Optional[str] = None) -> dict:
        files = group["files"]
        guess = group["guess"]
        note = ""
        if mal_id is None:
            mal_id, note = self.matcher.match(guess, "", len(files))
            if not mal_id and group.get("folder") and files:
                mal_id, note = self.matcher.match(guess_title(files[0]["name"]), "", len(files))
        info = self.titles.get(str(mal_id)) if mal_id else None
        title = (info or {}).get("title") or guess
        mtype = (info or {}).get("type") or ""
        langs = from_names([group.get("folder") or ""] + [f["name"] for f in files])
        dub_de = "de" in (langs.get("audio") or [])
        out = {"id": group["id"], "guess": guess, "source": group.get("folder") or group["root"],
               "mal_id": str(mal_id) if mal_id else "", "title": title, "type": mtype,
               "episodes": (info or {}).get("episodes"), "year": (info or {}).get("year"),
               "poster": f"/img/{mal_id}" if info and info.get("picture") else "",
               "note": "" if mal_id else (note or "Not recognized; pick the title by hand."),
               "flags": [], "new_show": True, "season_dir": ""}
        existing = sorted((s for s in self.shows if mal_id and s.get("mal_id") == str(mal_id)),
                          key=lambda s: len(s["episodes"]), reverse=True)
        if existing:
            sh = existing[0]
            out.update(library=sh["library"], folder=sh["folder"], new_show=False)
            top = [e["file"] for e in sh["episodes"] if "\\" not in e["file"]]
            seasons = sorted({e["file"].split("\\")[0] for e in sh["episodes"] if "\\" in e["file"]})
            if seasons and not top:
                out["season_dir"] = seasons[-1]
                out["flags"].append(f"This show uses season folders; the new files go into \"{seasons[-1]}\". Check that.")
                names = [e["file"].split("\\", 1)[1] for e in sh["episodes"] if e["file"].startswith(seasons[-1] + "\\")]
            else:
                names = top
            prefix, sep, digits = name_pattern(names, sh["folder"])
        else:
            lib = self.default_library(mtype, dub_de)
            out.update(library=lib or "", folder=safe_name(title))
            prefix, sep, digits = safe_name(title), " ", 2
            if not lib:
                out["flags"].append("No anime library folder found to put it in. Scan your library folders first.")
        most = max([out["episodes"] or 0] + [1])
        digits = max(digits, len(str(most)))
        out.update(prefix=prefix, sep=sep, digits=digits)
        rows = []
        for f in files:
            ext = os.path.splitext(f["name"])[1]
            num = episode_number(f["name"], guess)
            number = num[1] if num else (1 if len(files) == 1 else None)
            rows.append({"src": f["src"], "name": f["name"], "rel": f["rel"], "size": f["size"], "number": number,
                         "new_name": new_name(prefix, sep, digits, number, ext) if number is not None else safe_name(os.path.splitext(f["name"])[0]) + ext.lower(),
                         "flag": "" if number is not None else "No episode number found; check the name."})
        counts = Counter(r["number"] for r in rows if r["number"] is not None)
        have = set()
        if existing:
            sub = out["season_dir"]
            have = {e.get("number") for e in existing[0]["episodes"]
                    if (e["file"].split("\\")[0] == sub if sub else "\\" not in e["file"])}
        for r in rows:
            r["include"] = True
            if r["number"] is not None and counts[r["number"]] > 1:
                r["flag"] = "The same episode number twice (another version or language?)."
            elif r["number"] is not None and r["number"] in have:
                r["flag"] = f"Episode {r['number']} is already in the folder (another version?). Not added unless you tick it."
                r["include"] = False
        out["files"] = rows
        return out
