"""Tidy up: AniBox's own leftovers that aren't needed anymore (Settings → Your data → Tidy up).

Only things AniBox itself made or shipped are listed, each with what it is and how big it is, and each
is removed only when the user clicks its button:

- the old Library Check launchers (``run-check.bat``/``.sh``; part of AniBox since 1.5),
- the previous version kept after an update (``.previous-update``) and a new version that didn't
  start (``.failed-update``),
- leftovers of the update helper in the data folder (``update/staging``, ``update/runner``),
- AniBox update zips in Downloads that aren't newer than this version,
- the settings folder of AniBox 1.0 and older (copied to the new data folder in 1.1).

Videos, the library, watch progress and settings are never in this list.
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import time
from pathlib import Path
from typing import List, Optional

from anibox_check.home import home_dir, legacy_dirs

from . import __version__
from .selfupdate import UpdateError, ZIP_NAME_RE, downloads_dir, read_package, version_tuple


def _size(path: Path) -> int:
    if path.is_file():
        return path.stat().st_size
    total = 0
    for root, _, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return total


def _entry(path: Path, what: str) -> dict:
    return {"id": hashlib.sha1(str(path).encode("utf-8")).hexdigest()[:16], "path": str(path), "what": what,
            "size": _size(path), "folder": path.is_dir()}


def find_leftovers(program_dir: Path, data_dir: Path, downloads: Optional[Path] = None,
                   update_running: bool = False) -> List[dict]:
    program_dir, data_dir = Path(program_dir), Path(data_dir)
    out: List[dict] = []
    for name in ("run-check.bat", "run-check.sh"):
        p = program_dir / "library-check" / name
        if p.is_file():
            out.append(_entry(p, "The old Library Check launcher. The Library Check is part of AniBox now (Missing page)."))
    if (program_dir / "AniBox-handoff.txt").is_file():
        out.append(_entry(program_dir / "AniBox-handoff.txt", "An old notes file from an early version."))
    if (program_dir / ".previous-update").is_dir():
        out.append(_entry(program_dir / ".previous-update",
                          "The previous AniBox version, kept after the last update in case you wanted to go back."))
    if (program_dir / ".failed-update").is_dir():
        out.append(_entry(program_dir / ".failed-update", "A new version that didn't start; AniBox went back to this one."))
    if not update_running:
        for name in ("staging", "runner"):
            p = data_dir / "update" / name
            if p.is_dir():
                out.append(_entry(p, "Leftovers of the last update."))
    downloads = downloads_dir() if downloads is None else downloads
    try:
        zips = [p for p in Path(downloads).iterdir() if p.is_file() and ZIP_NAME_RE.match(p.name)]
    except OSError:
        zips = []
    for z in sorted(zips):
        try:
            v = read_package(z)["version"]
        except UpdateError:
            continue  # not an AniBox package after all: not ours to remove
        if version_tuple(v) <= version_tuple(__version__):
            out.append(_entry(z, f"The AniBox {v} update zip. Not needed anymore: you have {__version__}."))
    home = home_dir()
    if (home / "settings.json").is_file():  # copied over in 1.1, so the old folder is only a leftover
        for old in legacy_dirs():
            if old.is_dir() and old.resolve() != home.resolve():
                out.append(_entry(old, "Settings of AniBox 1.0 and older. They were copied to AniBox's data folder in 1.1."))
    return out


def remove(entry: dict) -> None:
    p = Path(entry["path"])
    if p.is_dir():
        shutil.rmtree(p)
    elif p.exists():
        p.unlink()


LOG_FILE = "tidy-log.jsonl"  # what Tidy up removed, for the History page (in AniBox's app folder)


def log_removal(log_path: Path, entry: dict) -> None:
    """Note a removal for the History page. (It can't be undone: Tidy up doesn't use the recycle bin.)"""
    line = {"time": time.time(), "path": entry["path"], "what": entry.get("what", ""), "size": entry.get("size", 0),
            "folder": bool(entry.get("folder"))}
    try:
        with open(log_path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(line, ensure_ascii=False) + "\n")
    except OSError:
        pass
