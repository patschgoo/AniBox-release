"""Your anime library: the folders on your drives, matched to MyAnimeList.

Scanning only *lists* folders (read-only). The result is cached in ``library.json`` in AniBox's
data folder, so the app starts instantly; "Scan now" refreshes it.

Rescans are quick: ``scan-cache.json`` (next to ``library.json``) remembers every folder's modified
time and its video files, so a folder that hasn't changed isn't listed again (see ``TreeWalker``).
On a drive that answers slowly (the network, SMB) folders are listed several at a time, because
waiting for each answer takes longer than the answer itself. ``scan(folders, full=True)`` ignores
the cache and lists everything.
"""

from __future__ import annotations

import json
import logging
import os
import queue
import re
from collections import Counter
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

from anibox_check import ignore as ignore_list

from .languages import from_names
from anibox_check.analyze import MISSING, PARTIAL, UNSURE, UPCOMING, Analyzer
from anibox_check.cli import ignored_path
from anibox_check.datasets import Datasets, default_data_dir, ensure_datasets
from anibox_check.folders import (
    EXTRA_DIRS, VIDEO_EXTENSIONS, TitleMatcher, episode_number, folder_episodes, is_season_dir, season_number,
)
from anibox_check.ids import MAL
from anibox_check.plex import PlexItem

log = logging.getLogger("anibox.library")

CACHE_VERSION = 2  # 2: automatic and by-hand matches kept apart
_SXXEYY = re.compile(r"\bS\d{1,2}\s?E\d{1,4}\b", re.I)  # "Show - S01E01": an episode, not a movie
AUTO_PICK_RATIO = 0.5  # libraries where at least half the folders are known anime are picked automatically

SCAN_CACHE_FILE = "scan-cache.json"
SCAN_CACHE_VERSION = 1
SCAN_WORKERS = 8  # folders listed at the same time; over SMB the wait per answer is the limit, not the line
RECENT_SECONDS = 5.0  # a folder changed this close to its listing isn't trusted next time (coarse timestamps)
SLOW_LISTING_SECONDS = 0.001  # listings slower than this (local disks: ~0.05 ms) mean a network drive ...
SLOW_IN_A_ROW = 3  # ... once this many in a row were slow; then SCAN_WORKERS folders are listed at a time


def natural_key(text: str):
    return [int(t) if t.isdigit() else t.casefold() for t in re.split(r"(\d+)", text)]


def episode_label(file: str, number: Optional[Tuple[int, int]], in_season_folder: bool) -> str:
    if number is None:
        return os.path.splitext(file.rsplit("\\", 1)[-1])[0]
    season, ep = number
    if season == 0:
        return f"Special {ep}"
    if in_season_folder:
        return f"Season {season} · Episode {ep}"
    return f"Episode {ep}"


def walk_videos(root: str, on_progress: Optional[Callable[[int], None]] = None) -> List[Tuple[str, float]]:
    """(full path, modified time) of every video file below ``root``. Only lists folders.

    Lists every folder (no scan cache; several at a time on slow drives). Same result and order
    as a plain one-folder-at-a-time walk.
    """
    with TreeWalker() as walker:
        return walker.walk(root, on_progress)


# -- the folder walker -------------------------------------------------------------------------------

def scan_rules() -> str:
    """What a cached file list depends on. If it changes (new video type, new extras folder), the
    scan cache is thrown away."""
    return ",".join(sorted(VIDEO_EXTENSIONS)) + "|" + ",".join(sorted(EXTRA_DIRS))


def _skipped_dir(name: str) -> bool:
    return name.startswith(".") or name.lower() in EXTRA_DIRS


def listing_times_trusted(root: str) -> bool:
    """Can the folder times that come with a parent's listing be trusted below ``root``?

    On Windows a listing reports the copy of a folder's times kept in its parent's NTFS directory
    entry, and NTFS refreshes that copy only when the last handle to the folder is closed (an open
    Explorer window can hold one). So on local Windows drives every folder is listed anyway, which is
    cheap there. On a network share the server fills in the times; the Shield (Android/Linux) reads
    the real ones. On Linux/macOS the times come from stat() and are always current.
    """
    return os.name != "nt" or _is_network_path(root)


def _is_network_path(path: str) -> bool:
    """Windows: a UNC path (\\\\server\\share\\...) or a mapped network drive."""
    import ntpath
    p = path.replace("/", "\\")
    if p[:8].upper() == "\\\\?\\UNC\\":
        return True
    if p.startswith(("\\\\?\\", "\\\\.\\")):
        p = p[4:]
    elif p.startswith("\\\\"):
        return True
    drive = ntpath.splitdrive(p)[0]
    if len(drive) != 2:
        return False
    try:
        import ctypes
        return ctypes.windll.kernel32.GetDriveTypeW(drive + "\\") == 4  # DRIVE_REMOTE
    except (AttributeError, OSError):  # not on Windows
        return False


def _list_dir(path: str):
    """List one folder: ``((videos, subfolders), listed_at)``, or ``(None, listed_at)`` if unreadable.

    ``videos`` = [(name, mtime)], ``subfolders`` = [(name, mtime or None)], both in listing order;
    skipped folders (dot folders, extras) are left out. On Windows the modified times come with the
    listing itself (no extra request per entry).
    """
    listed_at = time.time()
    try:
        with os.scandir(path) as it:
            entries = list(it)
    except OSError:
        return None, listed_at
    videos: List[Tuple[str, float]] = []
    subdirs: List[Tuple[str, Optional[float]]] = []
    for e in entries:
        try:
            if e.is_dir(follow_symlinks=False):
                if _skipped_dir(e.name):
                    continue
                try:
                    mtime: Optional[float] = e.stat(follow_symlinks=False).st_mtime
                except OSError:
                    mtime = None
                subdirs.append((e.name, mtime))
            elif os.path.splitext(e.name)[1].lower() in VIDEO_EXTENSIONS:
                try:
                    fmtime = e.stat().st_mtime
                except OSError:
                    fmtime = 0.0
                videos.append((e.name, fmtime))
        except OSError:
            continue
    return (videos, subdirs), listed_at


def _trusted(entry: dict, mtime: Optional[float]) -> bool:
    """A cached folder may be reused: same modified time as now, and that time was clearly older than
    the listing (a change in the same timestamp "tick" as the listing would otherwise go unseen)."""
    if mtime is None or mtime <= 0 or entry.get("mtime") != mtime:
        return False
    return entry.get("listed", 0.0) - mtime > RECENT_SECONDS


def _names_differ(old: dict, new: dict) -> bool:
    return ({f[0] for f in old["files"]} != {f[0] for f in new["files"]}
            or set(old["dirs"]) != set(new["dirs"]))


def _valid_entry(e) -> bool:
    if not isinstance(e, dict):
        return False
    files, dirs = e.get("files"), e.get("dirs")
    return (isinstance(files, list) and isinstance(dirs, list)
            and isinstance(e.get("listed"), (int, float))
            and (e.get("mtime") is None or isinstance(e.get("mtime"), (int, float)))
            and all(isinstance(f, list) and len(f) == 2 and isinstance(f[0], str) and isinstance(f[1], (int, float))
                    for f in files)
            and all(isinstance(d, str) for d in dirs))


def _flatten(root: str, tree: Dict[str, dict]) -> List[Tuple[str, float]]:
    """The video files of a walked tree, in the order a plain one-folder-at-a-time walk finds them."""
    out: List[Tuple[str, float]] = []
    stack = [root]
    while stack:
        path = stack.pop()
        entry = tree.get(path)
        if entry is None:  # couldn't be listed: skipped
            continue
        out.extend((os.path.join(path, name), mtime) for name, mtime in entry["files"])
        stack.extend(os.path.join(path, d) for d in entry["dirs"])
    return out


class TreeWalker:
    """Finds the video files below one or more folders, reusing unchanged folders from the scan
    cache and listing several folders at a time when the drive is slow to answer (network).

    For every folder the cache keeps its modified time (mtime), when it was listed, its video files
    (name + mtime) and its subfolders. Adding, removing or renaming something *in* a folder changes
    that folder's mtime (not its parent's). The rules:

    * A folder **with subfolders** is always listed. One listing returns the mtimes of all its
      subfolders at once (on Windows they come with the listing), which is far cheaper over SMB than
      asking for each subfolder; that's how changes further down are found. The library folders and
      season-style shows are such folders, so a rescan lists only a few dozen folders.
    * A folder **without subfolders** (a show or season folder holding the episodes) is not listed
      again if its mtime, as seen in its parent's listing, is exactly the cached one and that mtime
      was more than ``RECENT_SECONDS`` older than its last listing. Otherwise it's listed.
    * New folders are listed; folders that are gone simply aren't visited and drop out of the cache.
    * ``full=True`` lists every folder (the cache is only used to spot drives whose folder times
      don't change, see below). So does a local Windows drive (see ``listing_times_trusted``).
    * Safety net: if a listed folder turns out to have different contents although its mtime is the
      cached one (a drive or server that doesn't update folder times), it's logged, and that root is
      walked again without any reuse, as are the remaining roots of this scan.

    Listing: folders are listed one after another at first. Once ``SLOW_IN_A_ROW`` listings in a row
    took longer than ``SLOW_LISTING_SECONDS`` (a network drive: each listing waits for answers), the
    rest of the scan lists ``workers`` folders at a time. On a local disk threads would only add
    overhead. ``parallel=True``/``False`` forces one way.

    Video files are counted in ``on_progress`` as they're found. Results come out in the same order
    as the old one-folder-at-a-time walk, however the listings finish.
    """

    def __init__(self, cache: Optional[Dict[str, dict]] = None, full: bool = False, workers: int = SCAN_WORKERS,
                 parallel: Optional[bool] = None):
        self.old: Dict[str, dict] = cache or {}
        self.full = full
        self.workers = max(1, int(workers))
        self.parallel = bool(parallel)  # listing several folders at a time (switches on by itself if slow)
        self._auto = parallel is None
        self._slow_in_a_row = 0
        self.new: Dict[str, dict] = {}  # what to save as the next scan cache
        self.listed = 0  # folders listed (each one at least one request to the drive)
        self.reused = 0  # folders taken from the cache unchanged
        self.unreadable = 0  # folders that couldn't be listed (skipped, as before)
        self.unreliable = 0  # folders whose contents changed while their mtime didn't
        self.distrust = False  # set once that happened: no more reuse in this scan
        self._pool: Optional[ThreadPoolExecutor] = None
        self._entered = False

    def __enter__(self) -> "TreeWalker":
        self._entered = True
        return self

    def __exit__(self, *exc) -> None:
        self._entered = False
        if self._pool is not None:
            self._pool.shutdown(wait=True, cancel_futures=True)
            self._pool = None

    def walk(self, root: str, on_progress: Optional[Callable[[int], None]] = None) -> List[Tuple[str, float]]:
        """(full path, modified time) of every video file below ``root``."""
        if not self._entered:
            raise RuntimeError("TreeWalker must be used in a with block")
        trusted = listing_times_trusted(root)
        if not trusted and self.old and not self.full:
            log.info("%s is on a local Windows drive: every folder is listed (folder times there can lag)", root)
        reuse = trusted and not (self.full or self.distrust)
        tree, odd = self._walk(root, on_progress, reuse, check=trusted)
        if odd and reuse:  # some folder times can't be trusted here: walk this root again, listing everything
            self.distrust = True
            self._log_odd(odd)
            log.warning("Folder times look unreliable below %s; listing every folder there", root)
            tree, more = self._walk(root, on_progress, reuse=False, check=True)
            self._log_odd(more - odd)
        else:
            self._log_odd(odd)
        self.new.update(tree)
        return _flatten(root, tree)

    def _log_odd(self, paths) -> None:
        for path in sorted(paths):
            log.warning("%s changed although its modified time didn't", path)
        self.unreliable += len(paths)

    def _note_speed(self, seconds: float, listing) -> None:
        """Switch to parallel listing after a few slow listings in a row (allowing ~5 µs per entry)."""
        entries = len(listing[0]) + len(listing[1]) if listing else 0
        if seconds - 5e-6 * entries > SLOW_LISTING_SECONDS:
            self._slow_in_a_row += 1
            if self._slow_in_a_row >= SLOW_IN_A_ROW:
                self.parallel = True
                log.info("Folders answer slowly (network drive?): listing %d at a time", self.workers)
        else:
            self._slow_in_a_row = 0

    def _walk(self, root: str, on_progress: Optional[Callable[[int], None]], reuse: bool,
              check: bool = True) -> Tuple[Dict[str, dict], set]:
        tree: Dict[str, dict] = {}
        here: List[Tuple[str, Optional[float]]] = []  # folders to list on this thread
        pending: Dict[object, Tuple[str, Optional[float]]] = {}  # folders being listed by the pool
        finished: "queue.Queue" = queue.Queue()
        found = 0
        odd: set = set()  # listed folders whose contents changed while their mtime stayed the same

        def submit(path: str, mtime: Optional[float]) -> None:
            if self._pool is None:
                self._pool = ThreadPoolExecutor(max_workers=self.workers, thread_name_prefix="anibox-list")
            fut = self._pool.submit(_list_dir, path)
            pending[fut] = (path, mtime)
            fut.add_done_callback(finished.put)

        def visit(path: str, mtime: Optional[float]) -> None:
            nonlocal found
            old = self.old.get(path)
            if reuse and old is not None and not old["dirs"] and _trusted(old, mtime):
                tree[path] = old
                self.reused += 1
                found += len(old["files"])
            elif self.parallel:
                submit(path, mtime)
            else:
                here.append((path, mtime))

        try:
            root_mtime: Optional[float] = os.stat(root).st_mtime
        except OSError:
            root_mtime = None
        visit(root, root_mtime)
        while here or pending:
            if here:
                path, mtime = here.pop()
                t0 = time.perf_counter()
                listing, listed_at = _list_dir(path)
                if self._auto and not self.parallel:
                    self._note_speed(time.perf_counter() - t0, listing)
                    if self.parallel:  # hand the folders still waiting to the pool
                        for item in here:
                            submit(*item)
                        here.clear()
            else:
                fut = finished.get()
                path, mtime = pending.pop(fut)
                listing, listed_at = fut.result()
            if listing is None:
                self.unreadable += 1
                continue
            videos, subdirs = listing
            self.listed += 1
            entry = {"mtime": mtime, "listed": listed_at,
                     "files": [[n, m] for n, m in videos], "dirs": [n for n, _ in subdirs]}
            old = self.old.get(path) if check else None
            if old is not None and _trusted(old, mtime) and _names_differ(old, entry):
                odd.add(path)
            tree[path] = entry
            found += len(videos)
            for name, sub_mtime in subdirs:
                visit(os.path.join(path, name), sub_mtime)
            if on_progress:
                on_progress(found)
        if on_progress:
            on_progress(found)
        return tree, odd


def _parts(path: str) -> List[str]:
    return [p for p in re.split(r"[\\/]+", path) if p]


def group_files(files: List[Tuple[str, float]]) -> Dict[Tuple[str, str], List[dict]]:
    """Group video files by (library folder, show folder), the same way the Library Check does."""
    shows: Dict[Tuple[str, str], List[dict]] = {}
    for path, mtime in files:
        parts = _parts(path)
        if len(parts) < 3:
            continue
        name = parts[-1]
        folders = parts[:-1]
        if any(f.lower() in EXTRA_DIRS for f in folders[-2:]):
            continue
        season_dir = ""
        while len(folders) >= 3 and is_season_dir(folders[-1], folders[-2]):
            season_dir = season_dir or folders[-1].strip()
            folders = folders[:-1]
        library, show = folders[-2], folders[-1]
        rel = f"{season_dir}\\{name}" if season_dir else name
        shows.setdefault((library, show), []).append({"path": path, "file": rel, "mtime": mtime})
    return shows


class Library:
    def __init__(self, store, data_dir: Path, datasets_dir: Optional[Path] = None):
        self.store = store
        self.cache_path = data_dir / "library.json"
        self.scan_cache_path = data_dir / SCAN_CACHE_FILE
        self.datasets_dir = datasets_dir or default_data_dir()
        self._lock = threading.RLock()
        self._shows: Dict[str, dict] = {}
        self._libraries: Dict[str, dict] = {}  # name -> {"folders": n, "matched": n}
        self._scanned_at = 0.0
        self._ds: Optional[Datasets] = None
        self._report = None
        self.status = {"state": "idle", "phase": "", "found": 0, "message": "", "finished": 0.0, "full": False}
        self._load_cache()
        self.ensure_lock_baseline()

    # -- cache ---------------------------------------------------------------------------------

    def _load_cache(self) -> None:
        try:
            data = json.loads(self.cache_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return
        if data.get("version") not in (1, CACHE_VERSION):
            return
        if data.get("version") == 1:  # AniBox 1.0: there were only automatic matches
            for sh in data.get("shows", []):
                sh.setdefault("auto_mal_id", sh.get("mal_id"))
                sh.setdefault("auto_note", sh.get("note") or "")
                sh.setdefault("manual", False)
        with self._lock:
            self._shows = {s["id"]: s for s in data.get("shows", [])}
            self._libraries = data.get("libraries", {})
            self._scanned_at = data.get("scanned_at", 0.0)

    def _save_cache(self) -> None:
        data = {"version": CACHE_VERSION, "scanned_at": self._scanned_at,
                "libraries": self._libraries, "shows": list(self._shows.values())}
        tmp = self.cache_path.with_suffix(".part")
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, self.cache_path)

    def _load_scan_cache(self) -> Optional[Dict[str, dict]]:
        """The folder listings of the last scan, or None (missing, damaged, other version/rules)."""
        try:
            data = json.loads(self.scan_cache_path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return None
        except (OSError, ValueError):
            log.warning("The scan cache couldn't be read; listing every folder")
            return None
        dirs = data.get("dirs") if isinstance(data, dict) else None
        if (not isinstance(dirs, dict) or data.get("version") != SCAN_CACHE_VERSION
                or data.get("rules") != scan_rules()):
            log.info("The scan cache is from another version; listing every folder")
            return None
        if not all(isinstance(k, str) and _valid_entry(v) for k, v in dirs.items()):
            log.warning("The scan cache is damaged; listing every folder")
            return None
        return dirs

    def _save_scan_cache(self, dirs: Dict[str, dict]) -> None:
        data = {"version": SCAN_CACHE_VERSION, "rules": scan_rules(), "saved": time.time(), "dirs": dirs}
        tmp = self.scan_cache_path.with_suffix(".part")
        try:  # ASCII-escaped, so any file name survives the round trip
            tmp.write_text(json.dumps(data, separators=(",", ":")), encoding="utf-8")
            os.replace(tmp, self.scan_cache_path)
        except OSError:
            log.warning("The scan cache couldn't be saved", exc_info=True)

    # -- data ------------------------------------------------------------------------------------

    def datasets(self, refresh: bool = False, log: Callable[[str], None] = lambda m: None) -> Datasets:
        if self._ds is None or refresh:
            self._ds = ensure_datasets(self.datasets_dir, refresh=refresh, log=log)
        return self._ds

    @property
    def scanned_at(self) -> float:
        return self._scanned_at

    def libraries(self) -> Dict[str, dict]:
        with self._lock:
            return dict(self._libraries)

    # -- kinds of libraries, where they are ---------------------------------------------------------

    def matcher(self) -> TitleMatcher:
        ds = self.datasets()
        if getattr(self, "_matcher_for", None) is not ds:
            self._matcher, self._matcher_for = TitleMatcher(ds.titles), ds
        return self._matcher

    @staticmethod
    def show_folder_path(show: dict) -> str:
        """The show's folder on disk (from its first episode's path)."""
        if not show.get("episodes"):
            return ""
        ep = show["episodes"][0]
        path = ep["path"]
        for _ in range(len([p for p in re.split(r"[\\/]+", ep["file"]) if p])):
            path = os.path.dirname(path)
        return path

    def library_roots(self) -> Dict[str, List[Tuple[str, int]]]:
        """Library name -> [(folder on disk, number of shows there)], the fullest first. A library name
        can exist on several drives (e.g. an empty "Anime" folder next to the full one)."""
        with self._lock:
            shows = list(self._shows.values())
        counts: Dict[str, Counter] = {}
        for sh in shows:
            folder = self.show_folder_path(sh)
            if folder:
                counts.setdefault(sh["library"], Counter())[os.path.dirname(folder)] += 1
        return {lib: c.most_common() for lib, c in counts.items()}

    def library_kind(self, name: str) -> str:
        """anime, series or movies: what the user chose in Settings, else guessed (mostly matched to
        MyAnimeList = anime; mostly one file per folder = movies; else series)."""
        chosen = (self.store.settings().get("library_kinds") or {}).get(name)
        return chosen if chosen in ("anime", "series", "movies") else self.auto_kind(name)

    def auto_kind(self, name: str) -> str:
        with self._lock:
            lib = self._libraries.get(name) or {}
            singles = sum(1 for s in self._shows.values() if s["library"] == name and len(s["episodes"]) <= 1
                          and not any(_SXXEYY.search(e["file"]) for e in s["episodes"]))
        folders = lib.get("folders") or 0
        if folders and (lib.get("matched") or 0) / folders >= AUTO_PICK_RATIO:
            return "anime"
        if folders and singles / folders >= 0.6:
            return "movies"
        return "series"

    def show_kind(self, show: dict) -> Tuple[str, str]:
        """("anime" | "series" | "movie", MyAnimeList type in lower case for anime: tv, movie, ova ...)."""
        kind = self.library_kind(show["library"])
        if kind == "anime":
            return "anime", (show.get("type") or "").lower()
        if kind == "movies":
            return "movie", ""
        return "series", ""

    def selected_libraries(self) -> List[str]:
        chosen = self.store.settings().get("libraries") or []
        with self._lock:
            names = list(self._libraries)
        return [n for n in names if n in chosen] if chosen else names

    def shows(self, all_libraries: bool = False) -> List[dict]:
        selected = None if all_libraries else set(self.selected_libraries())
        with self._lock:
            return [s for s in self._shows.values() if selected is None or s["library"] in selected]

    def show(self, show_id: str) -> Optional[dict]:
        with self._lock:
            return self._shows.get(show_id)

    def episode(self, key: str) -> Tuple[Optional[dict], int]:
        # The key is "<library>\<show>\<file>"; the file part may contain a season folder.
        parts = key.split("\\")
        show = self.show(f"{parts[0]}\\{parts[1]}") if len(parts) >= 3 else None
        if show is None:
            return None, -1
        for i, ep in enumerate(show["episodes"]):
            if ep["key"] == key:
                return show, i
        return show, -1

    # -- scanning ----------------------------------------------------------------------------------

    def scan_async(self, folders: List[str], full: bool = False) -> bool:
        """Scan in the background. ``full=True`` lists every folder again instead of only changed ones."""
        with self._lock:
            if self.status["state"] == "running":
                return False
            self.status = {"state": "running", "phase": "Starting", "found": 0, "message": "", "finished": 0.0,
                           "full": bool(full)}
        threading.Thread(target=self._scan_safe, args=(list(folders), bool(full)), daemon=True,
                         name="anibox-scan").start()
        return True

    def scan_and_wait(self, folders: List[str], timeout: float = 900) -> bool:
        """Start a quick scan (after one that is already running) and wait for it. False on time-out."""
        end = time.time() + timeout
        while not self.scan_async(folders):
            if time.time() > end:
                return False
            time.sleep(0.5)
        while self.status.get("state") == "running":
            if time.time() > end:
                return False
            time.sleep(0.3)
        return self.status.get("state") == "done"

    def _scan_safe(self, folders: List[str], full: bool = False) -> None:
        started = time.time()
        log.info("Scan started: %d folder(s)%s", len(folders), ", full rescan" if full else "")
        try:
            self.scan(folders, full=full)
            self.status.update(state="done", phase="Done", finished=time.time())
            with self._lock:
                shows = list(self._shows.values())
            log.info("Scan done in %.1f s: %d files, %d show folders, %d matched to MyAnimeList "
                     "(%d folders listed, %d unchanged ones reused)",
                     time.time() - started, sum(len(s["episodes"]) for s in shows), len(shows),
                     sum(1 for s in shows if s.get("mal_id")), self.status.get("listed", 0),
                     self.status.get("reused", 0))
        except Exception as exc:  # shown in the app
            log.exception("Scan failed")
            self.status.update(state="error", phase="", message=str(exc), finished=time.time())

    def scan(self, folders: List[str], full: bool = False) -> None:
        """Read the folders and match them. Only changed folders are listed again (``scan-cache.json``);
        ``full=True`` lists every folder."""
        self.status.update(phase="Loading the anime lists (first time: about 70 MB)", full=bool(full))
        ds = self.datasets(log=lambda m: self.status.update(phase=m.strip()))
        matcher = TitleMatcher(ds.titles)
        files: List[Tuple[str, float]] = []
        with TreeWalker(self._load_scan_cache(), full=full) as walker:
            for folder in folders:
                if not os.path.isdir(folder):
                    raise FileNotFoundError(f"Folder not found or not reachable: {folder}")
                self.status.update(phase=f"Reading {folder}")
                base = len(files)
                t0 = time.time()
                listed, reused, unreadable = walker.listed, walker.reused, walker.unreadable
                files.extend(walker.walk(folder, lambda n: self.status.update(found=base + n)))
                log.info("Read %s: %d video files in %.1f s (%d folders listed, %d unchanged ones reused%s)",
                         folder, len(files) - base, time.time() - t0, walker.listed - listed,
                         walker.reused - reused,
                         f", {walker.unreadable - unreadable} couldn't be read" if walker.unreadable > unreadable else "")
        self._save_scan_cache(walker.new)
        self.status.update(listed=walker.listed, reused=walker.reused)
        if walker.unreliable:
            log.warning("%d folder(s) had changed although their modified time hadn't. %s", walker.unreliable,
                        "Quick rescans may miss changes on that drive." if full else
                        "Their folders were listed again; if files still seem missing, use a full rescan.")
        overrides = self.store.overrides()
        self.status.update(phase="Matching folder names to MyAnimeList")
        grouped = group_files(files)
        shows: Dict[str, dict] = {}
        libraries: Dict[str, dict] = {}
        for (library, folder), items in grouped.items():
            names = [i["file"] for i in items]
            counted = folder_episodes(names, folder)
            mal_id, note = matcher.match(folder, library, len(counted))
            episodes = []
            for it in items:
                number = None
                sub, _, fname = it["file"].rpartition("\\")
                num = episode_number(fname, folder)
                if num is not None:
                    number = num
                    if sub:
                        number = (season_number(sub), num[1]) if num[0] == 1 else num
                episodes.append({
                    "key": f"{library}\\{folder}\\{it['file']}",
                    "path": it["path"],
                    "file": it["file"],
                    "season": number[0] if number else None,
                    "number": number[1] if number else None,
                    "label": episode_label(it["file"], number, bool(sub)),
                })
            episodes.sort(key=lambda e: (e["number"] is None, e["season"] or 0, e["number"] or 0, natural_key(e["file"])))
            show_id = f"{library}\\{folder}"
            show = {
                "id": show_id, "library": library, "folder": folder,
                "name_langs": from_names([library, folder] + names),
                "auto_mal_id": mal_id, "auto_note": note,
                "added": max((i["mtime"] for i in items), default=0.0),
                "counted": len(counted),
                "episodes": episodes,
            }
            _apply_match(show, overrides.get(show_id), ds.titles)
            shows[show_id] = show
            lib = libraries.setdefault(library, {"folders": 0, "matched": 0})
            lib["folders"] += 1
            lib["matched"] += 1 if show["mal_id"] else 0
        with self._lock:
            previous = self._shows
        self._follow_moved_keys(previous, shows)
        with self._lock:
            self._shows = shows
            self._libraries = libraries
            self._scanned_at = time.time()
            self._report = None
            self._save_cache()
        self.ensure_lock_baseline()
        settings = self.store.settings()
        if not settings.get("libraries"):
            picked = [n for n, l in libraries.items() if l["folders"] and l["matched"] / l["folders"] >= AUTO_PICK_RATIO]
            if picked:
                self.store.update_settings({"libraries": sorted(picked)})

    def _follow_moved_keys(self, previous: Dict[str, dict], shows: Dict[str, dict]) -> None:
        """Same file, new key (e.g. "Show\\Show - Season 1" is now read as a season of "Show"): move the
        watch progress, locks and show settings along, and keep the show visible in the chosen libraries."""
        if not previous:
            return
        old_by_path = {e["path"]: (e["key"], sh["id"], sh["library"]) for sh in previous.values() for e in sh["episodes"]}
        episodes: Dict[str, Tuple[str, str]] = {}
        moved_shows: Dict[str, str] = {}
        libraries: Dict[str, str] = {}
        for sh in shows.values():
            for e in sh["episodes"]:
                old = old_by_path.get(e["path"])
                if old and old[0] != e["key"]:
                    episodes[old[0]] = (e["key"], sh["id"])
                    if old[1] not in shows:
                        moved_shows.setdefault(old[1], sh["id"])
                    libraries.setdefault(old[2], sh["library"])
        if not episodes:
            return
        self.store.move_keys(episodes, moved_shows)
        chosen = self.store.settings().get("libraries") or []
        extra = sorted({new for old, new in libraries.items() if old in chosen and new not in chosen})
        if chosen and extra:
            self.store.update_settings({"libraries": sorted(set(chosen) | set(extra))})
        log.info("%d episodes in %d folders are now read differently (e.g. %s → %s); their progress and locks moved along",
                 len(episodes), len(moved_shows), next(iter(moved_shows), "?"), next(iter(moved_shows.values()), "?"))

    # -- locks: what was already there stays as it is ------------------------------------------------

    def all_keys(self) -> List[str]:
        with self._lock:
            return [e["key"] for sh in self._shows.values() for e in sh["episodes"]]

    def ensure_lock_baseline(self) -> None:
        """The first time: every episode that exists now is locked. Later additions are "new"."""
        if not self.store.settings().get("protect_existing", True) or self.store.meta("lock_baseline"):
            return
        keys = self.all_keys()
        if not keys:
            return  # nothing scanned yet: the first scan becomes the baseline
        total = self.store.lock_snapshot(keys)
        self.store.set_meta("lock_baseline", time.time())
        log.info("Locked the %d episodes that were already there", total)

    def lock_everything_now(self) -> int:
        total = self.store.lock_snapshot(self.all_keys())
        self.store.set_meta("lock_baseline", time.time())
        log.info("Locked everything that's there now: %d episodes", total)
        return total

    def lock_view(self, show: dict, locked: Optional[set] = None, unlocked: Optional[set] = None) -> dict:
        """{"protect", "unlocked", "locked": n, "new": n, "keys": set of locked keys in this show}."""
        protect = bool(self.store.settings().get("protect_existing", True))
        locked = self.store.locked_keys() if locked is None else locked
        unlocked = self.store.unlocked_shows() if unlocked is None else unlocked
        mine = {e["key"] for e in show["episodes"] if e["key"] in locked}
        is_unlocked = show["id"] in unlocked
        active = mine if protect and not is_unlocked else set()
        return {"protect": protect, "unlocked": is_unlocked, "locked": len(mine),
                "new": len(show["episodes"]) - len(mine), "keys": active}

    # -- matching by hand ------------------------------------------------------------------------------

    def set_match(self, show_id: str, mal_id: Optional[str]) -> dict:
        """Match a folder to a MyAnimeList entry by hand ("" = no entry, None = automatic again).

        Saved in AniBox's database and applied after every scan; the folder itself isn't touched.
        """
        if mal_id:
            mal_id = str(mal_id).strip()
            if not mal_id.isdigit() or mal_id not in self.datasets().titles:
                raise ValueError("That MyAnimeList entry isn't in the anime lists.")
        with self._lock:
            show = self._shows.get(show_id)
            if not show:
                raise ValueError("Show not found.")
        self.store.set_override(show_id, mal_id)
        with self._lock:
            _apply_match(show, mal_id, self.datasets().titles)
            lib = self._libraries.get(show["library"])
            if lib is not None:
                lib["matched"] = sum(1 for s in self._shows.values() if s["library"] == show["library"] and s.get("mal_id"))
            self._report = None
            self._save_cache()
        log.info("Match by hand: %s -> %s", show_id, mal_id if mal_id is not None else "automatic")
        return show

    def reapply_matches(self) -> None:
        """After restoring a backup: apply the matches by hand to the cached library."""
        with self._lock:
            if not self._shows:
                return
        overrides = self.store.overrides()
        titles = self.datasets().titles
        with self._lock:
            for show in self._shows.values():
                _apply_match(show, overrides.get(show["id"]), titles)
            for name, lib in self._libraries.items():
                lib["matched"] = sum(1 for sh in self._shows.values() if sh["library"] == name and sh.get("mal_id"))
            self._report = None
            self._save_cache()

    def search_titles(self, query: str, limit: int = 20) -> List[dict]:
        """MyAnimeList entries whose title or alternative title contains all words of ``query``."""
        words = [w for w in re.split(r"\s+", _fold(query)) if w]
        if not words:
            return []
        if len(words) == 1 and words[0].isdigit():
            info = self.datasets().titles.get(words[0])
            return [_title_json(words[0], info)] if info else []
        hits = []
        for mal_id, info in self.datasets().titles.items():
            names = [info.get("title") or ""] + list(info.get("syn") or [])
            best = None
            for n in names:
                f = _fold(n)
                if all(w in f for w in words):
                    score = (0 if f == " ".join(words) else 1 if f.startswith(words[0]) else 2, len(f))
                    best = score if best is None or score < best else best
            if best is not None:
                hits.append((best, mal_id, info))
        hits.sort(key=lambda h: h[0])
        return [_title_json(m, i) for _, m, i in hits[:limit]]

    # -- "what's missing" ---------------------------------------------------------------------------

    def report(self):
        """The Library Check report for the selected libraries (cached until the next scan)."""
        with self._lock:
            if self._report is not None:
                return self._report
            shows = self.shows()
        ds = self.datasets()
        items = []
        for s in shows:
            items.append(PlexItem(
                rating_key=s["id"], title=s["folder"], year=None, type="show", section=s["library"],
                section_key=s["library"], guid=s["id"], ids={MAL: {s["mal_id"]}} if s["mal_id"] else {},
                episodes=folder_episodes([e["file"] for e in s["episodes"]], s["folder"]),
                note=s.get("note") or "", source="folder",
            ))
        report = Analyzer(ds).analyze(items, [], folder_mode=True)
        ignore_list.apply(report, ignore_list.load(ignored_path()))
        with self._lock:
            self._report = report
        return report

    def forget_report(self) -> None:
        with self._lock:
            self._report = None

    def missing_for(self, show: dict) -> List[dict]:
        """Missing entries of the franchise this show belongs to."""
        if not show.get("mal_id"):
            return []
        report = self.report()
        for fr in report.franchises:
            if any(e.mal_id == show["mal_id"] for e in fr.entries):
                return [entry_json(e) for e in fr.entries if e.status in (MISSING, UPCOMING, PARTIAL, UNSURE)]
        return []


def _fold(text: str) -> str:
    import unicodedata
    t = unicodedata.normalize("NFKD", text or "").casefold()
    t = "".join(c for c in t if not unicodedata.combining(c))
    return re.sub(r"[^0-9a-z]+", " ", t).strip()


def _title_json(mal_id: str, info: dict) -> dict:
    return {"mal_id": mal_id, "title": info.get("title") or "", "type": info.get("type") or "",
            "year": info.get("year"), "episodes": info.get("episodes"),
            "url": f"https://myanimelist.net/anime/{mal_id}"}


def _apply_match(show: dict, override: Optional[str], titles: dict) -> None:
    """Fill in the MyAnimeList fields: from a match by hand if there is one, else the automatic one."""
    if override is None:
        mal_id, note, manual = show.get("auto_mal_id"), show.get("auto_note") or "", False
    else:
        mal_id = override or None
        note = "Matched by hand" if mal_id else "Marked by hand: not on MyAnimeList"
        manual = True
    info = titles.get(mal_id, {}) if mal_id else {}
    show.update(
        mal_id=mal_id, note=note, manual=manual,
        title=info.get("title") or show["folder"],
        type=info.get("type") or "", year=info.get("year"),
        mal_episodes=info.get("episodes"),
        picture=info.get("picture") or info.get("thumbnail") or "",
        anidb=info.get("anidb"),
    )


def entry_json(e) -> dict:
    return {
        "mal_id": e.mal_id, "title": e.title, "type": e.type, "episodes": e.episodes, "year": e.year,
        "status": e.status, "detail": e.detail, "have": e.have, "short": e.short, "folder": e.plex_title,
        "mal_url": e.mal_url, "anidb_url": e.anidb_url,
    }


