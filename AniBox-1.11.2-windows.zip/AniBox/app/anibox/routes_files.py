"""Files on the drives: "Add new videos" (Downloads -> library folder), undo, "Open folder" and
"Move or rename" for a show that is new or unlocked. The moving itself is fileops.py.

Part of the App class (see server.py); the methods use the App's attributes.
"""

from __future__ import annotations

import logging
import os
import time
from pathlib import Path
from typing import Dict, List, Tuple

from . import cleanup, fileops
from .apierror import ApiError
from .fileops import FileOpError, safe_name, with_sidecars
from .importer import Proposer, name_pattern, new_name, scan_inbox
from .selfupdate import downloads_dir
from .shortcut import open_folder, show_file

log = logging.getLogger("anibox.server")


class RoutesFilesMixin:
    GET_ROUTES = {"/api/import/plex-sections": "_plex_scan_choices"}
    # -- where things are ----------------------------------------------------------------------------

    def _inbox_roots(self) -> List[str]:
        chosen = self.store.settings().get("inbox_folders") or []
        return chosen or [str(downloads_dir())]

    def _library_paths(self) -> Dict[str, str]:
        """Library name -> its fullest folder on disk (an empty folder of the same name is never used)."""
        return {lib: roots[0][0] for lib, roots in self.library.library_roots().items() if roots and roots[0][1] > 0}

    # -- Add new videos --------------------------------------------------------------------------------

    def _import_view(self) -> dict:
        roots = self._inbox_roots()
        groups = scan_inbox(roots, exclude=self.store.settings().get("folders") or [])
        self._inbox = {g["id"]: g for g in groups}
        proposer = Proposer(self.library, self.store.settings())
        items = [proposer.propose(g, self._import_matches.get(g["id"])) for g in groups]
        return {"roots": roots, "mode": self.store.settings().get("import_mode", "move"),
                "writeNfo": bool(self.store.settings().get("import_write_nfo")),
                "libraries": sorted(proposer.targets), "items": items, "job": self.fileops.state,
                "undo": self.fileops.last_batch()}

    def _import_count(self) -> int:
        now = time.time()
        if now - self._inbox_count[1] > 20:
            try:
                n = len(scan_inbox(self._inbox_roots(), exclude=self.store.settings().get("folders") or []))
            except OSError:
                n = 0
            self._inbox_count = (n, now)
        return self._inbox_count[0]

    def _import_match(self, body: dict) -> dict:
        gid = str(body.get("id") or "")
        if gid not in self._inbox:
            raise ApiError("That download isn't in the list anymore. Look again.")
        mal = body.get("mal_id")
        self._import_matches[gid] = str(mal) if mal else ""
        return Proposer(self.library, self.store.settings()).propose(self._inbox[gid], self._import_matches[gid] or "")

    def _import_apply(self, body: dict) -> dict:
        mode = body.get("mode") if body.get("mode") in ("move", "copy") else "move"
        write_nfo = bool(body.get("write_nfo"))
        plex_section = str(body.get("plex_section") or "")
        if not body.get("preview"):
            self.store.update_settings({"import_write_nfo": write_nfo, "plex_scan_section": plex_section})
        proposer = Proposer(self.library, self.store.settings())
        paths = self._library_paths()
        ops, new_shows, touched, targets = [], {}, set(), set()
        for item in body.get("items") or []:
            if not item.get("include", True):
                continue
            g = self._inbox.get(str(item.get("id") or ""))
            if not g:
                raise ApiError("The list is out of date. Look again.")
            lib = str(item.get("library") or "")
            existing = any(s["library"] == lib and s["folder"] == item.get("folder") for s in proposer.shows)
            if lib not in proposer.targets and not existing:
                raise ApiError(f"\"{lib}\" isn't one of your anime library folders (or it's protected).")
            if lib not in paths:
                raise ApiError(f"AniBox doesn't know where \"{lib}\" is. Scan your library folders first.")
            folder = safe_name(str(item.get("folder") or ""))
            target = os.path.join(paths[lib], folder)
            season = str(item.get("season_dir") or "")
            if season and existing:
                target = os.path.join(target, safe_name(season))
            touched.add(f"{lib}\\{folder}")
            targets.add(target)
            known = {f["src"]: f for f in g["files"]}
            for f in item.get("files") or []:
                if not f.get("include", True):
                    continue
                src = str(f.get("src") or "")
                if src not in known:
                    raise ApiError("A file in the list isn't in your Downloads anymore. Look again.")
                ext = os.path.splitext(src)[1].lower()
                stem = safe_name(os.path.splitext(str(f.get("new_name") or ""))[0] or os.path.splitext(known[src]["name"])[0])
                ops += with_sidecars(Path(src), Path(os.path.join(target, stem + ext)))
            if not existing and item.get("mal_id"):
                new_shows[f"{lib}\\{folder}"] = str(item["mal_id"])
        checked = fileops.FileOps.check(ops, allowed_roots=list(paths.values()))
        if body.get("preview"):
            return {"ops": checked}
        if not any(not op["problem"] for op in checked):
            raise ApiError("Nothing to do: " + (checked[0]["problem"] if checked else "no files chosen."))

        def done(result):
            for show_id, mal in new_shows.items():  # the new folder is that entry, whatever its name says
                self.store.set_override(show_id, mal)
            log.info("Added %d files (%s), %d new shows", result.get("moved", 0), mode, len(new_shows))
            self._inbox_count = (0, 0.0)
            folders = self.store.settings().get("folders") or []
            if not folders:
                return
            if not (write_nfo or plex_section):
                self.library.scan_async(folders)
                return
            self.fileops.state["after"] = ["Reading the library folders again …"]
            ok = self.library.scan_and_wait(folders)
            self.fileops.state["after"] = []
            if write_nfo and ok:
                self._after_import_nfo(touched)
            if plex_section:
                self._after_import_plex_scan(plex_section, targets)
        try:
            return {"job": self.fileops.start(checked, mode, "Adding new videos", done), "ops": checked}
        except FileOpError as exc:
            raise ApiError(str(exc))

    def _after_import_nfo(self, show_ids) -> None:
        """Info files for the shows that just got new files (old, locked episodes are left out)."""
        from . import nfo
        shows = [sh for sh in (self.library.show(i) for i in sorted(show_ids)) if sh]
        try:
            plan = self._nfo_plan_for(shows, posters=True)
            result = nfo.write(plan, self.nfo_undo)
            n = result.get("written", 0) if isinstance(result, dict) else 0
            self.fileops.state.setdefault("after", []).append(f"Info files for Plex: {n} written (Settings → Info files → Undo removes them).")
            log.info("Info files after adding videos: %s", {k: v for k, v in result.items() if k != "errors"})
        except Exception as exc:
            log.exception("Writing info files after adding videos failed")
            self.fileops.state.setdefault("after", []).append(f"Info files couldn't be written: {exc}")

    def _after_import_plex_scan(self, section_key: str, folders) -> None:
        """Ask Plex to scan the new folders, in the one (modern) library the user picked."""
        from . import plexhistory, plexscan
        creds = plexhistory.saved_credentials()
        say = self.fileops.state.setdefault("after", [])
        if not creds:
            say.append("Plex wasn't asked to scan: sign in to Plex first (Settings → Your Plex library).")
            return
        try:
            sec = next((s for s in plexscan.sections(creds) if s["key"] == section_key), None)
            if not sec:
                say.append("Plex wasn't asked to scan: that Plex library isn't there anymore.")
                return
            if sec["legacy"]:
                say.append(f"Plex wasn't asked to scan \"{sec['title']}\": it's one of the old libraries, and AniBox never scans those.")
                return
            paths = [plexscan.plex_path(f, sec["locations"]) for f in sorted(folders)]
            if paths and all(paths):
                for p in sorted(set(paths)):
                    plexscan.request_scan(creds, section_key, p)
            else:
                plexscan.request_scan(creds, section_key)
            say.append(f"Plex is scanning \"{sec['title']}\" for the new files.")
            log.info("Asked Plex to scan %s (%s) for %s", sec["title"], section_key, paths)
        except Exception as exc:
            log.warning("Asking Plex to scan failed: %s", exc)
            say.append(f"Plex couldn't be asked to scan ({exc}). Click \"Scan Library Files\" in Plex instead.")

    def _plex_scan_choices(self, query: dict) -> dict:
        """Plex libraries that "Then ask Plex to scan" may use (modern agents only)."""
        from . import plexhistory, plexscan
        creds = plexhistory.saved_credentials()
        if not creds:
            return {"signedIn": False, "sections": []}
        try:
            secs = plexscan.sections(creds)
        except Exception as exc:
            return {"signedIn": True, "sections": [], "error": f"Couldn't reach Plex: {exc}"}
        return {"signedIn": True, "sections": [{"key": s["key"], "title": s["title"]} for s in secs if not s["legacy"]],
                "old": [s["title"] for s in secs if s["legacy"]], "chosen": self.store.settings().get("plex_scan_section", "")}

    def _files_undo(self) -> dict:
        """Undo the last batch, the same way as the History page (watch progress and locks follow back)."""
        last = self.fileops.last_batch()
        if not last:
            raise ApiError("Nothing to undo.")
        return self._history_undo({"id": "files:" + last["batch"]})

    # -- Open folder -------------------------------------------------------------------------------------

    def _reveal(self, body: dict) -> dict:
        show = self.library.show(str(body.get("show") or ""))
        if not show:
            raise ApiError("Show not found", 404)
        key = str(body.get("key") or "")
        try:
            if key:
                ep = next((e for e in show["episodes"] if e["key"] == key), None)
                if not ep:
                    raise ApiError("Episode not found", 404)
                show_file(Path(ep["path"]))
            else:
                open_folder(Path(self.library.show_folder_path(show)))
        except RuntimeError as exc:
            raise ApiError(str(exc))
        return {"ok": True}

    # -- Move or rename a show (new or unlocked only) ------------------------------------------------------

    def _move_plan(self, body: dict) -> Tuple[dict, List[dict], Dict[str, Tuple[str, str]], str]:
        show = self.library.show(str(body.get("show") or ""))
        if not show:
            raise ApiError("Show not found", 404)
        lock = self.library.lock_view(show)
        if lock["keys"]:
            raise ApiError("This show's episodes were already there and are locked. Unlock the show first "
                           "(on its page) if you want AniBox to move or rename it.")
        paths = self._library_paths()
        lib = str(body.get("library") or show["library"])
        if lib not in paths:
            raise ApiError(f"AniBox doesn't know where \"{lib}\" is.")
        protected = [p.casefold() for p in self.store.settings().get("protected") or []]
        if lib.casefold() in protected:
            raise ApiError("That folder is protected.")
        folder = safe_name(str(body.get("folder") or show["folder"]))
        rename = bool(body.get("rename"))
        src_dir = self.library.show_folder_path(show)
        dst_dir = os.path.join(paths[lib], folder)
        new_id = f"{lib}\\{folder}"
        ops: List[dict] = []
        keys: Dict[str, Tuple[str, str]] = {}
        moved = set()
        top = [e["file"] for e in show["episodes"] if "\\" not in e["file"]]
        prefix, sep, digits = name_pattern(top, folder)
        if rename:
            prefix = folder
            digits = max(digits, len(str(max([e.get("number") or 0 for e in show["episodes"]] + [show.get("mal_episodes") or 0]))))
        for e in show["episodes"]:
            parts = e["file"].split("\\")
            name = parts[-1]
            if rename and e.get("number") is not None:
                name = new_name(prefix, sep, digits, int(e["number"]), os.path.splitext(name)[1])
            rel = parts[:-1] + [name]
            dst = os.path.join(dst_dir, *rel)
            for op in with_sidecars(Path(e["path"]), Path(dst)):
                if op["src"] != op["dst"]:
                    ops.append(op)
                moved.add(os.path.normcase(op["src"]))
            keys[e["key"]] = (f"{new_id}\\" + "\\".join(rel), new_id)
        if os.path.normcase(dst_dir) != os.path.normcase(src_dir):  # everything else in the folder comes along
            for dirpath, _, files in os.walk(src_dir):
                for f in files:
                    src = os.path.join(dirpath, f)
                    if os.path.normcase(src) not in moved:
                        ops.append({"src": src, "dst": os.path.join(dst_dir, os.path.relpath(src, src_dir))})
        return show, ops, keys, new_id

    def _move_preview(self, body: dict) -> dict:
        show, ops, _, new_id = self._move_plan(body)
        checked = fileops.FileOps.check(ops, allowed_roots=list(self._library_paths().values()))
        return {"ops": checked, "newId": new_id, "legacy": self._plex_for_show(show).get("legacy", False)}

    def _move_apply(self, body: dict) -> dict:
        show, ops, keys, new_id = self._move_plan(body)
        checked = fileops.FileOps.check(ops, allowed_roots=list(self._library_paths().values()))
        bad = [op for op in checked if op["problem"]]
        if bad:
            raise ApiError("Some files can't be moved: " + bad[0]["problem"])
        if not checked:
            raise ApiError("Nothing changes.")
        src_dir = self.library.show_folder_path(show)

        def done(result):
            moved = {op["src"] for op in result.get("ops") or []}
            ok = {old: new for old, new in keys.items()
                  if next((e["path"] for e in show["episodes"] if e["key"] == old), "") in moved or old == new[0]}
            self.store.move_keys(ok, {show["id"]: new_id} if new_id != show["id"] else {})
            for dirpath, _, _ in sorted(os.walk(src_dir), key=lambda w: len(w[0]), reverse=True):
                try:
                    os.rmdir(dirpath)  # only empty folders go
                except OSError:
                    pass
            log.info("Moved/renamed %s -> %s (%d files)", show["id"], new_id, result.get("moved", 0))
            folders = self.store.settings().get("folders") or []
            if folders:
                self.library.scan_async(folders)
        try:
            return {"job": self.fileops.start(checked, "move", "Moving " + show["title"], done), "newId": new_id}
        except FileOpError as exc:
            raise ApiError(str(exc))

    # -- Tidy up (cleanup.py) ------------------------------------------------------------------------------

    def _tidy_list(self) -> List[dict]:
        running = self.selfupdate.state.get("state") in ("preparing", "restarting")
        return cleanup.find_leftovers(self.selfupdate.program_dir, self.data_dir, update_running=running)

    def _tidy_remove(self, body: dict) -> dict:
        wanted = str(body.get("id") or "")
        entry = next((e for e in self._tidy_list() if e["id"] == wanted), None)
        if not entry:
            raise ApiError("That isn't in the list anymore.")
        try:
            cleanup.remove(entry)
        except OSError as exc:
            raise ApiError(f"Couldn't remove it: {exc}")
        cleanup.log_removal(self.data_dir / cleanup.LOG_FILE, entry)  # shown on the History page
        log.info("Tidy up: removed %s", entry["path"])
        return {"ok": True, "items": self._tidy_list()}
