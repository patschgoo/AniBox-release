"""TV copies: converted copies of videos the TV can't play as they are, 10-bit H.264 ("Hi10P") above all.

Neither the 2019 Shield's hardware nor phones decode Hi10P, which many older anime releases use; Plex
on the Shield converts it slowly and CastApp TV can't play it at all. Plex's answer is "Optimized
versions"; AniBox makes such copies on the PC, with ffmpeg, only when you click.

The rules ("protect the old, allow the new"):

- **Never next to the originals.** A second video in a show folder would be a duplicate episode in
  AniBox and Plex, and it would touch your anime folders. Copies go into their own folder (setting
  ``tv_copy_dir``, default ``<AniBox data folder>\\app\\tv-copies``) as ``<library>\\<show>\\<same name>.mkv``.
  A folder inside a library folder or the "Add new videos" folder is refused.
- **Never overwrite.** ffmpeg writes ``<name>.mkv.part`` (``-n``: never replace), the copy's length is
  checked against the original (±2 s), then it is renamed without replacing anything; a name that is
  taken gets " (2)".
- **Only AniBox's own files are ever deleted:** the ``.part`` of the copy being made (on Cancel or a
  failure) and copies listed in AniBox's index ``tv-copies.json``. Anything else in the folder stays.
- **The index** ``tv-copies.json`` remembers each copy: the original's path, size and modified time,
  the copy's path and size, and how it was made. When the original changes, its copy is "outdated"
  and :func:`copy_for` no longer returns it.
- Every copy made or removed is logged in ``tvcopy-log.jsonl`` (the History page shows it, with Undo).

How a copy is made: the picture becomes 8-bit H.264 High (``yuv420p``), at most 1920×1080 (smaller
videos keep their size), with a hardware encoder when ffmpeg has one that works on this PC
(``h264_nvenc``, ``h264_qsv``, ``h264_amf``; checked once with a 1-second test encode), else
``libx264 -preset veryfast -crf 20``. Sound the TV plays (AAC, AC3, E-AC3, MP3, FLAC, Opus) is copied as
it is; DTS, TrueHD and the rest become AC3 (640k for surround, 256k for stereo) or, as an option, AAC
stereo. All audio tracks keep their languages. Every subtitle track is copied as it is (ASS stays ASS,
PGS stays PGS: MKV holds them), plus subtitle files next to the original; the fonts inside the file,
the chapters and the titles too. One file at a time, at low priority, with a progress line from
ffmpeg (``-progress pipe:1``), Pause, Cancel and a free-space check first.
"""

from __future__ import annotations

import json
import logging
import os
import re
import secrets
import shutil
import signal
import subprocess
import sys
import threading
import time
from collections import deque
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Optional, Sequence, Tuple

from . import languages, media
from .fileops import safe_name

log = logging.getLogger("anibox.tvcopy")

IS_WINDOWS = sys.platform.startswith("win")
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
BELOW_NORMAL = getattr(subprocess, "BELOW_NORMAL_PRIORITY_CLASS", 0)

INDEX_FILE = "tv-copies.json"
LOG_FILE = "tvcopy-log.jsonl"
DEFAULT_DIR_NAME = "tv-copies"
INDEX_VERSION = 1
COPY_EXT = ".mkv"
PART = ".part"
MAX_W, MAX_H = 1920, 1080
DURATION_SLACK = 2.0  # seconds the copy may differ from the original
DISK_RESERVE = 512 * 1024 * 1024  # always left free on the copies' drive
PROBE_TIMEOUT = 90
TEST_TIMEOUT = 30
RECENT = 30  # finished jobs kept for the window

TV_AUDIO = {"aac", "ac3", "eac3", "mp3", "flac", "opus"}  # copied as they are
COPY_SUBS = {"ass", "ssa", "subrip", "srt", "webvtt", "hdmv_pgs_subtitle", "dvd_subtitle", "dvb_subtitle", "text"}
TEXT_TO_SRT = {"mov_text", "tx3g"}  # MP4 text subtitles: MKV can't hold them as they are
EXTERNAL_EXTS = {".ass", ".ssa", ".srt", ".vtt", ".sup"}  # subtitle files next to the original that go in
LANG3 = {"de": "ger", "ja": "jpn", "en": "eng", "fr": "fre", "es": "spa", "it": "ita", "pt": "por", "ru": "rus",
         "zh": "chi", "ko": "kor", "ar": "ara"}

CHOICES = ("auto", "nvidia", "intel", "amd", "cpu")
HARDWARE = ("nvidia", "intel", "amd")
ENCODERS = {"nvidia": "h264_nvenc", "intel": "h264_qsv", "amd": "h264_amf", "cpu": "libx264"}
ENCODER_NAMES = {"nvidia": "NVIDIA graphics (NVENC)", "intel": "Intel graphics (Quick Sync)", "amd": "AMD graphics (AMF)",
                 "cpu": "the processor (x264)"}
DEFAULT_SPEED = {"cpu": 3.0, "nvidia": 8.0, "intel": 7.0, "amd": 7.0, "copy": 40.0}  # × real time, until AniBox has measured
REPACK = "copy"  # the "encoder" of a copy that only repackages: the picture goes over as it is
REPACK_ENCODER = {"kind": REPACK, "encoder": "copy", "name": "Repackaged (picture unchanged)", "choice": "auto", "note": "",
                  "tested": {}}
AUDIO_MODES = ("ac3", "aac")

QUEUED, RUNNING, PAUSED, DONE, FAILED, CANCELLED = "queued", "running", "paused", "done", "failed", "cancelled"


# -- small helpers ---------------------------------------------------------------------------------

def _norm(path: str) -> str:
    return os.path.normcase(os.path.abspath(str(path)))


def inside(path: str, root: str) -> bool:
    """``path`` is ``root`` or somewhere below it (case as Windows sees it)."""
    p, r = _norm(path), _norm(root).rstrip("\\/")
    return bool(r) and (p == r or p.startswith(r + os.sep))


def stamp(path: str) -> Optional[Tuple[int, float]]:
    try:
        st = os.stat(path)
    except OSError:
        return None
    return st.st_size, st.st_mtime


def free_space(path) -> int:
    """Free bytes on the drive of ``path`` (or of its nearest folder that exists)."""
    p = Path(path)
    for cand in [p, *p.parents]:
        try:
            if cand.exists():
                return shutil.disk_usage(str(cand)).free
        except OSError:
            continue
    return 1 << 62


def nice_bytes(n: float) -> str:
    n = float(n or 0)
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.0f} {unit}" if unit in ("B", "KB") else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} GB"


def fit_size(w: int, h: int) -> Tuple[int, int]:
    """At most 1920×1080, the shape kept; smaller videos keep their size (even numbers, as H.264 needs)."""
    if not w or not h:
        return w, h
    if w > MAX_W or h > MAX_H:
        scale = min(MAX_W / w, MAX_H / h)
        w, h = int(w * scale), int(h * scale)
    return max(2, w - w % 2), max(2, h - h % 2)


def needs_copy(info: Optional[dict], caps: Optional[dict] = None, name: str = "") -> str:
    """Why this file needs a TV copy ("" = it plays directly): the picture has to be converted for
    Plex on the Shield or CastApp TV can't play it, also because of its file type (``name``, see
    media.check)."""
    if not info or not info.get("video"):
        return ""
    for target, c in ((media.PLEX, None), (media.CASTAPP, caps or {})):
        res = media.check(info, target, c, name)
        if res["level"] == media.CONVERT:
            return next((r["text"] for r in res["reasons"] if r["level"] == media.CONVERT), "needs converting")
    return ""


def repackage_only(info: Optional[dict], caps: Optional[dict] = None, name: str = "") -> bool:
    """A copy is needed only because of the file's type (e.g. Blu-ray .m2ts on CastApp TV), the picture
    itself plays on both TVs: then the copy only repackages it into MKV (seconds, not minutes, and
    no quality lost). Sound the TV can't play is still converted."""
    if not name or not info or not info.get("video"):
        return False
    for target, c in ((media.PLEX, None), (media.CASTAPP, caps or {})):
        if media.check(info, target, c)["level"] == media.CONVERT:
            return False
    return bool(needs_copy(info, caps, name))


def estimate_bytes(size: int, duration: Optional[float], repack: bool = False) -> int:
    """A rough size of the copy: about 1.25× the original's bit rate (8-bit H.264 needs more bits than
    10-bit for the same picture, and the fast settings are less efficient), within sane limits. A
    repackaged copy is about as big as the original."""
    if repack:
        return int((size or 0) * 1.02)
    if not duration or duration <= 0:
        return int((size or 0) * 1.3)
    bps = (size or 0) * 8 / duration
    bps = min(max(bps * 1.25, 600_000), 20_000_000)
    return int(bps * duration / 8)


# -- encoders --------------------------------------------------------------------------------------

def pixel_format(kind: str) -> str:
    return "nv12" if kind == "intel" else "yuv420p"


def encoder_args(kind: str) -> List[str]:
    if kind == REPACK:
        return ["-c:v", "copy"]
    if kind == "nvidia":
        return ["-c:v", "h264_nvenc", "-preset", "p5", "-rc", "vbr", "-cq", "21", "-b:v", "0", "-profile:v", "high"]
    if kind == "intel":
        return ["-c:v", "h264_qsv", "-preset", "medium", "-global_quality", "21", "-profile:v", "high"]
    if kind == "amd":
        return ["-c:v", "h264_amf", "-quality", "balanced", "-rc", "cqp", "-qp_i", "20", "-qp_p", "22", "-qp_b", "24",
                "-profile:v", "high"]
    return ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-profile:v", "high"]


def _tool_stamp(path: str) -> tuple:
    st = stamp(path)
    return (path,) + (st if st else (0, 0.0))


def list_encoders(ffmpeg: str) -> set:
    try:
        r = subprocess.run([ffmpeg, "-hide_banner", "-encoders"], stdin=subprocess.DEVNULL, capture_output=True,
                           timeout=TEST_TIMEOUT, creationflags=NO_WINDOW)
    except (OSError, subprocess.TimeoutExpired):
        return set()
    names = set()
    for line in r.stdout.decode("utf-8", "replace").splitlines():
        parts = line.split()
        if len(parts) >= 2 and len(parts[0]) == 6 and parts[0][0] in "VAS":
            names.add(parts[1])
    return names


def test_encoder(ffmpeg: str, kind: str) -> Tuple[bool, str]:
    """A 1-second test encode with the same settings a copy uses. (works, what ffmpeg said)."""
    args = [ffmpeg, "-hide_banner", "-nostdin", "-v", "error", "-f", "lavfi", "-i", "color=c=gray:s=320x240:r=25:d=1",
            "-vf", f"format={pixel_format(kind)}"] + encoder_args(kind) + ["-f", "null", "-"]
    try:
        r = subprocess.run(args, stdin=subprocess.DEVNULL, capture_output=True, timeout=TEST_TIMEOUT, creationflags=NO_WINDOW)
    except subprocess.TimeoutExpired:
        return False, "the test took too long"
    except OSError as exc:
        return False, str(exc)
    said = [x.strip() for x in r.stderr.decode("utf-8", "replace").splitlines() if x.strip()]
    if r.returncode == 0:
        return True, ""
    return False, (said[0] if said else f"ffmpeg stopped with code {r.returncode}")[:200]


class EncoderCache:
    """Which encoder to use, found once per ffmpeg (a test encode per graphics maker)."""

    def __init__(self, lister: Callable[[str], set] = list_encoders,
                 tester: Callable[[str, str], Tuple[bool, str]] = test_encoder):
        self.lister = lister
        self.tester = tester
        self._lock = threading.Lock()
        self._names: Dict[tuple, set] = {}
        self._tests: Dict[tuple, Tuple[bool, str]] = {}
        self.last: Optional[dict] = None

    def forget(self) -> None:
        with self._lock:
            self._names.clear()
            self._tests.clear()
            self.last = None

    def works(self, ffmpeg: str, kind: str) -> Tuple[bool, str]:
        key = _tool_stamp(ffmpeg)
        with self._lock:
            if key not in self._names:
                self._names[key] = self.lister(ffmpeg)
            names = self._names[key]
            if ENCODERS[kind] not in names:
                return False, "this ffmpeg doesn't have it"
            if (key, kind) not in self._tests:
                started = time.time()
                self._tests[(key, kind)] = self.tester(ffmpeg, kind)
                ok, said = self._tests[(key, kind)]
                log.info("TV copies: test encode with %s %s (%.1f s)%s", ENCODERS[kind], "works" if ok else "doesn't work",
                         time.time() - started, f": {said}" if said else "")
            return self._tests[(key, kind)]

    def pick(self, ffmpeg: str, choice: str = "auto") -> dict:
        """{"kind", "encoder", "name", "choice", "note", "tested": {kind: {"ok", "said"}}}."""
        choice = choice if choice in CHOICES else "auto"
        tested: Dict[str, dict] = {}
        kind, note = "", ""
        wanted = HARDWARE if choice == "auto" else ((choice,) if choice in HARDWARE else ())
        for k in wanted:
            ok, said = self.works(ffmpeg, k)
            tested[k] = {"ok": ok, "said": said}
            if ok:
                kind = k
                break
        if not kind:
            ok, said = self.works(ffmpeg, "cpu")
            tested["cpu"] = {"ok": ok, "said": said}
            if not ok:
                raise RuntimeError("this ffmpeg can't make H.264 videos (" + (said or "no libx264") + ")")
            kind = "cpu"
            if choice in HARDWARE:
                note = f"{ENCODER_NAMES[choice]} didn't work on this PC ({tested[choice]['said']}), so the processor does it."
        out = {"kind": kind, "encoder": ENCODERS[kind], "name": ENCODER_NAMES[kind], "choice": choice, "note": note,
               "tested": tested, "at": time.time()}
        self.last = out
        return out


# -- reading the original ----------------------------------------------------------------------------

def probe_streams(path: str, ffprobe: str) -> Optional[dict]:
    """What a copy needs to know about a file (ffprobe): ``{"info": media's info dict, "duration",
    "bitrate", "size", "video": {..., "index"}, "audio": [{index, codec, channels, lang, title}],
    "subs": [{index, codec, lang, forced}], "external": [subtitle files next to it]}`` or None."""
    try:
        r = subprocess.run([ffprobe, "-v", "error", "-print_format", "json", "-show_streams", "-show_format", "-i", path],
                           stdin=subprocess.DEVNULL, capture_output=True, timeout=PROBE_TIMEOUT, creationflags=NO_WINDOW)
    except (OSError, subprocess.TimeoutExpired) as exc:
        log.info("TV copies: ffprobe couldn't read %s: %s", path, exc)
        return None
    if r.returncode != 0:
        log.info("TV copies: ffprobe couldn't read %s: %s", path, r.stderr.decode("utf-8", "replace").strip()[:200])
        return None
    try:
        obj = json.loads(r.stdout.decode("utf-8", "replace") or "{}")
    except ValueError:
        return None
    info = media.parse_ffprobe(obj)
    info["external"] = media.external_subs(path)
    fmt = obj.get("format") or {}
    video, audio, subs = None, [], []
    durations = []
    for s in obj.get("streams") or []:
        kind = s.get("codec_type")
        tags = {str(k).lower(): v for k, v in (s.get("tags") or {}).items()}
        disp = s.get("disposition") or {}
        codec = str(s.get("codec_name") or "").lower()
        try:
            durations.append(float(s.get("duration")))
        except (TypeError, ValueError):
            pass
        if kind == "video" and video is None and not disp.get("attached_pic"):
            video = dict(info.get("video") or {}, index=int(s.get("index") or 0))
        elif kind == "audio":
            audio.append({"index": int(s.get("index") or 0), "codec": codec, "channels": int(s.get("channels") or 0),
                          "lang": languages.lang(str(tags.get("language") or "")), "title": str(tags.get("title") or "")})
        elif kind == "subtitle":
            subs.append({"index": int(s.get("index") or 0), "codec": codec, "lang": languages.lang(str(tags.get("language") or "")),
                         "forced": bool(disp.get("forced"))})
    duration = None
    try:
        duration = float(fmt.get("duration"))
    except (TypeError, ValueError):
        duration = max(durations) if durations else None
    try:
        bitrate = int(fmt.get("bit_rate"))
    except (TypeError, ValueError):
        bitrate = 0
    st = stamp(path)
    return {"info": info, "duration": duration, "bitrate": bitrate, "size": st[0] if st else 0, "video": video,
            "audio": audio, "subs": subs, "external": info["external"]}


def probe_duration(path: str, ffprobe: str) -> Optional[float]:
    try:
        r = subprocess.run([ffprobe, "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", "-i", path],
                           stdin=subprocess.DEVNULL, capture_output=True, timeout=PROBE_TIMEOUT, creationflags=NO_WINDOW)
        return float(r.stdout.decode("ascii", "replace").strip().splitlines()[0])
    except (OSError, subprocess.TimeoutExpired, ValueError, IndexError):
        return None


def external_inputs(probe: dict) -> List[dict]:
    """Subtitle files next to the original that go into the copy."""
    out = []
    for s in probe.get("external") or []:
        path = s.get("path") or ""
        if os.path.splitext(path)[1].lower() in EXTERNAL_EXTS and os.path.isfile(path):
            out.append(s)
    return out


def build_command(ffmpeg: str, src: str, out: str, probe: dict, kind: str, audio_mode: str = "ac3",
                  externals: Sequence[dict] = ()) -> List[str]:
    """The ffmpeg call that makes one copy (written to ``out``, never replacing a file)."""
    v = probe.get("video") or {}
    w, h = int(v.get("width") or 0), int(v.get("height") or 0)
    tw, th = fit_size(w, h)
    pix = pixel_format(kind)
    vf = (f"scale={tw}:{th}," if (tw, th) != (w, h) and tw and th else "") + f"format={pix}"
    args = [ffmpeg, "-hide_banner", "-nostdin", "-v", "error", "-nostats", "-progress", "pipe:1", "-n", "-i", src]
    for e in externals:
        args += ["-i", e["path"]]
    args += ["-map", f"0:{int(v.get('index') or 0)}"]
    for a in probe.get("audio") or []:
        args += ["-map", f"0:{a['index']}"]
    kept = [s for s in probe.get("subs") or [] if s["codec"] in COPY_SUBS or s["codec"] in TEXT_TO_SRT]
    for s in kept:
        args += ["-map", f"0:{s['index']}"]
    for i in range(len(externals)):
        args += ["-map", f"{i + 1}:s?"]
    args += ["-map", "0:t?", "-map_metadata", "0", "-map_chapters", "0"]
    if kind == REPACK:  # the picture as it is, at its own size
        args += encoder_args(kind)
    else:
        args += ["-vf", vf] + encoder_args(kind) + ["-pix_fmt", pix]
    args += ["-c:a", "copy"]
    for n, a in enumerate(probe.get("audio") or []):
        if a["codec"] in TV_AUDIO:
            continue
        if audio_mode == "aac":
            args += [f"-c:a:{n}", "aac", f"-b:a:{n}", "192k", f"-ac:a:{n}", "2"]
        else:
            ch = int(a.get("channels") or 0)
            args += [f"-c:a:{n}", "ac3", f"-b:a:{n}", "256k" if 0 < ch <= 2 else "640k"]
            if ch > 6:
                args += [f"-ac:a:{n}", "6"]
    args += ["-c:s", "copy"]
    for n, s in enumerate(kept):
        if s["codec"] in TEXT_TO_SRT:
            args += [f"-c:s:{n}", "srt"]
    for i, e in enumerate(externals):
        k = len(kept) + i
        code = languages.lang(e.get("lang") or "")
        code3 = LANG3.get(code) or (code if re.fullmatch(r"[a-z]{3}", code or "") else "")
        if code3:
            args += [f"-metadata:s:s:{k}", f"language={code3}"]
        args += [f"-disposition:s:{k}", "forced" if e.get("forced") else "0"]
        if os.path.splitext(e["path"])[1].lower() == ".srt":
            args += [f"-c:s:{k}", "srt"]
    args += ["-c:t", "copy", "-max_muxing_queue_size", "4096", "-f", "matroska", out]
    return args


# -- where copies go ---------------------------------------------------------------------------------

def mirror_path(root: str, library: str, folder: str, file: str) -> Path:
    """``<root>\\<library>\\<show>\\<same file name>.mkv`` (season folders kept)."""
    parts = [p for p in re.split(r"[\\/]+", file or "") if p]
    if not parts:
        parts = ["video"]
    stem = os.path.splitext(parts[-1])[0]
    path = Path(root) / safe_name(library) / safe_name(folder)
    for p in parts[:-1]:
        path = path / safe_name(p)
    return path / (safe_name(stem, "video") + COPY_EXT)


def free_name(path: Path) -> Path:
    """``path``, or "<name> (2).mkv" … when the name (or its .part) is taken."""
    def taken(p: Path) -> bool:
        return os.path.lexists(str(p)) or os.path.lexists(str(p) + PART)
    if not taken(path):
        return path
    for n in range(2, 1000):
        cand = path.with_name(f"{path.stem} ({n}){path.suffix}")
        if not taken(cand):
            return cand
    raise OSError("no free file name for the copy")


def rename_new(src: str, dst: str) -> None:
    """Rename without ever replacing a file (FileExistsError if ``dst`` is there)."""
    if IS_WINDOWS:
        os.rename(src, dst)  # Windows refuses when dst exists
        return
    try:
        os.link(src, dst)  # fails if dst exists; atomic
    except FileExistsError:
        raise
    except OSError:  # file systems without hard links (exFAT, some network drives)
        if os.path.lexists(dst):
            raise FileExistsError(dst)
        os.rename(src, dst)
        return
    os.unlink(src)


def folder_problem(folder: str, forbidden: Iterable[Tuple[str, str]]) -> str:
    """Why ``folder`` can't hold TV copies ("" = fine). ``forbidden`` = [(path, what it is)]: the
    library folders and the "Add new videos" folders."""
    folder = (folder or "").strip()
    if not folder:
        return "Choose a folder for the TV copies."
    if not os.path.isabs(folder):
        return "Type the whole path of the folder (for example D:\\TV copies)."
    for path, what in forbidden:
        if not path:
            continue
        if inside(folder, path):
            return (f"That folder is inside {what} {path}. TV copies there would show up as extra episodes "
                    "(in AniBox and in Plex), so pick a folder outside it.")
        if inside(path, folder):
            return f"{what[0].upper() + what[1:]} {path} is inside that folder. Pick a folder of its own for the TV copies."
    return ""


# -- the index and the log ----------------------------------------------------------------------------

class CopyIndex:
    """``tv-copies.json``: every copy AniBox made (and only those may ever be deleted)."""

    def __init__(self, path: Path):
        self.path = Path(path)
        self.lock = threading.RLock()
        self.copies: Dict[str, dict] = {}  # normcase(original) -> record
        self.parts: List[str] = []  # .part files being written (removed if AniBox stops in between)
        self.queue: List[dict] = []  # jobs waiting when AniBox closed
        self.speeds: Dict[str, float] = {}  # encoder kind -> × real time, measured
        self._load()

    def _load(self) -> None:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return
        except (OSError, ValueError):
            data = None
        if not isinstance(data, dict) or not isinstance(data.get("copies"), dict):
            try:  # kept for a look; AniBox starts a new list (and so never deletes anything it can't vouch for)
                shutil.copyfile(self.path, self.path.with_name("tv-copies.damaged.json"))
            except OSError:
                pass
            log.warning("TV copies: the list of copies was damaged; it was set aside as tv-copies.damaged.json")
            return
        self.copies = {k: v for k, v in data["copies"].items() if isinstance(v, dict) and v.get("copy") and v.get("original")}
        self.parts = [p for p in data.get("parts") or [] if isinstance(p, str) and p.endswith(PART)]
        self.queue = [j for j in data.get("queue") or [] if isinstance(j, dict) and j.get("original")]
        self.speeds = {k: float(v) for k, v in (data.get("speeds") or {}).items() if k in ENCODERS and isinstance(v, (int, float))}

    def save(self) -> None:
        with self.lock:
            data = json.dumps({"version": INDEX_VERSION, "copies": self.copies, "parts": self.parts,
                               "queue": self.queue, "speeds": self.speeds}, ensure_ascii=False, indent=1)
            try:
                self.path.parent.mkdir(parents=True, exist_ok=True)
                tmp = self.path.with_name(self.path.name + ".tmp")
                tmp.write_text(data, encoding="utf-8")
                os.replace(tmp, self.path)
            except OSError as exc:
                log.warning("TV copies: couldn't save %s: %s", self.path, exc)

    def get(self, original: str) -> Optional[dict]:
        with self.lock:
            return self.copies.get(_norm(original))

    def put(self, rec: dict) -> None:
        with self.lock:
            self.copies[_norm(rec["original"])] = rec
            self.save()

    def drop(self, original: str) -> Optional[dict]:
        with self.lock:
            rec = self.copies.pop(_norm(original), None)
            self.save()
            return rec

    def all(self) -> List[dict]:
        with self.lock:
            return list(self.copies.values())


class CopyLog:
    """``tvcopy-log.jsonl``: one line per copy made or removed (the History page reads it)."""

    def __init__(self, path: Path):
        self.path = Path(path)
        self._lock = threading.Lock()

    def add(self, rec: dict) -> None:
        rec = dict(rec, time=rec.get("time") or time.time())
        with self._lock:
            try:
                self.path.parent.mkdir(parents=True, exist_ok=True)
                with open(self.path, "a", encoding="utf-8", newline="\n") as fh:
                    fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
            except OSError as exc:
                log.warning("TV copies: couldn't write the log: %s", exc)


def _log_lines(path: Path) -> List[dict]:
    try:
        text = Path(path).read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return []
    out = []
    for line in text.splitlines():
        try:
            rec = json.loads(line)
        except ValueError:
            continue
        if isinstance(rec, dict):
            out.append(rec)
    return out


def history_entries(data_dir: Path) -> List[dict]:
    """For the History page: one entry per "Make TV copies" (Undo removes those copies) and one per
    "Remove all TV copies"."""
    recs = _log_lines(Path(data_dir) / LOG_FILE)
    removed: Dict[str, float] = {}
    for r in recs:
        if r.get("action") == "removed":
            for c in r.get("copies") or []:
                removed[_norm(c)] = float(r.get("time") or 0)
    batches: Dict[str, dict] = {}
    out = []
    for r in recs:
        if r.get("action") == "made" and r.get("batch") and r.get("copy"):
            b = batches.setdefault(r["batch"], {"time": float(r.get("time") or 0), "files": [], "titles": [], "encoders": []})
            b["files"].append(r)
            if r.get("title") and r["title"] not in b["titles"]:
                b["titles"].append(r["title"])
            if r.get("encoder") and r["encoder"] not in b["encoders"]:
                b["encoders"].append(r["encoder"])
        elif r.get("action") == "removed" and r.get("why") == "all" and r.get("copies"):
            n = len(r["copies"])
            out.append({"id": f"tvcopy-all:{r.get('time')}", "kind": "tvcopy", "time": float(r.get("time") or 0),
                        "title": "Removed all TV copies", "detail": f"{n} TV cop{'y' if n == 1 else 'ies'} removed.",
                        "count": n, "undone": None, "undo": {"can": False, "why": "Make them again from the show's page."},
                        "examples": [{"to": c} for c in r["copies"][:30]]})
    for batch, b in batches.items():
        files = b["files"]
        left = [f for f in files if _norm(f["copy"]) not in removed]
        size = sum(int(f.get("size") or 0) for f in files)
        gone = [removed[_norm(f["copy"])] for f in files if _norm(f["copy"]) in removed]
        title = "Made TV copies" + (f" of {b['titles'][0]}" if len(b["titles"]) == 1 else "")
        detail = (f"{len(files)} cop{'y' if len(files) == 1 else 'ies'}, {nice_bytes(size)}"
                  + (f", with {', '.join(b['encoders'])}" if b["encoders"] else "") + ". The originals weren't touched.")
        if gone and left:
            detail += f" {len(files) - len(left)} removed since."
        out.append({"id": f"tvcopy:{batch}", "kind": "tvcopy", "time": b["time"], "title": title, "detail": detail,
                    "count": len(files), "undone": (max(gone) if gone and not left else None),
                    "undo": {"can": bool(left), "why": "" if left else "Removed already."},
                    "examples": [{"from": f.get("original"), "to": f.get("copy")} for f in files[:30]]})
    return out


# -- suspending ffmpeg (Pause) ------------------------------------------------------------------------

def _suspend(proc: subprocess.Popen, on: bool) -> bool:
    try:
        if IS_WINDOWS:
            import ctypes
            from ctypes import wintypes
            k32 = ctypes.WinDLL("kernel32", use_last_error=True)
            ntdll = ctypes.WinDLL("ntdll")
            k32.OpenProcess.restype = wintypes.HANDLE
            k32.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
            k32.CloseHandle.argtypes = (wintypes.HANDLE,)
            fn = ntdll.NtSuspendProcess if on else ntdll.NtResumeProcess
            fn.argtypes = (wintypes.HANDLE,)
            handle = k32.OpenProcess(0x0800, False, proc.pid)  # PROCESS_SUSPEND_RESUME
            if not handle:
                return False
            try:
                return fn(handle) == 0
            finally:
                k32.CloseHandle(handle)
        os.kill(proc.pid, signal.SIGSTOP if on else signal.SIGCONT)
        return True
    except Exception:
        log.info("TV copies: couldn't %s ffmpeg", "pause" if on else "resume", exc_info=True)
        return False


# -- the copies and the queue -------------------------------------------------------------------------

def _public(job: dict) -> dict:
    keys = ("id", "batch", "show", "title", "label", "file", "state", "progress", "speed", "eta", "elapsed", "error",
            "est", "written", "target", "encoder", "duration", "finished")
    return {k: job.get(k) for k in keys}


class TvCopies:
    """The copies AniBox made (index), and the queue that makes new ones, one file at a time."""

    def __init__(self, data_dir: Path, settings: Callable[[], dict], tools: Callable[[], Dict[str, Optional[str]]],
                 forbidden: Callable[[], List[Tuple[str, str]]] = lambda: [],
                 on_done: Optional[Callable[[dict], None]] = None):
        self.data_dir = Path(data_dir)
        self.settings = settings
        self.tools = tools
        self.forbidden = forbidden
        self.on_done = on_done
        self.index = CopyIndex(self.data_dir / INDEX_FILE)
        self.log = CopyLog(self.data_dir / LOG_FILE)
        self.encoders = EncoderCache()
        self.free_space: Callable[[str], int] = free_space
        self._lock = threading.RLock()
        self._wake = threading.Event()
        self._closing = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._proc: Optional[subprocess.Popen] = None
        self.queue: List[dict] = []
        self.current: Optional[dict] = None
        self.recent: List[dict] = []
        self.paused = False
        self.message = ""
        self._remove_leftovers()
        self._restore_queue()

    # -- settings and the folder

    def default_dir(self) -> Path:
        return self.data_dir / DEFAULT_DIR_NAME

    def folder(self) -> str:
        return str(self.settings().get("tv_copy_dir") or "") or str(self.default_dir())

    def folder_problem(self, folder: Optional[str] = None) -> str:
        return folder_problem(folder or self.folder(), self.forbidden())

    def audio_mode(self) -> str:
        m = str(self.settings().get("tv_copy_audio") or "ac3")
        return m if m in AUDIO_MODES else "ac3"

    def choice(self) -> str:
        c = str(self.settings().get("tv_copy_encoder") or "auto")
        return c if c in CHOICES else "auto"

    def speed(self, kind: str) -> float:
        return self.index.speeds.get(kind) or DEFAULT_SPEED.get(kind, 2.0)

    # -- what's there

    def state_of(self, original: str) -> Tuple[str, Optional[dict]]:
        """("ready" | "outdated" | "missing" | "", the index record)."""
        rec = self.index.get(original)
        if not rec:
            return "", None
        cst = stamp(rec["copy"])
        if not cst or cst[0] != rec.get("copy_size"):
            return "missing", rec
        ost = stamp(original)
        if not ost or ost[0] != rec.get("size") or abs(ost[1] - float(rec.get("mtime") or 0)) > 1.0:
            return "outdated", rec
        return "ready", rec

    def copy_for(self, original: str) -> Optional[str]:
        """The up-to-date copy of ``original`` (None: no copy, or the original changed since)."""
        try:
            state, rec = self.state_of(original)
        except Exception:
            log.exception("TV copies: checking the copy of %s failed", original)
            return None
        return rec["copy"] if state == "ready" and rec else None

    def summary(self) -> dict:
        recs = self.index.all()
        return {"copies": len(recs), "bytes": sum(int(r.get("copy_size") or 0) for r in recs)}

    # -- the queue

    def busy(self) -> bool:
        """A copy is being made or waits (keeps AniBox open). A paused queue doesn't."""
        with self._lock:
            if self.paused:
                return False
            return bool(self.current) or bool(self.queue)

    def status(self) -> dict:
        with self._lock:
            out = {"paused": self.paused, "message": self.message,
                   "current": _public(self.current) if self.current else None,
                   "queue": [_public(j) for j in self.queue], "recent": [_public(j) for j in self.recent[:10]]}
        folder = self.folder()
        out.update(self.summary(), folder=folder, folderSetting=str(self.settings().get("tv_copy_dir") or ""),
                   defaultFolder=str(self.default_dir()), problem=self.folder_problem(folder),
                   free=self.free_space(folder), choice=self.choice(), audio=self.audio_mode(),
                   encoder=self.encoders.last, busy=self.busy())
        return out

    def enqueue(self, items: List[dict], batch: Optional[str] = None) -> List[dict]:
        """Queue copies. Each item: {original, show, key, title, label, file, library, folder, duration, est,
        repack (only repackaged, see repackage_only)}."""
        batch = batch or secrets.token_hex(6)
        jobs = []
        with self._lock:
            waiting = {_norm(j["original"]) for j in self.queue}
            if self.current:
                waiting.add(_norm(self.current["original"]))
            for it in items:
                if _norm(it["original"]) in waiting:
                    continue
                job = {k: it.get(k) for k in ("original", "show", "key", "title", "label", "file", "library", "folder",
                                               "duration", "est", "repack")}
                job.update(id=secrets.token_hex(6), batch=batch, state=QUEUED, progress=0.0, speed=None, eta=None,
                           elapsed=0.0, error="", written=0, target="", encoder="")
                self.queue.append(job)
                jobs.append(job)
            if jobs and self.message and not self.current:
                self.message = ""
            self._save_queue()
            self._kick()
        if jobs:
            log.info("TV copies: %d queued (%s)", len(jobs), ", ".join(j["file"] or "" for j in jobs[:3]) + (" …" if len(jobs) > 3 else ""))
        return jobs

    def _kick(self) -> None:
        with self._lock:
            if self._closing.is_set():
                return
            self._wake.set()
            if self._thread is None and self.queue and not self.paused:
                self._thread = threading.Thread(target=self._run, daemon=True, name="anibox-tvcopy")
                self._thread.start()

    def pause(self) -> None:
        with self._lock:
            self.paused = True
            job, proc = self.current, self._proc
            if job and proc and job["state"] == RUNNING:
                if _suspend(proc, True):
                    job["state"] = PAUSED
                    job["paused_at"] = time.time()
        log.info("TV copies: paused")

    def resume(self) -> None:
        with self._lock:
            self.paused = False
            self.message = ""
            job, proc = self.current, self._proc
            if job and proc and job["state"] == PAUSED:
                _suspend(proc, False)
                job["paused_total"] = job.get("paused_total", 0.0) + time.time() - job.pop("paused_at", time.time())
                job["state"] = RUNNING
            self._kick()
        log.info("TV copies: going on")

    def cancel(self, job_id: str = "") -> int:
        """Cancel one job (its id) or, with "" / "all", the whole queue. Only the .part of the copy
        being made is deleted."""
        n = 0
        with self._lock:
            everything = job_id in ("", "all")
            keep = []
            for j in self.queue:
                if everything or j["id"] == job_id:
                    j.update(state=CANCELLED, finished=time.time())
                    self.recent.insert(0, j)
                    n += 1
                else:
                    keep.append(j)
            self.queue = keep
            job, proc = self.current, self._proc
            if job and (everything or job["id"] == job_id):
                job["cancel"] = True
                n += 1
                if proc and proc.poll() is None:
                    try:
                        proc.kill()
                    except OSError:
                        pass
            if not self.queue and not self.current:
                self.message = ""
            del self.recent[RECENT:]
            self._save_queue()
        if n:
            log.info("TV copies: %d cancelled", n)
        return n

    def shutdown(self, timeout: float = 10) -> None:
        """AniBox closes: the copy being made stops (its .part is deleted) and waits in the queue for next time."""
        self._closing.set()
        with self._lock:
            proc = self._proc
            if self.current and not self.current.get("cancel"):
                self.current["closing"] = True
            if proc and proc.poll() is None:
                try:
                    proc.kill()
                except OSError:
                    pass
        self._wake.set()
        t = self._thread
        if t and t is not threading.current_thread():
            t.join(timeout)
        with self._lock:
            self._save_queue()

    def _save_queue(self) -> None:
        with self._lock:
            waiting = ([self.current] if self.current and not self.current.get("cancel") else []) + self.queue
            self.index.queue = [{k: j.get(k) for k in ("original", "show", "key", "title", "label", "file", "library",
                                                        "folder", "duration", "est", "batch")} for j in waiting]
        self.index.save()

    def _restore_queue(self) -> None:
        waiting = list(self.index.queue)
        if not waiting:
            return
        for it in waiting:
            job = dict(it, id=secrets.token_hex(6), state=QUEUED, progress=0.0, speed=None, eta=None, elapsed=0.0,
                       error="", written=0, target="", encoder="")
            job["batch"] = it.get("batch") or secrets.token_hex(6)
            self.queue.append(job)
        self.paused = True
        n = len(self.queue)
        self.message = (f"{n} TV cop{'y was' if n == 1 else 'ies were'} still waiting when AniBox closed. "
                        "Click Resume to go on.")
        log.info("TV copies: %d still waiting from last time (paused)", n)

    def _remove_leftovers(self) -> None:
        """.part files AniBox was writing when it stopped (only those listed in its index)."""
        with self.index.lock:
            parts, self.index.parts = list(self.index.parts), []
        for p in parts:
            try:
                if os.path.isfile(p):
                    os.remove(p)
                    log.info("TV copies: removed an unfinished copy from last time: %s", p)
            except OSError as exc:
                log.warning("TV copies: couldn't remove %s: %s", p, exc)
        if parts:
            self.index.save()

    # -- the worker

    def _run(self) -> None:
        while True:
            with self._lock:
                job = None
                if self._closing.is_set() or (not self.queue and not self.current):
                    self._thread = None
                    return
                if not self.paused and self.queue:
                    job = self.queue.pop(0)
                    job["state"] = RUNNING
                    self.current = job
            if job is None:
                self._wake.wait(1)
                self._wake.clear()
                with self._lock:
                    if self.paused and not self.current:
                        self._thread = None  # resume() starts a new one
                        return
                continue
            try:
                self._make(job)
            except Exception as exc:
                log.exception("TV copies: making a copy of %s failed", job.get("original"))
                job.update(state=FAILED, error=str(exc))
            with self._lock:
                self.current = None
                self._proc = None
                if job["state"] == QUEUED:  # put back (no room on the drive, or AniBox is closing)
                    self.queue.insert(0, job)
                else:
                    job["finished"] = time.time()
                    self.recent.insert(0, job)
                    del self.recent[RECENT:]
                self._save_queue()
            if job["state"] in (DONE, FAILED) and self.on_done:
                try:
                    self.on_done(job)
                except Exception:
                    log.exception("TV copies: after-copy step failed")

    def _fail(self, job: dict, error: str) -> None:
        job.update(state=FAILED, error=error)
        log.warning("TV copies: %s: %s", job.get("original"), error)
        self.log.add({"action": "failed", "batch": job.get("batch"), "original": job.get("original"), "error": error,
                      "show": job.get("show"), "key": job.get("key")})

    def _hold(self, job: dict, message: str) -> None:
        """Stop the queue with a message; the job waits at the front."""
        job.update(state=QUEUED, progress=0.0)
        with self._lock:
            self.paused = True
            self.message = message
        log.warning("TV copies paused: %s", message)

    def _make(self, job: dict) -> None:
        tools = self.tools()
        ffmpeg, ffprobe = tools.get("ffmpeg"), tools.get("ffprobe")
        if not ffmpeg or not ffprobe:
            self._hold(job, "TV copies need ffmpeg (Settings → Player → Download ffmpeg).")
            return
        folder = self.folder()
        problem = self.folder_problem(folder)
        if problem:
            self._hold(job, problem)
            return
        original = job["original"]
        before = stamp(original)
        if not before:
            self._fail(job, "the original isn't there anymore")
            return
        probe = probe_streams(original, ffprobe)
        if not probe or not probe.get("video"):
            self._fail(job, "AniBox couldn't read the video")
            return
        duration = probe.get("duration") or job.get("duration")
        if not duration:
            self._fail(job, "AniBox couldn't read how long the video is, so it couldn't check the copy")
            return
        job["duration"] = duration
        repack = bool(job.get("repack"))
        est = estimate_bytes(probe.get("size") or before[0], duration, repack)
        job["est"] = est
        free = self.free_space(folder)
        if free < est * 1.2 + DISK_RESERVE:
            self._hold(job, f"Not enough room for the next TV copy in {folder}: it needs about {nice_bytes(est)} "
                            f"(and {nice_bytes(DISK_RESERVE)} stay free), {nice_bytes(free)} are free. "
                            "Make room or choose another folder, then click Resume.")
            return
        try:
            enc = dict(REPACK_ENCODER) if repack else self.encoders.pick(ffmpeg, self.choice())
        except RuntimeError as exc:
            self._fail(job, str(exc))
            return
        kind = enc["kind"]
        job["encoder"] = enc["name"]
        created: List[str] = []
        try:
            target = free_name(mirror_path(folder, job.get("library") or "", job.get("folder") or "", job.get("file") or ""))
            for parent in reversed(target.parents):
                if not parent.exists():
                    parent.mkdir()
                    created.append(str(parent))
        except OSError as exc:
            self._fail(job, f"couldn't make the folder for the copy ({exc.strerror or exc})")
            return
        part = str(target) + PART
        job["target"], job["root"] = str(target), folder
        with self.index.lock:
            self.index.parts.append(part)
            self.index.save()
        externals = external_inputs(probe)
        try:
            ok = self._encode_checked(job, ffmpeg, ffprobe, original, part, probe, kind, externals, duration, before)
            if not ok:
                return
            final = Path(target)
            for _ in range(20):
                try:
                    rename_new(part, str(final))
                    break
                except FileExistsError:
                    final = free_name(final)
            else:
                raise OSError("no free name for the copy")
            job["target"] = str(final)
            self._record(job, original, before, str(final), kind, enc, duration)
        finally:
            if os.path.lexists(part):
                try:
                    os.remove(part)  # only the file this job was writing
                except OSError:
                    log.warning("TV copies: couldn't remove %s", part)
            with self.index.lock:
                if part in self.index.parts:
                    self.index.parts.remove(part)
                self.index.save()
            if job["state"] != DONE:
                for d in reversed(created):  # folders this job made, if still empty
                    try:
                        os.rmdir(d)
                    except OSError:
                        break

    def _encode_checked(self, job, ffmpeg, ffprobe, original, part, probe, kind, externals, duration, before) -> bool:
        audio = self.audio_mode()
        rc, said = self._encode(job, build_command(ffmpeg, original, part, probe, kind, audio, externals), duration)
        if rc != 0 and externals and not job.get("cancel") and not job.get("closing") and not self._closing.is_set():
            log.info("TV copies: ffmpeg failed with the subtitle files next to %s (%s); trying without them", original, said)
            if os.path.lexists(part):
                os.remove(part)
            rc, said = self._encode(job, build_command(ffmpeg, original, part, probe, kind, audio, ()), duration)
        if job.get("closing") or self._closing.is_set():
            job.update(state=QUEUED, progress=0.0)  # goes on next time
            return False
        if job.get("cancel"):
            job.update(state=CANCELLED)
            self.log.add({"action": "cancelled", "batch": job.get("batch"), "original": original})
            return False
        if rc != 0:
            self._fail(job, "ffmpeg couldn't convert it: " + (said or f"code {rc}"))
            return False
        if not os.path.isfile(part):
            self._fail(job, "ffmpeg wrote no file")
            return False
        got = probe_duration(part, ffprobe)
        if got is None or abs(got - duration) > DURATION_SLACK:
            self._fail(job, "the copy isn't as long as the original "
                            f"({'unreadable' if got is None else f'{got:.1f} s'} instead of {duration:.1f} s); it was deleted")
            return False
        if stamp(original) != before:
            self._fail(job, "the original changed while the copy was made; the copy was deleted")
            return False
        return True

    def _encode(self, job: dict, cmd: List[str], duration: float) -> Tuple[int, str]:
        flags = NO_WINDOW | BELOW_NORMAL if IS_WINDOWS else 0
        log.info("TV copies: %s %s", "repackaging" if job.get("repack") else "converting", job.get("original"))
        with self._lock:
            if job.get("cancel") or self._closing.is_set():
                return -1, "cancelled"
            proc = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                    creationflags=flags)
            self._proc = proc
            if not IS_WINDOWS:
                try:
                    os.setpriority(os.PRIO_PROCESS, proc.pid, 10)  # like "nice": the PC stays responsive
                except (OSError, AttributeError):
                    pass
            if self.paused and _suspend(proc, True):
                job["state"] = PAUSED
                job["paused_at"] = time.time()
        err: deque = deque(maxlen=40)

        def drain():
            for raw in proc.stderr:
                line = raw.decode("utf-8", "replace").strip()
                if line:
                    err.append(line)

        reader = threading.Thread(target=drain, daemon=True, name="anibox-tvcopy-err")
        reader.start()
        started = time.time()
        job.update(started=started, paused_total=0.0, progress=0.0)
        try:
            for raw in proc.stdout:
                line = raw.decode("utf-8", "replace").strip()
                key, _, value = line.partition("=")
                if key in ("out_time_us", "out_time_ms"):
                    try:
                        pos = int(value) / 1e6
                    except ValueError:
                        continue
                    self._progress(job, pos, duration)
                elif key == "total_size":
                    try:
                        job["written"] = int(value)
                    except ValueError:
                        pass
            rc = proc.wait()
            reader.join(5)
        finally:
            for pipe in (proc.stdout, proc.stderr):
                try:
                    pipe.close()
                except OSError:
                    pass
        said = next((x for x in reversed(err) if not x.startswith("frame=")), "")
        return rc, said[:300]

    @staticmethod
    def _progress(job: dict, pos: float, duration: float) -> None:
        now = time.time()
        paused = job.get("paused_total", 0.0) + (now - job["paused_at"] if job.get("paused_at") else 0.0)
        active = max(0.001, now - job["started"] - paused)
        pos = max(0.0, min(pos, duration))
        job["progress"] = round(pos / duration, 4) if duration else 0.0
        job["elapsed"] = round(active, 1)
        if pos > 1 and active > 1:
            rate = pos / active
            job["speed"] = round(rate, 2)
            job["eta"] = round((duration - pos) / rate)

    def _record(self, job: dict, original: str, before: Tuple[int, float], copy: str, kind: str, enc: dict,
                duration: float) -> None:
        size = os.path.getsize(copy)
        old = self.index.get(original)
        rec = {"original": original, "size": before[0], "mtime": before[1], "copy": copy, "copy_size": size,
               "root": job.get("root") or self.folder(), "made": time.time(), "show": job.get("show"), "key": job.get("key"),
               "title": job.get("title"), "batch": job.get("batch"), "duration": duration,
               "settings": {"encoder": enc["encoder"], "audio": self.audio_mode(), "max": f"{MAX_W}x{MAX_H}"}}
        self.index.put(rec)
        active = max(1.0, float(job.get("elapsed") or (time.time() - job.get("started", time.time()))))
        measured = duration / active
        old_speed = self.index.speeds.get(kind)
        with self.index.lock:
            self.index.speeds[kind] = round(measured if not old_speed else (old_speed + measured) / 2, 2)
            self.index.save()
        job.update(state=DONE, progress=1.0, eta=0, written=size)
        self.log.add({"action": "made", "batch": job.get("batch"), "original": original, "copy": copy, "size": size,
                      "show": job.get("show"), "key": job.get("key"), "title": job.get("title"),
                      "encoder": enc["name"], "seconds": round(active, 1)})
        log.info("TV copies: made %s (%s, %.0f s, %.1f× real time, %s)", copy, nice_bytes(size), active, measured, enc["encoder"])
        if old and _norm(old["copy"]) != _norm(copy):  # the outdated copy of the same original
            self._delete_copy(old, why="replaced")

    # -- removing copies (only files listed in the index)

    def _delete_copy(self, rec: dict, why: str) -> str:
        """"removed" | "kept" (changed since AniBox made it) | "missing" | "failed"."""
        copy = rec["copy"]
        result = "missing"
        try:
            if os.path.isfile(copy) and not os.path.islink(copy):
                if os.path.getsize(copy) != rec.get("copy_size"):
                    result = "kept"
                else:
                    os.remove(copy)
                    result = "removed"
        except OSError as exc:
            log.warning("TV copies: couldn't remove %s: %s", copy, exc)
            return "failed"
        if result == "removed":
            self._remove_empty_dirs(Path(copy).parent, rec.get("root") or "")
        if why == "replaced":
            self.log.add({"action": "removed", "why": why, "copies": [copy] if result == "removed" else []})
        return result

    @staticmethod
    def _remove_empty_dirs(folder: Path, root: str) -> None:
        if not root:
            return
        while inside(str(folder), root) and _norm(str(folder)) != _norm(root):
            try:
                os.rmdir(folder)  # only when empty
            except OSError:
                return
            folder = folder.parent

    def remove(self, originals: Iterable[str], why: str = "undo") -> dict:
        """Remove the copies of these originals (Undo). Copies that changed since are kept."""
        out = {"removed": 0, "kept": 0, "missing": 0, "failed": 0, "busy": 0, "copies": []}
        with self._lock:
            making = {_norm(j["original"]) for j in ([self.current] if self.current else [])}
        for original in originals:
            rec = self.index.get(original)
            if not rec:
                out["missing"] += 1
                continue
            if _norm(original) in making:
                out["busy"] += 1
                continue
            result = self._delete_copy(rec, why)
            out[result] += 1
            if result == "removed":
                out["copies"].append(rec["copy"])
            if result != "failed":
                self.index.drop(original)
        if out["copies"] or out["kept"]:
            self.log.add({"action": "removed", "why": why, "copies": out["copies"], "kept": out["kept"]})
        log.info("TV copies removed (%s): %s", why, {k: v for k, v in out.items() if k != "copies"})
        return out

    def remove_all(self) -> dict:
        return self.remove([r["original"] for r in self.index.all()], why="all")

    def batch_originals(self, batch: str) -> List[str]:
        return [r["original"] for r in self.index.all() if r.get("batch") == batch]


# -- the copy AniBox uses (Play on TV, the TV check) --------------------------------------------------------

_active: Optional[TvCopies] = None


def activate(copies: Optional[TvCopies]) -> None:
    global _active
    _active = copies


def copy_for(original_path: str) -> Optional[str]:
    """The up-to-date TV copy of a video, or None. Play on TV sends this instead of the original."""
    m = _active
    return m.copy_for(original_path) if m and original_path else None
