"""New episodes (Home), watch statistics (#/stats) and the watch order of franchises.

Part of the App class (see server.py); the methods use the App's attributes. Everything here only
reads: AniList is asked for air dates (airing.py), nothing is written to the drives, Plex or any
account.
"""

from __future__ import annotations

import logging
import time
from typing import Dict, List, Set

from anibox_check.folders import episode_number

from .airing import ANILIST, INTERVAL, AiringCheck, notice, owned_numbers
from .apierror import ApiError
from .importer import guess_title, scan_inbox
from .insights import next_in_order, watch_order, watch_stats
from .library import entry_json
from .watching import show_card

log = logging.getLogger("anibox.server")

INBOX_REUSE_SECONDS = 30  # the Downloads folder is looked through at most this often for the notices


class RoutesInsightsMixin:
    GET_ROUTES = {
        "/api/airing": "_airing",
        "/api/stats": "_stats",
        "/api/watch-order": "_watch_order",
        "/api/next-in-franchise": "_next_in_franchise",
    }
    POST_ROUTES = {"/api/airing/check": "_airing_check_now"}

    # -- new episodes ------------------------------------------------------------------------------------

    def _airing_checker(self) -> AiringCheck:
        chk = self.__dict__.get("_airing_check_obj")
        if chk is None:  # made on first use, so App.__init__ needs nothing for it
            # anilist_url / anilist_interval: set by the tests (a fake AniList, no waiting)
            chk = self.__dict__.setdefault("_airing_check_obj", AiringCheck(
                self.data_dir / "airing.json", base=getattr(self, "anilist_url", ANILIST),
                interval=getattr(self, "anilist_interval", INTERVAL)))
        return chk

    def _poster_of(self, show) -> str:
        if not show or not self.store.settings().get("posters", True):
            return ""
        return f"/img/{show['mal_id']}" if show.get("mal_id") and show.get("picture") else ""

    def _airing_candidates(self) -> Dict[str, dict]:
        """MyAnimeList id -> {"shows": every show folder of that entry, "watching": bool, "last": time}
        for the shows you're watching and the ones still airing."""
        shows = [s for s in self.library.shows() if str(s.get("mal_id") or "").isdigit()]
        if not shows:
            return {}
        titles = self.library.datasets().titles
        progress = self.store.all_progress()
        by_mal: Dict[str, List[dict]] = {}
        for sh in shows:
            by_mal.setdefault(str(sh["mal_id"]), []).append(sh)
        out: Dict[str, dict] = {}
        for mal, group in by_mal.items():
            cards = [show_card(sh, progress, False) for sh in group]
            watching = any(c["started"] and not c["finished"] for c in cards)
            airing = (titles.get(mal) or {}).get("status") == "ONGOING"
            if watching or airing:
                out[mal] = {"shows": group, "watching": watching, "cards": cards,
                            "last": max(c["last_played"] for c in cards)}
        return out

    def _inbox_waiting(self) -> Dict[str, Set[int]]:
        """MyAnimeList id -> episode numbers of finished downloads waiting in the inbox (Downloads)."""
        cached = self.__dict__.get("_inbox_waiting_cache")
        if cached and time.time() - cached[0] < INBOX_REUSE_SECONDS:
            return cached[1]
        out: Dict[str, Set[int]] = {}
        try:
            groups = scan_inbox(self._inbox_roots(), exclude=self.store.settings().get("folders") or [])
            matcher = self.library.matcher() if groups else None
            for g in groups:
                mal = self._import_matches.get(g["id"])  # a title picked by hand on the Add new videos page
                if mal is None:
                    mal, _ = matcher.match(g["guess"], "", len(g["files"]))
                    if not mal and g.get("folder") and g["files"]:
                        mal, _ = matcher.match(guess_title(g["files"][0]["name"]), "", len(g["files"]))
                if not mal:
                    continue
                for f in g["files"]:
                    num = episode_number(f["name"], g["guess"])
                    n = num[1] if num and num[0] != 0 else (1 if num is None and len(g["files"]) == 1 else None)
                    if n is not None:
                        out.setdefault(str(mal), set()).add(n)
        except OSError as exc:
            log.info("Couldn't look through the Downloads folder for new episodes: %s", exc)
        self.__dict__["_inbox_waiting_cache"] = (time.time(), out)
        return out

    def _airing(self, query: dict) -> dict:
        if not self.store.settings().get("airing_notices", True):
            return {"enabled": False, "state": "off", "items": [], "upcoming": [], "checked": 0}
        cands = self._airing_candidates()
        chk = self._airing_checker()
        if chk.needs_check(set(cands)):
            chk.check_async(set(cands))
        media = chk.usable()
        owned = {mal: set().union(*(owned_numbers(sh["episodes"]) for sh in c["shows"]))
                 for mal, c in cands.items() if media.get(mal)}
        found = {mal: n for mal in owned for n in [notice(owned[mal], media[mal])] if n}
        if any(n["missingCount"] for n in found.values()):  # only then look through Downloads
            waiting = self._inbox_waiting()
            found = {mal: notice(owned[mal], media[mal], waiting.get(mal, set())) if waiting.get(mal) else n
                     for mal, n in found.items()}
        items, upcoming = [], []
        now = time.time()
        for mal, n in found.items():
            c = cands[mal]
            if n["next"] and n["next"]["airingAt"] < now:
                n["next"] = None  # an old answer: that one is out by now
            best = max(zip(c["shows"], c["cards"]),
                       key=lambda sc: (sc[1]["started"] and not sc[1]["finished"], sc[1]["last_played"], len(sc[0]["episodes"])))[0]
            row = dict(n, mal_id=mal, show=best["id"], title=best.get("title") or best["folder"],
                       poster=self._poster_of(best), watching=c["watching"])
            if n["missingCount"]:
                items.append(row)
            elif n["next"]:
                upcoming.append(row)
        items.sort(key=lambda r: (-(r["airedAt"] or 0), not r["watching"], r["title"].casefold()))
        upcoming.sort(key=lambda r: r["next"]["airingAt"])
        data = chk.cached()
        return {"enabled": True, "state": chk.state["state"], "checked": float(data.get("fetched") or 0),
                "items": items, "upcoming": upcoming, "asked": len(cands)}

    def _airing_check_now(self, body: dict) -> dict:
        if not self.store.settings().get("airing_notices", True):
            raise ApiError("New-episode notices are switched off in Settings.")
        cands = self._airing_candidates()
        self.__dict__.pop("_inbox_waiting_cache", None)
        chk = self._airing_checker()
        if cands:
            chk.check_async(set(cands), force=True)
        return {"ok": True, "state": chk.state["state"], "asked": len(cands)}

    # -- statistics ------------------------------------------------------------------------------------------

    def _stats(self, query: dict) -> dict:
        shows = self.library.shows()
        titles = self.library.datasets().titles if any(s.get("mal_id") for s in shows) else {}

        def genres_of(mal_id: str):
            d = self.mal.cached(mal_id)
            return [g for g in d.get("genres") or [] if g] if isinstance(d, dict) else None

        return watch_stats(shows, self.store.all_progress(), self.library.show_kind, titles, genres_of, self._poster_of)

    # -- watch order ----------------------------------------------------------------------------------------

    def _order_for(self, fr) -> List[dict]:
        by_mal: Dict[str, List[dict]] = {}
        for sh in self.library.shows():
            if sh.get("mal_id"):
                by_mal.setdefault(str(sh["mal_id"]), []).append(sh)
        return watch_order([entry_json(e) for e in fr.entries], self.library.datasets().titles, by_mal,
                           self.store.all_progress(), self._poster_of)

    def _watch_order(self, query: dict) -> dict:
        key = query.get("key", "")
        groups, _ = self._franchise_groups()
        for k, fr, _owned in groups:
            if k == key:
                return {"key": k, "title": fr.name, "entries": self._order_for(fr)}
        raise ApiError("Franchise not found", 404)

    def _next_in_franchise(self, query: dict) -> dict:
        show = self.library.show(query.get("id", ""))
        if not show:
            raise ApiError("Show not found", 404)
        card = show_card(show, self.store.all_progress(), False)
        out = {"finished": card["finished"], "key": "", "title": "", "next": None, "step": 0, "steps": 0}
        if not show.get("mal_id"):
            return out
        groups, _ = self._franchise_groups()
        for k, fr, owned in groups:
            if any(sh["id"] == show["id"] for sh in owned) or any(e.mal_id == show["mal_id"] for e in fr.entries):
                order = self._order_for(fr)
                mine = next((e for e in order if e["mal_id"] == str(show["mal_id"])), None)
                out.update(key=k, title=fr.name, steps=sum(1 for e in order if e["step"]),
                           step=mine["step"] if mine else 0,
                           next=next_in_order(order, show["mal_id"]) if card["finished"] else None)
                break
        return out
