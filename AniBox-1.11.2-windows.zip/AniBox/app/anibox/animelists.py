"""Your anime lists on MyAnimeList and AniList: read them, compare them with AniBox, and decide what a
sync would change.

- Reading a public list needs no sign-in: MyAnimeList with the Client ID AniBox already has
  (setting ``mal_client_id``) and your user name, AniList with just your user name.
- Writing (sync) needs a sign-in to that account (routes_lists.py / listsync.py) and the user's OK.
  The rules of what may change are all in ``plan_change`` here: progress never goes down, nothing is
  removed, scores are never touched, plan-to-watch becomes watching, a completed entry is left alone
  unless the user turned on "count it as a rewatch".

Entries from both sites are turned into the same small dict ("entry")::

    {"mal_id": "52991" (or "" for AniList entries MyAnimeList doesn't have), "anilist_id": 154587 or None,
     "title": "Sousou no Frieren", "status": "watching", "progress": 5, "episodes": 28 (0 = unknown),
     "rewatching": False, "repeat": 0}

``status`` is one of STATUSES (MyAnimeList's words). AniList's REPEATING is "completed" with
``rewatching`` True, the way MyAnimeList keeps a rewatch.

The base addresses can be changed (tests use fake servers): constructor arguments, or the environment
variables ``ANIBOX_MAL_API``, ``ANIBOX_MAL_AUTH``, ``ANIBOX_ANILIST_API``, ``ANIBOX_ANILIST_AUTH``.
"""

from __future__ import annotations

import json
import logging
import os
import secrets
import socket
import urllib.error
import urllib.parse
import urllib.request
from typing import Dict, Iterable, List, Optional, Tuple

log = logging.getLogger("anibox.lists")

MAL_API = "https://api.myanimelist.net/v2"
MAL_AUTH = "https://myanimelist.net/v1/oauth2"
ANILIST_API = "https://graphql.anilist.co"
ANILIST_AUTH = "https://anilist.co/api/v2/oauth"

STATUSES = ("watching", "completed", "on_hold", "dropped", "plan_to_watch")
STATUS_NAMES = {"watching": "Watching", "completed": "Completed", "on_hold": "On hold", "dropped": "Dropped",
                "plan_to_watch": "Plan to watch"}
FROM_ANILIST = {"CURRENT": "watching", "PLANNING": "plan_to_watch", "COMPLETED": "completed", "DROPPED": "dropped",
                "PAUSED": "on_hold", "REPEATING": "completed"}
TO_ANILIST = {"watching": "CURRENT", "plan_to_watch": "PLANNING", "completed": "COMPLETED", "dropped": "DROPPED",
              "on_hold": "PAUSED"}
SOURCES = {"mal": "MyAnimeList", "anilist": "AniList"}
MAX_PAGES = 60  # 60 pages of 1,000 (MyAnimeList) or 500 (AniList) entries: far more than any real list
USER_AGENT = "AniBox"


class ListError(RuntimeError):
    """A list site said no or wasn't reachable. ``auth``: sign in again; ``retry``: worth trying later."""

    def __init__(self, message: str, status: int = 0, retry: bool = False, auth: bool = False,
                 retry_after: Optional[float] = None):
        super().__init__(message)
        self.status = status
        self.retry = retry
        self.auth = auth
        self.retry_after = retry_after


def _retry_after(headers) -> Optional[float]:
    try:
        return max(1.0, float(headers.get("Retry-After"))) if headers and headers.get("Retry-After") else None
    except (TypeError, ValueError):
        return None


def _request(method: str, url: str, headers: Optional[dict] = None, data: Optional[bytes] = None,
             timeout: float = 20.0, site: str = "The list site") -> dict:
    """One HTTP request, answered as JSON. Raises ListError with a plain message."""
    h = {"User-Agent": USER_AGENT, "Accept": "application/json"}
    h.update(headers or {})
    req = urllib.request.Request(url, data=data, method=method, headers=h)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read(30_000_000)
    except urllib.error.HTTPError as exc:
        body = b""
        try:
            body = exc.read(200_000)
        except Exception:
            pass
        detail = ""
        try:
            j = json.loads(body.decode("utf-8") or "{}")
            if isinstance(j, dict):
                errs = j.get("errors")
                if isinstance(errs, list) and errs and isinstance(errs[0], dict):
                    detail = str(errs[0].get("message") or "")
                detail = detail or str(j.get("message") or j.get("error") or "")
        except ValueError:
            pass
        code = exc.code
        if code == 429:
            raise ListError(f"{site} asks AniBox to slow down. AniBox tries again in a moment.", code, retry=True,
                            retry_after=_retry_after(exc.headers)) from exc
        if code in (500, 502, 503, 504):
            raise ListError(f"{site} has a problem right now ({code}). AniBox tries again later.", code,
                            retry=True, retry_after=_retry_after(exc.headers)) from exc
        raise ListError(detail or f"{site} answered with an error ({code}).", code,
                        auth=code == 401) from exc
    except (urllib.error.URLError, socket.timeout, ConnectionError, OSError) as exc:
        raise ListError(f"{site} isn't reachable right now. AniBox tries again later.", retry=True) from exc
    try:
        out = json.loads(raw.decode("utf-8") or "{}")
    except ValueError as exc:
        raise ListError(f"{site} sent an answer AniBox can't read.", retry=True) from exc
    if not isinstance(out, dict):
        raise ListError(f"{site} sent an answer AniBox can't read.", retry=True)
    return out


def _int(value) -> int:
    try:
        return max(0, int(value or 0))
    except (TypeError, ValueError):
        return 0


# -- sign-in helpers --------------------------------------------------------------------------------


def pkce_pair() -> Tuple[str, str, str]:
    """(code_verifier, code_challenge, method) for MyAnimeList's sign-in.

    MyAnimeList only supports the "plain" method, so the challenge is the verifier itself. The
    verifier is 128 characters from the allowed set (letters, digits, ``-`` and ``_``).
    """
    verifier = secrets.token_urlsafe(96)[:128]
    return verifier, verifier, "plain"


# -- MyAnimeList ------------------------------------------------------------------------------------


def mal_entry(node: dict, status: dict) -> dict:
    rewatching = bool(status.get("is_rewatching"))
    return {
        "mal_id": str(node.get("id") or ""),
        "anilist_id": None,
        "title": str(node.get("title") or ""),
        # A rewatch counts as completed (MyAnimeList's own way: status completed + is_rewatching).
        "status": "completed" if rewatching else status.get("status") if status.get("status") in STATUSES else "watching",
        "progress": _int(status.get("num_episodes_watched")),
        "episodes": _int(node.get("num_episodes")),
        "rewatching": rewatching,
        # None = MyAnimeList didn't say (then AniBox never sends a rewatch count, so it can't lower it)
        "repeat": _int(status.get("num_times_rewatched")) if "num_times_rewatched" in status else None,
    }


class MalClient:
    """MyAnimeList API v2 and its sign-in (OAuth 2 with PKCE, for apps of type "other": no secret)."""

    def __init__(self, api: Optional[str] = None, auth: Optional[str] = None, timeout: float = 20.0):
        self.api = (api or os.environ.get("ANIBOX_MAL_API") or MAL_API).rstrip("/")
        self.auth = (auth or os.environ.get("ANIBOX_MAL_AUTH") or MAL_AUTH).rstrip("/")
        self.timeout = timeout

    def _get(self, url: str, client_id: str = "", token: str = "") -> dict:
        h = {"Authorization": f"Bearer {token}"} if token else {"X-MAL-CLIENT-ID": client_id}
        return _request("GET", url, h, timeout=self.timeout, site="MyAnimeList")

    def fetch_list(self, user: str = "", client_id: str = "", token: str = "") -> List[dict]:
        """Every entry of a list: ``user``'s public list with the Client ID, or your own with a token."""
        if not token and not client_id:
            raise ListError("Reading a MyAnimeList list needs the Client ID (Settings → MyAnimeList).")
        who = "@me" if token and not user else user
        if not who:
            raise ListError("Add your MyAnimeList user name first.")
        url = f"{self.api}/users/{urllib.parse.quote(who, safe='@')}/animelist?" + urllib.parse.urlencode(
            {"fields": "list_status,num_episodes", "limit": 1000, "nsfw": "true"})
        out: List[dict] = []
        seen = set()
        for _ in range(MAX_PAGES):
            try:
                data = self._get(url, client_id, token)
            except ListError as exc:
                if exc.status == 403 and not token:
                    raise ListError("This MyAnimeList list is private. Connect your account below to read it.",
                                    403) from exc
                if exc.status == 404:
                    raise ListError(f"MyAnimeList doesn't know the user “{who}”.", 404) from exc
                if exc.status in (400, 401) and not token:
                    raise ListError("MyAnimeList didn't accept the Client ID. Check it in Settings.",
                                    exc.status) from exc
                raise
            for item in data.get("data") or []:
                if not isinstance(item, dict):
                    continue
                e = mal_entry(item.get("node") or {}, item.get("list_status") or {})
                if e["mal_id"] and e["mal_id"] not in seen:
                    seen.add(e["mal_id"])
                    out.append(e)
            nxt = str((data.get("paging") or {}).get("next") or "")
            # Only ever follow pages on the same API: the request carries the token or Client ID.
            if not nxt or not nxt.startswith(self.api + "/"):
                break
            url = nxt
        return out

    def entry(self, mal_id: str, token: str) -> Tuple[Optional[dict], dict]:
        """(your list entry or None, the anime's own info: title, episodes) for one MyAnimeList id."""
        base = f"{self.api}/anime/{int(mal_id)}?"
        try:  # the rewatch count is only sent when asked for by name
            data = self._get(base + urllib.parse.urlencode(
                {"fields": "num_episodes,my_list_status{status,num_episodes_watched,is_rewatching,num_times_rewatched}"}),
                token=token)
        except ListError as exc:
            if exc.status != 400:
                raise
            data = self._get(base + urllib.parse.urlencode({"fields": "num_episodes,my_list_status"}), token=token)
        info = {"title": str(data.get("title") or ""), "episodes": _int(data.get("num_episodes"))}
        status = data.get("my_list_status")
        return (mal_entry(data, status) if isinstance(status, dict) and status.get("status") else None), info

    def update(self, mal_id: str, token: str, fields: dict) -> dict:
        """PATCH my_list_status. ``fields`` only ever holds status, num_watched_episodes, is_rewatching
        and num_times_rewatched (never a score)."""
        allowed = {"status", "num_watched_episodes", "is_rewatching", "num_times_rewatched"}
        body = {k: ("true" if v is True else "false" if v is False else str(v)) for k, v in fields.items() if k in allowed}
        return _request("PATCH", f"{self.api}/anime/{int(mal_id)}/my_list_status",
                        {"Authorization": f"Bearer {token}", "Content-Type": "application/x-www-form-urlencoded"},
                        urllib.parse.urlencode(body).encode("ascii"), timeout=self.timeout, site="MyAnimeList")

    def me(self, token: str) -> str:
        return str(self._get(f"{self.api}/users/@me", token=token).get("name") or "")

    # sign-in: the redirect address is the one registered in the user's MyAnimeList app (only one), so it
    # isn't sent; MyAnimeList then uses it, and the token request leaves it out too.

    def authorize_url(self, client_id: str, challenge: str, state: str) -> str:
        return f"{self.auth}/authorize?" + urllib.parse.urlencode({
            "response_type": "code", "client_id": client_id, "code_challenge": challenge,
            "code_challenge_method": "plain", "state": state})

    def _token(self, form: dict) -> dict:
        try:
            data = _request("POST", f"{self.auth}/token", {"Content-Type": "application/x-www-form-urlencoded"},
                            urllib.parse.urlencode(form).encode("ascii"), timeout=self.timeout, site="MyAnimeList")
        except ListError as exc:
            if exc.status in (400, 401):
                raise ListError("MyAnimeList didn't accept the sign-in. Check that your MyAnimeList app has the "
                                "App Type “other” and the App Redirect URL AniBox shows, then try again.",
                                exc.status, auth=True) from exc
            raise
        if not data.get("access_token"):
            raise ListError("MyAnimeList didn't send a sign-in.", auth=True)
        return data

    def exchange(self, client_id: str, code: str, verifier: str) -> dict:
        return self._token({"client_id": client_id, "grant_type": "authorization_code", "code": code,
                            "code_verifier": verifier})

    def refresh(self, client_id: str, refresh_token: str) -> dict:
        return self._token({"client_id": client_id, "grant_type": "refresh_token", "refresh_token": refresh_token})


# -- AniList ----------------------------------------------------------------------------------------

LIST_QUERY = """query ($name: String, $id: Int, $chunk: Int) {
  MediaListCollection(userName: $name, userId: $id, type: ANIME, chunk: $chunk, perChunk: 500) {
    hasNextChunk
    lists { entries { status progress score repeat media { id idMal episodes title { romaji } } } }
  }
}"""
ENTRY_QUERY = """query ($mal: Int) {
  Media(idMal: $mal, type: ANIME) { id idMal episodes title { romaji } mediaListEntry { status progress repeat } }
}"""
SAVE_MUTATION = """mutation ($media: Int, $status: MediaListStatus, $progress: Int, $repeat: Int) {
  SaveMediaListEntry(mediaId: $media, status: $status, progress: $progress, repeat: $repeat) { id status progress repeat }
}"""
VIEWER_QUERY = "query { Viewer { id name } }"


def anilist_entry(media: dict, row: dict) -> dict:
    status = str(row.get("status") or "")
    return {
        "mal_id": str(media.get("idMal") or ""),
        "anilist_id": media.get("id"),
        "title": str(((media.get("title") or {}).get("romaji")) or ""),
        "status": FROM_ANILIST.get(status, "watching"),
        "progress": _int(row.get("progress")),
        "episodes": _int(media.get("episodes")),
        "rewatching": status == "REPEATING",
        "repeat": _int(row.get("repeat")),
    }


class AniListClient:
    """AniList's GraphQL API and its sign-in (implicit grant: the token comes back in the address)."""

    def __init__(self, api: Optional[str] = None, auth: Optional[str] = None, timeout: float = 20.0):
        self.api = (api or os.environ.get("ANIBOX_ANILIST_API") or ANILIST_API).rstrip("/")
        self.auth = (auth or os.environ.get("ANIBOX_ANILIST_AUTH") or ANILIST_AUTH).rstrip("/")
        self.timeout = timeout

    def _post(self, query: str, variables: Optional[dict] = None, token: str = "") -> dict:
        h = {"Content-Type": "application/json"}
        if token:
            h["Authorization"] = f"Bearer {token}"
        body = json.dumps({"query": query, "variables": variables or {}}).encode("utf-8")
        data = _request("POST", self.api, h, body, timeout=self.timeout, site="AniList")
        errs = data.get("errors")
        if errs and not data.get("data"):
            msg = str((errs[0] or {}).get("message") or "AniList answered with an error.") if isinstance(errs, list) else ""
            status = _int((errs[0] or {}).get("status")) if isinstance(errs, list) and isinstance(errs[0], dict) else 0
            if status == 404 or "not found" in msg.lower():
                raise ListError(msg or "Not found.", 404)
            raise ListError(msg or "AniList answered with an error.", status, auth=status == 401,
                            retry=status in (429, 500, 502, 503))
        return data.get("data") or {}

    def viewer(self, token: str) -> dict:
        v = (self._post(VIEWER_QUERY, token=token).get("Viewer") or {})
        if not v.get("id"):
            raise ListError("AniList didn't accept the sign-in.", 401, auth=True)
        return {"id": int(v["id"]), "name": str(v.get("name") or "")}

    def fetch_list(self, user: str = "", token: str = "", user_id: Optional[int] = None) -> List[dict]:
        if not user and not user_id:
            if not token:
                raise ListError("Add your AniList user name first.")
            user_id = self.viewer(token)["id"]
        out: List[dict] = []
        seen = set()
        for chunk in range(1, MAX_PAGES + 1):
            try:
                data = self._post(LIST_QUERY, {"name": user or None, "id": None if user else user_id, "chunk": chunk},
                                  token=token)
            except ListError as exc:
                if exc.status == 404:
                    raise ListError(f"AniList doesn't know the user “{user}”, or the profile is private.", 404) from exc
                raise
            coll = data.get("MediaListCollection") or {}
            for lst in coll.get("lists") or []:
                for row in (lst or {}).get("entries") or []:
                    media = (row or {}).get("media") or {}
                    if not media.get("id") or media["id"] in seen:  # custom lists repeat entries
                        continue
                    seen.add(media["id"])
                    out.append(anilist_entry(media, row))
            if not coll.get("hasNextChunk"):
                break
        return out

    def entry(self, mal_id: str, token: str) -> Tuple[Optional[dict], dict]:
        """(your list entry or None, {"anilist_id", "title", "episodes"}) for a MyAnimeList id."""
        try:
            media = self._post(ENTRY_QUERY, {"mal": int(mal_id)}, token=token).get("Media") or {}
        except ListError as exc:
            if exc.status == 404:
                return None, {}
            raise
        if not media.get("id"):
            return None, {}
        info = {"anilist_id": media["id"], "title": str((media.get("title") or {}).get("romaji") or ""),
                "episodes": _int(media.get("episodes"))}
        row = media.get("mediaListEntry")
        return (anilist_entry(media, row) if isinstance(row, dict) and row.get("status") else None), info

    def save(self, media_id: int, token: str, status: str, progress: int, repeat: Optional[int] = None) -> dict:
        """SaveMediaListEntry with status, progress and (only when a rewatch ends) repeat. Never a score."""
        variables = {"media": int(media_id), "status": status, "progress": int(progress)}
        if repeat is not None:
            variables["repeat"] = int(repeat)
        return self._post(SAVE_MUTATION, variables, token=token).get("SaveMediaListEntry") or {}

    def authorize_url(self, client_id: str) -> str:
        return f"{self.auth}/authorize?" + urllib.parse.urlencode({"client_id": client_id, "response_type": "token"})


# -- AniBox's side: which episodes of a MyAnimeList entry you have and have watched -------------------


def show_numbers(show: dict) -> List[Tuple[dict, Optional[int]]]:
    """(episode, its number in the MyAnimeList entry) for every file of a show folder.

    Season folders that restart at 1 are counted on (episodes.absolute_numbers). A folder with one
    file and no number (a movie) is episode 1. Specials (season 0) and files without a number get None.
    """
    from .episodes import absolute_numbers
    eps = show.get("episodes") or []
    nums = absolute_numbers(eps)
    if len(eps) == 1 and nums[0] is None and (eps[0].get("season") or 1) != 0:
        nums = [1]
    return list(zip(eps, nums))


def numbering_fits(show: dict, total: int) -> bool:
    """False if the file numbers can't be the entry's (e.g. "Title 13–24" in a 12-episode sequel)."""
    if not total:
        return True
    return all(n is None or n <= total for _, n in show_numbers(show))


def watched_upto(shows: Iterable[dict], progress: Dict[str, dict]) -> int:
    """The highest episode number watched in AniBox across the folders of one entry (0 = none)."""
    best = 0
    for sh in shows:
        for ep, n in show_numbers(sh):
            if n and (progress.get(ep["key"]) or {}).get("watched"):
                best = max(best, n)
    return best


def list_upto(entry: dict) -> float:
    """How far the list says you watched: the progress, or everything for a completed entry."""
    if entry["status"] == "completed":
        return max(entry["progress"], entry["episodes"]) if entry["episodes"] else float("inf")
    return entry["progress"]


# -- the sync rules -----------------------------------------------------------------------------------


def describe(state: Optional[dict]) -> str:
    """'Watching 5/12', 'Completed', 'Rewatching 2/12', 'not on your list'."""
    if not state:
        return "not on your list"
    eps = state.get("episodes") or 0
    of = f"/{eps}" if eps else ""
    if state.get("rewatching"):
        return f"Rewatching {state.get('progress', 0)}{of}"
    name = STATUS_NAMES.get(state.get("status"), state.get("status") or "")
    if state.get("status") == "completed":
        return name
    if state.get("status") == "plan_to_watch" and not state.get("progress"):
        return name
    return f"{name} {state.get('progress', 0)}{of}"


def plan_change(current: Optional[dict], watched: int, total: int = 0, rewatch: bool = False,
                finished: Optional[int] = None) -> Tuple[Optional[dict], str]:
    """What sending AniBox's state to a list would change: (new state, "") or (None, why not).

    ``current``: the list entry (or None: not on the list yet, then it's added as watching or, at the
    last episode, completed). ``watched``: the highest episode watched in AniBox. ``total``: the
    entry's episode count (0 = unknown: never completed by AniBox). ``rewatch``: the setting "When I
    watch a finished show again: count it as a rewatch". ``finished``: the episode just finished in
    the player (None when syncing everything at once: rewatches only come from the player).

    Rules: progress never goes down; plan-to-watch, on hold and dropped become watching when you
    watch further; watching becomes completed at the last episode; a completed entry stays as it is
    unless ``rewatch`` is on. The new state has "status", "progress", "rewatching" and "repeat";
    nothing else (no score) is ever part of it.
    """
    total = _int(total)

    def cap(n: int) -> int:
        return min(n, total) if total else n

    if current is None:
        n = cap(_int(watched))
        if n <= 0:
            return None, "nothing watched yet"
        return {"status": "completed" if total and n >= total else "watching", "progress": n,
                "rewatching": False, "repeat": 0, "episodes": total}, ""
    prog, repeat = _int(current.get("progress")), _int(current.get("repeat"))
    if current.get("status") == "completed":
        if not rewatch:
            return None, "completed on your list (AniBox leaves it alone)"
        if finished is None:
            return None, "completed on your list (rewatches are only counted while you watch)"
        ep = cap(_int(finished))
        if ep <= 0:
            return None, "no episode number"
        if current.get("rewatching") and ep <= prog:
            return None, "your list is already that far"
        if total and ep >= total:  # the rewatch is finished: one more time watched
            return {"status": "completed", "progress": total, "rewatching": False, "repeat": repeat + 1,
                    "episodes": total}, ""
        return {"status": "completed", "progress": ep, "rewatching": True, "repeat": repeat, "episodes": total}, ""
    n = cap(_int(watched))
    if n <= prog:
        return None, "your list is already that far"
    return {"status": "completed" if total and n >= total else "watching", "progress": n, "rewatching": False,
            "repeat": repeat, "episodes": total}, ""


def mal_fields(current: Optional[dict], new: dict) -> dict:
    """The MyAnimeList fields that make ``new`` true (only what changes, never a score)."""
    fields = {"status": new["status"], "num_watched_episodes": new["progress"]}
    if new.get("rewatching") or (current or {}).get("rewatching"):
        fields["is_rewatching"] = bool(new.get("rewatching"))
    if current and current.get("repeat") is not None and new.get("repeat", 0) > current["repeat"]:
        fields["num_times_rewatched"] = new["repeat"]
    return fields


def anilist_fields(current: Optional[dict], new: dict) -> dict:
    status = "REPEATING" if new.get("rewatching") else TO_ANILIST[new["status"]]
    out = {"status": status, "progress": new["progress"]}
    if current and new.get("repeat", 0) > (current.get("repeat") or 0):
        out["repeat"] = new["repeat"]
    return out


# -- comparing a list with AniBox ---------------------------------------------------------------------

WANTED = ("watching", "plan_to_watch", "completed")


def compare(entries: List[dict], all_shows: List[dict], shown: List[dict], progress: Dict[str, dict]) -> dict:
    """The three parts of the Lists page.

    ``all_shows``: every show folder AniBox found (decides "on your drives"); ``shown``: the libraries
    picked in Settings (marking and "not on your list" only look at those).

    - ``notOnDrives``: watching / plan-to-watch / completed entries no AniBox folder has.
    - ``behind``: per show folder, the episodes your list counts as watched that AniBox doesn't
      (only numbered episodes up to the list's progress; a completed entry means all of them).
    - ``notOnList``: entries AniBox has (by MyAnimeList id) that aren't on the list.
    """
    have = {sh["mal_id"] for sh in all_shows if sh.get("mal_id")}
    by_mal: Dict[str, List[dict]] = {}
    for sh in shown:
        if sh.get("mal_id"):
            by_mal.setdefault(str(sh["mal_id"]), []).append(sh)
    on_list = {e["mal_id"] for e in entries if e.get("mal_id")}
    not_on_drives = [e for e in entries if e["status"] in WANTED and (not e["mal_id"] or e["mal_id"] not in have)]
    order = {s: i for i, s in enumerate(WANTED)}
    not_on_drives.sort(key=lambda e: (order.get(e["status"], 9), e["title"].casefold()))
    behind = []
    for e in entries:
        upto = list_upto(e)
        if not upto:
            continue
        for sh in by_mal.get(e["mal_id"], []):
            if not numbering_fits(sh, e["episodes"]):
                continue
            todo = [(ep, n) for ep, n in show_numbers(sh)
                    if n is not None and n <= upto and not (progress.get(ep["key"]) or {}).get("watched")]
            if not todo:
                continue
            seen = sum(1 for ep, _ in show_numbers(sh) if (progress.get(ep["key"]) or {}).get("watched"))
            behind.append({
                "show": sh["id"], "title": sh.get("title") or sh["folder"], "folder": sh["folder"],
                "library": sh["library"], "mal_id": e["mal_id"], "list": describe(e), "files": len(sh["episodes"]),
                "watched": seen, "episodes": [{"key": ep["key"], "label": ep["label"], "number": n} for ep, n in todo],
            })
    behind.sort(key=lambda b: b["title"].casefold())
    not_on_list = []
    for mal_id, shows in by_mal.items():
        if mal_id in on_list:
            continue
        files = sum(len(sh["episodes"]) for sh in shows)
        seen = sum(1 for sh in shows for ep in sh["episodes"] if (progress.get(ep["key"]) or {}).get("watched"))
        not_on_list.append({"mal_id": mal_id, "title": shows[0].get("title") or shows[0]["folder"],
                            "type": shows[0].get("type") or "", "year": shows[0].get("year"),
                            "shows": [{"id": sh["id"], "library": sh["library"], "folder": sh["folder"]} for sh in shows],
                            "files": files, "watched": seen})
    not_on_list.sort(key=lambda x: x["title"].casefold())
    return {"notOnDrives": not_on_drives, "behind": behind, "notOnList": not_on_list}


def marks_for(entries: List[dict], shows: List[dict], progress: Dict[str, dict], wanted: Iterable[str]) -> Dict[str, List[str]]:
    """show id -> episode keys to mark as watched (``compare``'s "behind", only for ``wanted`` shows)."""
    wanted = set(wanted)
    rows = compare(entries, shows, [sh for sh in shows if sh["id"] in wanted], progress)["behind"]
    return {r["show"]: [e["key"] for e in r["episodes"]] for r in rows if r["show"] in wanted}
