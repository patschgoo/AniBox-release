"""AniList extras on a show's page (anilistinfo.py): the routes for the window.

All of them are for the AniBox window only (the phone remote can't reach them). The setting
``anilist_info`` (on by default) switches everything off: then AniBox doesn't ask AniList at all and
the pages show nothing of it. Only a show's AniList number is ever sent.

Part of the App class (see server.py); the methods use the App's attributes.
"""

from __future__ import annotations

from typing import Dict, Optional

from .airing import ANILIST, INTERVAL
from .anilistinfo import CAST_LANGS, CAST_NAMES, LOAD_PAUSE, MAX_AGE, AniListInfo, cast_order, default_cast
from .apierror import ApiError


class RoutesAniListInfoMixin:
    GET_ROUTES = {
        "/api/anilist/show": "_al_show",
        "/api/anilist/status": "_al_status",
    }
    POST_ROUTES = {
        "/api/anilist/load-all": "_al_load_all",
        "/api/anilist/cancel": "_al_cancel",
        "/api/anilist/cast": "_al_set_cast",
    }

    def _al(self) -> AniListInfo:
        al = self.__dict__.get("_anilist_info_obj")
        if al is None:  # made on first use, so App.__init__ needs nothing for it
            # anilist_url / anilist_interval: set by the tests (a fake AniList, no waiting)
            al = self.__dict__.setdefault("_anilist_info_obj", AniListInfo(
                self.data_dir / "anilist", base=getattr(self, "anilist_url", ANILIST),
                interval=getattr(self, "anilist_interval", INTERVAL)))
        return al

    def _al_enabled(self) -> bool:
        return bool(self.store.settings().get("anilist_info", True))

    def _al_ids(self) -> Dict[str, int]:
        """MyAnimeList id -> AniList id (Fribb's anime list), made once per list."""
        ds = self.library.datasets()
        hit = self.__dict__.get("_al_id_map")
        if hit is None or hit[0] is not ds:
            ids = {}
            for m in ds.mapping:
                mal, aid = m.get("mal_id"), m.get("anilist_id")
                if mal and isinstance(aid, int) and aid > 0:
                    ids.setdefault(str(mal), aid)
            hit = (ds, ids)
            self.__dict__["_al_id_map"] = hit
        return hit[1]

    def _anilist_id(self, mal_id) -> Optional[int]:
        return self._al_ids().get(str(mal_id)) if mal_id else None

    def _anilist_summary_for_mal(self, mal_id) -> Optional[dict]:
        """Genres, tags (no spoilers) and banner of a MyAnimeList entry from the cache on this PC
        (never asks AniList). None when AniBox has nothing for it."""
        aid = self._anilist_id(mal_id)
        return self._al().summaries().get(aid) if aid else None

    def _anilist_summaries_by_mal(self) -> Dict[str, dict]:
        index = self._al().summaries()
        return {mal: index[aid] for mal, aid in self._al_ids().items() if index.get(aid)}

    # -- GET ---------------------------------------------------------------------------------------------

    def _al_show(self, query: dict) -> dict:
        show = self.library.show(query.get("id", ""))
        if not show:
            raise ApiError("Show not found", 404)
        if not self._al_enabled():
            return {"enabled": False, "state": "off", "info": None}
        settings = self.store.settings()
        audio = settings.get("audio_langs") or ""
        out = {"enabled": True, "state": "none", "info": None, "anilist": None, "error": "",
               "cast": default_cast(audio, settings.get("anilist_cast") or ""), "castOrder": cast_order(audio),
               "castNames": CAST_NAMES}
        aid = self._anilist_id(show.get("mal_id"))
        if not aid:
            return out
        al = self._al()
        entry = al.entry(aid)
        if entry is None or al.clock() - float(entry["fetched"]) >= MAX_AGE:
            al.fetch_async(aid)
        busy = al.status(aid)
        out["anilist"] = aid
        if entry is not None:
            out["info"] = entry["media"]
            out["state"] = "missing" if entry["media"] is None else "done"
            if busy == "loading":
                out["refreshing"] = True
        else:
            out["state"] = "loading" if busy == "loading" else "error" if busy == "error" else "loading"
            if busy == "error":
                out["error"] = "AniList isn't reachable right now."
        return out

    def _al_library_ids(self) -> set:
        """The AniList ids of the shows in the libraries you show."""
        mals = {str(s["mal_id"]) for s in self.library.shows() if s.get("mal_id")}
        return {aid for mal, aid in self._al_ids().items() if mal in mals}

    def _al_status(self, query: dict) -> dict:
        al = self._al()
        ids = self._al_library_ids()
        index = al.summaries()
        return {"enabled": self._al_enabled(), "job": dict(al.job), "total": len(ids),
                "cached": sum(1 for a in ids if a in index)}

    # -- POST --------------------------------------------------------------------------------------------

    def _al_load_all(self, body: dict) -> dict:
        if not self._al_enabled():
            raise ApiError("AniList extras are switched off in Settings.")
        al = self._al()
        started = al.load_all(self._al_library_ids(), pause=getattr(self, "anilist_load_pause", LOAD_PAUSE), allowed=self._al_enabled)
        return {"ok": True, "started": started, "job": dict(al.job)}

    def _al_cancel(self, body: dict) -> dict:
        self._al().cancel()
        return {"ok": True}

    def _al_set_cast(self, body: dict) -> dict:
        lang = str(body.get("lang") or "")
        if lang and lang not in CAST_LANGS:
            raise ApiError("Pick Japanese, German or English.")
        self.store.update_settings({"anilist_cast": lang})
        return {"ok": True, "cast": lang}
