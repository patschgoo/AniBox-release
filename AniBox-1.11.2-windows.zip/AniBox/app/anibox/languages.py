"""Which languages a show has: dub or sub, German or English. Read-only, nothing is changed.

Three ways, combined (the strongest wins):

1. **Names** (free, instant): the library folder ("Anime (ger dub)"), the show folder and the file
   names ("[Ger Dub]", "GerSub", "OmU", "Dual Audio", ...).
2. **The files themselves**: the start of an MKV file (its track list) or the "moov" part of an
   MP4 file says which audio and subtitle tracks are inside and in which language. AniBox reads
   only those few hundred KB, of one or two episodes per show, when you open the show.
3. **The player**: when an episode plays, mpv lists its tracks; AniBox remembers them.

Your own choice (set by hand on the show page) always wins over all three.
"""

from __future__ import annotations

import os
import re
import struct
from typing import Dict, Iterable, List, Optional, Tuple

# ISO 639 codes to the two-letter form AniBox shows.
LANG = {"ger": "de", "deu": "de", "de": "de", "german": "de", "jpn": "ja", "ja": "ja", "jp": "ja", "japanese": "ja",
        "eng": "en", "en": "en", "english": "en", "fre": "fr", "fra": "fr", "fr": "fr", "spa": "es", "es": "es",
        "ita": "it", "it": "it", "por": "pt", "pt": "pt", "rus": "ru", "ru": "ru", "chi": "zh", "zho": "zh", "zh": "zh",
        "kor": "ko", "ko": "ko", "ara": "ar", "ar": "ar"}
NAMES = {"de": "German", "ja": "Japanese", "en": "English", "fr": "French", "es": "Spanish", "it": "Italian",
         "pt": "Portuguese", "ru": "Russian", "zh": "Chinese", "ko": "Korean", "ar": "Arabic"}

_SEP = r"[\s._\-]*"
_RULES: List[Tuple[re.Pattern, str, str]] = [
    (re.compile(r"\b(?:ger|german|deu|deutsch)" + _SEP + r"(?:dub|dubbed|synchro|fassung)\b", re.I), "audio", "de"),
    (re.compile(r"\bger" + _SEP + r"dub\b|\(ger\s*dub\)|\[ger\s*dub\]", re.I), "audio", "de"),
    (re.compile(r"\b(?:eng|english)" + _SEP + r"(?:dub|dubbed)\b", re.I), "audio", "en"),
    (re.compile(r"\b(?:jap|japanese|jpn)" + _SEP + r"(?:dub|audio)\b", re.I), "audio", "ja"),
    (re.compile(r"\b(?:ger|german|deu|deutsch)" + _SEP + r"(?:sub|subs|subbed|untertitel|ut)\b|\bgersub\b", re.I), "subs", "de"),
    (re.compile(r"\b(?:eng|english)" + _SEP + r"(?:sub|subs|subbed)\b|\bengsub\b", re.I), "subs", "en"),
    (re.compile(r"\bomu\b", re.I), "omu", "de"),  # "Original mit Untertiteln": Japanese audio, German subs
    (re.compile(r"\bomeu\b", re.I), "omu", "en"),
    (re.compile(r"\b(?:dual|multi)" + _SEP + r"audio\b", re.I), "dual", ""),
    (re.compile(r"\bhard" + _SEP + r"(?:sub|subs|subbed|coded|burned)\b|\bhardsub", re.I), "hard", ""),
]

# Subtitle types. "hard" = burned into the picture: can't be switched off, but shows everywhere.
SUBTYPES = ("hard", "ass", "srt", "vtt", "text", "pgs", "vobsub")
SUBTYPE_NAMES = {"hard": "Burned in", "ass": "ASS/SSA (styled)", "srt": "SRT (text)", "vtt": "WebVTT (text)",
                 "text": "MP4 text", "pgs": "PGS (image, Blu-ray)", "vobsub": "VobSub (image, DVD)"}
# Types that the Plex app on the Shield, many smart TVs and Chromecast can't show as they are:
# Plex then converts the whole video to burn them in (heavy for the Shield) or drops their styling.
PICKY = {"ass", "pgs", "vobsub"}
# What works where. "probably" = expected from how the players work, still to check on your TV.
COMPAT = [
    {"type": "hard", "pc": "yes", "plex": "yes", "castapp": "yes", "note": "Always visible; can't be switched off or changed."},
    {"type": "srt", "pc": "yes", "plex": "yes", "castapp": "yes", "note": "Plain text; works almost everywhere."},
    {"type": "vtt", "pc": "yes", "plex": "yes", "castapp": "yes", "note": "Plain text, the web's format."},
    {"type": "text", "pc": "yes", "plex": "yes", "castapp": "probably", "note": "Plain text inside MP4 files."},
    {"type": "ass", "pc": "yes, with all styling", "plex": "often converted or shown plain",
     "castapp": "probably plain text", "note": "Fonts, colours and signs; the usual fansub format."},
    {"type": "pgs", "pc": "yes", "plex": "often converted (heavy)", "castapp": "probably",
     "note": "Pictures of text from Blu-rays."},
    {"type": "vobsub", "pc": "yes", "plex": "often converted (heavy)", "castapp": "probably",
     "note": "Pictures of text from DVDs."},
]

_MKV_SUBTYPE = {"S_TEXT/ASS": "ass", "S_TEXT/SSA": "ass", "S_ASS": "ass", "S_SSA": "ass", "S_TEXT/UTF8": "srt",
                "S_TEXT/ASCII": "srt", "S_TEXT/WEBVTT": "vtt", "D_WEBVTT/SUBTITLES": "vtt", "S_HDMV/PGS": "pgs",
                "S_VOBSUB": "vobsub", "S_HDMV/TEXTST": "text", "S_DVBSUB": "pgs"}
# mpv's codec names (track-list "codec") and MP4 sample entries
_OTHER_SUBTYPE = {"ass": "ass", "ssa": "ass", "subrip": "srt", "srt": "srt", "webvtt": "vtt", "wvtt": "vtt",
                  "mov_text": "text", "tx3g": "text", "stpp": "text", "hdmv_pgs_subtitle": "pgs", "pgssub": "pgs",
                  "dvd_subtitle": "vobsub", "dvb_subtitle": "pgs", "text": "srt"}
SUB_EXTENSIONS = {".ass": "ass", ".ssa": "ass", ".srt": "srt", ".vtt": "vtt", ".sup": "pgs", ".idx": "vobsub"}


def subtype(codec: str) -> str:
    """'S_TEXT/ASS' / 'subrip' / 'tx3g' -> 'ass' / 'srt' / 'text' ('' if unknown)."""
    c = (codec or "").strip()
    return _MKV_SUBTYPE.get(c.upper()) or _OTHER_SUBTYPE.get(c.lower(), "")


def picky(types) -> bool:
    """True if every subtitle the show has may not show on Plex/the TV as it is (nothing plain or burned in)."""
    t = set(types or ())
    return bool(t & PICKY) and not (t - PICKY)


def lang(code: str) -> str:
    """'ger' / 'de-DE' / 'German' -> 'de'; unknown -> the code itself (lowercase, max 3 letters)."""
    c = (code or "").strip().lower().replace("_", "-")
    if not c or c in ("und", "zxx", "mis", "mul"):
        return ""
    base = c.split("-")[0]
    return LANG.get(c) or LANG.get(base) or base[:3]


def from_names(texts: Iterable[str]) -> Dict[str, List[str]]:
    """Languages written in folder and file names. Returns {"audio": [...], "subs": [...], "dual": bool}."""
    audio, subs, dual, hard = set(), set(), False, False
    for t in texts:
        t = t or ""
        for rx, kind, code in _RULES:
            if not rx.search(t):
                continue
            if kind == "audio":
                audio.add(code)
            elif kind == "subs":
                subs.add(code)
                audio.add("ja")  # subtitled releases are almost always Japanese audio
            elif kind == "omu":
                audio.add("ja")
                subs.add(code)
            elif kind == "dual":
                dual = True
                audio.add("ja")
            elif kind == "hard":
                hard = True
    out = {"audio": sorted(audio), "subs": sorted(subs), "dual": dual}
    if hard:
        out["subtypes"] = ["hard"]
    return out


# -- MKV (Matroska / WebM): the track list near the start of the file ---------------------------------

_EBML, _SEGMENT, _SEEKHEAD, _SEEK, _SEEKID, _SEEKPOS = 0x1A45DFA3, 0x18538067, 0x114D9B74, 0x4DBB, 0x53AB, 0x53AC
_TRACKS, _TRACKENTRY, _CLUSTER = 0x1654AE6B, 0xAE, 0x1F43B675
_TRACKTYPE, _CODEC, _NAME, _LANGUAGE, _LANG_BCP47, _DEFAULT, _FORCED = 0x83, 0x86, 0x536E, 0x22B59C, 0x22B59D, 0x88, 0x55AA
_TYPES = {1: "video", 2: "audio", 0x11: "sub"}
READ_FIRST = 1_500_000


def _vint(buf: bytes, pos: int, keep_marker: bool) -> Tuple[int, int]:
    """An EBML variable-size number at pos -> (value, length); (-1, length) for "unknown size"."""
    first = buf[pos]
    length = 1
    mask = 0x80
    while length <= 8 and not first & mask:
        mask >>= 1
        length += 1
    if length > 8 or pos + length > len(buf):
        raise ValueError("bad EBML number")
    value = first if keep_marker else first & (mask - 1)
    for b in buf[pos + 1:pos + length]:
        value = (value << 8) | b
    if not keep_marker and value == (1 << (7 * length)) - 1:
        return -1, length  # all ones: unknown size
    return value, length


def _elements(buf: bytes, start: int, end: int):
    """(id, data start, data end) for the elements between start and end (end clipped to the buffer)."""
    pos = start
    end = min(end, len(buf))
    while pos < end - 1:
        try:
            eid, a = _vint(buf, pos, True)
            size, b = _vint(buf, pos + a, False)
        except (ValueError, IndexError):
            return
        data = pos + a + b
        stop = len(buf) if size < 0 else data + size
        yield eid, data, stop
        if size < 0:
            return
        pos = stop


def _uint(b: bytes) -> int:
    return int.from_bytes(b, "big") if b else 0


def _tracks_from(buf: bytes, start: int, end: int) -> List[dict]:
    out = []
    for eid, a, b in _elements(buf, start, end):
        if eid != _TRACKENTRY:
            continue
        t = {"type": "", "lang": "", "name": "", "codec": "", "default": True, "forced": False}
        language, bcp47 = "eng", ""  # Matroska's default language is English
        for cid, x, y in _elements(buf, a, b):
            v = buf[x:y]
            if cid == _TRACKTYPE:
                t["type"] = _TYPES.get(_uint(v), "")
            elif cid == _CODEC:
                t["codec"] = v.decode("ascii", "replace").strip("\0")
            elif cid == _NAME:
                t["name"] = v.decode("utf-8", "replace").strip("\0")
            elif cid == _LANGUAGE:
                language = v.decode("ascii", "replace").strip("\0")
            elif cid == _LANG_BCP47:
                bcp47 = v.decode("ascii", "replace").strip("\0")
            elif cid == _DEFAULT:
                t["default"] = bool(_uint(v))
            elif cid == _FORCED:
                t["forced"] = bool(_uint(v))
        t["lang"] = lang(bcp47 or language)
        if t["type"]:
            out.append(t)
    return out


def probe_mkv(path: str) -> Optional[List[dict]]:
    """The tracks of an MKV/WebM file, or None if they can't be found. Reads ~1.5 MB at most twice."""
    with open(path, "rb") as f:
        buf = f.read(READ_FIRST)
        if len(buf) < 8 or _vint(buf, 0, True)[0] != _EBML:
            return None
        pos = 0
        for eid, a, b in _elements(buf, 0, len(buf)):
            if eid == _SEGMENT:
                pos = a
                break
        else:
            return None
        seek_tracks = None
        for eid, a, b in _elements(buf, pos, len(buf)):
            if eid == _TRACKS:
                if b <= len(buf):
                    return _tracks_from(buf, a, b)
                f.seek(a)  # starts in the buffer but doesn't fit: read just its contents
                data = f.read(min(b - a, 8 * READ_FIRST))
                return _tracks_from(data, 0, len(data))
            if eid == _SEEKHEAD:
                for sid, x, y in _elements(buf, a, b):
                    if sid != _SEEK:
                        continue
                    target, where = None, None
                    for cid, u, w in _elements(buf, x, y):
                        if cid == _SEEKID:
                            target = _uint(buf[u:w])
                        elif cid == _SEEKPOS:
                            where = _uint(buf[u:w])
                    if target == _TRACKS and where is not None:
                        seek_tracks = pos + where
            if eid == _CLUSTER:
                break
        if seek_tracks is None:
            return None
        f.seek(max(0, seek_tracks))
        more = f.read(READ_FIRST)
    for eid, a, b in _elements(more, 0, len(more)):
        if eid == _TRACKS:
            return _tracks_from(more, a, b)
    return None


# -- MP4: the "moov" box (at the start or at the end of the file) --------------------------------------

_MP4_TYPES = {b"soun": "audio", b"vide": "video", b"subt": "sub", b"sbtl": "sub", b"text": "sub", b"clcp": "sub"}
MAX_MOOV = 16_000_000


def _boxes(buf: bytes, start: int, end: int):
    pos = start
    while pos + 8 <= end:
        size, kind = struct.unpack(">I4s", buf[pos:pos + 8])
        head = 8
        if size == 1 and pos + 16 <= end:
            size = struct.unpack(">Q", buf[pos + 8:pos + 16])[0]
            head = 16
        elif size == 0:
            size = end - pos
        if size < head:
            return
        yield kind, pos + head, min(pos + size, end)
        pos += size


def probe_mp4(path: str) -> Optional[List[dict]]:
    with open(path, "rb") as f:
        total = os.fstat(f.fileno()).st_size
        pos, moov = 0, None
        while pos + 8 <= total:
            f.seek(pos)
            head = f.read(16)
            if len(head) < 8:
                break
            size, kind = struct.unpack(">I4s", head[:8])
            hlen = 8
            if size == 1 and len(head) >= 16:
                size, hlen = struct.unpack(">Q", head[8:16])[0], 16
            elif size == 0:
                size = total - pos
            if size < hlen:
                break
            if kind == b"moov":
                if size > MAX_MOOV:
                    return None
                f.seek(pos + hlen)
                moov = f.read(size - hlen)
                break
            pos += size
    if not moov:
        return None
    out = []
    for kind, a, b in _boxes(moov, 0, len(moov)):
        if kind != b"trak":
            continue
        t = {"type": "", "lang": "", "name": "", "codec": "", "default": True, "forced": False}
        for k2, a2, b2 in _boxes(moov, a, b):
            if k2 != b"mdia":
                continue
            for k3, a3, b3 in _boxes(moov, a2, b2):
                if k3 == b"hdlr" and b3 - a3 >= 12:
                    t["type"] = _MP4_TYPES.get(moov[a3 + 8:a3 + 12], "")
                elif k3 == b"minf":
                    for k4, a4, b4 in _boxes(moov, a3, b3):
                        if k4 != b"stbl":
                            continue
                        for k5, a5, b5 in _boxes(moov, a4, b4):
                            if k5 == b"stsd" and b5 - a5 >= 16:
                                t["codec"] = moov[a5 + 12:a5 + 16].decode("ascii", "replace")
                elif k3 == b"mdhd" and b3 - a3 >= 24:
                    off = a3 + (32 if moov[a3] == 1 else 20)
                    packed = struct.unpack(">H", moov[off:off + 2])[0] if off + 2 <= b3 else 0
                    code = "".join(chr(((packed >> s) & 0x1F) + 0x60) for s in (10, 5, 0)) if packed else ""
                    t["lang"] = lang(code) if code.isalpha() else ""
        if t["type"]:
            out.append(t)
    return out


def probe(path: str) -> Optional[List[dict]]:
    """Tracks of a video file (MKV/WebM/MP4), or None for other kinds or when nothing is found."""
    ext = os.path.splitext(path)[1].lower()
    try:
        if ext in (".mkv", ".mk3d", ".webm", ".mka"):
            return probe_mkv(path)
        if ext in (".mp4", ".m4v", ".mov"):
            return probe_mp4(path)
    except (OSError, ValueError, struct.error, IndexError):
        return None
    return None


def summarize(tracks: List[dict]) -> Dict[str, List[str]]:
    audio = sorted({t["lang"] for t in tracks if t["type"] == "audio" and t["lang"]})
    subs = sorted({t["lang"] for t in tracks if t["type"] == "sub" and t["lang"] and not t.get("forced")})
    types = sorted({subtype(t.get("codec") or "") for t in tracks if t["type"] == "sub"} - {""})
    return {"audio": audio, "subs": subs, "subtypes": types}


def external_subtitles(video_path: str) -> List[Tuple[str, str]]:
    """(language, type) of subtitle files next to a video with the same start of name ("Show 01.de.ass")."""
    folder, name = os.path.split(video_path)
    stem = os.path.splitext(name)[0].casefold()
    out = []
    try:
        names = os.listdir(folder)
    except OSError:
        return out
    for n in names:
        base, ext = os.path.splitext(n)
        kind = SUB_EXTENSIONS.get(ext.lower())
        if not kind or not base.casefold().startswith(stem):
            continue
        rest = base[len(stem):].strip(" ._-").split(".")[-1] if base[len(stem):] else ""
        out.append((lang(rest) if rest and len(rest) <= 8 else "", kind))
    return out


def badges(audio: List[str], subs: List[str], subtypes: Optional[List[str]] = None) -> List[str]:
    """Short labels for cards: "DUB DE", "JA", "SUB DE·EN", "BURNED IN", "ASS"."""
    out = []
    for a in audio:
        out.append(a.upper() if a == "ja" else f"DUB {a.upper()}")
    if subs:
        out.append("SUB " + "·".join(s.upper() for s in subs))
    types = list(subtypes or [])
    if "hard" in types:
        out.append("BURNED IN")
    soft = [t for t in types if t != "hard"]
    if soft:
        out.append("/".join({"vobsub": "VOBSUB"}.get(t, t.upper()) for t in soft))
    return out
