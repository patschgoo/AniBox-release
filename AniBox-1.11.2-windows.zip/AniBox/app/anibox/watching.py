"""What you've watched and what comes next (Continue watching, Up next, show cards)."""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

RESUME_MIN_SECONDS = 30  # positions earlier than this start from the beginning


def episode_state(ep: dict, progress: Dict[str, dict]) -> dict:
    p = progress.get(ep["key"]) or {}
    pos, dur = float(p.get("position") or 0), float(p.get("duration") or 0)
    return {
        "watched": bool(p.get("watched")),
        "position": pos,
        "duration": dur,
        "percent": round(100 * pos / dur, 1) if dur > 0 else 0,
        "updated": float(p.get("updated") or 0),
    }


def next_up(show: dict, progress: Dict[str, dict]) -> Tuple[Optional[dict], float]:
    """The episode to play next and where to start (seconds, before the "go back a bit")."""
    eps = show.get("episodes") or []
    if not eps:
        return None, 0.0
    states = [episode_state(e, progress) for e in eps]
    touched = [i for i, s in enumerate(states) if s["updated"]]
    if touched:
        last = max(touched, key=lambda i: states[i]["updated"])
        s = states[last]
        if not s["watched"]:  # the one you were on (or un-marked, or started again from)
            return eps[last], s["position"] if s["position"] >= RESUME_MIN_SECONDS else 0.0
        for i in range(last + 1, len(eps)):
            if not states[i]["watched"]:  # e.g. after watching an old episode again: back to where you were
                p = states[i]["position"]
                return eps[i], p if p >= RESUME_MIN_SECONDS else 0.0
    for i, s in enumerate(states):
        if not s["watched"]:
            return eps[i], s["position"] if s["position"] >= RESUME_MIN_SECONDS else 0.0
    return None, 0.0


def resume_from(position: float, duration: float, back: int) -> float:
    if position < RESUME_MIN_SECONDS or (duration and position >= duration - 15):
        return 0.0
    return max(0.0, position - back)


def show_card(show: dict, progress: Dict[str, dict], posters: bool) -> dict:
    eps = show.get("episodes") or []
    watched = sum(1 for e in eps if (progress.get(e["key"]) or {}).get("watched"))
    nxt, pos = next_up(show, progress)
    last = max((float((progress.get(e["key"]) or {}).get("updated") or 0) for e in eps), default=0.0)
    return {
        "id": show["id"],
        "title": show["title"],
        "folder": show["folder"],
        "library": show["library"],
        "type": show.get("type") or "",
        "year": show.get("year"),
        "mal_id": show.get("mal_id"),
        "mal_episodes": show.get("mal_episodes"),
        "files": len(eps),
        "counted": show.get("counted", len(eps)),
        "watched": watched,
        "finished": bool(eps) and watched >= len(eps),
        "started": last > 0,
        "last_played": last,
        "added": show.get("added", 0),
        "poster": f"/img/{show['mal_id']}" if posters and show.get("mal_id") and show.get("picture") else "",
        "next": {"key": nxt["key"], "label": nxt["label"], "position": pos} if nxt else None,
    }


def continue_watching(shows: List[dict], progress: Dict[str, dict], posters: bool, limit: int = 12) -> List[dict]:
    cards = [show_card(s, progress, posters) for s in shows]
    cards = [c for c in cards if c["started"] and c["next"]]
    cards.sort(key=lambda c: c["last_played"], reverse=True)
    return cards[:limit]
