"""Your anime lists (MyAnimeList, AniList): the Lists page, list badges, sign-ins and sync.

Part of the App class (see server.py); the methods use the App's attributes. The work is done by
``listsync.ListService`` (``self.animelists``) and the rules in ``animelists.py``. Only the AniBox
window reaches these routes (never the phone remote): the route tables below are window-only.
"""

from __future__ import annotations

import logging

from .animelists import SOURCES, STATUS_NAMES, ListError
from .apierror import ApiError
from .listsync import ListService

log = logging.getLogger("anibox.server")


def _source(value) -> str:
    src = str(value or "")
    if src not in SOURCES:
        raise ApiError("Unknown list. Use mal or anilist.")
    return src


class RoutesListsMixin:
    GET_ROUTES = {
        "/api/lists": "_lists_view",
        "/api/lists/badges": "_lists_badges",
        "/api/lists/show": "_lists_show",
        "/api/lists/accounts": "_lists_accounts",
    }
    POST_ROUTES = {
        "/api/lists/refresh": "_lists_refresh",
        "/api/lists/mark": "_lists_mark",
        "/api/lists/connect": "_lists_connect",
        "/api/lists/oauth/mal": "_lists_oauth_mal",
        "/api/lists/oauth/anilist": "_lists_oauth_anilist",
        "/api/lists/disconnect": "_lists_disconnect",
        "/api/lists/sync/preview": "_lists_sync_preview",
        "/api/lists/sync/apply": "_lists_sync_apply",
        "/api/lists/sync/off": "_lists_sync_off",
    }
    # The sign-in pages MyAnimeList and AniList send the browser back to (registered in the user's apps).
    PAGE_FILES = {"/oauth/mal": "oauth.html", "/oauth/anilist": "oauth.html"}

    def _lists_init(self) -> None:
        self.animelists = ListService(self.store, self.library, self.data_dir / "lists")
        # Called when the player (on this PC or a TV) marks an episode as watched.
        self.store.watched_hooks.append(self.animelists.on_watched)

    @staticmethod
    def _lists_run(fn, *args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except ListError as exc:
            raise ApiError(str(exc), 400, "auth" if exc.auth else "")

    # -- reading ------------------------------------------------------------------------------------

    def _lists_view(self, query: dict) -> dict:
        out = self.animelists.view(str(query.get("source") or ""), refresh=query.get("refresh") == "1")
        out["statusNames"] = STATUS_NAMES
        return out

    def _lists_badges(self, query: dict) -> dict:
        return self.animelists.badges()

    def _lists_show(self, query: dict) -> dict:
        show = self.library.show(str(query.get("id") or ""))
        if not show:
            raise ApiError("Show not found", 404)
        return {"lines": self.animelists.show_lines(show)}

    def _lists_refresh(self, body: dict) -> dict:
        return self.animelists.refresh(_source(body.get("source")))

    def _lists_mark(self, body: dict) -> dict:
        shows = [str(s) for s in body.get("shows") or [] if s]
        if not shows:
            raise ApiError("Pick at least one show.")
        return dict(self._lists_run(self.animelists.mark, _source(body.get("source")), shows), ok=True)

    # -- accounts -----------------------------------------------------------------------------------

    def _lists_accounts(self, query: dict) -> dict:
        s = self.store.settings()
        out = {src: dict(self.animelists.account_info(src), redirect=f"http://127.0.0.1:{self.port}/oauth/{src}")
               for src in SOURCES}
        out["mal"]["hasClientId"] = bool(s.get("mal_client_id"))
        out["anilist"]["hasClientId"] = bool(s.get("anilist_client_id"))
        return {"accounts": out, "port": self.port, "rewatch": bool(s.get("lists_rewatch"))}

    def _lists_connect(self, body: dict) -> dict:
        return self._lists_run(self.animelists.connect, _source(body.get("source")))

    def _lists_oauth_mal(self, body: dict) -> dict:
        return self._lists_run(self.animelists.finish_mal, str(body.get("code") or ""), str(body.get("state") or ""),
                               str(body.get("error") or ""))

    def _lists_oauth_anilist(self, body: dict) -> dict:
        return self._lists_run(self.animelists.finish_anilist, str(body.get("access_token") or ""),
                               body.get("expires_in"), str(body.get("error") or ""))

    def _lists_disconnect(self, body: dict) -> dict:
        return self.animelists.disconnect(_source(body.get("source")))

    # -- sync -----------------------------------------------------------------------------------------

    def _lists_sync_preview(self, body: dict) -> dict:
        return self._lists_run(self.animelists.preview, _source(body.get("source")))

    def _lists_sync_apply(self, body: dict) -> dict:
        return self._lists_run(self.animelists.apply, _source(body.get("source")), str(body.get("token") or ""),
                               bool(body.get("turnOn")))

    def _lists_sync_off(self, body: dict) -> dict:
        return self.animelists.sync_off(_source(body.get("source")))
