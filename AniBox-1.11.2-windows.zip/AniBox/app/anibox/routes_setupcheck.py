"""Check my setup (setupcheck.py): start the checks, show their progress, save or copy the report.

Nothing runs until the window asks for it (``POST /api/setupcheck/start``, after a click). The page only
ever gets scrubbed text: the rows and the report go through the run's ``Scrubber`` first. The last
report is kept (scrubbed) in ``setup-check.json`` in AniBox's app folder, so it's still there after a
restart. These routes are for the AniBox window only, never the phone remote.

Part of the App class (see server.py); the methods use the App's attributes. The state lives in the
instance's ``__dict__`` (``_sc()``), so the App's ``__init__`` needs nothing for it.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from typing import List

from . import __version__, setupcheck
from .apierror import ApiError
from .selfupdate import downloads_dir
from .shortcut import open_folder

log = logging.getLogger("anibox.server")
_INIT = threading.Lock()

WINDOW_NUMBERS = ("iw", "ih", "ow", "oh", "sw", "sh")
WINDOW_FLAGS = ("standalone", "minimal", "locationbar", "toolbar")


def window_facts(raw) -> dict:
    """What the page says about itself, cleaned: only known keys, short texts, sane numbers."""
    if not isinstance(raw, dict):
        return {}
    out: dict = {}
    for k in ("ua", "platformVersion"):
        if isinstance(raw.get(k), str):
            out[k] = raw[k][:400]
    try:
        out["dpr"] = max(0.1, min(10.0, float(raw.get("dpr", 1))))
    except (TypeError, ValueError):
        out["dpr"] = 1.0
    for k in WINDOW_NUMBERS:
        try:
            out[k] = max(0, min(100000, int(raw.get(k))))
        except (TypeError, ValueError):
            pass
    for k in WINDOW_FLAGS:
        if isinstance(raw.get(k), bool):
            out[k] = raw[k]
    brands = raw.get("brands")
    if isinstance(brands, list):
        out["brands"] = [str(b)[:80] for b in brands[:10]]
    return out


class RoutesSetupCheckMixin:
    GET_ROUTES = {
        "/api/setupcheck": "_setup_get",
    }
    POST_ROUTES = {
        "/api/setupcheck/start": "_setup_start",
        "/api/setupcheck/save": "_setup_save",
        "/api/setupcheck/downloads": "_setup_downloads",
    }

    # -- state -------------------------------------------------------------------------------------------

    def _sc(self) -> dict:
        with _INIT:
            st = self.__dict__.get("_setup_state")
            if st is None:
                st = {"job": {"state": "idle"}, "rows": [], "view": [], "report": "", "lock": threading.Lock(),
                      "scrub": None, "ctx": None, "path": self.data_dir / "setup-check.json"}
                try:
                    saved = json.loads(st["path"].read_text(encoding="utf-8"))
                    if isinstance(saved.get("rows"), list) and isinstance(saved.get("report"), str):
                        st.update(view=saved["rows"], report=saved["report"],
                                  job={"state": "done", "finished": saved.get("finished"), "version": saved.get("version")})
                except (OSError, ValueError, AttributeError):
                    pass
                self.__dict__["_setup_state"] = st
        return st

    def _setup_scrubber(self) -> setupcheck.Scrubber:
        """A scrubber that knows this user's secrets and names before any check runs."""
        from anibox_check import cli as check_cli
        from . import plexhistory
        s = self.store.settings()
        secrets = [s.get(k) for k in ("mal_client_id", "tmdb_api_key", "anilist_client_id", "remote_key")]
        names = [(s.get("mal_username"), "<account>"), (s.get("anilist_username"), "<account>")]
        try:
            creds = plexhistory.saved_credentials()
            if creds:
                secrets += [creds[1], creds[2]]
            info = check_cli.load_settings().get(plexhistory.SERVER_INFO_KEY) or {}
            names.append((info.get("name"), "<Plex server>"))
        except Exception:
            log.info("Setup check: the Plex sign-in couldn't be read", exc_info=True)
        try:
            acc = self._media()["accounts"].get()
            secrets += [acc.get("jimaku_key"), acc.get("opensubtitles_key"), acc.get("opensubtitles_password")]
            names.append((acc.get("opensubtitles_user"), "<account>"))
        except Exception:
            log.info("Setup check: the subtitle accounts couldn't be read", exc_info=True)
        cache = getattr(self, "iacache", None)
        if cache is not None:
            secrets.append(getattr(cache, "token", ""))
        secrets += list((self.store.meta("tv_tokens") or {}).values())
        for dev in (self.store.meta("tv_devices") or {}).values():
            if isinstance(dev, dict) and str(dev.get("name") or "").casefold() not in ("", "castapp tv", "tv"):
                names.append((dev.get("name"), "<TV name>"))
        shows: List[str] = []
        for sh in self.library.shows(all_libraries=True):
            shows += [sh.get("folder") or "", sh.get("title") or ""]
        return setupcheck.Scrubber(secrets=[x for x in secrets if x], names=[(a, b) for a, b in names if a],
                                   shows=shows, known=s.get("folders") or [])

    def _setup_view(self, scrub: setupcheck.Scrubber, ctx, rows: List[dict]) -> List[dict]:
        if ctx is not None:
            with ctx.lock:
                scrub.add_names(list(ctx.names))
                scrub.add_secrets(list(ctx.secrets))
        out = []
        for r in rows:
            out.append({"id": r["id"], "group": r["group"], "title": scrub(r["title"]), "status": r["status"],
                        "line": scrub(r["line"]), "fix": scrub(r["fix"]), "details": [scrub(d) for d in r["details"]],
                        "seconds": r.get("seconds")})
        return out

    # -- routes ------------------------------------------------------------------------------------------

    def _setup_get(self, query: dict) -> dict:
        st = self._sc()
        with st["lock"]:
            job, rows, scrub, ctx = dict(st["job"]), list(st["rows"]), st["scrub"], st["ctx"]
            view, report = st["view"], st["report"]
        if job.get("state") == "running":
            view = self._setup_view(scrub, ctx, rows) if scrub is not None else []
            report = ""
        return {"job": job, "rows": view, "report": report, "groups": list(setupcheck.GROUPS),
                "marks": setupcheck.MARKS}

    def _setup_start(self, body: dict) -> dict:
        st = self._sc()
        window = window_facts(body.get("window"))
        with st["lock"]:
            if st["job"].get("state") == "running":
                return {"job": dict(st["job"])}
            st["job"] = {"state": "running", "started": time.time(), "done": 0, "total": 0}
            st["rows"], st["scrub"], st["ctx"] = [], None, None
            job = dict(st["job"])
        threading.Thread(target=self._setup_run, args=(window,), daemon=True, name="anibox-setup-check").start()
        return {"job": job}

    def _setup_run(self, window: dict) -> None:
        st = self._sc()
        started = time.time()
        try:
            scrub = self._setup_scrubber()
            ctx = setupcheck.Context(self, window)
            ctx.ssdp_targets = getattr(self, "setup_check_ssdp_targets", None)  # tests: a fake network
            ctx.discover_timeout = float(getattr(self, "setup_check_discover_timeout", 3.0))
            checks = setupcheck.build_checks(self, ctx)
            with st["lock"]:
                st["scrub"], st["ctx"] = scrub, ctx
                st["job"]["total"] = len(checks)

            def progress(rows: List[dict]) -> None:
                with st["lock"]:
                    st["rows"] = rows
                    st["job"]["done"] = sum(1 for r in rows if r["status"] in setupcheck.STATES)

            log.info("Setup check started (%d checks)", len(checks))
            rows = setupcheck.run_checks(checks, ctx, progress)
            meta = {"date": time.strftime("%Y-%m-%d %H:%M (%z)"), "version": __version__,
                    "seconds": time.time() - started}
            view = self._setup_view(scrub, ctx, rows)
            report = scrub(setupcheck.report_text(rows, meta))
            finished = time.time()
            saved = {"finished": finished, "version": __version__, "rows": view, "report": report}
            tmp = st["path"].with_suffix(".part")
            try:
                tmp.write_text(json.dumps(saved, ensure_ascii=False), encoding="utf-8")
                os.replace(tmp, st["path"])
            except OSError:
                log.warning("The setup check's report couldn't be kept in %s", st["path"].name, exc_info=True)
            with st["lock"]:
                st.update(view=view, report=report, rows=[], ctx=None,
                          job={"state": "done", "finished": finished, "version": __version__})
            log.info("Setup check done in %.1f s: %s", finished - started, setupcheck.summary_text(rows))
        except Exception as exc:  # shown on the page
            log.exception("Setup check failed")
            with st["lock"]:
                st.update(rows=[], ctx=None, job={"state": "error", "message": str(exc) or exc.__class__.__name__})

    def _setup_save(self, body: dict) -> dict:
        st = self._sc()
        with st["lock"]:
            running, report = st["job"].get("state") == "running", st["report"]
        if running:
            raise ApiError("The check is still running.")
        if not report:
            raise ApiError("Run the check first.")
        try:
            path = setupcheck.save_report(report, downloads_dir())
        except OSError as exc:
            raise ApiError(f"The report couldn't be saved in your Downloads folder ({exc.strerror or exc}).")
        log.info("Setup check report saved in Downloads as %s", path.name)
        return {"ok": True, "name": path.name}

    def _setup_downloads(self, body: dict) -> dict:
        try:
            open_folder(downloads_dir())
        except RuntimeError as exc:
            raise ApiError(str(exc))
        return {"ok": True}
