"""ffmpeg on request, "Plays on the TV?", TV-friendly subtitles and the online subtitle search.

Part of the App class (see server.py); the methods use the App's attributes. Only the AniBox window
reaches these routes (``GET_ROUTES``/``POST_ROUTES`` are never served to the phone remote).

Writing next to videos follows the user's rule "protect the old, allow the new": only for episodes
that aren't locked (new ones, or shows the user unlocked), never in protected folders, never over an
existing file, always logged for Undo (``subtitle-log.jsonl``).
"""

from __future__ import annotations

import json
import logging
import os
import secrets
import threading
import time
from typing import Dict, List, Optional

from . import languages, media, subsearch, tvcopy
from . import tv as tvlib
from .apierror import ApiError
from .ffmpegsetup import FfmpegSetup, find_tools, IS_WINDOWS

log = logging.getLogger("anibox.server")

_INIT_LOCK = threading.Lock()
CAPS_SECONDS = 600  # how long CastApp TV's answer is kept
MAX_SEARCHES = 20


def _ep_number(ep: dict) -> Optional[int]:
    return ep.get("number") if isinstance(ep.get("number"), int) else None


class RoutesMediaMixin:
    GET_ROUTES = {
        "/api/media/status": "_media_status",
        "/api/media/check": "_media_check_get",
        "/api/media/subs/preview": "_media_preview_get",
        "/api/media/subs/job": "_media_job",
        "/api/media/subs/search": "_media_search",
    }
    POST_ROUTES = {
        "/api/media/ffmpeg/install": "_media_ffmpeg_install",
        "/api/media/check": "_media_check_post",
        "/api/media/check/all": "_media_check_all",
        "/api/media/subs/preview": "_media_preview_post",
        "/api/media/subs/write": "_media_write",
        "/api/media/subs/undo": "_media_undo",
        "/api/media/subs/download": "_media_download",
        "/api/media/accounts": "_media_accounts",
    }

    # -- state (made on first use, so server.py needs no changes for it) --------------------------------

    def _media(self) -> dict:
        st = self.__dict__.get("_media_state")
        if st is not None:
            return st
        with _INIT_LOCK:
            st = self.__dict__.get("_media_state")
            if st is None:
                checks_path = self.data_dir / "media-checks.json"
                try:
                    verdicts = json.loads(checks_path.read_text(encoding="utf-8"))
                    verdicts = verdicts if isinstance(verdicts, dict) else {}
                except (OSError, ValueError):
                    verdicts = {}
                st = {
                    "setup": FfmpegSetup(self.data_dir),
                    "cache": media.InfoCache(self.data_dir / "media-info.json"),
                    "log": media.SubtitleLog(self.data_dir / "subtitle-log.jsonl"),
                    "accounts": subsearch.Accounts(self.data_dir / "subtitle-accounts.json"),
                    "checks": {},  # show id -> {"state", "result"}
                    "verdicts": verdicts,  # show id -> {"plex": level, "castapp": level, "at"} (library filter)
                    "verdicts_path": checks_path,
                    "plans": {},  # show id -> {"state", "token", "plan"}
                    "job": {"state": "idle"},  # writing TV-friendly subtitles (one at a time)
                    "all": {"state": "idle"},  # "Check every show"
                    "searches": {},
                    "caps": None,  # (time, device name, capabilities)
                    "bases": {"jimaku": subsearch.JIMAKU_BASE, "opensubtitles": subsearch.OPENSUBTITLES_BASE},
                    "lock": threading.Lock(),
                }
                self.__dict__["_media_state"] = st
        return st

    def _media_tools(self) -> Dict[str, Optional[str]]:
        return find_tools(self.data_dir, self.store.settings().get("ffmpeg_path") or "")

    def _media_show(self, show_id: str) -> dict:
        show = self.library.show(str(show_id or ""))
        if not show:
            raise ApiError("Show not found", 404)
        return show

    def _media_protected(self, show: dict) -> bool:
        from . import nfo
        return nfo.is_protected(show, self.store.settings().get("protected") or [])

    def _media_locked(self, show: dict) -> set:
        return self.library.lock_view(show)["keys"]

    # -- status and ffmpeg ------------------------------------------------------------------------------

    def _media_status(self, query: dict) -> dict:
        st = self._media()
        tools = self._media_tools()
        return {"ffmpeg": tools["ffmpeg"] or "", "ffprobe": tools["ffprobe"] or "", "setup": st["setup"].status,
                "canDownload": IS_WINDOWS, "accounts": st["accounts"].public(), "checkAll": st["all"],
                "howTo": subsearch.HOW_TO}

    def _media_ffmpeg_install(self, body: dict) -> dict:
        st = self._media()
        st["setup"].start()
        return {"ok": True, "status": st["setup"].status}

    def _media_accounts(self, body: dict) -> dict:
        changes = {k: body[k] for k in subsearch.FIELDS if k in body and isinstance(body[k], str)}
        try:
            self._media()["accounts"].update(changes)
        except OSError as exc:  # incl. secret.SecretError: Windows couldn't encrypt it
            raise ApiError(f"Couldn't save the keys ({exc}).")
        subsearch._TOKENS.clear()
        log.info("Subtitle site keys changed: %s", ", ".join(sorted(k for k in changes)) or "none")
        return {"ok": True, "accounts": self._media()["accounts"].public()}

    # -- "Plays on the TV?" ---------------------------------------------------------------------------

    def _media_castapp(self) -> tuple:
        """(name of the CastApp TV or "", its capabilities or {}), asked at most every 10 minutes."""
        st = self._media()
        hit = st["caps"]
        if hit and time.time() - hit[0] < CAPS_SECONDS:
            return hit[1], hit[2]
        name, caps = "", {}
        try:
            devices = [d for d in self.tv.known() if d.get("castapp")]
            last = self.store.settings().get("tv_device") or ""
            devices.sort(key=lambda d: d.get("id") != last)
            for dev in devices[:2]:
                try:
                    r = tvlib.Renderer(dev, token=self.tv._token(dev.get("id") or ""))
                except tvlib.TvError:
                    continue
                name = dev.get("name") or "CastApp TV"
                caps = r.capabilities()
                if caps:
                    break
        except Exception:
            log.exception("Asking CastApp TV what it plays failed")
        st["caps"] = (time.time(), name, caps)
        return name, caps

    def _media_sample(self, show: dict) -> List[dict]:
        eps = show["episodes"]
        picked = [eps[0], eps[len(eps) // 2]] if len(eps) > 1 else list(eps)
        out, seen = [], set()
        for e in picked:
            if e["key"] not in seen:
                seen.add(e["key"])
                out.append(e)
        return out

    def _media_save_verdicts(self) -> None:
        st = self._media()
        with st["lock"]:
            data = json.dumps(st["verdicts"], ensure_ascii=False)
            try:
                tmp = st["verdicts_path"].with_suffix(".part")
                tmp.write_text(data, encoding="utf-8")
                os.replace(tmp, st["verdicts_path"])
            except OSError as exc:
                log.warning("Couldn't save the TV check results: %s", exc)

    def _media_run_check(self, show: dict, save: bool = True) -> dict:
        st = self._media()
        tools = self._media_tools()
        sample = self._media_sample(show)
        infos = [(e["file"], media.probe(e["path"], tools["ffprobe"], st["cache"])) for e in sample]
        if save:
            st["cache"].save()
        device, caps = self._media_castapp()
        copies = {e["file"] for e in sample if tvcopy.copy_for(e["path"])}  # "TV copy ready" (tvcopy.py)
        plex = media.check_show(infos, media.PLEX, copies=copies)
        cast = media.check_show(infos, media.CASTAPP, caps, copies)
        if device:
            cast["name"] = f"CastApp TV ({device})" if device != "CastApp TV" else device
        cast["device"] = device
        cast["capsKnown"] = bool(caps)
        result = {"targets": [plex, cast], "ffprobe": bool(tools["ffprobe"]), "at": time.time(),
                  "scan": self.library.scanned_at}
        with st["lock"]:
            st["verdicts"][show["id"]] = {"plex": plex["level"], "castapp": cast["level"], "at": time.time()}
        if save:
            self._media_save_verdicts()
        return result

    def _media_check_start(self, show: dict) -> None:
        st = self._media()
        with st["lock"]:
            cur = st["checks"].get(show["id"])
            if cur and cur.get("state") == "loading":
                return
            st["checks"][show["id"]] = {"state": "loading", "result": (cur or {}).get("result")}

        def run():
            try:
                result = self._media_run_check(show)
                st["checks"][show["id"]] = {"state": "done", "result": result}
                log.info("TV check of %s: Plex %s, CastApp TV %s", show["id"], result["targets"][0]["level"],
                         result["targets"][1]["level"])
            except Exception as exc:
                log.exception("TV check of %s failed", show["id"])
                st["checks"][show["id"]] = {"state": "error", "error": str(exc)}

        threading.Thread(target=run, daemon=True, name="anibox-tvcheck").start()

    def _media_check_get(self, query: dict) -> dict:
        show = self._media_show(query.get("id", ""))
        st = self._media()
        cur = st["checks"].get(show["id"])
        res = (cur or {}).get("result") or {}
        stale = bool(res) and (res.get("scan") != self.library.scanned_at  # scanned again since
                               or (not res.get("ffprobe") and self._media_tools()["ffprobe"]))  # ffmpeg is there now
        if not cur or (stale and cur.get("state") != "loading"):
            self._media_check_start(show)
            cur = st["checks"].get(show["id"]) or {"state": "loading"}
        out = {"state": cur.get("state"), "error": cur.get("error", "")}
        if cur.get("result"):
            out.update(cur["result"])
        return out

    def _media_check_post(self, body: dict) -> dict:
        show = self._media_show(body.get("show"))
        if body.get("refresh"):
            self._media()["caps"] = None
        self._media_check_start(show)
        return {"ok": True}

    def _media_check_all(self, body: dict) -> dict:
        """Check the first and a middle episode of every show (for the library filter)."""
        st = self._media()
        if st["all"].get("state") == "running":
            return {"ok": True, "job": st["all"]}
        shows = self.library.shows()
        job = {"state": "running", "done": 0, "total": len(shows), "convert": 0}
        st["all"] = job

        def run():
            try:
                for i, sh in enumerate(shows, 1):
                    try:
                        result = self._media_run_check(sh, save=False)
                        st["checks"][sh["id"]] = {"state": "done", "result": result}
                        if any(t["level"] == media.CONVERT for t in result["targets"]):
                            job["convert"] += 1
                    except Exception:
                        log.exception("TV check of %s failed", sh["id"])
                    job["done"] += 1
                    if i % 25 == 0:  # saved now and then, not after every show
                        st["cache"].save()
                        self._media_save_verdicts()
                st["cache"].save()
                self._media_save_verdicts()
                job["state"] = "done"
                log.info("TV check of every show: %d of %d may need converting", job["convert"], job["total"])
            except Exception as exc:
                job.update(state="error", message=str(exc))

        threading.Thread(target=run, daemon=True, name="anibox-tvcheck-all").start()
        return {"ok": True, "job": job}

    def _cards_with_langs(self, pairs) -> list:
        """Cards get ``tvWarn`` for shows the TV check found that need converting (library filter)."""
        cards = super()._cards_with_langs(pairs)
        verdicts = self._media()["verdicts"]
        for c in cards:
            v = verdicts.get(c.get("id"))
            if v:
                c["tvWarn"] = media.CONVERT in (v.get("plex"), v.get("castapp"))
        return cards

    # -- TV-friendly subtitles ------------------------------------------------------------------------

    def _media_preview_post(self, body: dict) -> dict:
        show = self._media_show(body.get("show"))
        st = self._media()
        with st["lock"]:
            cur = st["plans"].get(show["id"])
            if cur and cur.get("state") == "loading":
                return {"ok": True, "state": "loading"}
            st["plans"][show["id"]] = {"state": "loading", "done": 0, "total": len(show["episodes"])}
        entry = st["plans"][show["id"]]

        def run():
            try:
                tools = self._media_tools()
                locked = self._media_locked(show)
                protected = self._media_protected(show)
                infos = {}
                if not protected:
                    for e in show["episodes"]:
                        if e["key"] not in locked:  # locked episodes aren't even read
                            infos[e["key"]] = media.probe(e["path"], tools["ffprobe"], st["cache"])
                        entry["done"] += 1
                st["cache"].save()
                plan = media.plan_subtitles(show, infos, locked, protected, bool(tools["ffmpeg"]))
                plan["ffmpeg"] = bool(tools["ffmpeg"])
                st["plans"][show["id"]] = {"state": "done", "token": secrets.token_urlsafe(8), "plan": plan}
                log.info("TV-friendly subtitles preview for %s: %s", show["id"], plan["counts"])
            except Exception as exc:
                log.exception("Subtitle preview of %s failed", show["id"])
                st["plans"][show["id"]] = {"state": "error", "error": str(exc)}

        threading.Thread(target=run, daemon=True, name="anibox-subs-preview").start()
        return {"ok": True, "state": "loading"}

    def _media_preview_get(self, query: dict) -> dict:
        show = self._media_show(query.get("id", ""))
        st = self._media()
        cur = st["plans"].get(show["id"]) or {"state": "none"}
        out = {"state": cur["state"], "error": cur.get("error", ""), "done": cur.get("done", 0), "total": cur.get("total", 0),
               "added": len(st["log"].entries(show["id"]))}
        if cur.get("plan"):
            plan = cur["plan"]
            out.update(token=cur["token"], counts=plan["counts"], new=plan["new"], ffmpeg=plan.get("ffmpeg"),
                       items=[dict({k: it.get(k) for k in ("file", "action", "reason", "lang", "label", "forced", "source")},
                                   name=os.path.basename(it.get("path") or ""))
                              for it in plan["items"] if it["action"] != media.SKIP_LOCKED])  # locked ones: only counted
        return out

    def _media_still_allowed(self, show_id: str):
        def allowed(key: str) -> bool:
            show = self.library.show(show_id)
            return bool(show) and not self._media_protected(show) and key not in self._media_locked(show)
        return allowed

    def _media_write(self, body: dict) -> dict:
        show = self._media_show(body.get("show"))
        st = self._media()
        cur = st["plans"].get(show["id"]) or {}
        if cur.get("state") != "done" or cur.get("token") != str(body.get("token") or ""):
            raise ApiError("Make a new preview first.")
        if st["job"].get("state") == "running":
            raise ApiError("AniBox is still making subtitles for another show. Wait a moment.")
        plan = cur["plan"]
        st["plans"].pop(show["id"], None)  # a preview is written once
        job = {"state": "running", "show": show["id"], "done": 0, "total": plan["new"], "written": 0, "errors": []}
        st["job"] = job

        def progress(done, total):
            job.update(done=done, total=total)

        def run():
            try:
                tools = self._media_tools()
                result = media.write_subtitles(plan, tools["ffmpeg"], st["log"], self._media_still_allowed(show["id"]), progress)
                job.update(state="done", **result)
                log.info("TV-friendly subtitles for %s: %d written, %d skipped, %d failed", show["id"], result["written"],
                         result["skipped"], result["failed"])
            except Exception as exc:
                log.exception("Writing subtitles for %s failed", show["id"])
                job.update(state="error", message=str(exc))
            self._media_changed(show)

        threading.Thread(target=run, daemon=True, name="anibox-subs-write").start()
        return {"ok": True, "job": job}

    def _media_job(self, query: dict) -> dict:
        return dict(self._media()["job"])

    def _media_changed(self, show: dict) -> None:
        """Subtitle files next to the videos changed: read the languages again, check again later."""
        st = self._media()
        st["checks"].pop(show["id"], None)
        try:
            self._probe_langs(show)
        except Exception:
            log.exception("Reading the languages of %s again failed", show["id"])

    def _media_undo(self, body: dict) -> dict:
        show_id = str(body.get("show") or "")
        st = self._media()
        if st["job"].get("state") == "running":
            raise ApiError("Wait until AniBox has finished making subtitles.")
        if not st["log"].entries(show_id or None):
            raise ApiError("There's nothing to undo.")
        result = st["log"].undo(show_id or None)
        log.info("Subtitle files undone for %s: %s", show_id or "all shows",
                 {k: v for k, v in result.items() if k not in ("kept_paths", "errors")})
        show = self.library.show(show_id) if show_id else None
        if show:
            self._media_changed(show)
        return {"ok": True, **result}

    # -- online search ----------------------------------------------------------------------------------

    def _media_provider(self, name: str):
        acc = self._media()["accounts"].get()
        bases = self._media()["bases"]
        if name == "jimaku":
            return subsearch.Jimaku(acc["jimaku_key"], bases["jimaku"])
        if name == "opensubtitles":
            return subsearch.OpenSubtitles(acc["opensubtitles_key"], acc["opensubtitles_user"],
                                           acc["opensubtitles_password"], bases["opensubtitles"])
        raise ApiError("Unknown subtitle site.")

    def _media_episode(self, show: dict, key: str) -> dict:
        for e in show["episodes"]:
            if e["key"] == key:
                return e
        raise ApiError("Episode not found", 404)

    def _media_ids(self, show: dict) -> dict:
        """AniList and IMDb numbers and the TMDB/TVDB season of the show's MyAnimeList entry (Fribb's list)."""
        mal = str(show.get("mal_id") or "")
        if not mal:
            return {}
        try:
            for m in self.library.datasets().mapping:
                if str(m.get("mal_id") or "") == mal:
                    season = m.get("season") if isinstance(m.get("season"), dict) else {}
                    imdb = str(m.get("imdb_id") or "")
                    return {"anilist": m.get("anilist_id"), "imdb": int(imdb[2:]) if imdb.startswith("tt") and imdb[2:].isdigit() else None,
                            "season": season.get("tmdb") or season.get("tvdb")}
        except Exception:
            log.exception("Reading the anime lists failed")
        return {}

    def _media_search(self, query: dict) -> dict:
        show = self._media_show(query.get("show", ""))
        ep = self._media_episode(show, str(query.get("key") or ""))
        name = str(query.get("provider") or "")
        try:
            provider = self._media_provider(name)
        except subsearch.SubtitleError as exc:
            return {"ok": False, "reason": exc.reason, "error": str(exc), "results": []}
        ids = self._media_ids(show)
        number = _ep_number(ep)
        text = str(query.get("q") or "").strip() or show.get("title") or show["folder"]
        try:
            if name == "jimaku":
                results = provider.search(anilist_id=ids.get("anilist"), query=text, episode=number)
            else:
                langs = str(query.get("langs") or self.store.settings().get("sub_langs") or "")
                codes = sorted({languages.lang(x) for x in langs.replace(";", ",").replace(" ", ",").split(",")} - {""})
                results = provider.search(query=text, episode=number, season=ids.get("season") if ids.get("imdb") else None,
                                          languages=codes, moviehash=subsearch.movie_hash(ep["path"]),
                                          parent_imdb=ids.get("imdb"))
        except subsearch.SubtitleError as exc:
            log.info("Subtitle search on %s: %s", name, exc)
            return {"ok": False, "reason": exc.reason, "error": str(exc), "results": []}
        st = self._media()
        token = secrets.token_urlsafe(8)
        with st["lock"]:
            st["searches"][token] = {"provider": name, "show": show["id"], "key": ep["key"], "results": results}
            while len(st["searches"]) > MAX_SEARCHES:
                st["searches"].pop(next(iter(st["searches"])))
        locked = ep["key"] in self._media_locked(show) or self._media_protected(show)
        log.info("Subtitle search on %s for %s: %d results", name, ep["key"], len(results))
        return {"ok": True, "token": token, "locked": locked,
                "results": [dict({k: r.get(k) for k in ("name", "release", "lang", "format", "size", "downloads", "hashMatch",
                                                         "downloadable", "note", "title")}, id=i) for i, r in enumerate(results)]}

    def _media_download(self, body: dict) -> dict:
        st = self._media()
        search = st["searches"].get(str(body.get("token") or ""))
        if not search:
            raise ApiError("Search again first.")
        try:
            result = search["results"][int(body.get("id"))]
        except (TypeError, ValueError, IndexError):
            raise ApiError("That result isn't there anymore. Search again.")
        if not result.get("downloadable"):
            raise ApiError("AniBox can't use this file" + (f" ({result['note']})." if result.get("note") else "."))
        show = self._media_show(search["show"])
        ep = self._media_episode(show, search["key"])
        if self._media_protected(show):
            raise ApiError("This show is in a protected folder: AniBox writes nothing there.")
        if ep["key"] in self._media_locked(show):
            raise ApiError("This episode was already there and is locked. Unlock the show first to add files next to it.")
        ext = os.path.splitext(result.get("name") or "")[1].lower() if search["provider"] == "jimaku" else ".srt"
        if ext not in subsearch.SUB_EXTS:
            raise ApiError("AniBox can't use this file.")
        lang = media.safe_lang(result.get("lang") or "")
        folder, name = os.path.split(ep["path"])
        target = os.path.join(folder, os.path.splitext(name)[0] + (f".{lang}" if lang else "") + ext)
        try:
            existing = {n.casefold() for n in os.listdir(folder)}
        except OSError as exc:
            raise ApiError(f"AniBox can't read the folder ({exc.strerror or exc}).")
        if os.path.basename(target).casefold() in existing:
            raise ApiError(f"{os.path.basename(target)} is already there; AniBox never replaces a file.")
        try:
            data = self._media_provider(search["provider"]).fetch(result)
        except subsearch.SubtitleError as exc:
            raise ApiError(str(exc), 400, exc.reason)
        head = data[:200].lstrip(b"\xef\xbb\xbf").lstrip().lower()
        if not data.strip() or head.startswith((b"<!doctype", b"<html", b"pk\x03\x04", b"rar!")) or b"\0" in data[:4000]:
            raise ApiError("The download isn't a subtitle file.")
        try:
            media.write_new_file(target, data)
        except FileExistsError:
            raise ApiError(f"{os.path.basename(target)} is already there; AniBox never replaces a file.")
        except OSError as exc:
            raise ApiError(f"Couldn't save it next to the video ({exc.strerror or exc}).")
        st["log"].add(show["id"], ep["key"], target, data, "downloaded", search["provider"])
        log.info("Subtitle from %s saved: %s", search["provider"], target)
        self._media_changed(show)
        return {"ok": True, "file": os.path.basename(target), "added": len(st["log"].entries(show["id"]))}
