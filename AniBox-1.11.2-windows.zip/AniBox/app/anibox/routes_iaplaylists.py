"""Series playlists of Internet Archive videos (iaplaylists.py): the routes for the window.

All of them are for the AniBox window only (the phone remote can't reach them); changes are POSTs
with the ``X-AniBox: 1`` header like everywhere else. Playing goes through ``/api/play`` with
``{show: "ia:@<id>", key}``, so next and previous follow the playlist.

Part of the App class (see server.py); the methods use the App's attributes.
"""

from __future__ import annotations

from . import iaplaylists
from .apierror import ApiError
from .iarchive import valid_id


def _keys(body: dict) -> list:
    keys = body.get("keys")
    if not isinstance(keys, list) or not all(isinstance(k, str) for k in keys) or len(keys) > 20000:
        raise ApiError("Pick at least one episode.")
    return keys


class RoutesIaPlaylistsMixin:
    GET_ROUTES = {
        "/api/ia/playlists": "_pl_list",
        "/api/ia/playlists/one": "_pl_one",
        "/api/ia/playlists/edit": "_pl_edit",
    }
    POST_ROUTES = {
        "/api/ia/playlists/scan": "_pl_scan",
        "/api/ia/playlists/preview": "_pl_preview",
        "/api/ia/playlists/create": "_pl_create",
        "/api/ia/playlists/save": "_pl_save",
        "/api/ia/playlists/rename": "_pl_rename",
        "/api/ia/playlists/sort": "_pl_sort",
        "/api/ia/playlists/order": "_pl_order",
        "/api/ia/playlists/hide": "_pl_hide",
        "/api/ia/playlists/watched": "_pl_watched",
        "/api/ia/playlists/refresh": "_pl_refresh",
        "/api/ia/playlists/delete": "_pl_delete",
    }

    def _playlists_init(self) -> None:
        """After _stream_init: the playlists are shows of the Internet Archive streams."""
        self.playlists = iaplaylists.IaPlaylists(self.data_dir, self.ia_client, self.streams, self.store)
        self.streams.providers.append(self.playlists)

    def _pl(self, fn, *args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except iaplaylists.PlaylistError as exc:
            raise ApiError(str(exc), exc.status)

    # -- GET ---------------------------------------------------------------------------------------------

    def _pl_list(self, query: dict) -> dict:
        item = query.get("item", "")
        return {"playlists": self.playlists.summaries(), "notice": self.playlists.notice,
                "withItem": self.playlists.playlists_with(item) if valid_id(item) else []}

    def _pl_one(self, query: dict) -> dict:
        return self._pl(self.playlists.page, query.get("id", ""))

    def _pl_edit(self, query: dict) -> dict:
        return self._pl(self.playlists.editor, query.get("id", ""))

    # -- POST --------------------------------------------------------------------------------------------

    def _pl_scan(self, body: dict) -> dict:
        return {"items": self._pl(self.playlists.scan, body.get("links") or body.get("items") or "")}

    def _pl_preview(self, body: dict) -> dict:
        items = body.get("items")
        return {"episodes": self._pl(self.playlists.preview, str(body.get("sort") or ""),
                                     items if isinstance(items, list) else None, str(body.get("id") or ""))}

    def _pl_create(self, body: dict) -> dict:
        out = self._pl(self.playlists.create, body.get("name") or "", str(body.get("sort") or ""), body.get("items"))
        return {"ok": True, "playlist": out}

    def _pl_save(self, body: dict) -> dict:
        name = body.get("name")
        out = self._pl(self.playlists.save, str(body.get("id") or ""), body.get("items"),
                       str(name) if name is not None else None)
        return {"ok": True, "playlist": out}

    def _pl_rename(self, body: dict) -> dict:
        return {"ok": True, "playlist": self._pl(self.playlists.rename, str(body.get("id") or ""), body.get("name") or "")}

    def _pl_sort(self, body: dict) -> dict:
        return {"ok": True, "playlist": self._pl(self.playlists.set_sort, str(body.get("id") or ""), str(body.get("sort") or ""))}

    def _pl_order(self, body: dict) -> dict:
        return {"ok": True, "playlist": self._pl(self.playlists.set_order, str(body.get("id") or ""), _keys(body))}

    def _pl_hide(self, body: dict) -> dict:
        n = self._pl(self.playlists.set_hidden, str(body.get("id") or ""), _keys(body), bool(body.get("hidden", True)))
        return {"ok": True, "count": n}

    def _pl_watched(self, body: dict) -> dict:
        n = self._pl(self.playlists.set_watched, str(body.get("id") or ""), _keys(body), bool(body.get("watched", True)))
        return {"ok": True, "count": n}

    def _pl_refresh(self, body: dict) -> dict:
        return {"ok": True, **self._pl(self.playlists.refresh, str(body.get("id") or ""))}

    def _pl_delete(self, body: dict) -> dict:
        self._pl(self.playlists.delete, str(body.get("id") or ""))
        return {"ok": True}
