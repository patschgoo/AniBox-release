"""Openings and endings without chapter marks: found by comparing the sound of a show's episodes.

Many anime files have no chapters, so the player's Skip button (player.py, chapters named "Opening",
"ED" …) has nothing to go by. Plex finds intros and credits by comparing episodes' audio; this does
the same, on this PC, on request (or, if switched on, when a show's page opens):

1. **Only a little of each file is read.** ffmpeg decodes just the first ~6 minutes (openings often
   come after a cold open) and the last ~5 minutes, with fast seeking (``-ss``/``-t`` before ``-i``),
   as mono audio at a low sample rate. Nothing is ever written next to the videos.
2. **A compact fingerprint** per window, one number every ~0.1 s:
   - ``chromaprint``: ffmpeg's Chromaprint muxer (``-f chromaprint -fp_format raw``), when this
     ffmpeg has it (Linux packages usually do; Gyan's Windows "essentials" build doesn't).
   - ``bands``, otherwise: ffmpeg does the heavy part (16 band-pass filters, squaring with
     ``amultiply``, resampling the energy down to 100 values a second); Python turns the band
     energies into 31-bit patterns in the style of Haitsma & Kalker's audio fingerprints (does the
     difference between neighbouring bands grow or shrink; does each band get louder).
3. **Matching** works like Jellyfin's Intro Skipper plugin (github.com/intro-skipper/intro-skipper,
   ``ChromaprintAnalyzer.cs``): equal fingerprint values (an inverted index, here over both 16-bit
   halves so a few flipped bits don't hide a match) vote for how far one episode is shifted against
   the other; along the best shifts, points whose bits differ in at most a few places (Hamming
   distance) count as the same sound, short gaps are allowed, and the longest run is the shared part.
4. **Several partners per episode** (the nearest episodes of the same folder) and a consensus: the
   first episode often has no opening and a finale may differ, so one pair isn't enough. An opening
   is a shared part of about 45–115 s near the start, an ending one of about 35–155 s near the end
   (it may end before the file does: "ending, then a preview of the next episode").

Results are kept in ``<data>/skip-markers.json`` by file path, size and modified time (a changed
file is looked at again). Chapters in the file always win over anything found here.
"""

from __future__ import annotations

import json
import logging
import math
import os
import re
import struct
import subprocess
import sys
import threading
import time
from array import array
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Optional, Sequence, Tuple

log = logging.getLogger("anibox.introdetect")

IS_WINDOWS = sys.platform.startswith("win")
# No console window on Windows, and a lower priority so the player and the PC stay smooth.
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0) | getattr(subprocess, "BELOW_NORMAL_PRIORITY_CLASS", 0)
CACHE_VERSION = 1
DECODE_TIMEOUT = 300  # a few minutes of a file on the Shield's drives, read over the network
PROBE_TIMEOUT = 60

KINDS = ("opening", "ending")
CHROMAPRINT = "chromaprint"
BANDS = "bands"

# Chromaprint: 11025 Hz, 4096-sample frames with 2/3 overlap -> one value every 1365 samples.
CHROMA_RATE = 11025
CHROMA_HOP = 1365 / CHROMA_RATE  # 0.1238 s (Intro Skipper's "SampleDuration")
# Each Chromaprint value looks at ~16 frames (about 2 s), so a shared part's last matching value
# starts well before the part ends; both edges measured on made-up episodes (tests/test_introdetect.py).
CHROMA_LEAD = 0.75
CHROMA_TAIL = 1.15

# AniBox's own fingerprint: 16 bands between 150 and 3400 Hz, energy windows of 0.3 s every 0.1 s.
BAND_COUNT = 16
BAND_RATE = 8000
BAND_LOW, BAND_HIGH = 150.0, 3400.0
ENVELOPE_RATE = 100
BAND_HOP = 0.1
BAND_SILENCE = 1e-7  # mean power below this (about -70 dB): too quiet to compare
BAND_LEAD = -0.25  # edges measured like Chromaprint's
BAND_TAIL = 0.1

POP16 = bytes(bin(i).count("1") for i in range(1 << 16))
WINDOW = 8  # points compared together (about 1 s)
ENTRY_KEYS = ("size", "mtime", "show", "duration", "at", "method", "partners", "chapters", "found", "manual", "note")


class DetectError(Exception):
    """Something the user can act on (no ffmpeg, a file that can't be read …)."""


class Cancelled(Exception):
    """The user clicked Cancel."""


class Params:
    """Time limits. Tests use shorter ones (``Params(start_window=30, …)``) with short made-up episodes."""

    def __init__(self, start_window: float = 360.0, end_window: float = 300.0,
                 opening: Tuple[float, float] = (45.0, 115.0), ending: Tuple[float, float] = (35.0, 155.0),
                 max_gap: float = 3.0, min_density: float = 0.35, partners: int = 4, tolerance: float = 4.0,
                 min_confidence: float = 0.35, min_duration: float = 180.0, snap_start: float = 2.0,
                 snap_end: float = 3.0, max_bits: Optional[Dict[str, int]] = None):
        self.start_window = float(start_window)
        self.end_window = float(end_window)
        self.opening = (float(opening[0]), float(opening[1]))
        self.ending = (float(ending[0]), float(ending[1]))
        self.max_gap = float(max_gap)  # seconds without a matching point inside one shared part
        self.min_density = float(min_density)  # share of matching points inside a shared part
        self.partners = int(partners)  # episodes each episode is compared with
        self.tolerance = float(tolerance)  # partners agree when start and end are this close (s)
        self.min_confidence = float(min_confidence)
        self.min_duration = float(min_duration)  # shorter files are left out (trailers, clips)
        self.snap_start = float(snap_start)  # an opening this close to 0:00 starts at 0:00
        self.snap_end = float(snap_end)  # an ending this close to the end goes to the end
        # The same sound: over ~1 s, values differ in at most this many of their 31/32 bits on average
        # (Intro Skipper allows 6 of 32 per single Chromaprint value; random sound differs in ~16).
        self.max_bits = dict(max_bits or {CHROMAPRINT: 8.0, BANDS: 6.0})

    def bounds(self, kind: str) -> Tuple[float, float]:
        return self.opening if kind == "opening" else self.ending


PARAMS = Params()


# -- running ffmpeg ------------------------------------------------------------------------------------

def _run(args: List[str], timeout: float, cancel: Optional[threading.Event] = None) -> Tuple[int, bytes, bytes]:
    """Run a program without a console window; Cancel and the timeout stop it."""
    try:
        proc = subprocess.Popen(args, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                creationflags=NO_WINDOW)
    except OSError as exc:
        raise DetectError(f"Couldn't start {os.path.basename(args[0])} ({exc}).")
    deadline = time.time() + timeout
    while True:
        try:
            out, err = proc.communicate(timeout=0.3)
            return proc.returncode, out or b"", err or b""
        except subprocess.TimeoutExpired:
            stop = cancel is not None and cancel.is_set()
            if stop or time.time() > deadline:
                proc.kill()
                try:
                    proc.communicate(timeout=10)
                except (subprocess.TimeoutExpired, OSError):
                    pass
                if stop:
                    raise Cancelled()
                raise DetectError("Reading the file took too long.")


_CHROMAPRINT_CACHE: Dict[str, bool] = {}


def has_chromaprint(ffmpeg: str) -> bool:
    """Does this ffmpeg have the Chromaprint muxer (``ffmpeg -hide_banner -muxers``)?"""
    if not ffmpeg:
        return False
    if ffmpeg not in _CHROMAPRINT_CACHE:
        try:
            code, out, _ = _run([ffmpeg, "-hide_banner", "-muxers"], 30)
            text = out.decode("utf-8", "replace")
            _CHROMAPRINT_CACHE[ffmpeg] = code == 0 and bool(re.search(r"^\s*E\S*\s+chromaprint\b", text, re.M))
        except (DetectError, Cancelled):
            _CHROMAPRINT_CACHE[ffmpeg] = False
    return _CHROMAPRINT_CACHE[ffmpeg]


def pick_method(ffmpeg: str, wanted: str = "") -> str:
    if wanted in (CHROMAPRINT, BANDS):
        return CHROMAPRINT if wanted == CHROMAPRINT and has_chromaprint(ffmpeg) else BANDS
    return CHROMAPRINT if has_chromaprint(ffmpeg) else BANDS


_DURATION_RE = re.compile(rb"Duration:\s*(\d+):(\d\d):(\d\d(?:\.\d+)?)")


def probe(path: str, ffprobe: Optional[str], ffmpeg: Optional[str] = None,
          cancel: Optional[threading.Event] = None) -> dict:
    """``{"duration": seconds, "chapters": [(kind, start, end)]}`` from the file's header.

    Chapters are read with ffprobe (the start of the file only); without ffprobe the duration comes
    from ffmpeg's own description of the file and chapters stay unknown."""
    if ffprobe:
        code, out, err = _run([ffprobe, "-v", "error", "-print_format", "json", "-show_format", "-show_chapters",
                               "-i", path], PROBE_TIMEOUT, cancel)
        if code != 0:
            raise DetectError(err.decode("utf-8", "replace").strip()[-200:] or "ffprobe couldn't read the file.")
        try:
            obj = json.loads(out.decode("utf-8", "replace") or "{}")
        except ValueError:
            raise DetectError("ffprobe's answer couldn't be read.")
        try:
            duration = float((obj.get("format") or {}).get("duration") or 0)
        except (TypeError, ValueError):
            duration = 0.0
        chapters = []
        for ch in obj.get("chapters") or []:
            try:
                chapters.append({"title": str((ch.get("tags") or {}).get("title") or ""), "time": float(ch.get("start_time") or 0)})
            except (TypeError, ValueError):
                continue
        from .player import skip_segments  # (player.py imports this module)
        return {"duration": duration, "chapters": skip_segments(chapters, duration) if chapters else []}
    if not ffmpeg:
        raise DetectError("ffmpeg isn't installed.")
    _, _, err = _run([ffmpeg, "-hide_banner", "-nostdin", "-i", path], PROBE_TIMEOUT, cancel)
    m = _DURATION_RE.search(err)
    if not m:
        raise DetectError("ffmpeg couldn't tell how long the file is.")
    return {"duration": int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3)), "chapters": []}


# -- fingerprints ------------------------------------------------------------------------------------

class Print:
    """The fingerprint of one window of a file: ``values[i]`` describes the sound at
    ``offset + i * hop`` seconds; ``valid[i]`` is False where there's nothing to compare (silence,
    a steady tone)."""

    def __init__(self, values: Sequence[int], valid: Sequence[bool], hop: float, offset: float,
                 lead: float = 0.0, tail: float = 0.0, method: str = "", length: Optional[float] = None):
        self.values = list(values)
        self.valid = bytearray(1 if v else 0 for v in valid)
        self.hop = hop
        self.offset = offset
        self.lead = lead
        self.tail = tail
        self.method = method
        self.length = float(length) if length is not None else len(self.values) * hop  # seconds decoded
        ok = [i for i, v in enumerate(self.valid) if v]
        self._first, self._last = (ok[0], ok[-1]) if ok else (0, -1)
        self._index = None

    def __len__(self) -> int:
        return len(self.values)

    def start_time(self, i: int) -> float:
        if i <= self._first + 2:  # shared from the very start of what was read (an opening at 0:00)
            return self.offset
        return self.offset + i * self.hop + self.lead

    def end_time(self, i_end: int) -> float:
        """The end of a shared part whose last matching point is ``i_end - 1``."""
        if i_end >= self._last - 1:  # shared to the very end of what was read (Chromaprint's last ~2 s
            return self.offset + self.length  # have no values of their own)
        return self.offset + i_end * self.hop + self.tail

    def index(self) -> Dict[int, List[int]]:
        """Both 16-bit halves of every value -> where they occur (halves that occur very often are
        left out: they say nothing)."""
        if self._index is None:
            idx: Dict[int, List[int]] = {}
            for i, v in enumerate(self.values):
                if self.valid[i]:
                    idx.setdefault(v & 0xFFFF, []).append(i)
                    idx.setdefault(0x10000 | ((v >> 16) & 0xFFFF), []).append(i)
            limit = max(8, len(self.values) // 200)
            self._index = {k: p for k, p in idx.items() if len(p) <= limit}
        return self._index


def _steady(values: Sequence[int]) -> List[bool]:
    """True for values inside a run of 3 or more equal ones (Chromaprint gives one value again and
    again for silence and steady tones)."""
    n = len(values)
    out = [False] * n
    i = 0
    while i < n:
        j = i
        while j + 1 < n and values[j + 1] == values[i]:
            j += 1
        if j - i >= 2:
            for k in range(i, j + 1):
                out[k] = True
        i = j + 1
    return out


def _decode_args(ffmpeg: str, path: str, start: float, length: float) -> List[str]:
    return [ffmpeg, "-hide_banner", "-nostdin", "-nostats", "-v", "error",
            "-ss", f"{max(0.0, start):.3f}", "-t", f"{max(0.1, length):.3f}", "-i", path]


def chromaprint_print(path: str, ffmpeg: str, start: float, length: float,
                      cancel: Optional[threading.Event] = None) -> Print:
    args = _decode_args(ffmpeg, path, start, length) + [
        "-map", "0:a:0", "-vn", "-sn", "-dn", "-ac", "1", "-ar", str(CHROMA_RATE),
        "-f", "chromaprint", "-fp_format", "raw", "-"]
    code, out, err = _run(args, DECODE_TIMEOUT, cancel)
    if code != 0:
        raise DetectError(err.decode("utf-8", "replace").strip()[-200:] or "ffmpeg couldn't read the sound.")
    n = len(out) // 4
    values = list(struct.unpack(f"<{n}I", out[: n * 4]))
    steady = _steady(values)
    return Print(values, [not s for s in steady], CHROMA_HOP, start, CHROMA_LEAD, CHROMA_TAIL, CHROMAPRINT, length)


def band_graph() -> str:
    """ffmpeg filters: 16 bands (log-spaced), each band's power, 100 values a second."""
    edges = [BAND_LOW * (BAND_HIGH / BAND_LOW) ** (i / BAND_COUNT) for i in range(BAND_COUNT + 1)]
    labels = "".join(f"[s{i}]" for i in range(BAND_COUNT))
    parts = [f"[0:a:0]aresample={BAND_RATE},aformat=sample_fmts=fltp:channel_layouts=mono,asplit={BAND_COUNT}{labels}"]
    for i in range(BAND_COUNT):
        centre = math.sqrt(edges[i] * edges[i + 1])
        width = edges[i + 1] - edges[i]
        parts.append(f"[s{i}]bandpass=f={centre:.1f}:width_type=h:w={width:.1f}[b{i}]")
    merged = "".join(f"[b{i}]" for i in range(BAND_COUNT))
    parts.append(f"{merged}amerge=inputs={BAND_COUNT},asplit[p][q]")
    parts.append(f"[p][q]amultiply,aresample={BAND_RATE // 8}:filter_size=8,aresample={ENVELOPE_RATE}:filter_size=8,"
                 "aformat=sample_fmts=flt[out]")
    return ";".join(parts)


def band_values(env: Sequence[float], bands: int = BAND_COUNT) -> Tuple[List[int], List[bool]]:
    """Band powers (``bands`` values per 1/100 s, interleaved) -> 31-bit values every 0.1 s.

    Bits 0-14: does the difference between band b and b+1 grow compared with 0.2 s before
    (Haitsma & Kalker's idea); bits 15-30: does band b's share of the sound grow compared with 0.2 s
    before. Both ignore the volume, and neither follows beats or fades that move all bands at once."""
    step = int(round(ENVELOPE_RATE * BAND_HOP))
    n = len(env) // bands
    frames = n // step
    if frames < 3:
        return [], []
    blocks = []
    for b in range(bands):
        series = env[b::bands]
        blocks.append([sum(series[k * step:(k + 1) * step]) for k in range(frames)])
    logs, power = [], []
    for t in range(frames):
        lo, hi = max(0, t - 1), min(frames, t + 2)
        energies = [max(0.0, sum(blk[lo:hi])) / ((hi - lo) * step) for blk in blocks]
        power.append(sum(energies) / bands)
        logs.append([math.log(e + 1e-12) for e in energies])
    values, valid = [], []
    for t in range(frames):
        if t < 2:
            values.append(0)
            valid.append(False)
            continue
        cur, back = logs[t], logs[t - 2]
        v = 0
        for b in range(bands - 1):
            if (cur[b] - cur[b + 1]) - (back[b] - back[b + 1]) > 0:
                v |= 1 << b
        level = (sum(cur) - sum(back)) / bands
        for b in range(bands):
            if cur[b] - back[b] > level:
                v |= 1 << (bands - 1 + b)
        values.append(v)
        valid.append(power[t] > BAND_SILENCE and power[t - 2] > BAND_SILENCE)
    return values, valid


def band_print(path: str, ffmpeg: str, start: float, length: float,
               cancel: Optional[threading.Event] = None) -> Print:
    args = _decode_args(ffmpeg, path, start, length) + [
        "-filter_complex", band_graph(), "-map", "[out]", "-f", "f32le", "-"]
    code, out, err = _run(args, DECODE_TIMEOUT, cancel)
    if code != 0:
        raise DetectError(err.decode("utf-8", "replace").strip()[-200:] or "ffmpeg couldn't read the sound.")
    env = array("f")
    size = BAND_COUNT * env.itemsize
    env.frombytes(out[: len(out) // size * size])
    if sys.byteorder == "big":
        env.byteswap()
    values, valid = band_values(env)
    return Print(values, valid, BAND_HOP, start, BAND_LEAD, BAND_TAIL, BANDS, length)


def fingerprint(path: str, ffmpeg: str, start: float, length: float, method: str,
                cancel: Optional[threading.Event] = None) -> Print:
    if method == CHROMAPRINT:
        return chromaprint_print(path, ffmpeg, start, length, cancel)
    return band_print(path, ffmpeg, start, length, cancel)


# -- matching --------------------------------------------------------------------------------------------

def _runs_at(a: Print, b: Print, d: int, max_mean: float, gap: int, window: int = WINDOW) -> List[Tuple[int, int, int]]:
    """Runs of matching points of ``a`` against ``b`` shifted by ``d``: [(start, end, matched)].

    A point matches when, over the ``window`` points around it, the values differ on average in at
    most ``max_mean`` bits (one noisy point doesn't break a match, and random sound almost never
    looks alike for that long)."""
    av, bv, aok, bok = a.values, b.values, a.valid, b.valid
    lo, hi = max(0, -d), min(len(av), len(bv) - d)
    if hi - lo < window:
        return []
    pop = POP16
    # prefix sums of the bit differences and of the points that can be compared
    diff_sum = [0] * (hi - lo + 1)
    ok_sum = [0] * (hi - lo + 1)
    ds = os_ = 0
    for k, i in enumerate(range(lo, hi)):
        if aok[i] and bok[i + d]:
            x = av[i] ^ bv[i + d]
            ds += pop[x & 0xFFFF] + pop[(x >> 16) & 0xFFFF]
            os_ += 1
        diff_sum[k + 1] = ds
        ok_sum[k + 1] = os_
    half = window // 2
    need = max(2, window // 2)
    span = hi - lo
    runs = []
    start = last = -1
    count = 0
    for k in range(span):
        w0, w1 = max(0, k - half), min(span, k - half + window)
        oks = ok_sum[w1] - ok_sum[w0]
        if oks < need or diff_sum[w1] - diff_sum[w0] > max_mean * oks:
            continue
        i = k + lo
        if last >= 0 and i - last <= gap:
            last = i
            count += 1
        else:
            if last >= 0:
                runs.append((start, last + 1, count))
            start = last = i
            count = 1
    if last >= 0:
        runs.append((start, last + 1, count))
    return runs


def shared_parts(a: Print, b: Print, bounds: Tuple[float, float], params: Params = PARAMS,
                 candidates: int = 6) -> List[Tuple[float, float, float, float, float]]:
    """Parts of ``a`` and ``b`` that sound the same and last between ``bounds`` seconds:
    ``[(a_start, a_end, b_start, b_end, quality)]`` in seconds of each file, best first."""
    if not len(a) or not len(b):
        return []
    hop = a.hop
    idx = b.index()
    votes: Dict[int, int] = {}
    for i, v in enumerate(a.values):
        if not a.valid[i]:
            continue
        for key in (v & 0xFFFF, 0x10000 | ((v >> 16) & 0xFFFF)):
            for j in idx.get(key, ()):
                votes[j - i] = votes.get(j - i, 0) + 1
    if not votes:
        return []
    smooth = {d: votes.get(d - 1, 0) + c + votes.get(d + 1, 0) for d, c in votes.items()}
    picked: List[int] = []
    for d, c in sorted(smooth.items(), key=lambda x: -x[1]):
        if c < 5 or len(picked) >= candidates:
            break
        if all(abs(d - p) > 3 for p in picked):
            picked.append(d)
    method = a.method if a.method in params.max_bits else BANDS
    max_bits = params.max_bits[method]
    gap = max(1, int(round(params.max_gap / hop)))
    lo_len, hi_len = bounds
    found = []
    for d0 in picked:
        best = None
        for d in (d0 - 1, d0, d0 + 1):
            for s, e, count in _runs_at(a, b, d, max_bits, gap):
                length = (e - s) * hop
                if length < lo_len * 0.8 or length > hi_len * 1.1 or count / (e - s) < params.min_density:
                    continue
                if best is None or count > best[3]:
                    best = (s, e, d, count)
        if best is None:
            continue
        s, e, d, count = best
        a0, a1 = a.start_time(s), a.end_time(e)
        b0, b1 = b.start_time(s + d), b.end_time(e + d)
        if not (lo_len <= a1 - a0 <= hi_len):
            continue
        quality = count / (e - s)
        if any(abs(a0 - f[0]) < params.tolerance and abs(a1 - f[1]) < params.tolerance for f in found):
            continue  # the same part through a neighbouring shift
        found.append((round(a0, 2), round(a1, 2), round(b0, 2), round(b1, 2), round(quality, 3)))
    found.sort(key=lambda f: (-(f[1] - f[0]) * f[4]))
    return found


def _consensus(cands: List[Tuple[float, float, float, str]], partners: int, params: Params) -> Optional[dict]:
    """Candidates ``(start, end, quality, partner)`` of one episode -> the part most partners agree on."""
    if not cands or partners <= 0:
        return None
    best = None
    for s0, e0, _, _ in sorted(cands, key=lambda c: -(c[1] - c[0])):
        members: Dict[str, Tuple[float, float, float]] = {}
        for s, e, q, who in cands:
            if abs(s - s0) <= params.tolerance and abs(e - e0) <= params.tolerance:
                if who not in members or q > members[who][2]:
                    members[who] = (s, e, q)
        support = len(members)
        quality = sum(m[2] for m in members.values()) / support
        key = (support, quality)
        if best is None or key > best[0]:
            best = (key, members)
    (support, quality), members = best
    need = 2 if partners >= 2 else 1
    confidence = support / partners * quality
    if support < need or confidence < params.min_confidence:
        return None
    starts = sorted(m[0] for m in members.values())
    ends = sorted(m[1] for m in members.values())
    mid = len(starts) // 2
    start = starts[mid] if len(starts) % 2 else (starts[mid - 1] + starts[mid]) / 2
    end = ends[mid] if len(ends) % 2 else (ends[mid - 1] + ends[mid]) / 2
    return {"start": round(start, 1), "end": round(end, 1), "conf": round(min(1.0, confidence), 2), "agree": support}


def pick_partners(n: int, i: int, count: int) -> List[int]:
    """The ``count`` episodes nearest to episode ``i`` (alternating after/before)."""
    out = []
    step = 1
    while len(out) < count and (i - step >= 0 or i + step < n):
        for j in (i + step, i - step):
            if 0 <= j < n and len(out) < count:
                out.append(j)
        step += 1
    return out


def analyse(prints: List[Dict[str, Optional[Print]]], durations: List[float], targets: Iterable[int],
            params: Params = PARAMS) -> Dict[int, dict]:
    """Episodes of one folder, in order: ``prints[i] = {"opening": Print, "ending": Print}`` (None if
    unreadable). Returns ``{i: {"opening": part or None, "ending": part or None, "partners": n}}`` for
    the target episodes."""
    n = len(prints)
    pairs: Dict[Tuple[str, int, int], list] = {}

    def pair(kind: str, i: int, j: int) -> list:
        lo, hi = min(i, j), max(i, j)
        key = (kind, lo, hi)
        if key not in pairs:
            pa, pb = prints[lo].get(kind), prints[hi].get(kind)
            pairs[key] = shared_parts(pa, pb, params.bounds(kind), params) if pa and pb else []
        # (a_start, a_end, b_start, b_end, q) of (lo, hi) -> this episode's own times
        return [(p[0], p[1], p[4]) if i == lo else (p[2], p[3], p[4]) for p in pairs[key]]

    readable = [i for i in range(n) if prints[i].get("opening") or prints[i].get("ending")]
    out: Dict[int, dict] = {}
    for i in targets:
        if i not in readable:
            continue
        pos = readable.index(i)
        partners = [readable[k] for k in pick_partners(len(readable), pos, params.partners)]
        result = {"partners": len(partners)}
        for kind in KINDS:
            cands = []
            for j in partners:
                for s, e, q in pair(kind, i, j):
                    cands.append((s, e, q, str(j)))
            part = _consensus(cands, len(partners), params)
            if part and kind == "opening" and part["start"] <= params.snap_start:
                part["start"] = 0.0
            if part and kind == "ending" and durations[i] and durations[i] - part["end"] <= params.snap_end:
                part["end"] = round(durations[i], 1)
            result[kind] = part
        op, ed = result.get("opening"), result.get("ending")
        if op and ed and op["start"] < ed["end"] and ed["start"] < op["end"]:  # short file: the same part twice
            result["opening" if op["conf"] < ed["conf"] else "ending"] = None
        out[i] = result
    return out


# -- the markers file ------------------------------------------------------------------------------------

def file_stamp(path: str) -> Optional[Tuple[int, float]]:
    try:
        st = os.stat(path)
    except (OSError, ValueError):
        return None
    return st.st_size, round(st.st_mtime, 3)


def _part(value) -> Optional[dict]:
    """``{"start", "end"}`` (seconds) from the window or the file, or None."""
    if not isinstance(value, dict):
        return None
    try:
        start, end = float(value.get("start")), float(value.get("end"))
    except (TypeError, ValueError):
        return None
    if not (math.isfinite(start) and math.isfinite(end)) or start < 0 or end - start < 1:
        return None
    out = {"start": round(start, 1), "end": round(end, 1)}
    if isinstance(value.get("conf"), (int, float)):
        out["conf"] = float(value["conf"])
    return out


class MarkerStore:
    """``skip-markers.json``: per video file (path + size + modified time) what was found, what the
    user changed by hand, and which shows are switched off."""

    def __init__(self, path: Path):
        self.path = Path(path)
        self._lock = threading.RLock()
        self._files: Dict[str, dict] = {}
        self._off: set = set()
        self._dirty = False
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            if isinstance(data, dict) and data.get("version") == CACHE_VERSION:
                if isinstance(data.get("files"), dict):
                    self._files = {k: v for k, v in data["files"].items() if isinstance(v, dict)}
                self._off = {str(x) for x in data.get("off") or []}
        except FileNotFoundError:
            pass
        except (OSError, ValueError) as exc:
            log.warning("Couldn't read %s (%s); openings and endings will be looked for again", self.path, exc)

    # reading
    def entry(self, path: str) -> Optional[dict]:
        with self._lock:
            e = self._files.get(path)
            return json.loads(json.dumps(e)) if e else None

    def current(self, path: str) -> Optional[dict]:
        """The entry, if the file is still the same (size and modified time)."""
        e = self.entry(path)
        if not e:
            return None
        stamp = file_stamp(path)
        if stamp is None or (e.get("size"), e.get("mtime")) != stamp:
            return None
        return e

    def is_off(self, show_id: str) -> bool:
        with self._lock:
            return show_id in self._off

    @staticmethod
    def effective(entry: Optional[dict]) -> Dict[str, Optional[dict]]:
        """{kind: {"start", "end", "conf"?, "source": "found"|"edited"} or None}: hand edits win."""
        out: Dict[str, Optional[dict]] = {}
        if not entry:
            return {k: None for k in KINDS}
        manual = entry.get("manual") or {}
        found = entry.get("found") or {}
        for kind in KINDS:
            if kind in manual:
                p = _part(manual[kind])
                out[kind] = dict(p, source="edited") if p else None
            else:
                p = _part(found.get(kind))
                out[kind] = dict(p, source="found") if p else None
        return out

    def markers(self, path: str) -> List[Tuple[str, float, float]]:
        """[(kind, start, end)] AniBox found (or the user set) for this file; [] when the file
        changed since, or the show is switched off."""
        e = self.current(path)
        if not e or self.is_off(str(e.get("show") or "")):
            return []
        eff = self.effective(e)
        return [(k, eff[k]["start"], eff[k]["end"]) for k in KINDS if eff[k]]

    # writing
    def put(self, path: str, entry: dict) -> None:
        with self._lock:
            self._files[path] = {k: entry[k] for k in ENTRY_KEYS if k in entry}
            self._dirty = True

    def set_manual(self, path: str, show_id: str, kind: str, part: Optional[dict]) -> None:
        if kind not in KINDS:
            raise ValueError(kind)
        stamp = file_stamp(path)
        if stamp is None:
            raise DetectError("The file isn't there any more. Scan again.")
        with self._lock:
            e = self._files.get(path)
            if not e or (e.get("size"), e.get("mtime")) != stamp:
                e = {"size": stamp[0], "mtime": stamp[1], "show": show_id, "at": time.time(), "found": {}}
                self._files[path] = e
            e.setdefault("manual", {})[kind] = _part(part) if part else None
            self._dirty = True

    def reset_manual(self, path: str) -> None:
        with self._lock:
            e = self._files.get(path)
            if e and e.get("manual"):
                e.pop("manual", None)
                self._dirty = True

    def set_off(self, show_id: str, off: bool) -> None:
        with self._lock:
            if off:
                self._off.add(show_id)
            else:
                self._off.discard(show_id)
            self._dirty = True

    def save(self) -> None:
        with self._lock:
            if not self._dirty:
                return
            data = json.dumps({"version": CACHE_VERSION, "files": self._files, "off": sorted(self._off)},
                              ensure_ascii=False)
            self._dirty = False
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_name(self.path.name + ".part")
            tmp.write_text(data, encoding="utf-8")
            os.replace(tmp, self.path)
        except OSError as exc:
            log.warning("Couldn't save %s: %s", self.path, exc)
            with self._lock:
                self._dirty = True


_STORES: Dict[str, MarkerStore] = {}
_STORES_LOCK = threading.Lock()
_DEFAULT: List[MarkerStore] = []


def store_for(data_dir) -> MarkerStore:
    """One MarkerStore per data folder in this process (the window, the player and the TV share it)."""
    path = Path(data_dir) / "skip-markers.json"
    key = os.path.normcase(os.path.abspath(str(path)))
    with _STORES_LOCK:
        st = _STORES.get(key)
        if st is None:
            st = _STORES[key] = MarkerStore(path)
        _DEFAULT[:] = [st]
        return st


def markers_for(path: str, data_dir=None) -> List[Tuple[str, float, float]]:
    """``[(kind, start, end)]`` of openings/endings found for this video file (not chapters).

    For players: the PC player (player.py) uses it through ``with_markers``; TV playback
    (tvplayer.py) can call it the same way. Without ``data_dir`` it uses the data folder AniBox
    opened in this process (else AniBox's usual one). Never raises."""
    try:
        if data_dir is not None:
            st = store_for(data_dir)
        elif _DEFAULT:
            st = _DEFAULT[0]
        else:
            from .paths import data_dir as default_dir
            st = store_for(default_dir())
        return st.markers(path)
    except Exception:
        log.warning("Couldn't read the openings/endings found for %s", path, exc_info=True)
        return []


def with_markers(segments: List[Tuple[str, float, float]], path: str, data_dir=None) -> List[Tuple[str, float, float]]:
    """The player's chapter segments plus found openings/endings for the kinds chapters don't cover
    (chapters always win)."""
    if not path:
        return segments
    have = {k for k, _, _ in segments}
    extra = [m for m in markers_for(path, data_dir) if m[0] not in have]
    if not extra:
        return segments
    log.info("Found earlier (no chapters): %s", ", ".join(f"{k} {a:.0f}-{b:.0f}s" for k, a, b in extra))
    return sorted(list(segments) + extra, key=lambda s: s[1])


# -- looking at a show -----------------------------------------------------------------------------------

def folder_groups(show: dict) -> List[List[dict]]:
    """A show's episodes per folder (season folders are compared on their own), in order."""
    groups: Dict[str, List[dict]] = {}
    for ep in show.get("episodes") or []:
        sub = str(ep.get("file") or "").replace("/", "\\").rpartition("\\")[0]
        groups.setdefault(sub, []).append(ep)
    return list(groups.values())


class Detector:
    """Looks at one show at a time in the background, with progress and Cancel.

    ``tools()`` -> {"ffmpeg", "ffprobe"}; ``busy(show_id)`` -> True while that show is playing (then
    automatic runs leave it alone); ``pause`` seconds between files keep the drives calm."""

    def __init__(self, store: MarkerStore, tools: Callable[[], dict], params: Params = PARAMS, pause: float = 1.0,
                 busy: Optional[Callable[[str], bool]] = None, method: str = "",
                 keepalive: Optional[Callable[[], None]] = None):
        self.store = store
        self.keepalive = keepalive  # called while working (AniBox doesn't close itself meanwhile)
        self.tools = tools
        self.params = params
        self.pause = pause
        self.busy = busy or (lambda show_id: False)
        self.method = method  # "" = Chromaprint if this ffmpeg has it, else bands (tests force one)
        self._lock = threading.Lock()
        self._queue: List[Tuple[dict, bool, bool, bool]] = []  # (show, again, auto, part of the batch)
        self._cancel = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self.status: dict = {"state": "idle"}
        self.batch: dict = {"state": "idle"}  # "Check every show"

    # -- the queue
    def queue(self, shows: List[dict], again: bool = False, auto: bool = False, batch: bool = False) -> dict:
        with self._lock:
            if batch:
                self.batch = {"state": "running", "done": 0, "total": len(shows), "found": 0, "skipped": 0,
                              "started": time.time()}
            queued = {q[0]["id"] for q in self._queue}
            if self.status.get("state") == "running":
                queued.add(self.status.get("show"))
            added = 0
            for sh in shows:
                if sh["id"] in queued and not again:
                    continue
                self._queue.append((sh, again, auto or batch, batch))
                added += 1
            if batch:
                self.batch["total"] = added
                if not added:
                    self.batch["state"] = "done"
            if self._queue and self._thread is None:
                self._cancel.clear()
                self._thread = threading.Thread(target=self._worker, daemon=True, name="anibox-introdetect")
                self._thread.start()
        return self.state()

    def cancel(self) -> dict:
        """Stop the show being looked at (its finished episodes are kept) and forget the queue."""
        with self._lock:
            self._queue.clear()
            if self._thread is not None:
                self._cancel.set()
            if self.batch.get("state") == "running":
                self.batch["state"] = "cancelled"
        return self.state()

    def state(self) -> dict:
        with self._lock:
            st = dict(self.status)
            st["queued"] = len(self._queue)
            st["queuedShows"] = [q[0]["id"] for q in self._queue[:50]]
            st["batch"] = dict(self.batch)
        return st

    def wait(self, timeout: float = 60) -> bool:
        """Wait until the queue is done (tests)."""
        end = time.time() + timeout
        while time.time() < end:
            t = self._thread
            if t is None:
                return True
            t.join(0.1)
        return False

    @property
    def running(self) -> bool:
        return self._thread is not None

    def _worker(self) -> None:
        while True:
            with self._lock:
                self._cancel.clear()  # a Cancel ended the last show; what was queued since goes on
                if not self._queue:
                    if self.batch.get("state") == "running":
                        self.batch["state"] = "done"
                    self._thread = None
                    return
                show, again, auto, in_batch = self._queue.pop(0)
                in_batch = in_batch and self.batch.get("state") == "running"
            if auto and self.busy(show["id"]):
                log.info("Openings/endings: %s is playing, left for later", show["id"])
                with self._lock:
                    if in_batch:
                        self.batch["skipped"] = self.batch.get("skipped", 0) + 1
                        self.batch["done"] = self.batch.get("done", 0) + 1
                continue
            started = time.time()
            self.status = {"state": "running", "show": show["id"], "title": show.get("title") or show.get("folder") or "",
                           "done": 0, "total": 0, "phase": "Looking at the episodes …", "auto": auto, "started": started}
            try:
                summary = self.run_show(show, again=again)
                self.status = dict(self.status, state="done", phase="", finished=time.time(), **summary)
                log.info("Openings/endings for %s in %.1f s: %s", show["id"], time.time() - started, summary)
                with self._lock:
                    if in_batch:
                        self.batch["found"] = self.batch.get("found", 0) + (1 if summary.get("found") else 0)
            except Cancelled:
                self.status = {"state": "cancelled", "show": show["id"], "title": self.status.get("title", ""),
                               "finished": time.time()}
                log.info("Openings/endings for %s: cancelled", show["id"])
            except DetectError as exc:
                self.status = {"state": "error", "show": show["id"], "title": self.status.get("title", ""),
                               "message": str(exc), "finished": time.time()}
                log.info("Openings/endings for %s: %s", show["id"], exc)
            except Exception as exc:  # shown in the window, logged with the details
                log.exception("Looking for openings/endings in %s failed", show["id"])
                self.status = {"state": "error", "show": show["id"], "title": self.status.get("title", ""),
                               "message": str(exc) or exc.__class__.__name__, "finished": time.time()}
            finally:
                self.store.save()
            with self._lock:
                if in_batch and self.batch.get("state") == "running":
                    self.batch["done"] = self.batch.get("done", 0) + 1

    # -- one show
    def needs_work(self, show: dict, again: bool = False) -> bool:
        """Are there episodes without an up-to-date result? (Looks at each file's size and time.)"""
        for group in folder_groups(show):
            if self._targets(group, again):
                return True
        return False

    def _left_out(self, ep: dict) -> bool:
        """Known to be no use as a partner (too short, couldn't be read)."""
        e = self.store.entry(ep["path"])
        return bool(e) and e.get("note") in ("short", "unreadable")

    def _targets(self, group: List[dict], again: bool) -> List[int]:
        usable = sum(1 for ep in group if not self._left_out(ep))
        possible = min(self.params.partners, usable - 1)
        out = []
        for i, ep in enumerate(group):
            e = None if again else self.store.current(ep["path"])
            if e is None:
                out.append(i)
                continue
            if e.get("note") in ("chapters", "short", "unreadable"):
                continue
            missing = [k for k in KINDS if not (e.get("found") or {}).get(k) and k not in (e.get("chapters") or [])]
            if missing and int(e.get("partners") or 0) < possible:  # more episodes to compare with now
                out.append(i)
        return out

    def _step(self, phase: str) -> None:
        if self._cancel.is_set():
            raise Cancelled()
        self.status.update(phase=phase)
        if self.keepalive:
            self.keepalive()

    def run_show(self, show: dict, again: bool = False) -> dict:
        """Look at one show now (in this thread). Returns a short summary."""
        tools = self.tools() or {}
        ffmpeg = tools.get("ffmpeg")
        if not ffmpeg:
            raise DetectError("ffmpeg isn't installed yet: Settings → Player → Download ffmpeg.")
        method = pick_method(ffmpeg, self.method)
        p = self.params
        summary = {"episodes": 0, "read": 0, "found": 0, "openings": 0, "endings": 0, "method": method}
        plans = []
        for group in folder_groups(show):
            targets = self._targets(group, again)
            if targets:
                plans.append((group, targets))
        total = sum(len(t) for _, t in plans)
        self.status.update(total=total, done=0)
        for group, targets in plans:
            summary["episodes"] += len(targets)
            info: Dict[int, dict] = {}

            def look(i: int) -> Optional[dict]:
                if i not in info:
                    self._step(f"Reading {group[i].get('file') or ''}")
                    try:
                        info[i] = probe(group[i]["path"], tools.get("ffprobe"), ffmpeg, self._cancel)
                    except DetectError as exc:
                        info[i] = {"error": str(exc), "duration": 0.0, "chapters": []}
                return info[i]

            # 1. chapters and length of the episodes that need a look
            work = []
            for i in targets:
                ep = group[i]
                stamp = file_stamp(ep["path"])
                meta = look(i)
                base = {"size": stamp[0] if stamp else 0, "mtime": stamp[1] if stamp else 0, "show": show["id"],
                        "duration": round(meta.get("duration") or 0, 1), "at": time.time(), "method": method,
                        "chapters": sorted({k for k, _, _ in meta.get("chapters") or []}), "found": {}}
                old = self.store.entry(ep["path"])
                if old and old.get("manual") and (old.get("size"), old.get("mtime")) == stamp:
                    base["manual"] = old["manual"]  # hand edits stay
                if meta.get("error"):
                    self.store.put(ep["path"], dict(base, note="unreadable"))
                    self.status["done"] += 1
                elif set(base["chapters"]) >= set(KINDS):
                    self.store.put(ep["path"], dict(base, note="chapters"))
                    self.status["done"] += 1
                elif (meta.get("duration") or 0) < p.min_duration:
                    self.store.put(ep["path"], dict(base, note="short"))
                    self.status["done"] += 1
                else:
                    work.append((i, base))
            if not work:
                continue
            # 2. fingerprints of these and their partners (nearest episodes of the same folder; episodes
            #    with chapters are good partners too)
            usable = [i for i in range(len(group))
                      if (i in info and not info[i].get("error") and (info[i].get("duration") or 0) >= p.min_duration)
                      or (i not in info and not self._left_out(group[i]))]
            needed = set()
            for i, _ in work:
                pos = usable.index(i)
                needed.add(i)
                needed.update(usable[k] for k in pick_partners(len(usable), pos, p.partners))
            prints: List[Dict[str, Optional[Print]]] = [{} for _ in group]
            durations = [0.0] * len(group)
            order = sorted(needed)
            self.status["total"] = self.status.get("total", 0) + len(order) - len(work)
            for n, i in enumerate(order):
                ep = group[i]
                meta = look(i)
                dur = float(meta.get("duration") or 0)
                durations[i] = dur
                if meta.get("error") or dur < p.min_duration:
                    self.status["done"] += 1
                    continue
                self._step(f"Listening to {ep.get('file') or ''}")
                try:
                    start_len = min(p.start_window, dur)
                    prints[i]["opening"] = fingerprint(ep["path"], ffmpeg, 0.0, start_len, method, self._cancel)
                    end_start = max(0.0, dur - p.end_window)
                    prints[i]["ending"] = fingerprint(ep["path"], ffmpeg, end_start, dur - end_start, method, self._cancel)
                    summary["read"] += 1
                except DetectError as exc:
                    log.info("Openings/endings: couldn't read %s (%s)", ep["path"], exc)
                    prints[i] = {}
                self.status["done"] += 1
                if n + 1 < len(order) and self.pause > 0 and self._cancel.wait(self.pause):
                    raise Cancelled()
            # 3. compare and keep
            self._step("Comparing the episodes …")
            results = analyse(prints, durations, [i for i, _ in work], p)
            for i, base in work:
                r = results.get(i)
                if r is None:
                    self.store.put(group[i]["path"], dict(base, note="unreadable", partners=0))
                    continue
                found = {k: r.get(k) for k in KINDS if r.get(k)}
                entry = dict(base, found=found, partners=r.get("partners", 0))
                if not r.get("partners"):
                    entry["note"] = "alone"
                self.store.put(group[i]["path"], entry)
                summary["openings"] += 1 if found.get("opening") else 0
                summary["endings"] += 1 if found.get("ending") else 0
            self.store.save()
        summary["found"] = summary["openings"] + summary["endings"]
        return summary
