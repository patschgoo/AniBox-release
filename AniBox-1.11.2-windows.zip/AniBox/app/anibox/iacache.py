"""Internet Archive streams through a cache on this PC: parallel loading, loading ahead and a Keep folder.

Without the cache mpv reads ``archive.org/download/<item>/<file>`` itself: one connection, nothing
loaded ahead, and on a slow day it stops to buffer. With the cache (Settings → Internet Archive
streaming, on by default):

- mpv opens ``http://127.0.0.1:<random port>/<random token>/<item>/<file>`` instead (a url hook of
  ``stream.IaStreams``). That small server (``StreamServer``, this PC only) answers byte ranges like
  archive.org does, but from a cache file. A part that isn't there yet is loaded first and the answer
  waits for it: jumping into an unloaded part takes a moment, but playback never fails because of it.
  The cache's addresses get mpv's ``network-timeout=0``, so mpv waits instead of giving up.
- A cache file is a sparse ``.part`` file plus a piece map (``.part.pieces``, 1 MB pieces). The map is
  saved right after pieces finish (at most twice a second, the data is forced to disk first), so after
  a crash or a closed window only the missing pieces load again; the pieces written last are checked
  against their checksum first.
- Loading: archive.org's ``/download/`` redirect is resolved once, then N parallel range requests
  (setting ``ia_cache_connections``, 8) go to the storage server, the start first. A seek moves the
  loading to that point. 5 tries with growing waits (5 s, 15 s, 30 s, 1 min, 2 min), then "Paused".
  No internet: "Waiting for internet", no try is used up and loading goes on by itself. 429/503: fewer
  connections and longer pauses. 404: "No longer online". A full disk pauses with a message. A complete
  file is checked against archive.org's MD5 (when the item lists one): loaded again once on a mismatch,
  then "Broken" with "Reload".
- Loading ahead: when an episode of a stream show starts (a play hook), the next ``ia_cache_ahead`` (2)
  episodes load after it. One file loads at a time, the one playing first.
- The cache never grows over its limit (``ia_cache_gb``, 20 GB). Space is made when it's needed, and at
  the start: watched episodes first (the oldest first), then the ones loaded furthest ahead. Only files
  the cache made itself and lists in its index (``ia-cache.json`` in AniBox's data folder) are ever
  deleted; other files in the folder are never touched.
- Keep: the episode loads fully in the background, is checked, then moves to the Keep folder
  (``ia_keep_dir``, by default ``AniBox Keep`` beside the Internet Archive download folder) as
  ``<item or show title> – <file name>``, never over another file (" (2)"). From then on it plays from
  there and doesn't count toward the limit. A kept file you delete yourself is noticed and forgotten.

The design is Frostbox's (Martin's archive.org player, used with permission): ``CacheManager``,
``DownloadJob``, ``PieceMap``, ``StreamServer``, ``NetworkProbe`` and ``ArchiveClient.ResolveAsync``,
ported to Python threads.
"""

from __future__ import annotations

import errno
import hashlib
import hmac
import http.client
import json
import logging
import mimetypes
import os
import re
import secrets
import select
import shutil
import socket
import ssl
import struct
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

from .iarchive import USER_AGENT, fit_path, move_no_replace, safe_name, unique_path
from .stream import split_key, stream_key

log = logging.getLogger("anibox.iacache")

PIECE = 1 << 20  # 1 MB
GB = 1 << 30
INDEX_FILE = "ia-cache.json"
MAP_MAGIC = b"ABPM1"
RETRY_DELAYS = (5.0, 15.0, 30.0, 60.0, 120.0)
RUN_PIECES = 4  # pieces per request away from the playing point (more speed); 1 right at it (sooner there)
RECENT = 16  # pieces written last, checked again after a restart
CHUNK = 256 * 1024
DISK_RESERVE = 512 * 1024 * 1024  # always left free on the cache's drive
MAP_SAVE_EVERY = 0.5

KEEP_FOLDER_NAME = "AniBox Keep"  # beside the Internet Archive download folder
DEFAULT_GB = 20
DEFAULT_CONNECTIONS = 8
DEFAULT_AHEAD = 2

# Entry states. "new" = not loading right now (maybe partly there)
LIVE = ("loading", "waiting", "offline", "verifying")
NEEDS_USER = ("paused", "gone", "broken")
ACTIONS = {"paused": ["retry", "restart"], "gone": ["retry"], "broken": ["reload"]}

VIDEO_TYPES = {".mkv": "video/x-matroska", ".mp4": "video/mp4", ".m4v": "video/mp4", ".avi": "video/x-msvideo",
               ".ogv": "video/ogg", ".webm": "video/webm", ".mpg": "video/mpeg", ".mpeg": "video/mpeg",
               ".mov": "video/quicktime", ".wmv": "video/x-ms-wmv", ".ts": "video/mp2t"}


class _Gone(Exception):
    """404/410: the file isn't on archive.org any more."""


class _Denied(Exception):
    """401/403: archive.org doesn't let anyone load it (lending only, restricted)."""


class _Busy(Exception):
    def __init__(self, code: int, retry_after: Optional[str] = None):
        super().__init__(f"archive.org is busy ({code})")
        self.code = code
        self.retry_after = retry_after


class _NetError(Exception):
    pass


class _DiskFull(Exception):
    pass


class _WriteError(Exception):
    pass


def _secs(seconds: float) -> str:
    seconds = int(round(seconds))
    return f"{seconds} s" if seconds < 90 else f"{round(seconds / 60)} min"


def _disk_full(exc: OSError) -> bool:
    return exc.errno == errno.ENOSPC or getattr(exc, "winerror", 0) in (39, 112)


def _cross_device(exc: OSError) -> bool:
    return exc.errno == errno.EXDEV or getattr(exc, "winerror", 0) == 17


def _clamp(value, low: int, high: int, default: int) -> int:
    try:
        return max(low, min(high, int(value)))
    except (TypeError, ValueError):
        return default


def _same_dir(a, b) -> bool:
    return os.path.normcase(os.path.abspath(str(a))) == os.path.normcase(os.path.abspath(str(b)))


def allocated(path) -> int:
    """Space a file really takes on the disk (a sparse cache file takes less than its size)."""
    path = str(path)
    if os.name == "nt":
        try:
            import ctypes
            from ctypes import wintypes
            k32 = ctypes.WinDLL("kernel32", use_last_error=True)
            k32.GetCompressedFileSizeW.argtypes = [wintypes.LPCWSTR, ctypes.POINTER(wintypes.DWORD)]
            k32.GetCompressedFileSizeW.restype = wintypes.DWORD
            high = wintypes.DWORD(0)
            low = k32.GetCompressedFileSizeW(path, ctypes.byref(high))
            if low != 0xFFFFFFFF or ctypes.get_last_error() == 0:
                return (high.value << 32) | low
        except Exception:
            pass
    try:
        st = os.stat(path)
    except OSError:
        return 0
    blocks = getattr(st, "st_blocks", None)
    return min(st.st_size, blocks * 512) if blocks is not None else st.st_size


def _set_sparse(fh) -> None:
    """Windows: mark a new cache file as sparse. Without it NTFS fills everything before a far write
    (a seek to the end) with zeros first, which takes many seconds for a big file on a hard disk."""
    if os.name != "nt":
        return  # Linux and macOS leave the gaps empty by themselves
    try:
        import ctypes
        import msvcrt
        from ctypes import wintypes
        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        k32.DeviceIoControl.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPVOID, wintypes.DWORD,
                                        wintypes.LPVOID, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD), wintypes.LPVOID]
        k32.DeviceIoControl.restype = wintypes.BOOL
        returned = wintypes.DWORD(0)
        handle = wintypes.HANDLE(msvcrt.get_osfhandle(fh.fileno()))
        if not k32.DeviceIoControl(handle, 0x000900C4, None, 0, None, 0, ctypes.byref(returned), None):  # FSCTL_SET_SPARSE
            log.info("Couldn't mark the cache file as sparse (error %s)", ctypes.get_last_error())
    except Exception:
        log.info("Couldn't mark the cache file as sparse", exc_info=True)


def free_space(path) -> int:
    """Free bytes on the drive of ``path`` (or of its nearest folder that exists)."""
    p = Path(path)
    for cand in [p, *p.parents]:
        try:
            if cand.exists():
                return shutil.disk_usage(str(cand)).free
        except OSError:
            continue
    return 1 << 62


# -- HTTP to archive.org ---------------------------------------------------------------------------------

def _proxied(url: str) -> bool:
    """A proxy is set up for this address (then urllib is used, one connection per request)."""
    try:
        u = urllib.parse.urlsplit(url)
        return bool(urllib.request.getproxies().get(u.scheme)) and not urllib.request.proxy_bypass(u.hostname or "")
    except Exception:
        return False


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None  # the cache follows archive.org's redirect itself, once


_OPENER = urllib.request.build_opener(_NoRedirect)


class _Conn:
    """One connection to archive.org's storage server, kept open between requests (keep-alive)."""

    def __init__(self, timeout: float):
        self.timeout = timeout
        self.c: Optional[http.client.HTTPConnection] = None
        self.target = None
        self.resp = None

    def close(self) -> None:
        resp, self.resp = self.resp, None
        if resp is not None:
            try:
                resp.close()
            except Exception:
                pass
        c, self.c, self.target = self.c, None, None
        if c is not None:
            try:
                c.close()
            except Exception:
                pass

    def abort(self) -> None:
        """From another thread: make a read that's waiting fail now."""
        c = self.c
        sock = getattr(c, "sock", None) if c is not None else None
        if sock is not None:
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass

    def get(self, url: str, headers: Optional[dict] = None, method: str = "GET"):
        """(status, headers, response). Read the response to its end, or call close()."""
        hdrs = {"User-Agent": USER_AGENT, "Accept-Encoding": "identity", **(headers or {})}
        if _proxied(url):
            self.close()
            try:
                resp = _OPENER.open(urllib.request.Request(url, headers=hdrs, method=method), timeout=self.timeout)
            except urllib.error.HTTPError as exc:
                self.resp = exc
                return exc.code, exc.headers, exc
            except urllib.error.URLError as exc:
                raise OSError(str(exc.reason)) from exc
            self.resp = resp
            return resp.status, resp.headers, resp
        u = urllib.parse.urlsplit(url)
        target = (u.scheme, u.hostname, u.port)
        path = (u.path or "/") + ("?" + u.query if u.query else "")
        for attempt in (0, 1):
            reused = self.c is not None and self.target == target
            if not reused:
                self.close()
                if u.scheme == "https":
                    self.c = http.client.HTTPSConnection(u.hostname, u.port, timeout=self.timeout,
                                                         context=ssl.create_default_context())
                else:
                    self.c = http.client.HTTPConnection(u.hostname, u.port, timeout=self.timeout)
                self.target = target
            try:
                self.c.request(method, path, headers=hdrs)
                resp = self.c.getresponse()
            except (http.client.HTTPException, OSError):
                self.close()
                if reused and attempt == 0:
                    continue  # the server had closed the kept-alive connection: once more on a new one
                raise
            self.resp = resp
            return resp.status, resp.headers, resp
        raise OSError("no connection")

    def drain(self, resp, limit: int = 65536) -> None:
        """Read a small answer to its end so the connection can be used again (else close it)."""
        try:
            data = resp.read(limit + 1)
            if len(data) > limit:
                self.close()
        except (OSError, http.client.HTTPException):
            self.close()


# -- which pieces are there --------------------------------------------------------------------------------

class PieceMap:
    """Which pieces of a file are on the disk, each with its CRC-32 (saved as ``<file>.pieces``)."""

    def __init__(self, size: int, piece: int = PIECE):
        self.size = int(size)
        self.piece = int(piece)
        self.count = max(1, -(-self.size // self.piece))
        self.done = bytearray(self.count)
        self.crc = [0] * self.count
        self.recent: List[int] = []
        self.n = 0

    @property
    def complete(self) -> bool:
        return self.n == self.count

    @property
    def fraction(self) -> float:
        return self.n / self.count

    def piece_of(self, offset: int) -> int:
        return max(0, min(self.count - 1, offset // self.piece))

    def start_of(self, i: int) -> int:
        return i * self.piece

    def length_of(self, i: int) -> int:
        return max(0, min(self.piece, self.size - i * self.piece))

    def mark(self, i: int, crc: int) -> None:
        if not self.done[i]:
            self.done[i] = 1
            self.n += 1
        self.crc[i] = crc & 0xFFFFFFFF
        if i in self.recent:
            self.recent.remove(i)
        self.recent.append(i)
        del self.recent[:-RECENT]

    def unmark(self, i: int) -> None:
        if self.done[i]:
            self.done[i] = 0
            self.n -= 1
        self.crc[i] = 0
        if i in self.recent:
            self.recent.remove(i)

    def clear(self) -> None:
        self.done = bytearray(self.count)
        self.crc = [0] * self.count
        self.recent = []
        self.n = 0

    def to_bytes(self) -> bytes:
        bits = bytearray((self.count + 7) // 8)
        for i in range(self.count):
            if self.done[i]:
                bits[i >> 3] |= 1 << (i & 7)
        return (MAP_MAGIC + struct.pack("<QII", self.size, self.piece, self.count) + bytes(bits)
                + struct.pack(f"<{self.count}I", *self.crc)
                + struct.pack("<H", len(self.recent)) + struct.pack(f"<{len(self.recent)}I", *self.recent))

    @staticmethod
    def write(path: str, data: bytes) -> None:
        """Atomically: a temporary file first, then renamed over the old map."""
        tmp = path + ".tmp"
        with open(tmp, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        for i in range(5):
            try:
                os.replace(tmp, path)
                return
            except PermissionError:  # Windows: a virus scanner may be looking at the old map
                if i == 4:
                    raise
                time.sleep(0.05)

    @classmethod
    def load(cls, path: str, size: int, piece: int = PIECE) -> "PieceMap":
        """The saved map, or an empty one when there's none or it doesn't fit the file."""
        m = cls(size, piece)
        try:
            data = Path(path).read_bytes()
        except OSError:
            return m
        try:
            if not data.startswith(MAP_MAGIC):
                return m
            o = len(MAP_MAGIC)
            fsize, fpiece, count = struct.unpack_from("<QII", data, o)
            o += 16
            if fsize != m.size or fpiece != m.piece or count != m.count:
                return m
            nbits = (count + 7) // 8
            bits = data[o:o + nbits]
            o += nbits
            crcs = struct.unpack_from(f"<{count}I", data, o)
            o += 4 * count
            (nrec,) = struct.unpack_from("<H", data, o)
            o += 2
            recent = list(struct.unpack_from(f"<{nrec}I", data, o))
        except struct.error:
            return m
        if len(bits) != nbits:
            return m
        for i in range(count):
            if bits[i >> 3] & (1 << (i & 7)):
                m.done[i] = 1
                m.n += 1
                m.crc[i] = crcs[i]
        m.recent = [i for i in recent if 0 <= i < count and m.done[i]][-RECENT:]
        return m


class _Claim:
    __slots__ = ("a", "b", "cancelled")

    def __init__(self, a: int, b: int):
        self.a, self.b, self.cancelled = a, b, False


# -- one cached file ------------------------------------------------------------------------------------

class Job:
    """One file in the cache: loads it in pieces over parallel connections and lets readers wait for them.

    Lock order: the cache's lock may be held while taking a job's lock, never the other way round.
    """

    def __init__(self, cache: "IaCache", entry: dict):
        self.cache = cache
        self.e = entry
        self.key = entry["key"]
        self.lock = threading.RLock()
        self.cond = threading.Condition(self.lock)
        self.open_lock = threading.Lock()
        self.size_lock = threading.Lock()
        self.io = threading.Lock()
        self.save_lock = threading.Lock()
        self.map: Optional[PieceMap] = None
        self.fh = None
        self.taken = bytearray()  # piece there or being loaded
        self.inflight = bytearray()
        self.claims: List[_Claim] = []
        self.conns: set = set()
        self.focus = 0
        self.readers = 0
        self.idle_since = time.monotonic()
        self.thread: Optional[threading.Thread] = None
        self.stop = threading.Event()
        self.closed = False
        self.url: Optional[str] = None  # the storage server's address after archive.org's redirect
        self.throttle = 0  # fewer connections while archive.org is busy (0 = as many as the setting says)
        self.throttled_at = 0.0
        self.attempt = 0
        self.busy_waits = 0
        self.fatal: Optional[Tuple[str, str, str]] = None
        self.force_stall = False
        self.errors = 0
        self.net_errors = 0
        self.last_progress = time.monotonic()
        self.active = 0
        self.bytes = 0
        self.speed = 0.0
        self.dirty = False
        self.saved_at = 0.0

    # -- looking

    @property
    def running(self) -> bool:
        t = self.thread
        return t is not None and t.is_alive()

    def fraction(self) -> Optional[float]:
        with self.lock:
            return self.map.fraction if self.map is not None else None

    def complete(self) -> bool:
        with self.lock:
            if self.map is not None:
                return self.map.complete
        return self.e.get("state") in ("done", "broken")

    def has(self, offset: int) -> bool:
        with self.lock:
            return bool(self.map.done[self.map.piece_of(offset)])

    def piece_end(self, offset: int) -> int:
        m = self.map
        p = m.piece_of(offset)
        return m.start_of(p) + m.length_of(p) - 1

    def _target(self) -> int:
        n = self.cache.settings()["connections"]
        return max(1, min(n, self.throttle) if self.throttle else n)

    # -- state

    def _state(self, state: str, message: str = "", reason: str = "") -> None:
        with self.cache.lock:
            changed = self.e.get("state") != state or self.e.get("message") != message
            self.e.update(state=state, message=message, reason=reason)
            if self.map is not None:
                self.e["pct"] = self.map.fraction
            self.cache.dirty = True
        with self.cond:
            self.cond.notify_all()
        if changed and state not in ("loading", "new"):
            log.info("Internet Archive cache: %s · %s%s", self.key, state, f" ({message})" if message else "")

    # -- size and the storage server's address

    def resolve(self) -> Tuple[str, Optional[int]]:
        """Follow archive.org's ``/download/`` redirect to the storage server (once) and learn the size."""
        url = self.cache.client.file_url(self.e["item"], self.e["name"])
        conn = _Conn(self.cache.read_timeout)
        try:
            for _ in range(6):
                status, headers, resp = conn.get(url, {"Range": "bytes=0-0"})
                loc = headers.get("Location")
                if 300 <= status < 400 and loc:
                    conn.drain(resp)
                    url = urllib.parse.urljoin(url, loc)
                    continue
                if status in (404, 410):
                    raise _Gone()
                if status in (429, 503):
                    raise _Busy(status, headers.get("Retry-After"))
                if status in (401, 403):
                    raise _Denied()
                if status == 206:
                    m = re.match(r"bytes\s+\d+-\d+/(\d+)", headers.get("Content-Range") or "")
                    conn.drain(resp)
                    return url, int(m.group(1)) if m else None
                if status == 200:
                    length = headers.get("Content-Length") or ""
                    return url, int(length) if length.isdigit() else None
                raise _NetError(f"archive.org answered {status}")
            raise _NetError("Too many redirects")
        except (OSError, http.client.HTTPException) as exc:
            raise _NetError(str(exc) or exc.__class__.__name__) from exc
        finally:
            conn.close()

    def ensure_size(self) -> int:
        """The file's size (from archive.org's list of files, else from its first answer)."""
        if self.e.get("size"):
            return int(self.e["size"])
        with self.size_lock:
            if not self.e.get("size"):
                url, size = self.resolve()
                if not size:
                    raise _NetError("archive.org didn't say how big the file is")
                self.url = url
                self._apply_size(size)
        return int(self.e["size"])

    def _apply_size(self, size: Optional[int]) -> None:
        if not size:
            return
        with self.cache.lock:
            if self.e.get("size") == size:
                return
            old = self.e.get("size")
            self.e["size"] = size
            self.cache.dirty = True
        with self.open_lock:
            if self.fh is not None:  # opened with another size: start this file over
                log.info("Internet Archive cache: %s is %s bytes, not %s; loading it again", self.key, size, old)
                with self.lock:
                    self.map = PieceMap(size, self.cache.piece_size)
                    self.taken = bytearray(self.map.count)
                    self.inflight = bytearray(self.map.count)
                    self.focus = 0
                with self.io:
                    self.fh.truncate(size)
                self.dirty = True

    # -- the cache file

    def ensure_open(self) -> None:
        """Open the ``.part`` file and its piece map (made new, exclusively, when there's none yet)."""
        with self.open_lock:
            if self.fh is not None:
                return
            if self.closed:
                raise _NetError("closed")
            size = int(self.e.get("size") or 0)
            if size <= 0:
                raise _NetError("size unknown")
            path = self.e.get("path") or ""
            if path and os.path.isfile(path) and self.cache.own(self.e):
                fh = open(path, "r+b", buffering=0)
                m = PieceMap.load(path + ".pieces", size, self.cache.piece_size)
                if os.fstat(fh.fileno()).st_size != size:
                    m.clear()
                    fh.truncate(size)
                self._check_recent(fh, m)
            else:
                path, fh = self.cache.create_file(self.e, size)
                m = PieceMap(size, self.cache.piece_size)
                with self.cache.lock:  # a new file: whatever the entry said about the old one is over
                    if self.e.get("state") in ("done", "broken"):
                        self.e.update(state="new", message="", reason="")
                    self.e.update(verified=False, reloaded=False, pct=0.0)
            with self.lock:
                self.fh, self.map = fh, m
                self.taken = bytearray(m.done)
                self.inflight = bytearray(m.count)
            with self.cache.lock:
                self.e["pct"] = m.fraction

    def _check_recent(self, fh, m: PieceMap) -> None:
        """After a restart: the pieces written last must still match their checksum (else load them again)."""
        bad = []
        for p in list(m.recent):
            try:
                fh.seek(m.start_of(p))
                data = fh.read(m.length_of(p))
            except OSError:
                data = b""
            if len(data) != m.length_of(p) or zlib.crc32(data) & 0xFFFFFFFF != m.crc[p]:
                m.unmark(p)
                bad.append(p)
        if bad:
            log.warning("Internet Archive cache: %d piece(s) of %s were damaged; they load again", len(bad), self.key)

    def _save_map(self) -> None:
        """First the data onto the disk, then the note which pieces are there."""
        with self.save_lock:
            with self.lock:
                if self.fh is None or self.map is None:
                    return
                data = self.map.to_bytes()
                fraction = self.map.fraction
                self.dirty = False
                fh = self.fh
            try:
                os.fsync(fh.fileno())
                PieceMap.write(self.e["path"] + ".pieces", data)
            except (OSError, ValueError) as exc:
                log.warning("Internet Archive cache: the piece map of %s wasn't saved (%s)", self.key, exc)
                self.dirty = True
            self.saved_at = time.monotonic()
            with self.cache.lock:
                self.e["pct"] = fraction
                self.cache.dirty = True

    def reset(self) -> None:
        """Throw away what's loaded (the cache file stays and is written again from the start)."""
        with self.lock:
            if self.map is not None:
                self.map.clear()
                self.taken = bytearray(self.map.count)
                self.inflight = bytearray(self.map.count)
            self.focus = 0
            self.attempt = self.busy_waits = 0
            self.url = None
        self.dirty = True
        self._save_map()
        with self.cache.lock:
            self.e.update(reloaded=False, verified=False, pct=0.0)
            self.cache.dirty = True

    # -- starting and stopping

    def start(self, force: bool = False) -> bool:
        with self.lock:
            if self.closed or self.running:
                return False
            if self.e.get("state") in ("gone", "broken") and not force:
                return False
            if self.e.get("state") == "done" and not force and (self.map is None or self.map.complete):
                return False
            self.stop = threading.Event()
            self.thread = threading.Thread(target=self._run, daemon=True, name="anibox-iacache-job")
            self.thread.start()
        return True

    def stop_running(self, wait: bool = True) -> None:
        with self.lock:
            t, ev = self.thread, self.stop
            conns = list(self.conns)
        if t is None:
            return
        ev.set()
        for c in conns:
            c.abort()
        if wait and t is not threading.current_thread():
            t.join(30)

    def close(self) -> None:
        """Stop loading, save the map and let go of the file (readers keep their own handles)."""
        self.stop_running()
        with self.lock:
            self.closed = True
            self.cond.notify_all()
        self._save_map()
        with self.open_lock, self.lock:
            fh, self.fh = self.fh, None
        if fh is not None:
            try:
                fh.close()
            except OSError:
                pass

    def disk_full(self, need: int = 0) -> None:
        where = os.path.splitdrive(os.path.abspath(self.cache.settings()["dir"]))[0] or "the cache's drive"
        more = f" AniBox needs about {need / GB:.1f} GB more." if need > 0 else ""
        self._state("paused", f"The disk is full ({where}).{more} Make room, then click Try again.", "disk")

    # -- readers (the stream server)

    def set_focus(self, offset: int) -> None:
        """A reader wants this point: load from there first. A real jump redirects the requests that
        load far away from it; reading on normally only changes the order."""
        with self.lock:
            if self.map is None:
                return
            p = self.map.piece_of(offset)
            if self.focus == p:
                return
            old, self.focus = self.focus, p
            window = max(1, self._target()) * RUN_PIECES
            if not (p < old or p > old + window) or self.map.done[p]:
                return
            moved = 0
            for c in self.claims:
                if not (c.a <= p <= c.b) and (c.b < p or c.a > p + window):
                    c.cancelled = True
                    moved += 1
        log.info("Internet Archive cache: %s jumps to %.0f MB (%d request(s) moved)", self.key, offset / 1048576, moved)

    def want(self, offset: int) -> None:
        self.set_focus(offset)
        if not self.running:
            if self.e.get("state") == "paused" and self.e.get("reason") not in ("disk", "write", "denied"):
                self.attempt = 0  # someone is watching it now: give it its tries again
            self.start()

    def wait_for(self, offset: int, gone: Callable[[], bool]) -> bool:
        """Wait until the piece at ``offset`` is there. False when the reader should stop (it went away,
        the file is gone from archive.org, or it can't be loaded into the cache)."""
        with self.cond:
            p = self.map.piece_of(offset)
            while not self.map.done[p]:
                if self.closed or self.cache.closed:
                    return False
                st, reason = self.e.get("state"), self.e.get("reason")
                if st == "gone" or (st == "paused" and reason in ("disk", "write", "denied")):
                    return False
                if not self.running and st not in NEEDS_USER:
                    self.start()
                self.cond.wait(0.5)
                if gone():
                    return False
        return True

    # -- loading

    def _run(self) -> None:
        try:
            if self.e.get("size") and self.e.get("path"):
                try:
                    self.ensure_open()  # a complete file only needs its check, not archive.org (also offline)
                except (OSError, _NetError):
                    pass  # tried again below, with a message
            while not self.stop.is_set():
                if self.map is not None and self.map.complete:
                    ok = self._verify()
                    if ok is None or ok:
                        return
                    if self.e.get("reloaded"):
                        self._state("broken", "The file doesn't match archive.org's checksum, also after loading it "
                                              "again. Click Reload to try once more.")
                        return
                    log.warning("Internet Archive cache: %s doesn't match archive.org's checksum; loading it again", self.key)
                    with self.cache.lock:
                        self.e["reloaded"] = True
                    with self.lock:
                        self.map.clear()
                        self.taken = bytearray(self.map.count)
                        self.focus = 0
                    self.dirty = True
                    self._save_map()
                    continue
                self._state("loading")
                try:
                    if not self.url:
                        url, size = self.resolve()
                        self._apply_size(size)
                        self.url = url
                    self.ensure_open()
                    result = self._round()
                except _Gone:
                    self.fatal, result = ("gone", "This file isn't on archive.org any more.", ""), "fatal"
                except _Denied:
                    self.fatal, result = ("paused", "archive.org doesn't let AniBox load this file (it may be for "
                                                    "lending only or restricted).", "denied"), "fatal"
                except _Busy as busy:
                    delays = self.cache.busy_delays
                    wait = delays[min(self.busy_waits, len(delays) - 1)]
                    self.busy_waits += 1
                    ra = (busy.retry_after or "").strip()
                    if ra.isdigit():
                        wait = max(wait, min(300.0, float(ra)))
                    self._throttle(busy.code)
                    self._state("waiting", f"archive.org is busy. Trying again in {_secs(wait)} …")
                    if self.stop.wait(wait):
                        return
                    continue
                except _NetError as exc:
                    log.info("Internet Archive cache: %s: %s", self.key, exc)
                    result = "stalled"
                except OSError as exc:  # making or opening the cache file
                    if _disk_full(exc):
                        self.fatal = ("paused", "The disk is full. Make room, then click Try again.", "disk")
                    else:
                        self.fatal = ("paused", f"AniBox couldn't write into the cache folder ({exc.strerror or exc}). "
                                                "Check the folder in Settings, then click Try again.", "write")
                    result = "fatal"
                if result == "complete":
                    continue
                if result == "stopped":
                    return
                if result == "fatal":
                    state, message, reason = self.fatal or ("paused", "", "")
                    self.fatal = None
                    self._state(state, message, reason)
                    return
                # Stuck: is the internet gone, or is it archive.org?
                self.url = None
                if not self.cache.online():
                    self._state("offline", "AniBox can't reach archive.org (no internet?). Loading goes on by itself "
                                           "when it's back.")
                    log.info("Internet Archive cache: no internet, waiting")
                    while not self.cache.online():
                        if self.stop.wait(self.cache.offline_poll):
                            return
                    log.info("Internet Archive cache: the internet is back")
                    continue  # no try used up
                self.attempt += 1
                delays = self.cache.retry_delays
                if self.attempt > len(delays):
                    self.attempt = 0
                    self._state("paused", f"archive.org didn't send this file after {len(delays)} tries.", "retries")
                    return
                wait = delays[self.attempt - 1]
                self._state("waiting", f"Trying again ({self.attempt} of {len(delays)}) in {_secs(wait)} …")
                if self.stop.wait(wait):
                    return
        except Exception as exc:
            log.exception("Internet Archive cache: loading %s stopped", self.key)
            self._state("paused", f"Loading stopped: {exc}", "error")
        finally:
            self._save_map()
            with self.cache.lock:
                live = self.e.get("state") in LIVE
            if live:
                self._state("new")

    def _round(self) -> str:
        """Parallel requests until the file is complete, the job stops, or loading gets stuck."""
        rnd = threading.Event()
        self.last_progress = time.monotonic()
        self.errors = self.net_errors = 0
        self.force_stall = False
        workers: List[threading.Thread] = []
        speed_at, speed_bytes = time.monotonic(), self.bytes
        try:
            while True:
                if self.map.complete:
                    return "complete"
                if self.stop.is_set():
                    return "stopped"
                if self.fatal:
                    return "fatal"
                target = self._target()
                workers = [w for w in workers if w.is_alive()]
                while len(workers) < target and self._claimable():
                    t = threading.Thread(target=self._worker, args=(rnd,), daemon=True, name="anibox-iacache-load")
                    t.start()
                    workers.append(t)
                now = time.monotonic()
                since = now - self.last_progress
                if self.force_stall or (self.errors and (since > self.cache.stall_timeout
                                                         or self.net_errors >= max(4, target))):
                    return "stalled"
                if self.throttle and now - self.throttled_at > self.cache.relax_after:
                    with self.lock:  # archive.org's brake: loosen it slowly again
                        n = self.cache.settings()["connections"]
                        self.throttle = 0 if self.throttle + 2 >= n else self.throttle + 2
                        self.throttled_at = now
                busy = "archive.org is busy: loading with fewer connections for now." if self.throttle else ""
                if self.e.get("message", "") != busy and self.e.get("state") == "loading":
                    with self.cache.lock:
                        self.e["message"] = busy
                if now - speed_at >= 1.0:
                    self.speed = (self.bytes - speed_bytes) / (now - speed_at)
                    speed_at, speed_bytes = now, self.bytes
                if self.dirty and now - self.saved_at >= MAP_SAVE_EVERY:
                    self._save_map()
                self.stop.wait(0.05)
        finally:
            rnd.set()
            with self.lock:
                for c in self.claims:
                    c.cancelled = True
                conns = list(self.conns)
            for c in conns:
                c.abort()
            for w in workers:
                w.join(10)
            self.speed = 0.0
            self._save_map()

    def _claimable(self) -> bool:
        with self.lock:
            return self.taken.find(0) >= 0

    def _claim(self) -> Optional[_Claim]:
        with self.lock:
            p = self.taken.find(0, self.focus)
            if p < 0:
                p = self.taken.find(0, 0, self.focus)
            if p < 0:
                return None
            # At the playing point one piece per request, so the first pieces come in parallel;
            # further on bigger requests for more speed.
            run = 1 if self.focus <= p < self.focus + self._target() else RUN_PIECES
            e = p
            while e + 1 < self.map.count and e + 1 - p < run and not self.taken[e + 1]:
                e += 1
            for i in range(p, e + 1):
                self.taken[i] = 1
                self.inflight[i] = 1
            claim = _Claim(p, e)
            self.claims.append(claim)
            return claim

    def _release(self, claim: _Claim) -> None:
        with self.lock:
            for i in range(claim.a, claim.b + 1):
                if self.inflight[i]:
                    self.inflight[i] = 0
                    if not self.map.done[i]:
                        self.taken[i] = 0
            if claim in self.claims:
                self.claims.remove(claim)

    def _worker(self, rnd: threading.Event) -> None:
        conn = _Conn(self.cache.read_timeout)
        with self.lock:
            self.conns.add(conn)
            self.active += 1
        try:
            while not rnd.is_set() and not self.stop.is_set() and not self.fatal:
                with self.lock:
                    if self.active > self._target():
                        return  # archive.org asked for fewer connections
                claim = self._claim()
                if claim is None:
                    return
                try:
                    self._fetch(claim, conn, rnd)
                finally:
                    self._release(claim)
        finally:
            with self.lock:
                self.conns.discard(conn)
                self.active -= 1
            conn.close()

    def _fetch(self, claim: _Claim, conn: _Conn, rnd: threading.Event) -> None:
        m = self.map
        start = m.start_of(claim.a)
        end = m.start_of(claim.b) + m.length_of(claim.b) - 1
        url = self.url
        if not url:
            self.force_stall = True
            return
        try:
            status, headers, resp = conn.get(url, {"Range": f"bytes={start}-{end}"})
        except (OSError, http.client.HTTPException) as exc:
            if not rnd.is_set():
                self._error(True, str(exc) or exc.__class__.__name__)
            return
        try:
            if status in (404, 410):
                conn.close()
                self.fatal = ("gone", "This file isn't on archive.org any more.", "")
                return
            if status in (429, 503):
                conn.close()
                self._throttle(status)
                rnd.wait(self.cache.busy_pause)
                return
            if status in (401, 403) or 300 <= status < 400:
                conn.close()
                self.force_stall = True  # the storage address may have run out: ask archive.org again
                self._error(False, f"HTTP {status}")
                return
            if status == 206:
                mm = re.match(r"bytes\s+(\d+)-", headers.get("Content-Range") or "")
                if not mm or int(mm.group(1)) != start:
                    conn.close()
                    self._error(False, "archive.org sent another part than asked for")
                    return
            elif not (status == 200 and start == 0):
                conn.close()
                self._error(False, f"HTTP {status}")
                return
            for p in range(claim.a, claim.b + 1):
                data = self._read_exact(resp, m.length_of(p), rnd)
                if data is None:
                    conn.close()
                    return
                self._write(p, data)
                self._piece_done(p, zlib.crc32(data))
                if (claim.cancelled or rnd.is_set()) and p < claim.b:
                    conn.close()  # the reader jumped elsewhere: let the rest go
                    return
            if status == 200:
                conn.close()  # the server sent the whole file; the rest isn't wanted from here
        except _NetError as exc:
            conn.close()
            if not rnd.is_set():
                self._error(True, str(exc))
        except _DiskFull:
            conn.close()
            self.fatal = ("paused", "The disk is full. Make room, then click Try again.", "disk")
        except _WriteError as exc:
            conn.close()
            self.fatal = ("paused", f"AniBox couldn't write the cache file ({exc}). Click Try again.", "write")
        except (OSError, http.client.HTTPException) as exc:
            conn.close()
            if not rnd.is_set():
                self._error(True, str(exc) or exc.__class__.__name__)

    def _read_exact(self, resp, n: int, rnd: threading.Event) -> Optional[bytes]:
        buf = bytearray()
        while len(buf) < n:
            if rnd.is_set() or self.stop.is_set():
                return None
            try:
                data = resp.read(min(65536, n - len(buf)))
            except (OSError, http.client.HTTPException) as exc:
                raise _NetError(str(exc) or "The connection broke off") from exc
            if not data:
                raise _NetError("The connection to archive.org broke off")
            buf += data
            self.bytes += len(data)
        return bytes(buf)

    def _write(self, p: int, data: bytes) -> None:
        try:
            with self.io:
                fh = self.fh
                if fh is None:
                    raise _NetError("closed")
                fh.seek(self.map.start_of(p))
                view = memoryview(data)
                while view:
                    n = fh.write(view)
                    view = view[n:]
        except OSError as exc:
            if _disk_full(exc):
                raise _DiskFull() from exc
            raise _WriteError(exc.strerror or str(exc)) from exc

    def _piece_done(self, p: int, crc: int) -> None:
        with self.cond:
            self.map.mark(p, crc)
            self.inflight[p] = 0
            self.taken[p] = 1
            self.dirty = True
            self.last_progress = time.monotonic()
            self.errors = self.net_errors = 0
            self.attempt = 0
            self.busy_waits = 0
            self.cond.notify_all()

    def _error(self, net: bool, message: str) -> None:
        with self.lock:
            self.errors += 1
            if net:
                self.net_errors += 1
        log.info("Internet Archive cache: %s: %s", self.key, message)

    def _throttle(self, code: int) -> None:
        with self.lock:
            self.throttle = max(1, self._target() // 2)
            self.throttled_at = time.monotonic()
        log.warning("Internet Archive cache: archive.org is busy (%s); %d connection(s) for %s now",
                    code, self.throttle, self.key)

    def _verify(self) -> Optional[bool]:
        """True: complete and fine; False: the checksum doesn't match; None: stopped while checking."""
        self._save_map()
        md5 = (self.e.get("md5") or "").lower()
        if not md5:
            with self.cache.lock:
                self.e["verified"] = False
            self._state("done")
            return True
        self._state("verifying", "Checking the file …")
        try:
            h = hashlib.md5(usedforsecurity=False)  # type: ignore[call-arg]
        except TypeError:
            h = hashlib.md5()
        try:
            with open(self.e["path"], "rb") as f:
                while True:
                    if self.stop.is_set():
                        return None
                    block = f.read(1 << 20)
                    if not block:
                        break
                    h.update(block)
        except OSError as exc:
            log.warning("Internet Archive cache: %s couldn't be checked (%s)", self.key, exc)
            return False
        if h.hexdigest() == md5:
            with self.cache.lock:
                self.e["verified"] = True
            self._state("done", "Checked ✓")
            return True
        return False


# -- the stream server (127.0.0.1 only) -------------------------------------------------------------------

def parse_range(header: Optional[str], size: int) -> Optional[Tuple[int, int, bool]]:
    """(start, end, partial) for a ``Range`` header; None when it can't be served (416). Several
    ranges at once aren't supported: then the whole file is sent."""
    if not header:
        return 0, size - 1, False
    m = re.fullmatch(r"\s*bytes\s*=\s*(\d*)\s*-\s*(\d*)\s*", header)
    if not m or (not m.group(1) and not m.group(2)):
        return 0, size - 1, False
    a, b = m.groups()
    if not a:
        n = int(b)
        if n <= 0:
            return None
        return max(0, size - n), size - 1, True
    start = int(a)
    end = min(int(b), size - 1) if b else size - 1
    if start >= size or start > end:
        return None
    return start, end, True


class _Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "AniBox"

    def log_message(self, *args):
        pass

    def do_HEAD(self):
        self._serve(head=True)

    def do_GET(self):
        self._serve(head=False)

    def _plain(self, code: int, text: str, head: bool, headers: Optional[dict] = None) -> None:
        body = text.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if not head:
            self.wfile.write(body)

    def _gone(self) -> bool:
        """The player closed this connection (e.g. it jumped elsewhere)."""
        try:
            r, _, _ = select.select([self.connection], [], [], 0)
            return bool(r) and self.connection.recv(1, socket.MSG_PEEK) == b""
        except (OSError, ValueError):
            return True

    def _serve(self, head: bool) -> None:
        cache: IaCache = self.server.cache  # type: ignore[attr-defined]
        host = (self.headers.get("Host") or "").rsplit(":", 1)[0].strip("[]").lower()
        if host not in ("127.0.0.1", "localhost"):
            return self._plain(403, "Forbidden", head)
        parts = urllib.parse.urlsplit(self.path).path.split("/", 3)
        if len(parts) < 4 or not hmac.compare_digest(parts[1].encode(), cache.token.encode()):
            return self._plain(404, "Not found", head)
        ident, name = parts[2], urllib.parse.unquote(parts[3])
        key = stream_key(ident, name)
        if not name or split_key(key) is None:
            return self._plain(404, "Not found", head)
        try:
            src = cache.open_source(key)
        except _Gone:
            return self._plain(404, "This file isn't on archive.org any more.", head)
        except _Busy as exc:
            return self._plain(503, "archive.org is busy.", head, {"Retry-After": "5"} if exc.code else None)
        except (_Denied, _NetError, OSError) as exc:
            log.info("Internet Archive cache: %s can't be served from the cache (%s)", key, exc)
            return self._plain(502, "archive.org didn't answer.", head)
        if src is None:
            return self._plain(404, "Not found", head)
        if src[0] == "direct":  # can't go into the cache right now (disk full …): straight from archive.org
            self.send_response(302)
            self.send_header("Location", src[1])
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        size = src[2] if src[0] == "file" else int(src[1].e["size"])
        rng = parse_range(self.headers.get("Range"), size)
        if rng is None:
            return self._plain(416, "", head, {"Content-Range": f"bytes */{size}"})
        start, end, partial = rng
        self.send_response(206 if partial else 200)
        self.send_header("Content-Type", VIDEO_TYPES.get(os.path.splitext(name)[1].lower())
                         or mimetypes.guess_type(name)[0] or "application/octet-stream")
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(end - start + 1))
        if partial:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        if head:
            return
        if src[0] == "file":
            self._send_file(src[1], start, end)
        else:
            self._send_job(cache, src[1], start, end)

    def _send_file(self, path: str, start: int, end: int) -> None:
        pos = start
        try:
            with open(path, "rb") as f:
                f.seek(start)
                while pos <= end:
                    data = f.read(min(CHUNK, end - pos + 1))
                    if not data:
                        break
                    self.wfile.write(data)
                    pos += len(data)
        except OSError:
            pass
        if pos <= end:
            self.close_connection = True

    def _send_job(self, cache: "IaCache", job: Job, start: int, end: int) -> None:
        cache.reading(job, 1)
        pos = start
        try:
            log.info("Internet Archive cache: player reads %s from %.1f MB%s", job.key, start / 1048576,
                     " (already there)" if job.has(start) else "")
            with open(job.e["path"], "rb", buffering=0) as f:
                while pos <= end:
                    if not job.has(pos):
                        job.want(pos)
                        if not job.wait_for(pos, self._gone):
                            break
                    n = min(CHUNK, min(end, job.piece_end(pos)) - pos + 1)
                    f.seek(pos)
                    data = f.read(n)
                    if not data:
                        break
                    self.wfile.write(data)
                    pos += len(data)
        except OSError:  # the player closed the connection (a jump, the next episode …)
            pass
        finally:
            cache.reading(job, -1)
        if pos <= end:
            self.close_connection = True


class StreamServer(ThreadingHTTPServer):
    daemon_threads = True
    block_on_close = False

    def __init__(self, cache: "IaCache"):
        super().__init__(("127.0.0.1", 0), _Handler)
        self.cache = cache


# -- the cache ------------------------------------------------------------------------------------------

class IaCache:
    """All cached Internet Archive files, the stream server, loading ahead, the limit and Keep."""

    def __init__(self, data_dir: Path, store, streams, client=None, keep_root: Optional[Callable[[], str]] = None,
                 stopping: Optional[threading.Event] = None, background: bool = True):
        self.data_dir = Path(data_dir)
        self.store = store
        self.streams = streams
        self.client = client or streams.client
        self.keep_root = keep_root or (lambda: str(Path.home() / "Downloads"))
        self.stopping = stopping
        self.background = background
        self.index_path = self.data_dir / INDEX_FILE
        self.lock = threading.RLock()
        self.entries: Dict[str, dict] = {}
        self.jobs: Dict[str, Job] = {}
        self.plan: List[str] = []  # the episode playing, then the ones to load ahead
        self.order: Dict[str, int] = {}  # key -> place in the show played last (for "furthest ahead")
        self.cur = 0
        self.titles: Dict[str, str] = {}  # key -> title of the show it was played from
        self.token = secrets.token_urlsafe(18)
        self.server: Optional[StreamServer] = None
        self.thread: Optional[threading.Thread] = None
        self.closed = False
        self.dirty = False
        self.saved_at = 0.0
        self.moving: set = set()
        self._wake = threading.Event()
        self._save_lock = threading.Lock()
        self._s_cache: Optional[dict] = None
        self._s_at = 0.0
        self._cleaned = False
        self._kept_at = 0.0
        self._limit_seen: Optional[int] = None
        # Tunables (the tests make them small)
        self.piece_size = PIECE
        self.retry_delays: Tuple[float, ...] = RETRY_DELAYS
        self.busy_delays: Tuple[float, ...] = RETRY_DELAYS
        self.busy_pause = 5.0
        self.relax_after = 30.0
        self.stall_timeout = 15.0
        self.read_timeout = 20.0
        self.offline_poll = 3.0
        self.tick_every = 0.5
        self.idle_close = 30.0
        self.disk_reserve = DISK_RESERVE
        self.free_space: Callable[[str], int] = free_space
        self.limit_override: Optional[int] = None  # bytes instead of the GB setting (tests)
        self.probe: Optional[Callable[[], bool]] = None
        self._load()

    # -- settings ------------------------------------------------------------------------------------

    def default_dir(self) -> Path:
        return self.data_dir / "ia-cache"

    def settings(self) -> dict:
        now = time.monotonic()
        cached = self._s_cache
        if cached is not None and now - self._s_at < 1.0:
            return cached
        try:
            raw = self.store.settings()
        except Exception:  # AniBox is closing (the database is closed already)
            raw = {}
            if cached is not None:
                return cached
        gb = _clamp(raw.get("ia_cache_gb", DEFAULT_GB), 1, 100000, DEFAULT_GB)
        keep_setting = str(raw.get("ia_keep_dir") or "")
        if keep_setting:
            keep_dir = keep_setting
        else:
            try:
                keep_dir = str(Path(self.keep_root()).parent / KEEP_FOLDER_NAME)  # beside it, not inside:
                # the download folder can be one of the library's folders (it would show a show "Keep")
            except Exception:
                keep_dir = str(Path.home() / "Downloads" / KEEP_FOLDER_NAME)
        out = {
            "enabled": bool(raw.get("ia_cache", True)),
            "dirSetting": str(raw.get("ia_cache_dir") or ""),
            "dir": str(raw.get("ia_cache_dir") or self.default_dir()),
            "gb": gb, "limit": self.limit_override or gb * GB,
            "connections": _clamp(raw.get("ia_cache_connections", DEFAULT_CONNECTIONS), 1, 32, DEFAULT_CONNECTIONS),
            "ahead": _clamp(raw.get("ia_cache_ahead", DEFAULT_AHEAD), 0, 10, DEFAULT_AHEAD),
            "keepSetting": keep_setting, "keepDir": keep_dir,
        }
        self._s_cache, self._s_at = out, now
        return out

    def settings_changed(self) -> None:
        self._s_cache = None
        self.kick()

    def cacheable(self, video: Optional[dict]) -> bool:
        """Does this video go through the cache? (Not when the cache is off, or the file is bigger
        than the whole cache: then mpv reads it straight from archive.org.)"""
        s = self.settings()
        if not s["enabled"]:
            return False
        size = (video or {}).get("size")
        return size is None or 0 < int(size) <= s["limit"]

    # -- saving --------------------------------------------------------------------------------------

    def _load(self) -> None:
        try:
            data = json.loads(self.index_path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return
        except (OSError, ValueError) as exc:
            # Without its index the cache doesn't know which files are its own, so it deletes none of them.
            log.warning("The cache index %s couldn't be read (%s); starting with an empty one", self.index_path, exc)
            try:
                os.replace(self.index_path, self.index_path.with_name("ia-cache.damaged.json"))
            except OSError:
                pass
            return
        entries = data.get("entries") if isinstance(data, dict) else None
        for key, e in (entries or {}).items() if isinstance(entries, dict) else []:
            parts = split_key(key)
            if not parts or not parts[1] or not isinstance(e, dict):
                continue
            e = {**self._blank(key, parts[0], parts[1], {}, "play"), **e, "key": key, "item": parts[0], "name": parts[1]}
            if e["state"] in LIVE:
                e["state"], e["message"] = "new", ""
            self.entries[key] = e
        plan = data.get("plan") if isinstance(data, dict) else None
        self.plan = [k for k in plan if isinstance(k, str) and k in self.entries][:11] if isinstance(plan, list) else []
        order = data.get("order") if isinstance(data, dict) else None
        if isinstance(order, dict):
            self.order = {k: int(v) for k, v in order.items() if isinstance(k, str) and isinstance(v, int)}
        try:
            self.cur = int(data.get("cur") or 0)
        except (TypeError, ValueError):
            self.cur = 0

    def _save_index(self, force: bool = False) -> None:
        with self._save_lock:
            with self.lock:
                if not force and (not self.dirty or time.monotonic() - self.saved_at < 2.0):
                    return
                for key, job in self.jobs.items():
                    f = job.fraction()
                    if f is not None and key in self.entries:
                        self.entries[key]["pct"] = f
                data = {"version": 1, "entries": self.entries, "plan": self.plan,
                        "order": {k: v for k, v in self.order.items() if k in self.entries}, "cur": self.cur}
                text = json.dumps(data, ensure_ascii=False)
                self.dirty = False
                self.saved_at = time.monotonic()
            try:
                self.data_dir.mkdir(parents=True, exist_ok=True)
                tmp = self.index_path.with_name(INDEX_FILE + ".tmp")
                tmp.write_text(text, encoding="utf-8")
                os.replace(tmp, self.index_path)
            except OSError as exc:
                log.warning("The cache index couldn't be saved (%s)", exc)
                with self.lock:
                    self.dirty = True

    # -- entries and jobs -------------------------------------------------------------------------------

    @staticmethod
    def _blank(key: str, item: str, name: str, video: dict, source: str) -> dict:
        return {"key": key, "item": item, "name": name, "path": "", "dir": "", "size": video.get("size"),
                "md5": (video.get("md5") or "").lower(), "state": "new", "message": "", "reason": "", "pct": 0.0,
                "verified": False, "reloaded": False, "source": source, "created": time.time(), "used": 0.0,
                "keep": False, "keepAt": 0.0, "kept": "", "title": ""}

    def _entry(self, key: str, source: str) -> Optional[dict]:
        """The index entry of a key, made when needed (call with the lock held)."""
        e = self.entries.get(key)
        if e is not None:
            return e
        parts = split_key(key)
        if not parts or not parts[1]:
            return None
        video = self.streams.video(*parts)
        if video is None:
            return None
        e = self._blank(key, parts[0], parts[1], video, source)
        self.entries[key] = e
        self.dirty = True
        return e

    def _job(self, key: str) -> Job:
        """The job of an entry (call with the lock held)."""
        job = self.jobs.get(key)
        if job is None or job.closed:
            job = Job(self, self.entries[key])
            self.jobs[key] = job
        return job

    def own(self, e: dict) -> bool:
        """Is this entry's file one the cache made itself? (Only those are ever deleted.)"""
        path, folder = e.get("path") or "", e.get("dir") or ""
        return bool(path and folder) and path.endswith(".part") and _same_dir(Path(path).parent, folder)

    def create_file(self, e: dict, size: int):
        """A new, sparse ``.part`` file for an entry, made exclusively (an existing file is never taken over)."""
        folder = Path(self.settings()["dir"])
        folder.mkdir(parents=True, exist_ok=True)
        base_name = e["name"].rsplit("/", 1)[-1]
        tag = hashlib.sha1(e["key"].encode("utf-8")).hexdigest()[:8]
        stem = f"{safe_name(e['item'], 'item', 40)} - {safe_name(base_name, 'video', 60)}.{tag}"
        for n in range(1, 100):
            path = folder / (stem + (f" ({n})" if n > 1 else "") + ".part")
            if os.path.lexists(str(path) + ".pieces"):
                continue
            try:
                fh = open(path, "x+b", buffering=0)
            except FileExistsError:
                continue
            try:
                _set_sparse(fh)
                fh.truncate(size)
            except OSError:
                fh.close()
                try:
                    os.remove(path)
                except OSError:
                    pass
                raise
            with self.lock:
                e["path"], e["dir"] = str(path), str(folder)
                self.dirty = True
            log.info("Internet Archive cache: new file %s (%.1f MB)", path.name, size / 1048576)
            return str(path), fh
        raise OSError(errno.EEXIST, "AniBox found no free file name in the cache folder")

    def reading(self, job: Job, delta: int) -> None:
        with self.lock:
            job.readers = max(0, job.readers + delta)
            job.idle_since = time.monotonic()
            job.e["used"] = time.time()
            if delta > 0 and job.e.get("source") != "play":
                job.e["source"] = "play"
            self.dirty = True

    def open_source(self, key: str):
        """What the stream server reads for a key: ("file", path, size) for a kept file,
        ("job", job) for the cache, ("direct", url) when it can't go into the cache right now."""
        with self.lock:
            if self.closed:
                return None
            e = self.entries.get(key)
            if e and e.get("kept"):
                kept = e["kept"]
                if os.path.isfile(kept):
                    e["used"] = time.time()
                    return "file", kept, os.path.getsize(kept)
                self._forget_kept(key, e)
            e = self._entry(key, "play")
            if e is None:
                return None
            if e.get("state") == "gone":
                raise _Gone()  # known: no reconnecting again and again (Try again asks archive.org once more)
            job = self._job(key)
            new = not e.get("path") or not os.path.isfile(e["path"])
        direct = self.client.file_url(e["item"], e["name"])
        if job.url is None and (new or e.get("state") != "done"):
            # Ask archive.org first (its redirect is needed anyway): a file that's gone is a 404 now,
            # not an answer that never comes. A complete file plays without asking (also offline).
            try:
                url, size = job.resolve()
                job.url = url
                job._apply_size(size)
            except _Gone:
                job._state("gone", "This file isn't on archive.org any more.")
                raise
            except _Denied:
                job._state("paused", "archive.org doesn't let AniBox load this file (it may be for lending only "
                                     "or restricted).", "denied")
                return "direct", direct
            except (_Busy, _NetError):
                if not e.get("size"):
                    raise  # nobody knows how big it is: nothing to answer with
        job.ensure_size()
        state, reason = e.get("state"), e.get("reason")
        if state == "paused" and reason == "denied":
            return "direct", direct
        if new:
            self.make_room(int(e["size"]), key, {key})  # the episode playing: preloaded ones may go for it
            if not self.disk_ok(job):
                job.disk_full()
                return "direct", direct
        elif state == "paused" and reason in ("disk", "write"):
            if not self.disk_ok(job):
                return "direct", direct
            with self.lock:
                e["state"], e["reason"], e["message"] = "new", "", ""
        try:
            job.ensure_open()
        except OSError as exc:
            log.warning("Internet Archive cache: %s plays straight from archive.org (%s)", key, exc)
            return "direct", direct
        return "job", job

    # -- hooks for stream.py -------------------------------------------------------------------------------

    def address(self, ident: str, name: str) -> Optional[str]:
        try:
            port = self._ensure_started()
        except OSError as exc:
            log.warning("Internet Archive cache: the stream server couldn't start (%s)", exc)
            return None
        if port is None:
            return None
        return f"http://127.0.0.1:{port}/{self.token}/{ident}/{urllib.parse.quote(name, safe='/')}"

    def _kept_file(self, key: str) -> str:
        with self.lock:
            e = self.entries.get(key)
            kept = e.get("kept") if e else ""
        return kept if kept and os.path.isfile(kept) else ""

    def local(self, ident: str, name: str, video: Optional[dict]) -> bool:
        """Does mpv read this video from the cache's server?"""
        if self.closed:
            return False
        return bool(self._kept_file(stream_key(ident, name))) or self.cacheable(video)

    def url_hook(self, ident: str, name: str, video: dict) -> Optional[str]:
        """``IaStreams.url_hooks``: the cache's address for a video (kept files always play from the Keep folder)."""
        if not self.local(ident, name, video):
            return None
        return self.address(ident, name)

    def play_hook(self, show: dict, idx: int) -> None:
        """``IaStreams.play_hooks``: an episode started. Load it first, then the next ones."""
        eps = show.get("episodes") or []
        if not 0 <= idx < len(eps):
            return
        s = self.settings()
        if not s["enabled"]:
            with self.lock:
                self.plan = []
            return
        keys = []
        for i in range(idx, min(len(eps), idx + 1 + s["ahead"])):
            parts = split_key(eps[i].get("key") or "")
            if not parts or not parts[1]:
                continue
            video = self.streams.video(*parts)
            if video is None or not self.cacheable(video) or (i > idx and not video.get("size")):
                continue  # straight from archive.org, or a size nobody knows (no room can be kept for it)
            keys.append(eps[i]["key"])
        title = str(show.get("title") or "")
        with self.lock:
            self.plan = keys
            self.order = {e["key"]: i for i, e in enumerate(eps) if isinstance(e.get("key"), str)}
            self.cur = idx
            for n, key in enumerate(keys):
                e = self._entry(key, "play" if n == 0 else "preload")
                if e is not None and title and not e.get("kept"):
                    e["title"] = title[:200]
                    self.titles[key] = title[:200]
            self.dirty = True
        if keys:
            log.info("Internet Archive cache: playing %s, loading ahead: %s", keys[0], ", ".join(keys[1:]) or "nothing")
        self._ensure_started()
        self.kick()

    def mpv_option_hook(self, key: str) -> str:
        """``IaStreams.option_hooks``: mpv waits for the cache instead of giving up after 60 s (and then
        ending the episode early): ``network-timeout=0`` for the cache's addresses."""
        parts = split_key(key)
        if parts and parts[1] and self.local(parts[0], parts[1], self.streams.video(*parts)):
            return "network-timeout=0"
        return ""

    def has_file(self, ident: str, name: str) -> bool:
        """``IaStreams.local_checks``: the whole file is on this PC (kept, or fully loaded and checked)."""
        key = stream_key(ident, name)
        if self._kept_file(key):
            return True
        with self.lock:
            e = self.entries.get(key)
            return bool(e) and e.get("state") == "done"

    def local_file(self, ident: str, name: str) -> Optional[str]:
        """``IaStreams.local_files``: where the whole file is on this PC: the kept file, or the cache's own
        file once it's fully loaded and checked (a ``.part`` file; it moves when it's kept). None otherwise."""
        key = stream_key(ident, name)
        kept = self._kept_file(key)
        if kept:
            return kept
        with self.lock:
            e = self.entries.get(key)
            if not e or e.get("state") != "done" or not self.own(e):
                return None
            path = e["path"]
        return path if os.path.isfile(path) else None

    def wrap_mpv_options(self) -> None:
        """Registers :meth:`mpv_option_hook`, :meth:`has_file` and :meth:`local_file` with the streams."""
        if self.mpv_option_hook not in self.streams.option_hooks:
            self.streams.option_hooks.append(self.mpv_option_hook)
        if self.has_file not in self.streams.local_checks:
            self.streams.local_checks.append(self.has_file)
        if self.local_file not in self.streams.local_files:
            self.streams.local_files.append(self.local_file)

    # -- running ---------------------------------------------------------------------------------------

    def _ensure_started(self) -> Optional[int]:
        with self.lock:
            if self.closed:
                return None
            if self.server is None:
                srv = StreamServer(self)
                threading.Thread(target=srv.serve_forever, kwargs={"poll_interval": 0.3}, daemon=True,
                                 name="anibox-iacache-server").start()
                self.server = srv
                log.info("Internet Archive cache: stream server on 127.0.0.1:%d", srv.server_address[1])
            if self.background and (self.thread is None or not self.thread.is_alive()):
                self.thread = threading.Thread(target=self._loop, daemon=True, name="anibox-iacache")
                self.thread.start()
            return self.server.server_address[1]

    def resume(self) -> None:
        """At AniBox's start: go on with what was left (keeping, loading ahead) and keep the limit."""
        with self.lock:
            pending = any(e.get("keep") and not e.get("kept") for e in self.entries.values())
            used = sum(int(e.get("size") or 0) for e in self.entries.values()
                       if e.get("path") and not e.get("kept") and not e.get("keep"))
            planned = any(self.entries.get(k, {}).get("state") not in ("done",) for k in self.plan)
            kept = any(e.get("kept") for e in self.entries.values())
        if pending or kept or (planned and self.settings()["enabled"]) or used > self.settings()["limit"]:
            self._ensure_started()

    def kick(self) -> None:
        self._wake.set()

    def _loop(self) -> None:
        while True:
            if self.stopping is not None and self.stopping.is_set():
                self.shutdown()
                return
            if self.closed:
                return
            try:
                self.tick()
            except Exception:
                log.exception("Internet Archive cache: planning failed")
            self._wake.wait(self.tick_every)
            self._wake.clear()

    def tick(self) -> None:
        """One look at everything: what loads now, what stops, what moves to Keep, what gets saved."""
        if self.closed:
            return
        s = self.settings()
        now = time.monotonic()
        if not self._cleaned:
            self._cleaned = True
            with self.lock:
                protect = set(self.plan)
            self.make_room(0, None, protect)  # at the start (e.g. after the limit was made smaller)
        elif self._limit_seen is not None and s["limit"] < self._limit_seen:
            with self.lock:
                protect = set(self.plan[:1])
            self.make_room(0, None, protect)
        self._limit_seen = s["limit"]
        if now - self._kept_at > 10:
            self._kept_at = now
            self.check_kept()
        with self.lock:
            plan = list(self.plan) if s["enabled"] else []
            keepq = sorted((k for k, e in self.entries.items() if e.get("keep") and not e.get("kept") and k not in plan),
                           key=lambda k: self.entries[k].get("keepAt") or 0)
        order = plan + keepq
        active = False
        for key in order:
            with self.lock:
                e = self._entry(key, "preload")
                if e is None or e.get("kept") or key in self.moving:
                    continue
                job = self._job(key)
            if job.complete():
                if e.get("state") not in ("done", "broken", "verifying") and not job.running:
                    job.start()  # complete but not checked yet
                continue
            if e.get("state") in NEEDS_USER:
                continue
            if not active:
                active = True
                if not job.running:
                    new = not e.get("path") or not os.path.isfile(e["path"])
                    if new and key in plan and key == plan[0]:
                        self.make_room(int(e.get("size") or 0), key, {key})  # the one playing: preloaded ones may go
                    elif new and key in plan:
                        # Loading ahead only when there's room for it in the cache
                        if not e.get("size") or not self.make_room(int(e["size"]), key, set(plan)):
                            active = False  # the next one may still load (e.g. one to keep)
                            continue
                    if e.get("size") and not self.disk_ok(job):
                        job.disk_full(self._remaining(job) + self.disk_reserve - self._free(job))
                        active = False
                        continue
                    job.start()
            elif job.running and job.readers == 0:
                job.stop_running(wait=False)  # one file at a time: the one playing gets the whole line
        with self.lock:
            others = [(k, j) for k, j in self.jobs.items() if k not in order]
        for key, job in others:
            if job.running and job.readers == 0 and not job.complete():
                job.stop_running(wait=False)
            elif not job.running and job.map is not None and job.map.complete and job.e.get("state") == "new":
                job.start()  # complete but not checked yet (e.g. after a restart): only the check runs
            elif not job.running and job.readers == 0 and now - job.idle_since > self.idle_close:
                with self.lock:
                    if self.jobs.get(key) is job:
                        del self.jobs[key]
                job.close()  # let go of the file (Windows can't move or delete open files)
        # Keep: finished and checked ones move to the Keep folder
        with self.lock:
            ready = [k for k, e in self.entries.items() if e.get("keep") and not e.get("kept") and e.get("state") == "done"
                     and k not in self.moving and time.time() >= float(e.get("moveRetryAt") or 0)]
        for key in ready:
            with self.lock:
                job = self.jobs.get(key)
                if job is not None and (job.readers or job.running):
                    continue  # after it stopped playing
                self.moving.add(key)
            threading.Thread(target=self._move_to_keep, args=(key,), daemon=True, name="anibox-iacache-keep").start()
        self._save_index()

    # -- room ----------------------------------------------------------------------------------------

    def _free(self, job: Job) -> int:
        folder = os.path.dirname(job.e.get("path") or "") or self.settings()["dir"]
        try:
            return int(self.free_space(folder))
        except Exception:
            return 1 << 62

    def _remaining(self, job: Job) -> int:
        size = int(job.e.get("size") or 0)
        f = job.fraction()
        done = f if f is not None else float(job.e.get("pct") or 0)
        return max(0, int(size * (1 - done)))

    def disk_ok(self, job: Job) -> bool:
        """Is there room on the drive for the rest of this file (and a reserve)?"""
        return self._free(job) - self._remaining(job) >= self.disk_reserve

    def make_room(self, needed: int, for_key: Optional[str], protect) -> bool:
        """Keep the cache under its limit with ``needed`` more bytes: delete what goes first (watched
        episodes, the oldest first; then the ones loaded furthest ahead). Never files being read, loading,
        protected, to be kept or kept, and never a file the cache didn't make itself."""
        limit = self.settings()["limit"]
        with self.lock:
            cands, used = [], 0
            for key, e in self.entries.items():
                if key == for_key or e.get("kept") or e.get("keep") or not self.own(e):
                    continue
                if not os.path.isfile(e["path"]):
                    continue
                size = int(e.get("size") or 0) or allocated(e["path"])
                used += size
                cands.append((key, e, size))
            if used + needed <= limit:
                return True
            order = self._deletion_order(cands, set(protect or ()))
        for key, e, size in order:
            if used + needed <= limit:
                break
            if self._delete(key, "to make room"):
                used -= size
        if used + needed > limit:
            log.info("Internet Archive cache: no room for %.1f MB more (%.1f of %.1f GB used)",
                     needed / 1048576, used / GB, limit / GB)
        return used + needed <= limit

    def _deletion_order(self, cands, protect: set):
        try:  # "watched" = finished by every profile that started it, so nobody's place goes first
            done = self.store.watched_by_everyone()
        except Exception:
            done = {}
        watched, rest = [], []
        for key, e, size in cands:
            job = self.jobs.get(key)
            if key in protect or key in self.moving or (job is not None and (job.readers or (job.running and not job.complete()))):
                continue
            if key in done:
                watched.append((done[key], key, e, size))
            else:
                pos = self.order.get(key)
                ahead = pos - self.cur if pos is not None else 10 ** 9
                rest.append((-ahead, float(e.get("used") or e.get("created") or 0), key, e, size))
        watched.sort(key=lambda x: x[0])
        rest.sort(key=lambda x: (x[0], x[1]))
        return [(k, e, s) for _, k, e, s in watched] + [(k, e, s) for _, _, k, e, s in rest]

    def _delete(self, key: str, why: str) -> bool:
        """Delete a cache file (only one the cache made itself) and forget it."""
        with self.lock:
            e = self.entries.get(key)
            if e is None or e.get("kept"):
                return False
            job = self.jobs.pop(key, None)
        if job is not None:
            job.close()
        path = e.get("path") or ""
        if path and self.own(e):
            for p in (path, path + ".pieces", path + ".pieces.tmp"):
                try:
                    os.remove(p)
                except FileNotFoundError:
                    pass
                except OSError as exc:
                    log.warning("Internet Archive cache: %s couldn't be deleted (%s)", p, exc)
                    if p == path:
                        return False
        with self.lock:
            if self.entries.get(key) is e:
                del self.entries[key]
            self.dirty = True
        log.info("Internet Archive cache: removed %s (%s)", key, why)
        return True

    # -- Keep ----------------------------------------------------------------------------------------

    def keep_name(self, e: dict) -> str:
        """``<item or show title> – <file name>``, as a file name Windows accepts."""
        known = self.streams.known(e["item"]) or {}
        title = (e.get("title") or self.titles.get(e["key"]) or known.get("title") or e["item"]).strip()
        base = e["name"].rsplit("/", 1)[-1]
        squash = lambda t: re.sub(r"[\W_]+", "", t).casefold()  # noqa: E731
        name = base if squash(os.path.splitext(base)[0]).startswith(squash(title)) else f"{title} – {base}"
        return safe_name(name, base, 150)

    def _move_file(self, src: Path, target: Path) -> Path:
        """Move ``src`` to ``target`` without ever replacing a file there (a new name gets " (2)")."""
        for _ in range(50):
            try:
                move_no_replace(src, target)
                return target
            except FileExistsError:
                target = unique_path(target)
            except OSError as exc:
                if not _cross_device(exc):
                    raise
                break
        else:
            raise OSError(errno.EEXIST, "no free file name in the Keep folder")
        # Another drive: copy, check the size, then remove the cache file
        tmp = unique_path(target.with_name(target.name + ".anibox-part"))
        with open(src, "rb") as a, open(tmp, "xb") as b:
            shutil.copyfileobj(a, b, 1 << 20)
            b.flush()
            os.fsync(b.fileno())
        if os.path.getsize(tmp) != os.path.getsize(src):
            os.remove(tmp)
            raise OSError(errno.EIO, "the copy in the Keep folder is incomplete")
        for _ in range(50):
            try:
                move_no_replace(tmp, target)
                break
            except FileExistsError:
                target = unique_path(target)
        else:
            raise OSError(errno.EEXIST, "no free file name in the Keep folder")
        os.remove(src)
        return target

    def _move_to_keep(self, key: str) -> None:
        e = None
        try:
            with self.lock:
                e = self.entries.get(key)
                job = self.jobs.pop(key, None)
            if job is not None:
                job.close()
            if not e or not e.get("keep") or e.get("kept") or not self.own(e):
                return
            src = Path(e["path"])
            folder = Path(self.settings()["keepDir"])
            folder.mkdir(parents=True, exist_ok=True)
            target = unique_path(fit_path(folder, [self.keep_name(e)]))
            moved = self._move_file(src, target)
            for p in (str(src) + ".pieces", str(src) + ".pieces.tmp"):
                try:
                    os.remove(p)
                except OSError:
                    pass
            with self.lock:
                e.update(kept=str(moved), path="", dir="", state="done", message="", keptAt=time.time())
                self.dirty = True
            log.info("Internet Archive cache: kept %s as %s", key, moved)
        except OSError as exc:
            log.warning("Internet Archive cache: %s couldn't be moved to the Keep folder (%s)", key, exc)
            if e is not None:
                with self.lock:
                    e["message"] = (f"AniBox couldn't move it to the Keep folder ({exc.strerror or exc}). "
                                    "It tries again in a minute.")
                    e["moveRetryAt"] = time.time() + 60
                    self.dirty = True
        finally:
            with self.lock:
                self.moving.discard(key)
            self._save_index(force=True)

    def _forget_kept(self, key: str, e: dict) -> None:
        log.info("Internet Archive cache: the kept file %s is gone (deleted?); forgetting it", e.get("kept"))
        with self.lock:
            if self.entries.get(key) is e:
                del self.entries[key]
            self.dirty = True

    def check_kept(self) -> None:
        """Kept files someone deleted in the Keep folder: forget them. Cache files someone deleted:
        the entry starts again from nothing."""
        with self.lock:
            kept = [(k, e) for k, e in self.entries.items() if e.get("kept")]
            lost = [e for k, e in self.entries.items() if not e.get("kept") and e.get("path") and k not in self.jobs
                    and k not in self.moving and not os.path.isfile(e["path"])]
            for e in lost:
                log.info("Internet Archive cache: %s is gone from the cache folder; it loads again when needed", e["path"])
                e.update(path="", dir="", state="new", message="", reason="", pct=0.0, verified=False, reloaded=False)
                self.dirty = True
            # Entries without a file that nobody needs any more (a week old): forgotten, so the index stays small
            old = time.time() - 7 * 86400
            for k, e in list(self.entries.items()):
                last = max(float(e.get("used") or 0), float(e.get("created") or 0))
                if (not e.get("path") and not e.get("kept") and not e.get("keep") and k not in self.plan
                        and k not in self.jobs and last < old):
                    del self.entries[k]
                    self.dirty = True
        for key, e in kept:
            if not os.path.isfile(e["kept"]):
                self._forget_kept(key, e)

    def keep(self, key: str, on: bool = True, title: str = "") -> dict:
        parts = split_key(key)
        if not parts or not parts[1]:
            raise ValueError("That isn't an Internet Archive video.")
        with self.lock:
            e = self.entries.get(key)
            if on:
                if e is None:
                    e = self._entry(key, "keep")
                    if e is None:
                        raise ValueError("AniBox doesn't know this video yet. Open its item first.")
                if not e.get("kept"):
                    e["keep"] = True
                    e["keepAt"] = time.time()
                    title = str(title or "").strip()
                    if title:
                        e["title"] = title[:200]
                    elif not e.get("title"):
                        e["title"] = self.titles.get(key) or (self.streams.known(parts[0]) or {}).get("title") or ""
                    log.info("Internet Archive cache: keep %s", key)
            elif e is not None and not e.get("kept"):
                e["keep"] = False
                e.pop("moveRetryAt", None)
                log.info("Internet Archive cache: don't keep %s", key)
            self.dirty = True
        self._ensure_started()
        self.kick()
        return self.state(key)

    # -- buttons -------------------------------------------------------------------------------------

    def action(self, key: str, what: str) -> dict:
        """"retry" (Try again), "restart" (Start over) or "reload" (a broken file)."""
        if what not in ("retry", "restart", "reload"):
            raise ValueError("Unknown action")
        with self.lock:
            e = self.entries.get(key)
            if e is None or e.get("kept"):
                raise KeyError("That video isn't in the cache.")
            job = self._job(key)
        if what == "retry":
            job.attempt = 0
            with self.lock:
                e.update(state="new", message="", reason="")
            job.start(force=True)
        else:
            job.stop_running()
            with self.lock:
                e.update(state="new", message="", reason="")
            if e.get("path") and os.path.isfile(e["path"]):
                try:
                    job.ensure_open()
                    job.reset()
                except (OSError, _NetError):
                    pass
            job.start(force=True)
        log.info("Internet Archive cache: %s · %s", key, what)
        self._ensure_started()
        self.kick()
        return self.state(key)

    def empty(self) -> dict:
        """"Empty the cache": delete every cache file (only the cache's own; not kept ones, not ones
        waiting to be kept, not the one playing)."""
        with self.lock:
            keys = [k for k, e in self.entries.items() if not e.get("kept") and not e.get("keep")]
            keeping = sum(1 for e in self.entries.values() if e.get("keep") and not e.get("kept"))
            self.plan = self.plan[:1]  # nothing loads ahead again until the next episode starts
        removed = freed = in_use = 0
        for key in keys:
            with self.lock:
                e = self.entries.get(key)
                job = self.jobs.get(key)
                if e is None:
                    continue
                if (job is not None and job.readers) or key in self.moving:
                    in_use += 1
                    continue
                path = e.get("path") if self.own(e) else ""
            size = allocated(path) if path and os.path.isfile(path) else 0
            if self._delete(key, "the cache was emptied") and path:
                removed += 1
                freed += size
        self._save_index(force=True)
        log.info("Internet Archive cache emptied: %d file(s), %.1f MB", removed, freed / 1048576)
        return {"removed": removed, "freed": freed, "inUse": in_use, "keeping": keeping}

    # -- what the window shows -------------------------------------------------------------------------

    def state(self, key: str) -> dict:
        with self.lock:
            e = self.entries.get(key)
            if e is None:
                return {"state": "none", "label": "", "keep": False, "pct": 0, "actions": [], "message": ""}
            if e.get("kept"):
                if os.path.isfile(e["kept"]):
                    return {"state": "kept", "label": "Kept", "keep": True, "kept": True, "pct": 100, "actions": [],
                            "path": e["kept"], "message": "In your Keep folder: " + e["kept"]}
                self._forget_kept(key, e)
                return self.state(key)
            job = self.jobs.get(key)
            f = job.fraction() if job is not None else None
            pct = int(100 * (f if f is not None else float(e.get("pct") or 0)))
            st, keep, msg = e.get("state") or "new", bool(e.get("keep")), e.get("message") or ""
            out = {"keep": keep, "pct": pct, "actions": ACTIONS.get(st, []), "message": msg,
                   "speed": round(job.speed) if job is not None and job.running else 0}
            if key in self.moving:
                out.update(state="moving", label="Moving to Keep …")
            elif st == "done":
                if keep:
                    out.update(state="keeping", label="Keeping · moving soon")
                else:
                    out.update(state="preloaded" if e.get("source") == "preload" else "loaded",
                               label="Preloaded" if e.get("source") == "preload" else "Loaded")
            elif st in ("loading", "waiting"):
                out.update(state="keeping" if keep else st,
                           label=(f"Keeping · loading {pct} %" if keep else f"Loading {pct} %"))
            elif st == "verifying":
                out.update(state="verifying", label="Checking …")
            elif st == "offline":
                out.update(state="offline", label="Waiting for internet")
            elif st == "paused":
                out.update(state="paused", label=f"Paused · {pct} %")
            elif st == "gone":
                out.update(state="gone", label="No longer online")
            elif st == "broken":
                out.update(state="broken", label="Broken")
            elif keep:
                out.update(state="keeping", label=f"Keeping · {pct} %" if pct else "Keeping · waiting")
            elif pct > 0:
                out.update(state="partial", label=f"{pct} % loaded")
            else:
                out.update(state="none", label="")
            return out

    def states(self, keys: List[str]) -> Dict[str, dict]:
        return {k: self.state(k) for k in keys}

    def info(self) -> dict:
        s = self.settings()
        used = files = kept_n = kept_bytes = 0
        with self.lock:
            entries = list(self.entries.values())
            loading = [(k, j) for k, j in self.jobs.items() if j.running]
        for e in entries:
            if e.get("kept"):
                if os.path.isfile(e["kept"]):
                    kept_n += 1
                    kept_bytes += os.path.getsize(e["kept"])
            elif self.own(e) and os.path.isfile(e["path"]):
                files += 1
                used += allocated(e["path"])
        try:
            free = int(self.free_space(s["dir"]))
        except Exception:
            free = None
        now = []
        for key, job in loading:
            st = self.state(key)
            now.append({"key": key, "file": job.e["name"].rsplit("/", 1)[-1], "title": job.e.get("title") or "",
                        "label": st["label"], "pct": st["pct"], "speed": st["speed"], "readers": job.readers})
        return {"enabled": s["enabled"], "dir": s["dir"], "dirSetting": s["dirSetting"], "defaultDir": str(self.default_dir()),
                "gb": s["gb"], "limit": s["limit"], "connections": s["connections"], "ahead": s["ahead"],
                "keepDir": s["keepDir"], "keepSetting": s["keepSetting"], "used": used, "files": files,
                "free": free, "kept": kept_n, "keptBytes": kept_bytes, "loading": now, "busy": self.busy()}

    def busy(self) -> bool:
        """Something is being kept (AniBox stays open until it's in the Keep folder)."""
        with self.lock:
            if self.moving:
                return True
            return any(e.get("keep") and not e.get("kept") and e.get("state") not in NEEDS_USER
                       for e in self.entries.values())

    # -- internet --------------------------------------------------------------------------------------

    def online(self) -> bool:
        """Is archive.org reachable at all? (Any answer counts.)"""
        if self.probe is not None:
            return bool(self.probe())
        conn = _Conn(6.0)
        try:
            conn.get(self.client.base + "/", method="HEAD")
            return True
        except (OSError, http.client.HTTPException):
            return False
        finally:
            conn.close()

    # -- the end ---------------------------------------------------------------------------------------

    def shutdown(self) -> None:
        """AniBox closes: stop loading (it goes on next time), save the maps and the index."""
        with self.lock:
            if self.closed:
                return
            self.closed = True
            jobs = list(self.jobs.values())
            srv, self.server = self.server, None
        self._wake.set()
        for job in jobs:
            try:
                job.close()
            except Exception:
                log.exception("Internet Archive cache: closing a file failed")
        self._save_index(force=True)
        if srv is not None:
            srv.shutdown()
            srv.server_close()
        log.info("Internet Archive cache closed")
