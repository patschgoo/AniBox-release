"""Plex: watch history import (read-only).

Part of the App class (see server.py); the methods use the App's attributes.
"""

from __future__ import annotations

import logging
import threading

from . import plexdetails, plexhistory
from .apierror import ApiError

log = logging.getLogger("anibox.server")


class RoutesPlexMixin:
    def _plex_import(self) -> dict:
        """Copy watched marks and resume points from Plex (read-only there) in the background."""
        if self.plex_import.get("state") == "running":
            return self.plex_import
        creds = plexhistory.saved_credentials()
        if not creds:
            raise ApiError("Sign in to Plex first.")
        pid = self.store.profile  # it all goes into the profile that started it, even if someone switches meanwhile
        row = self.store.profile_row(pid) or {}
        name = row.get("name") or ""
        self.plex_import = {"state": "running", "profileName": name,
                            "message": "Reading your Plex libraries (a sleeping Shield can take a minute) …"}

        def run():
            try:
                entries = plexhistory.fetch_history(*creds, log=lambda m: self.plex_import.update(message=m.strip()))
                keys = [e["key"] for sh in self.library.shows(all_libraries=True) for e in sh["episodes"]]
                self.plex_import["message"] = f"Matching {len(entries):,} Plex episodes to your folders …"
                matched, unmatched = plexhistory.match_keys(entries, keys)
                result = plexhistory.apply_history(self.store, matched, profile=pid)
                shows = sorted({f"{u.get('section', '')} · {u.get('show', '')}" for u in unmatched})
                self.plex_import = {"state": "done", "plex": len(entries), "matched": len(matched),
                                    "unmatched": len(unmatched), "unmatchedShows": shows[:40], "profileName": name, **result}
                log.info("Plex import: %s", {k: v for k, v in self.plex_import.items() if k != "unmatchedShows"})
            except Exception as exc:
                log.exception("Plex import failed")
                self.plex_import = {"state": "error", "message": str(exc) or exc.__class__.__name__}

        threading.Thread(target=run, daemon=True, name="anibox-plex-import").start()
        return self.plex_import

    def _plex_agents(self) -> dict:
        """What the Plex server offers for metadata (read-only): agents and metadata providers.

        Decides how MAL info can get into Plex: "Plex NFO Series" (AniBox writes .nfo files) or
        custom metadata providers ("Add Provider"). The exact names differ between Plex versions,
        so the raw lists are passed on too and the page says to double-check in Plex Web.
        """
        creds = plexhistory.saved_credentials()
        if not creds:
            raise ApiError("Sign in to Plex first (Settings → Your Plex library).")
        reader = plexhistory._Reader(creds[0], creds[1], creds[2])
        found = {"agents": [], "providers": [], "errors": []}
        for path, key in (("/system/agents", "agents"), ("/media/providers", "providers")):
            try:
                data = reader._get(path).get("MediaContainer") or {}
            except Exception as exc:  # an older or newer Plex may not have one of them
                found["errors"].append(f"{path}: {exc}")
                continue
            for item in data.get("Agent") or data.get("MediaProvider") or data.get("Provider") or []:
                ident = str(item.get("identifier") or item.get("id") or "")
                name = str(item.get("title") or item.get("name") or ident)
                if ident or name:
                    found[key].append({"id": ident, "name": name})
        text = " ".join(f"{x['id']} {x['name']}".lower() for x in found["agents"] + found["providers"])
        found["nfo"] = "nfo" in text
        found["custom"] = any(x["id"] and not x["id"].startswith(("tv.plex.", "com.plexapp.", "org.musicbrainz"))
                              for x in found["providers"])
        log.info("Plex agents check: nfo=%s custom=%s (%d agents, %d providers)", found["nfo"], found["custom"],
                 len(found["agents"]), len(found["providers"]))
        return found

    # -- copy of Plex's details (linked, locked): plexdetails.py --------------------------------------

    @property
    def plex_snapshot(self):
        if self._plex_snapshot is None and self.plex_details_path.is_file():
            self._plex_snapshot = plexdetails.load_snapshot(self.plex_details_path) or {}
        return self._plex_snapshot or {}

    def _plex_copy(self) -> dict:
        """Read everything Plex knows about your shows (GET only) and keep it in AniBox, linked by file."""
        if self.plex_copy.get("state") == "running":
            return self.plex_copy
        creds = plexhistory.saved_credentials()
        if not creds:
            raise ApiError("Sign in to Plex first.")
        self.plex_copy = {"state": "running", "message": "Reading your Plex libraries (a sleeping Shield can take a minute) …"}

        def run():
            try:
                details = plexdetails.fetch_details(*creds, posters_dir=self.plex_posters_dir,
                                                    log=lambda m: self.plex_copy.update(message=str(m).strip()))
                shows = self.library.shows(all_libraries=True)
                self.plex_copy["message"] = "Linking Plex's shows to your folders …"
                snapshot = plexdetails.link(details, shows)
                old = plexdetails.load_snapshot(self.plex_details_path) if self.plex_details_path.is_file() else None
                if old:
                    locked = set()
                    lk, ul = self.store.locked_keys(), self.store.unlocked_shows()
                    for sh in shows:
                        locked |= self.library.lock_view(sh, lk, ul)["keys"]
                    snapshot = plexdetails.merge_snapshots(old, snapshot, locked)
                plexdetails.save_snapshot(self.plex_details_path, snapshot)
                self._plex_snapshot = snapshot
                diff = plexdetails.diff_mal(snapshot, shows)
                self.plex_copy = {"state": "done", "counts": snapshot.get("counts") or {}, "diff": len(diff),
                                  "posters": details.get("posters") or {}, "fetched": snapshot.get("fetched")}
                log.info("Plex details copied: %s, %d MAL differences", snapshot.get("counts"), len(diff))
            except Exception as exc:
                log.exception("Copying Plex's details failed")
                self.plex_copy = {"state": "error", "message": str(exc) or exc.__class__.__name__}

        threading.Thread(target=run, daemon=True, name="anibox-plex-copy").start()
        return self.plex_copy

    def _plex_summary(self) -> dict:
        snap = self.plex_snapshot
        if not snap:
            return {}
        return {"fetched": snap.get("fetched"), "server": snap.get("server"), "counts": snap.get("counts") or {},
                "unlinked": len(snap.get("unlinked") or []), "conflicts": len(snap.get("conflicts") or [])}

    def _plex_for_show(self, show: dict) -> dict:
        """What the copy of Plex's details says about this show, for the show page (or {})."""
        entry = (self.plex_snapshot.get("shows") or {}).get(show["id"])
        if not entry:
            return {}
        px = entry.get("plex") or {}
        poster = px.get("poster") or ""
        return {
            "title": px.get("title") or "", "originalTitle": px.get("originalTitle") or "",
            "summary": px.get("summary") or "", "year": px.get("year"), "studio": px.get("studio") or "",
            "genres": px.get("genres") or [], "rating": px.get("rating") or px.get("audienceRating"),
            "contentRating": px.get("contentRating") or "", "section": px.get("section") or "",
            "legacy": bool(px.get("legacy")), "home": bool(entry.get("home", True)),
            "malId": entry.get("mal_id") or "", "malTitle": "", "fetched": self.plex_snapshot.get("fetched"),
            "poster": f"/plexposter/{poster}" if poster else "",
            "others": [o.get("plex", {}).get("section") for o in entry.get("others") or []],
            "episodes": len(entry.get("episodes") or {}),
        }

    def _plex_episodes(self, show: dict) -> dict:
        entry = (self.plex_snapshot.get("shows") or {}).get(show["id"]) or {}
        return entry.get("episodes") or {}

    def _plex_diff(self) -> dict:
        snap = self.plex_snapshot
        if not snap:
            return {"items": []}
        titles = self.library.datasets().titles
        items = plexdetails.diff_mal(snap, self.library.shows(all_libraries=True))
        for it in items:
            it["plex_mal_title"] = (titles.get(str(it.get("plex_mal_id") or "")) or {}).get("title", "")
        return {"items": items}
