"""The Internet Archive page: search archive.org, look at an item, download files (iarchive.py).

Downloads only ever create new files in the chosen download folder (``ia_download_dir``, by default
``Downloads\\AniBox Internet Archive``): ``<download folder>\\<item title>\\<files>``. With "Add to my
AniBox library", AniBox then scans that folder like a library folder, so every item becomes a show.

Part of the App class (see server.py); the methods use the App's attributes.
"""

from __future__ import annotations

import logging
import os
import re
import threading
import time
from pathlib import Path

from . import iarchive
from .apierror import ApiError
from .selfupdate import downloads_dir
from .shortcut import open_folder, pick_folder

log = logging.getLogger("anibox.server")


def _norm(path: str) -> str:
    return os.path.normcase(os.path.normpath(os.path.abspath(str(path))))


def _inside(path: str, folder: str) -> bool:
    p, f = _norm(path), _norm(folder)
    return p == f or p.startswith(f.rstrip("\\/") + os.sep)


def library_name(root: str) -> str:
    """The name AniBox's library gives the download folder (the folder's own name)."""
    parts = [p for p in re.split(r"[\\/]+", str(root)) if p]
    return parts[-1] if parts else ""


class RoutesIaMixin:
    def _ia_init(self) -> None:
        self.ia_client = iarchive.ArchiveClient()
        self.ia = iarchive.Downloads(self.data_dir, self.ia_client, on_done=self._ia_done)
        self.ia_thumbs = iarchive.ThumbCache(self.data_dir / "ia-thumbs", self.ia_client)
        self.ia_library = {"state": "idle", "message": ""}  # "Add to my AniBox library" after downloads
        self.ia_settle = 3.0  # seconds to wait for more finished downloads before scanning
        self._ia_pending = set()  # download folders waiting to be added and scanned
        self._ia_scanned = set()  # finished downloads already handed to the library
        self._ia_lock = threading.Lock()
        self._ia_thread = None
        # downloads from last time go on in serve_forever(): an App whose port was taken must not start them

    def _ia_dir(self) -> str:
        return self.store.settings().get("ia_download_dir") or str(downloads_dir() / iarchive.DEFAULT_FOLDER_NAME)

    # -- API -----------------------------------------------------------------------------------------

    def _ia_get(self, path: str, query: dict):
        if path == "/api/ia/search":
            text = (query.get("q") or "").strip()
            opened = iarchive.link_id(text)
            if opened:  # a pasted archive.org link: go straight to the item
                return {"open": opened}
            try:
                out = self.ia_client.search(text, query.get("media", "video"), query.get("sort", "downloads"),
                                            query.get("page", "1"), (query.get("c") or "").strip())
            except iarchive.ArchiveError as exc:
                raise ApiError(str(exc), 502 if exc.status or str(exc) in (iarchive.NO_CONNECTION, iarchive.BUSY) else 400)
            for r in out["results"]:
                r["img"] = "/ia/thumb/" + r["id"]
            return out
        if path == "/api/ia/item":
            ident = query.get("id", "")
            if not iarchive.valid_id(ident):
                raise ApiError("That isn't an archive.org item name.")
            try:
                item = self.ia_client.item(ident)
            except iarchive.ArchiveError as exc:
                raise ApiError(str(exc), 404 if exc.status == 404 else 502)
            root = self._ia_dir()
            return {"item": {**item, "img": "/ia/thumb/" + ident}, "dir": root,
                    "folder": str(self.ia.folder_for(root, item)) if os.path.isabs(root) else "",
                    "add": bool(self.store.settings().get("ia_add_to_library", True)),
                    "jobs": self.ia.jobs(ident)}
        if path == "/api/ia/downloads":
            return {"jobs": self.ia.jobs(), "dir": self._ia_dir(), "library": self.ia_library,
                    "add": bool(self.store.settings().get("ia_add_to_library", True))}
        raise ApiError("Not found", 404)

    def _ia_post(self, path: str, body: dict):
        if path == "/api/ia/download":
            ident = str(body.get("id") or "")
            if not iarchive.valid_id(ident):
                raise ApiError("That isn't an archive.org item name.")
            files = body.get("files")
            if not isinstance(files, list) or not files or len(files) > 5000 or not all(isinstance(f, str) for f in files):
                raise ApiError("Tick at least one file.")
            root = str(body.get("dir") or "").strip().strip('"') or self._ia_dir()
            add = body.get("add")
            add = bool(self.store.settings().get("ia_add_to_library", True)) if add is None else bool(add)
            try:
                item = self.ia_client.cached_item(ident)
            except iarchive.ArchiveError as exc:
                raise ApiError(str(exc), 404 if exc.status == 404 else 502)
            try:
                out = self.ia.add(item, files, root, add)
            except ValueError as exc:
                raise ApiError(str(exc))
            return {"ok": True, **out}
        if path == "/api/ia/downloads/action":
            try:
                return self.ia.action(str(body.get("action") or ""), str(body.get("id") or ""), str(body.get("item") or ""))
            except KeyError as exc:
                raise ApiError(str(exc.args[0]) if exc.args else "Not found", 404)
            except ValueError as exc:
                raise ApiError(str(exc))
        if path == "/api/ia/dir":
            return self._ia_set_dir(str(body.get("path") or ""))
        if path == "/api/ia/pick-folder":
            picked = pick_folder(title="Choose where AniBox saves downloads from the Internet Archive", new_folder=True)
            return self._ia_set_dir(picked) if picked else {"ok": True, "dir": self._ia_dir(), "changed": False}
        if path == "/api/ia/open":
            return self._ia_open(str(body.get("id") or ""))
        raise ApiError("Not found", 404)

    def _ia_set_dir(self, path: str) -> dict:
        path = path.strip().strip('"')
        if path and not os.path.isabs(path):
            raise ApiError("Type a full folder path, e.g. D:\\Downloads\\Internet Archive.")
        self.store.update_settings({"ia_download_dir": path})
        log.info("Internet Archive download folder: %s", path or "the standard one")
        return {"ok": True, "dir": self._ia_dir(), "changed": True}

    def _ia_open(self, job_id: str) -> dict:
        if job_id:
            job = next((j for j in self.ia.jobs() if j["id"] == job_id), None)
            if not job:
                raise ApiError("That download isn't in the list any more.", 404)
            target = Path(job["target"]).parent if job["state"] == "done" else Path(job["folder"])
            if not target.is_dir():
                raise ApiError("That folder isn't there (any more).")
        else:
            target = Path(self._ia_dir())
            if not target.is_absolute():
                raise ApiError("Choose a download folder first.")
            target.mkdir(parents=True, exist_ok=True)  # the chosen folder itself; nothing in it changes
        open_folder(target)
        return {"ok": True}

    def _ia_thumb(self, ident: str):
        data, ctype = self.ia_thumbs.get(ident)
        return data, ctype or "image/jpeg"

    # -- "Add to my AniBox library" -------------------------------------------------------------------

    def _ia_done(self, job: dict) -> None:
        """A download finished (download thread). When it was the last file of its item that's still
        coming, put the download folder into the scanned folders and scan."""
        if not job.get("add") or self.ia.pending_for_item(job["item"], exclude=job["id"]):
            return
        with self._ia_lock:
            # only new videos need a scan: a subtitle or picture alone doesn't make a show
            # (and mpv finds subtitles next to the video by itself)
            new = [j["id"] for j in self.ia.jobs(job["item"]) if j["add"] and j["state"] == "done"
                   and j["target"].lower().endswith(iarchive.VIDEO_EXT) and j["id"] not in self._ia_scanned]
            if not new:
                return
            self._ia_scanned.update(new)
            self._ia_pending.add(job.get("dir") or str(Path(job["folder"]).parent))
            if self._ia_thread and self._ia_thread.is_alive():
                return
            self._ia_thread = threading.Thread(target=self._ia_add_loop, daemon=True, name="anibox-ia-library")
            self._ia_thread.start()

    def _ia_add_loop(self) -> None:
        try:
            while True:
                time.sleep(self.ia_settle)
                with self._ia_lock:
                    roots = sorted(self._ia_pending)
                    self._ia_pending.clear()
                    if not roots:
                        self._ia_thread = None
                        return
                self._ia_add_roots(roots)
        except Exception as exc:  # shown on the page
            log.exception("Adding the downloads to the library failed")
            self.ia_library = {"state": "error", "message": f"AniBox couldn't add the downloads to the library: {exc}"}
            with self._ia_lock:
                self._ia_thread = None

    def _ia_wait_scan(self, limit: float = 3600) -> None:
        end = time.time() + limit
        while self.library.status.get("state") == "running" and time.time() < end:
            time.sleep(0.2)

    def _ia_add_roots(self, roots) -> None:
        notes, names = [], []
        if self.library.status.get("state") == "running":
            self.ia_library = {"state": "waiting", "message": "Waiting for the scan that's running …"}
            self._ia_wait_scan()
        folders = [str(f) for f in self.store.settings().get("folders") or []]
        for root in roots:
            if any(_inside(root, f) for f in folders):
                names.append(library_name(root))  # already scanned (it's in one of your folders)
            elif any(_inside(f, root) for f in folders):
                notes.append(f"{root} holds a folder AniBox already scans, so it wasn't added. "
                             "Choose a download folder of its own.")
            else:
                folders.append(root)
                names.append(library_name(root))
                log.info("Internet Archive: added the download folder %s to the scanned folders", root)
        self.store.update_settings({"folders": folders})
        if not names:
            self.ia_library = {"state": "error", "message": " ".join(notes)}
            return
        self.ia_library = {"state": "scanning", "message": "Adding your downloads to the library …"}
        for _ in range(3):
            if self.library.scan_async(folders):
                break
            self._ia_wait_scan()  # someone else started a scan; ours comes after it
        self._ia_wait_scan()
        status = self.library.status
        if status.get("state") == "error":
            self.ia_library = {"state": "error", "message": "The downloads are in the folder, but AniBox couldn't scan your "
                               f"folders ({status.get('message')}). Click Scan now in Settings when your drives are reachable."}
            return
        chosen = self.store.settings().get("libraries") or []
        known = self.library.libraries()
        extra = [n for n in dict.fromkeys(names) if n and n in known and n not in chosen]
        if chosen and extra:  # an empty choice shows every library anyway
            self.store.update_settings({"libraries": sorted(set(chosen) | set(extra))})
            self.library.forget_report()
        self.ia_library = {"state": "done", "at": time.time(), "message": "In your library under “" + "”, “".join(
            dict.fromkeys(n for n in names if n)) + "”." + (" " + " ".join(notes) if notes else "")}
