"""Profiles ("Who's watching?", like Plex Home): picking one, switching with a PIN, Settings → Profiles,
and the limits of a kids profile.

Part of the App class (see server.py); the methods use the App's attributes. The routes in the tables
below are window-only (never the phone remote).

- One profile is active at a time: it's one PC and one player (``Store.profile``, remembered across
  restarts). Switching stops nothing; the player keeps saving to the profile that was active when the
  episode started. The phone remote acts on the active profile.
- When AniBox starts with two or more profiles, the window asks "Who's watching?". Until someone
  picks, AniBox only shows things: nothing can be played or changed.
- A restricted (kids) profile sees only its libraries, no adult anime and, unless allowed, no Internet
  Archive tab. It can't open Settings or change anything but its own watching, and it can only switch
  to another profile with the PIN of an unrestricted profile. These limits are checked here, for every
  request (``_pf_guard``), not only hidden in the window.
- PINs have 4–8 digits and are kept only as a salted PBKDF2 hash (store.py). After five wrong PINs
  AniBox waits a minute before it checks another one.
"""

from __future__ import annotations

import dataclasses
import functools
import json
import logging
import threading
import time
from typing import List, Optional

from .apierror import ApiError
from .routes_missing import missing_json
from .store import COLORS, MAIN, MAX_PROFILES, PIN_RE, PROFILE_SETTINGS
from .watching import show_card

log = logging.getLogger("anibox.profiles")

_INIT_LOCK = threading.Lock()

# Always reachable: the window's heartbeat, picking a profile, and placing/closing the video.
ALWAYS = {"/api/ping", "/api/state", "/api/profiles", "/api/profiles/switch", "/api/embed/attach",
          "/api/embed/place", "/api/quit", "/api/update/dismiss"}
# Settings and everything that changes shared things or the files: not for a kids profile (nor before
# someone picked a profile).
ADMIN_GET = ("/api/settings", "/api/search", "/api/history", "/api/health", "/api/import", "/api/tidy",
             "/api/files", "/api/plex", "/api/nfo", "/api/update/local", "/api/media/status", "/api/media/subs",
             "/api/missing/plex", "/api/lists", "/api/tmdb", "/api/iacache")
KIDS_GET = ("/api/lists/badges", "/api/lists/show", "/api/tmdb/show")  # read-only parts of the pages above
# What a kids profile may do: watch, mark its own episodes, start again, the TV and the TV check.
KIDS_POST = {"/api/cmd", "/api/play", "/api/watched", "/api/rewatch/restart", "/api/rewatch/undo",
             "/api/tv/discover", "/api/tv/play", "/api/tv/pair", "/api/media/check", "/api/airing/check"}
ARCHIVE = ("/api/ia", "/api/stream", "/api/iacache")  # the Internet Archive tab
ARCHIVE_KIDS_POST = ("/api/ia", "/api/iacache/states")  # ... when a kids profile may use it
ARCHIVE_ADMIN = ("/api/ia/dir", "/api/ia/pick-folder", "/api/ia/open")
ADULT_GENRES = {"hentai", "erotica"}
MAX_FAILS = 5
WAIT_SECONDS = 60
KIDS_NO = "This profile can't do that. Ask someone with a grown-up profile."
NO_ARCHIVE = "The Internet Archive isn't part of this profile."


def _under(path: str, prefixes) -> bool:
    return any(path == p or path.startswith(p + "/") for p in prefixes)


def _guarded(fn, method: str):
    @functools.wraps(fn)
    def wrapper(self, path, data, remote):
        self._pf_guard(method, path, data if isinstance(data, dict) else {}, remote)
        return fn(self, path, data, remote)
    wrapper._profile_guard = True
    return wrapper


def _adult_details(d: dict) -> bool:
    """MyAnimeList details (malapi.py cache): rated Rx, or the genres Hentai/Erotica."""
    if not isinstance(d, dict):
        return False
    genres = {str(g).lower() for g in d.get("genres") or []}
    return str(d.get("rating") or "").lower().startswith("rx") or bool(genres & ADULT_GENRES)


class RoutesProfilesMixin:
    GET_ROUTES = {"/api/profiles": "_profiles_get"}
    POST_ROUTES = {
        "/api/profiles/switch": "_profiles_switch",
        "/api/profiles/save": "_profiles_save",
        "/api/profiles/delete": "_profiles_delete",
    }

    def __init_subclass__(cls, **kwargs):
        """The App's ``api_get``/``api_post`` pass ``_pf_guard`` first, so the limits hold for every page
        and feature, also ones added later (a kids profile may only do what ``KIDS_POST`` lists)."""
        super().__init_subclass__(**kwargs)
        for name, method in (("api_get", "GET"), ("api_post", "POST")):
            fn = cls.__dict__.get(name)
            if fn is not None and not getattr(fn, "_profile_guard", False):
                setattr(cls, name, _guarded(fn, method))

    # -- state (made on first use, so server.py needs no changes for it) --------------------------------

    def _pf(self) -> dict:
        st = self.__dict__.get("_pf_state")
        if st is not None:
            return st
        with _INIT_LOCK:
            st = self.__dict__.get("_pf_state")
            if st is None:
                st = {"chosen": False, "fails": [], "wait_until": 0.0, "adult": (None, frozenset()), "adult_looked": 0.0,
                      "refreshing": False, "lock": threading.Lock()}
                self.__dict__["_pf_state"] = st
                self.store.export_check = self._pf_export_check
        return st

    def _pf_active(self, profiles: Optional[List[dict]] = None) -> dict:
        profiles = profiles if profiles is not None else self.store.profiles()
        return next((p for p in profiles if p["id"] == self.store.profile), profiles[0])

    def _pf_locked(self, profiles: List[dict]) -> bool:
        """Two or more profiles and nobody picked one since AniBox started."""
        st = self._pf()
        if len(profiles) < 2:
            st["chosen"] = True  # one profile: nothing to ask (a second one made later doesn't lock you out)
        return not st["chosen"]

    def _pf_limits(self) -> Optional[dict]:
        """The active profile's limits when it's a restricted (kids) profile, else None."""
        r = self.store.restrictions()
        return r if r["restricted"] else None

    def _pf_export_check(self) -> None:
        profiles = self.store.profiles()
        if self._pf_locked(profiles) or self._pf_active(profiles)["restrictions"]["restricted"]:
            raise PermissionError("A backup has everyone's watch progress: only a grown-up profile can download it.")

    # -- the guard: every request passes here first ---------------------------------------------------

    def _pf_guard(self, method: str, path: str, data: dict, remote: bool) -> None:
        if path in ALWAYS:
            return
        profiles = self.store.profiles()
        locked = self._pf_locked(profiles)
        r = self._pf_active(profiles)["restrictions"]
        if locked and (method == "POST" or (_under(path, ADMIN_GET) and not _under(path, KIDS_GET))):
            raise ApiError("Pick who's watching first.", 403, "profile")
        if not r["restricted"]:
            return
        if not r["archive"] and _under(path, ARCHIVE):
            raise ApiError(NO_ARCHIVE, 403, "restricted")
        if method == "GET":
            if _under(path, ADMIN_GET) and not _under(path, KIDS_GET):
                raise ApiError(KIDS_NO, 403, "restricted")
            if data.get("id") and not self._pf_show_ok(str(data["id"]), r):
                raise ApiError("Show not found", 404)
            return
        archive_ok = r["archive"] and _under(path, ARCHIVE_KIDS_POST) and not _under(path, ARCHIVE_ADMIN)
        if path not in KIDS_POST and not archive_ok:
            raise ApiError(KIDS_NO, 403, "restricted")
        # What it plays, marks or starts again must be one of its own shows.
        if path == "/api/cmd":
            shows, keys = [], ([data.get("id") or data.get("value")] if data.get("cmd") == "play-episode" else [])
        else:
            shows, keys = [data.get("show")], [data.get("key")] + list(data.get("keys") or [])
        if not r["archive"] and any(str(x or "").startswith("ia:") for x in shows + keys):
            raise ApiError(NO_ARCHIVE, 403, "restricted")
        for sid in shows:
            if sid and not self._pf_show_ok(str(sid), r):
                raise ApiError("Show not found", 404)
        for key in keys:
            if key and not self._pf_key_ok(str(key), r):
                raise ApiError("Show not found", 404)

    # -- what a kids profile sees -----------------------------------------------------------------------

    def _pf_allowed(self, show: dict, r: dict) -> bool:
        if r["libraries"] and show.get("library") not in r["libraries"]:
            return False
        return not (r["hideAdult"] and self._pf_adult(show.get("mal_id")))

    def _pf_show_ok(self, show_id: str, r: dict) -> bool:
        if show_id.startswith("ia:"):
            return r["archive"]
        show = self.library.show(show_id)
        return show is None or self._pf_allowed(show, r)  # unknown: the page itself says "not found"

    def _pf_key_ok(self, key: str, r: dict) -> bool:
        if key.startswith("ia:"):
            return r["archive"]
        show, _ = self.library.episode(key)
        return show is None or self._pf_allowed(show, r)

    def _pf_adult(self, mal_id) -> bool:
        """Adult anime: tagged hentai/erotica in the anime lists, or rated Rx (or genre Hentai/Erotica)
        by MyAnimeList when its details are on this PC. Folders without a MyAnimeList match can't be
        told apart; "Only these libraries" is the sure way."""
        if not mal_id:
            return False
        try:
            ds = self.library.datasets()
        except Exception:
            ds = None
        if ds is not None:
            if (ds.titles.get(str(mal_id)) or {}).get("adult"):
                return True
            if "adult" not in (ds.titles_meta.get("flags") or []):
                self._pf_refresh_lists()
        return str(mal_id) in self._pf_adult_mal()

    def _pf_refresh_lists(self) -> None:
        """The anime lists on this PC are from before AniBox marked adult entries: get them again once
        (in the background; the old copy stays in use if that fails)."""
        st = self._pf()
        with st["lock"]:
            if st["refreshing"]:
                return
            st["refreshing"] = True

        def run():
            try:
                self.library.datasets(refresh=True)
                log.info("Anime lists read again: adult entries are marked now")
            except Exception as exc:
                log.warning("Couldn't read the anime lists again: %s", exc)

        threading.Thread(target=run, daemon=True, name="anibox-lists-refresh").start()

    def _pf_adult_mal(self) -> frozenset:
        """MyAnimeList ids whose cached details say adult (read again when the cache folder changes)."""
        st = self._pf()
        now = time.time()
        if now - st["adult_looked"] < 2:  # a page asks for every show: look at the folder once
            return st["adult"][1]
        st["adult_looked"] = now
        folder = self.mal.cache_dir
        try:
            stamp = folder.stat().st_mtime
        except OSError:
            return frozenset()
        if st["adult"][0] == stamp:
            return st["adult"][1]
        found = set()
        for f in folder.glob("*.json"):
            try:
                if _adult_details(json.loads(f.read_text(encoding="utf-8"))):
                    found.add(f.stem)
            except (OSError, ValueError):
                continue
        st["adult"] = (stamp, frozenset(found))
        return st["adult"][1]

    def _pf_entries(self, entries: list, r: dict) -> list:
        if not r["hideAdult"]:
            return entries
        return [e for e in entries if not self._pf_adult(e.get("mal_id") if isinstance(e, dict) else e.mal_id)]

    # The pages (each calls the feature's own code first, then leaves out what the profile doesn't see).

    def _cards_with_langs(self, pairs) -> list:
        r = self._pf_limits()
        if r is not None:
            pairs = [(show, card) for show, card in pairs if self._pf_allowed(show, r)]
        return super()._cards_with_langs(pairs)

    def _franchise_groups(self):
        groups, loose = super()._franchise_groups()
        r = self._pf_limits()
        if r is None:
            return groups, loose
        kept = []
        for key, fr, owned in groups:
            owned = [s for s in owned if self._pf_allowed(s, r)]
            if owned:
                kept.append((key, fr, owned))
        return kept, [s for s in loose if self._pf_allowed(s, r)]

    def _franchise(self, key: str) -> dict:
        out = super()._franchise(key)
        r = self._pf_limits()
        if r is not None:
            out["entries"] = self._pf_entries(out["entries"], r)
        return out

    def _franchises(self) -> dict:
        out = super()._franchises()
        r = self._pf_limits()
        if r is not None and r["libraries"]:
            out["libraries"] = [n for n in out["libraries"] if n in r["libraries"]]
        return out

    def _order_for(self, fr) -> list:
        order = super()._order_for(fr)
        r = self._pf_limits()
        return self._pf_entries(order, r) if r is not None else order

    def _library(self) -> dict:
        out = super()._library()
        r = self._pf_limits()
        if r is not None and r["libraries"]:
            out["libraries"] = [n for n in out["libraries"] if n in r["libraries"]]
            out["kinds"] = {n: k for n, k in out["kinds"].items() if n in r["libraries"]}
        return out

    def _home(self) -> dict:
        out = super()._home()
        r = self._pf_limits()
        if r is None:
            return out
        shows = [s for s in self.library.shows() if self._pf_allowed(s, r)]
        progress = self.store.all_progress()
        posters = bool(self.store.settings().get("posters", True))
        recent = sorted(shows, key=lambda s: s.get("added", 0), reverse=True)[:14]
        out["recent"] = self._tmdb_cards(self._cards_with_langs([(s, show_card(s, progress, posters)) for s in recent]))
        out["counts"] = {"shows": len(shows), "episodes": sum(len(s["episodes"]) for s in shows),
                         "matched": sum(1 for s in shows if s.get("mal_id"))}
        out.update(update=None, localUpdate=None, updateResult=None)  # updating is for a grown-up profile
        return out

    def _show(self, show_id: str) -> dict:
        r = self._pf_limits()
        if r is not None:
            show = self.library.show(show_id)
            if show and not self._pf_allowed(show, r):
                raise ApiError("Show not found", 404)
        out = super()._show(show_id)
        if r is not None:
            out["missing"] = self._pf_entries(out.get("missing") or [], r)
        return out

    def _airing(self, query: dict) -> dict:
        out = super()._airing(query)
        r = self._pf_limits()
        if r is not None:
            for k in ("items", "upcoming"):
                out[k] = [row for row in out.get(k) or [] if self._pf_show_ok(str(row.get("show") or ""), r)]
        return out

    def _missing(self, source: str = "folders") -> dict:
        r = self._pf_limits()
        if r is None:
            return super()._missing(source)
        if source == "plex":
            raise ApiError(KIDS_NO, 403, "restricted")
        report = self.library.report()
        allowed = {str(s["mal_id"]) for s in self.library.shows() if s.get("mal_id") and self._pf_allowed(s, r)}
        franchises = [dataclasses.replace(fr, entries=self._pf_entries(fr.entries, r)) for fr in report.franchises
                      if any(e.mal_id in allowed for e in fr.entries)]
        in_libs = (lambda i: not r["libraries"] or i.section in r["libraries"])  # noqa: E731
        report = dataclasses.replace(report, franchises=franchises,
                                     unidentified=[i for i in report.unidentified if in_libs(i)],
                                     ignored=[i for i in report.ignored if in_libs(i)])
        return {"source": "folders", **missing_json(report)}

    def _missing_export(self, source: str, fmt: str):
        profiles = self.store.profiles()
        if self._pf_locked(profiles) or self._pf_active(profiles)["restrictions"]["restricted"]:
            raise ApiError(KIDS_NO, 403, "restricted")
        return super()._missing_export(source, fmt)

    def _history_get(self, query: dict) -> dict:
        """History: "Start again from here" says which profile it was done in."""
        out = super()._history_get(query)
        profiles = self.store.profiles()
        if len(profiles) > 1:
            names = {p["id"]: p["name"] for p in profiles}
            for it in out.get("items") or []:
                if it.get("kind") == "rewatch" and it.get("profile"):
                    name = names.get(it["profile"], "a deleted profile")
                    it["detail"] = f"{it.get('detail') or ''} · profile {name}".lstrip(" ·")
        return out

    # -- picking and switching ----------------------------------------------------------------------------

    def _pf_pin_kind(self, target: dict, cur: dict, chosen: bool, profiles: List[dict]) -> str:
        """"" (no PIN), "own" (the target's PIN) or "grownup" (the PIN of any unrestricted profile)."""
        if target["id"] == cur["id"] and chosen:
            return ""
        if cur["restrictions"]["restricted"] and target["id"] != cur["id"] and \
                any(p["hasPin"] and not p["restrictions"]["restricted"] for p in profiles):
            return "grownup"  # leaving a kids profile
        return "own" if target["hasPin"] else ""

    def _pf_pin_ok(self, kind: str, target: dict, pin: str, profiles: List[dict]) -> bool:
        if kind == "own":
            return self.store.check_pin(target["id"], pin)
        return any(self.store.check_pin(p["id"], pin) for p in profiles
                   if p["hasPin"] and not p["restrictions"]["restricted"])

    def _pf_check_pin(self, kind: str, target: dict, pin: str, profiles: List[dict]) -> None:
        """Raises unless ``pin`` is right; five wrong ones in a row: a minute's wait."""
        st = self._pf()
        with st["lock"]:
            now = time.time()
            if st["wait_until"] > now:
                raise ApiError(f"Too many wrong PINs. Try again in {int(st['wait_until'] - now) + 1} seconds.", 429, "wait")
            if not pin:
                raise ApiError("Enter a grown-up's PIN." if kind == "grownup" else "Enter the PIN.", 403, "pin")
            if self._pf_pin_ok(kind, target, pin, profiles):
                st["fails"] = []
                return
            st["fails"] = [t for t in st["fails"] if now - t < 600] + [now]
            if len(st["fails"]) >= MAX_FAILS:
                st["fails"], st["wait_until"] = [], now + WAIT_SECONDS
                log.info("Profiles: %d wrong PINs, waiting a minute", MAX_FAILS)
        raise ApiError("That PIN isn't right.", 403, "pin")

    def _profiles_get(self, query: dict) -> dict:
        profiles = self.store.profiles()
        locked = self._pf_locked(profiles)
        cur = self._pf_active(profiles)
        restricted = cur["restrictions"]["restricted"]
        counts = self.store.profile_counts() if not restricted else {}
        items = []
        for p in profiles:
            item = {"id": p["id"], "name": p["name"], "color": p["color"], "emoji": p["emoji"], "hasPin": p["hasPin"],
                    "restricted": p["restrictions"]["restricted"], "active": p["id"] == cur["id"],
                    "pin": self._pf_pin_kind(p, cur, not locked, profiles)}
            if not restricted:
                item.update(restrictions=p["restrictions"], watched=(counts.get(p["id"]) or {}).get("watched", 0),
                            main=p["id"] == MAIN)
            items.append(item)
        out = {"profiles": items, "active": cur["id"], "ask": locked, "restricted": restricted,
               "archive": cur["restrictions"]["archive"]}
        if not restricted:
            grownup_pin = any(p["hasPin"] and not p["restrictions"]["restricted"] for p in profiles)
            owners = {}
            if getattr(self, "animelists", None) is not None:
                for src in ("mal", "anilist"):
                    if self.animelists.accounts.get(src):
                        owners[src] = self.animelists.owner(src)
            out.update(libraries=self.library.selected_libraries(), perProfile=list(PROFILE_SETTINGS),
                       pinWarning=any(p["restrictions"]["restricted"] for p in profiles) and not grownup_pin,
                       max=MAX_PROFILES, colors=list(COLORS), listOwners=owners)
        return out

    def _profiles_switch(self, body: dict) -> dict:
        pid = str(body.get("id") or "")
        profiles = self.store.profiles()
        target = next((p for p in profiles if p["id"] == pid), None)
        if target is None:
            raise ApiError("That profile isn't there any more.", 404)
        st = self._pf()
        cur = self._pf_active(profiles)
        kind = self._pf_pin_kind(target, cur, not self._pf_locked(profiles), profiles)
        if kind:
            self._pf_check_pin(kind, target, str(body.get("pin") or ""), profiles)
        self.store.set_profile(pid)
        st["chosen"] = True
        log.info("Profile: %s%s", target["name"], " (restricted)" if target["restrictions"]["restricted"] else "")
        return dict(self._profiles_get({}), ok=True)

    # -- Settings → Profiles (only a grown-up profile gets here: see the guard) --------------------------

    def _profiles_save(self, body: dict) -> dict:
        """Add (no ``id``) or change a profile: name, colour, emoji, restrictions, PIN."""
        pid = str(body.get("id") or "")
        pin = str(body.get("pin") or "")
        if pin and not PIN_RE.fullmatch(pin):
            raise ApiError("A PIN has 4 to 8 digits.")
        restrictions = body.get("restrictions") if isinstance(body.get("restrictions"), dict) else None
        if pid == MAIN and restrictions and restrictions.get("restricted"):
            raise ApiError("The first profile can't be restricted: someone has to be able to open Settings.")
        try:
            if not pid:
                row = self.store.add_profile(str(body.get("name") or ""), str(body.get("color") or ""),
                                             str(body.get("emoji") or ""), restrictions)
                pid = row["id"]
                log.info("Profile added: %s%s", row["name"], " (restricted)" if row["restrictions"]["restricted"] else "")
            else:
                row = self.store.profile_row(pid)
                if row is None:
                    raise ApiError("That profile isn't there any more.", 404)
                if (pin or body.get("removePin")) and row["hasPin"] and pid != self.store.profile \
                        and not row["restrictions"]["restricted"]:
                    # another grown-up's PIN: only with that PIN
                    if not self.store.check_pin(pid, str(body.get("oldPin") or "")):
                        raise ApiError(f"To change {row['name']}'s PIN, enter the current one.", 403, "pin")
                self.store.update_profile(pid, name=body.get("name"), color=body.get("color"),
                                          emoji=body.get("emoji"), restrictions=restrictions)
            if pin:
                self.store.set_pin(pid, pin)
            elif body.get("removePin"):
                self.store.set_pin(pid, None)
        except ValueError as exc:
            raise ApiError(str(exc))
        self._pf()["chosen"] = True  # whoever set this up is here
        return dict(self._profiles_get({}), ok=True, id=pid)

    def _profiles_delete(self, body: dict) -> dict:
        """Delete a profile with its watch progress (asked first in the window); "main" stays."""
        pid = str(body.get("id") or "")
        row = self.store.profile_row(pid)
        if row is None:
            raise ApiError("That profile isn't there any more.", 404)
        if pid == MAIN:
            raise ApiError("The first profile can't be deleted.")
        lists = getattr(self, "animelists", None)
        if lists is not None:  # its MyAnimeList/AniList connection: sync off, back to the first profile
            for src in ("mal", "anilist"):
                if lists.accounts.get(src) and lists.owner(src) == pid:
                    lists.sync_off(src)
                    lists.accounts.set(src, profile=MAIN)
                    log.info("Profiles: %s sync turned off (its profile was deleted)", src)
        self.store.delete_profile(pid)
        log.info("Profile deleted: %s", row["name"])
        return dict(self._profiles_get({}), ok=True)
