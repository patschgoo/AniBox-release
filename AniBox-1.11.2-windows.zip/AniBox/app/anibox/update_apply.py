"""Swap in a new AniBox version after AniBox has closed (the "Update now" button).

This file runs on its own (standard library only, no AniBox imports): AniBox copies it, with a copy of
its Python, into ``<data>/update/`` and starts it just before it closes, because Windows won't let
anyone replace the Python that is still running from the program folder.

Steps:
1. Wait until the old AniBox has closed (its process is gone and no AniBox answers anymore).
2. Move the old program files (``AniBox.bat``, ``app``, ``library-check``, ``python`` ...) into
   ``<program>/.previous-update/``. Your data is never touched: not the ``data`` folder of portable
   mode, not ``%LOCALAPPDATA%\\AniBox``, not any other file in the program folder.
3. Copy the new files in and start AniBox.
4. Wait until the new AniBox answers with the new version number. If it doesn't within the time
   limit, put the old files back and start the old version again.
5. Write ``result.json`` (AniBox shows it once) and a log.

If replacing the files fails half-way (a file still in use), everything that was moved is moved back.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request
from pathlib import Path
from typing import List, Optional

# Program files AniBox owns. Anything else in the program folder (the "data" folder of portable
# mode, your own files) stays where it is.
OWN_ITEMS = ["AniBox.bat", "AniBox.sh", "README.md", "app", "library-check", "python", "tools"]
NEVER = {"data", ".previous-update", ".failed-update"}
BACKUP = ".previous-update"
FAILED = ".failed-update"


class Log:
    def __init__(self, path: Optional[Path]):
        self.path = path

    def __call__(self, message: str) -> None:
        line = time.strftime("%Y-%m-%d %H:%M:%S ") + message
        if self.path:
            try:
                with open(self.path, "a", encoding="utf-8") as fh:
                    fh.write(line + "\n")
            except OSError:
                pass


def ping(ports: List[int], timeout: float = 1.5) -> Optional[str]:
    """The version of the AniBox answering on one of these ports, or None."""
    for port in ports:
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/ping", timeout=timeout) as r:
                data = json.loads(r.read(4096).decode("utf-8"))
            if data.get("app") == "AniBox":
                return str(data.get("version") or "")
        except Exception:
            continue
    return None


def process_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    if os.name == "nt":  # never os.kill on Windows: it would end the process
        import ctypes
        SYNCHRONIZE, STILL_ACTIVE = 0x00100000, 259
        k32 = ctypes.windll.kernel32
        handle = k32.OpenProcess(SYNCHRONIZE | 0x1000, False, pid)  # | PROCESS_QUERY_LIMITED_INFORMATION
        if not handle:
            return False
        try:
            code = ctypes.c_ulong()
            if k32.GetExitCodeProcess(handle, ctypes.byref(code)):
                return code.value == STILL_ACTIVE
            return True
        finally:
            k32.CloseHandle(handle)
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def wait_for_old(pid: int, ports: List[int], old_version: str, seconds: float, log: Log) -> bool:
    end = time.time() + seconds
    while time.time() < end:
        if not process_alive(pid) and ping(ports, 0.5) != old_version:
            return True
        time.sleep(0.5)
    log(f"The old AniBox (process {pid}) didn't close within {seconds:.0f} s")
    return False


def _retry(action, what: str, seconds: float, log: Log):
    """Retry while Windows still holds a file open (e.g. a virus scanner looking at it)."""
    end = time.time() + seconds
    while True:
        try:
            return action()
        except OSError as exc:
            if time.time() >= end:
                raise OSError(f"{what}: {exc}") from exc
            time.sleep(0.5)


def move_out(program: Path, names: List[str], target: Path, log: Log, seconds: float) -> List[str]:
    """Move these program items into ``target``. On failure, moves back what was moved and raises."""
    target.mkdir(parents=True, exist_ok=True)
    moved: List[str] = []
    try:
        for name in names:
            src = program / name
            if src.exists():
                _retry(lambda: os.replace(src, target / name), f"Couldn't move {src}", seconds, log)
                moved.append(name)
    except OSError:
        move_back(program, moved, target, log)
        raise
    return moved


def move_back(program: Path, names: List[str], source: Path, log: Log) -> None:
    for name in names:
        try:
            dest = program / name
            if dest.exists():
                _remove(dest)
            os.replace(source / name, dest)
        except OSError as exc:  # keep going: put back as much as possible
            log(f"Couldn't put back {name}: {exc}")


def _remove(path: Path) -> None:
    if path.is_dir() and not path.is_symlink():
        shutil.rmtree(path)
    else:
        path.unlink()


def copy_in(staging: Path, program: Path, names: List[str]) -> List[str]:
    copied: List[str] = []
    for name in names:
        src, dest = staging / name, program / name
        if src.is_dir():
            shutil.copytree(src, dest)
        else:
            shutil.copy2(src, dest)
        copied.append(name)
    return copied


def start_anibox(program: Path, command: Optional[List[str]], log: Log) -> None:
    """Start AniBox from the program folder (``command``: for tests, with ``{program}`` filled in)."""
    if command:
        cmd = [c.replace("{program}", str(program)) for c in command]
        subprocess.Popen(cmd, cwd=str(program), close_fds=True, start_new_session=(os.name != "nt"))
        return
    pythonw = program / "python" / "pythonw.exe"
    if os.name == "nt" and pythonw.is_file():
        flags = 0x00000008 | 0x00000200  # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
        subprocess.Popen([str(pythonw), "-m", "anibox"], cwd=str(program / "app"), creationflags=flags, close_fds=True)
    elif os.name == "nt":
        os.startfile(str(program / "AniBox.bat"))  # type: ignore[attr-defined]
    else:
        subprocess.Popen(["sh", str(program / "AniBox.sh")], cwd=str(program), start_new_session=True)


def wait_for_new(ports: List[int], version: str, seconds: float) -> bool:
    end = time.time() + seconds
    while time.time() < end:
        if ping(ports) == version:
            return True
        time.sleep(1)
    return False


def write_result(path: Optional[Path], data: dict) -> None:
    if not path:
        return
    tmp = path.with_suffix(".part")
    tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, path)


def run(program: Path, staging: Path, old_version: str, new_version: str, pid: int, ports: List[int],
        result: Optional[Path], log: Log, start: Optional[List[str]] = None, wait_seconds: float = 90,
        verify_seconds: float = 120, retry_seconds: float = 30) -> dict:
    done = {"from": old_version, "to": new_version, "time": time.time()}
    log(f"Update {old_version} -> {new_version} in {program}")
    new_items = [p.name for p in staging.iterdir() if p.name not in NEVER]
    if "app" not in new_items:
        out = {**done, "ok": False, "message": "The update package is incomplete; nothing was changed."}
        write_result(result, out)
        return out
    if not wait_for_old(pid, ports, old_version, wait_seconds, log):
        out = {**done, "ok": False, "message": "The old AniBox didn't close, so nothing was changed. Try again."}
        write_result(result, out)
        return out

    backup = program / BACKUP
    if backup.exists():
        _remove(backup)
    names = list(dict.fromkeys(OWN_ITEMS + new_items))
    try:
        moved = move_out(program, names, backup, log, retry_seconds)
    except OSError as exc:
        log(str(exc))
        start_anibox(program, start, log)
        out = {**done, "ok": False, "message": "A program file was still in use, so nothing was changed. "
                                               "Close other AniBox windows and try again."}
        write_result(result, out)
        return out
    log(f"Moved the old files to {backup}: {', '.join(moved)}")

    copied: List[str] = []
    try:
        copied = copy_in(staging, program, new_items)
    except OSError as exc:
        log(f"Copying the new files failed: {exc}")
        for name in copied:
            try:
                _remove(program / name)
            except OSError:
                pass
        move_back(program, moved, backup, log)
        start_anibox(program, start, log)
        out = {**done, "ok": False, "message": "Copying the new files failed, so the old version was put back."}
        write_result(result, out)
        return out
    log("New files are in place; starting AniBox " + new_version)

    # Written before the start, so the new AniBox can show it as soon as it opens. If the new
    # version doesn't start, the message below replaces it before the old version starts again.
    out = {**done, "ok": True, "message": f"AniBox was updated to {new_version}."}
    write_result(result, out)
    start_anibox(program, start, log)
    if wait_for_new(ports, new_version, verify_seconds):
        log("AniBox " + new_version + " is running. The old files stay in " + str(backup))
        return out

    log(f"AniBox {new_version} didn't answer within {verify_seconds:.0f} s; going back to {old_version}")
    failed = program / FAILED
    if failed.exists():
        _remove(failed)
    try:
        move_out(program, copied, failed, log, retry_seconds)
    except OSError as exc:
        log(f"Couldn't move the new files away: {exc}")
    move_back(program, moved, backup, log)
    start_anibox(program, start, log)
    out = {**done, "ok": False, "rolled_back": True,
           "message": f"AniBox {new_version} didn't start, so AniBox went back to {old_version}. "
                      "Details: logs\\update.log in AniBox's data folder."}
    write_result(result, out)
    return out


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description="Swap in a new AniBox version (started by AniBox itself).")
    p.add_argument("--program", required=True)
    p.add_argument("--staging", required=True)
    p.add_argument("--old-version", required=True)
    p.add_argument("--new-version", required=True)
    p.add_argument("--pid", type=int, default=0)
    p.add_argument("--port", type=int, default=43210)
    p.add_argument("--result")
    p.add_argument("--log")
    p.add_argument("--wait-seconds", type=float, default=90)
    p.add_argument("--verify-seconds", type=float, default=120)
    p.add_argument("--start", nargs=argparse.REMAINDER, help="for tests: the command that starts AniBox")
    a = p.parse_args(argv)
    log = Log(Path(a.log) if a.log else None)
    try:
        out = run(Path(a.program), Path(a.staging), a.old_version, a.new_version, a.pid,
                  list(range(a.port, a.port + 10)), Path(a.result) if a.result else None, log,
                  start=a.start or None, wait_seconds=a.wait_seconds, verify_seconds=a.verify_seconds)
    except Exception as exc:  # last resort: say what happened
        log(f"Update failed: {exc!r}")
        write_result(Path(a.result) if a.result else None,
                     {"ok": False, "message": f"The update failed: {exc}", "time": time.time()})
        return 1
    return 0 if out.get("ok") else 1


if __name__ == "__main__":
    sys.exit(main())
