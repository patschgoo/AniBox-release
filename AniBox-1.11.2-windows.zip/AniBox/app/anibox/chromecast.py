"""Play on TV with Google Cast: Chromecasts, Google TV and the NVIDIA Shield's built-in Cast receiver.

Three parts, standard library only (no pychromecast, protobuf or zeroconf packages):

1. **Finding Cast devices** (:func:`discover`): a multicast DNS question for
   ``_googlecast._tcp.local`` on every network adapter (answers by unicast to us, plus the usual
   multicast answers on port 5353; on Windows only when nothing else holds that port, so Windows' own
   mDNS keeps its messages). The answer's records say the name (TXT ``fn``), the model (``md``),
   a stable id (``id``), the port (SRV) and the address (A). :func:`address_device` adds one by its
   address instead, :func:`locate` finds a remembered one again.
2. **The Cast v2 protocol** (:class:`CastClient`): TLS to port 8009 (Cast devices use self-signed
   certificates, so none is checked; only addresses in the home network are allowed), every message a
   4-byte big-endian length plus a protobuf ``CastMessage`` with a JSON payload. A tiny protobuf
   encoder/decoder for just that message is below. Namespaces: connection (CONNECT/CLOSE), heartbeat
   (PING/PONG every 5 s), receiver (GET_STATUS, LAUNCH of Google's Default Media Receiver ``CC1AD845``,
   SET_VOLUME, STOP) and media (LOAD, PLAY, PAUSE, SEEK, STOP, GET_STATUS, EDIT_TRACKS_INFO).
3. **One TV for the episode logic** (:class:`CastRenderer`): the same public methods and fields as
   ``tv.Renderer`` (load/play/pause/seek/stop/status/volume, ``name``, ``device``, ``host``,
   ``castapp`` False ...), so ``tvplayer.TvPlayer`` keeps its resume, progress, watched and
   next-episode logic. :meth:`CastRenderer.prepare` decides how a file reaches the TV (``castserve.py``:
   the file as it is, remuxed on the fly, converted, or a TV copy) and returns what to LOAD.

Errors are :class:`tv.TvError` (a short English sentence for the user plus a ``reason``), so the
app's TV routes handle them like DLNA errors. Nothing is sent until a function is called; nothing
listens on the network except during :func:`discover`. Untested with real Cast devices so far.
"""

from __future__ import annotations

import ipaddress
import itertools
import json
import logging
import os
import re
import select
import shutil
import socket
import ssl
import struct
import threading
import time
import urllib.parse
from typing import Callable, Dict, Iterable, List, NamedTuple, Optional, Sequence, Tuple

from . import castserve, tv
from .tv import TvError

log = logging.getLogger("anibox.chromecast")

KIND = "chromecast"
ID_PREFIX = "cast:"
CAST_PORT = 8009
MDNS_GROUP = ("224.0.0.251", 5353)
SERVICE = "_googlecast._tcp.local"

DEFAULT_RECEIVER = "CC1AD845"  # Google's Default Media Receiver (MP4/WebM, WebVTT subtitles)
SENDER_ID = "sender-0"
RECEIVER_ID = "receiver-0"
NS_CONNECTION = "urn:x-cast:com.google.cast.tp.connection"
NS_HEARTBEAT = "urn:x-cast:com.google.cast.tp.heartbeat"
NS_RECEIVER = "urn:x-cast:com.google.cast.receiver"
NS_MEDIA = "urn:x-cast:com.google.cast.media"

MAX_MESSAGE = 64 * 1024  # the Cast protocol's limit for one message
HEARTBEAT = 5.0  # a PING every 5 s
DEAD_AFTER = 20.0  # nothing heard for this long: the connection is gone
CONNECT_TIMEOUT = 5.0
REQUEST_TIMEOUT = 8.0
LAUNCH_TIMEOUT = 25.0  # starting the receiver app on a sleeping TV takes a while
LOAD_TIMEOUT = 30.0  # the receiver opens the video before it answers
STATUS_TIMEOUT = 3.0
MDNS_ASK_TIMEOUT = 1.5

CAP_VIDEO_OUT = 0x01  # TXT "ca": the device has a picture
CAP_GROUP = 0x20  # a speaker group

TEXT_STYLE = {  # white text with a black outline, like most fansub subtitles
    "foregroundColor": "#FFFFFFFF", "backgroundColor": "#00000000", "edgeType": "OUTLINE",
    "edgeColor": "#000000FF", "fontScale": 1.0,
}

__all__ = [
    "CastMessage", "encode_message", "decode_message", "frame", "read_frames", "build_query", "parse_dns",
    "devices_from_records", "discover", "address_device", "is_cast_address", "locate", "CastClient", "CastRenderer",
    "KIND", "CAST_PORT",
]


# ---- the protobuf CastMessage ----------------------------------------------------------------------
#
#   message CastMessage {
#     required ProtocolVersion protocol_version = 1;  // CASTV2_1_0 = 0
#     required string source_id = 2;
#     required string destination_id = 3;
#     required string namespace = 4;
#     required PayloadType payload_type = 5;          // STRING = 0, BINARY = 1
#     optional string payload_utf8 = 6;
#     optional bytes payload_binary = 7;
#   }

class CastMessage(NamedTuple):
    source_id: str
    destination_id: str
    namespace: str
    payload_utf8: Optional[str] = None
    payload_binary: Optional[bytes] = None
    protocol_version: int = 0
    payload_type: int = 0  # 0 = STRING, 1 = BINARY


_VARINT, _I64, _LEN, _I32 = 0, 1, 2, 5


def _varint(value: int) -> bytes:
    if value < 0:
        raise ValueError("negative varint")
    out = bytearray()
    while True:
        low = value & 0x7F
        value >>= 7
        if value:
            out.append(low | 0x80)
        else:
            out.append(low)
            return bytes(out)


def _read_varint(data: bytes, pos: int) -> Tuple[int, int]:
    result = shift = 0
    while True:
        if pos >= len(data):
            raise ValueError("truncated varint")
        b = data[pos]
        pos += 1
        result |= (b & 0x7F) << shift
        if not b & 0x80:
            return result, pos
        shift += 7
        if shift > 63:
            raise ValueError("varint too long")


def _field(number: int, wire: int) -> bytes:
    return _varint(number << 3 | wire)


def _bytes_field(number: int, value: bytes) -> bytes:
    return _field(number, _LEN) + _varint(len(value)) + value


def encode_message(msg: CastMessage) -> bytes:
    """A CastMessage as protobuf bytes (without the length prefix, see :func:`frame`)."""
    binary = msg.payload_binary is not None
    out = bytearray()
    out += _field(1, _VARINT) + _varint(msg.protocol_version)
    out += _bytes_field(2, msg.source_id.encode("utf-8"))
    out += _bytes_field(3, msg.destination_id.encode("utf-8"))
    out += _bytes_field(4, msg.namespace.encode("utf-8"))
    out += _field(5, _VARINT) + _varint(1 if binary else 0)
    if binary:
        out += _bytes_field(7, bytes(msg.payload_binary or b""))
    else:
        out += _bytes_field(6, (msg.payload_utf8 or "").encode("utf-8"))
    return bytes(out)


def decode_message(data: bytes) -> CastMessage:
    """Protobuf bytes -> CastMessage. Unknown fields are skipped; raises ValueError for broken data."""
    pos = 0
    fields: Dict[int, object] = {}
    while pos < len(data):
        key, pos = _read_varint(data, pos)
        number, wire = key >> 3, key & 7
        if wire == _VARINT:
            value, pos = _read_varint(data, pos)
            fields[number] = value
        elif wire == _LEN:
            length, pos = _read_varint(data, pos)
            if pos + length > len(data):
                raise ValueError("truncated field")
            fields[number] = bytes(data[pos:pos + length])
            pos += length
        elif wire == _I64:
            pos += 8
        elif wire == _I32:
            pos += 4
        else:
            raise ValueError(f"unsupported wire type {wire}")
    if pos > len(data):
        raise ValueError("truncated field")

    def text(n: int) -> str:
        v = fields.get(n, b"")
        return v.decode("utf-8", "replace") if isinstance(v, bytes) else ""

    utf8 = fields.get(6)
    binary = fields.get(7)
    version = fields.get(1, 0)
    ptype = fields.get(5, 0)
    return CastMessage(
        source_id=text(2), destination_id=text(3), namespace=text(4),
        payload_utf8=utf8.decode("utf-8", "replace") if isinstance(utf8, bytes) else None,
        payload_binary=binary if isinstance(binary, bytes) else None,
        protocol_version=version if isinstance(version, int) else 0,
        payload_type=ptype if isinstance(ptype, int) else 0,
    )


def frame(msg: CastMessage) -> bytes:
    """One message on the wire: its length as 4 bytes (big-endian), then the protobuf bytes."""
    body = encode_message(msg)
    if len(body) > MAX_MESSAGE:
        raise ValueError("message too large")
    return struct.pack(">I", len(body)) + body


def read_frames(buf: bytearray) -> List[CastMessage]:
    """Takes every complete message out of ``buf`` (what's left is the start of the next one)."""
    out = []
    while len(buf) >= 4:
        (n,) = struct.unpack(">I", bytes(buf[:4]))
        if n > MAX_MESSAGE:
            raise ValueError(f"message of {n} bytes")
        if len(buf) < 4 + n:
            break
        body = bytes(buf[4:4 + n])
        del buf[:4 + n]
        out.append(decode_message(body))
    return out


def _json(payload: dict) -> str:
    return json.dumps(payload, separators=(",", ":"), ensure_ascii=False)


# ---- addresses --------------------------------------------------------------------------------------

def _home_ip(ip: str) -> bool:
    """Private or link-local addresses only (127.x counts as private): never the internet."""
    try:
        addr = ipaddress.ip_address(str(ip).split("%")[0])
    except ValueError:
        return False
    mapped = getattr(addr, "ipv4_mapped", None)
    if mapped:
        addr = mapped
    if addr.is_multicast or addr.is_unspecified:
        return False
    return addr.is_private or addr.is_link_local


def _local_ipv4s() -> List[str]:
    ips = set()
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except (OSError, UnicodeError):
        pass
    ips.add(tv.lan_ip_for(MDNS_GROUP[0]))
    return sorted(ip for ip in ips if not ip.startswith("127.") and ip != "0.0.0.0")


_LOCAL_NAME = re.compile(r"[A-Za-z0-9-]{1,63}(\.(local|lan|home|fritz\.box|box))?", re.I)


def _parse_address(text: str) -> Tuple[str, int, bool]:
    """"192.168.1.60", "192.168.1.60:8009", "cast://shield.local" -> (ip, port, port given?).

    Only addresses in the home network (private or link-local IPs, or a local name that points at
    one). Raises :class:`TvError`.
    """
    raw = (text or "").strip()
    if not raw:
        raise TvError("Type the TV's address, for example 192.168.1.60.", "bad_answer")
    low = raw.lower()
    rest = raw[7:] if low.startswith("cast://") else raw
    if "://" in rest:
        raise TvError(f"\"{raw}\" isn't a Chromecast address AniBox can use.", "bad_answer")
    try:
        u = _netloc(rest)
    except ValueError:
        raise TvError(f"\"{raw}\" isn't a Chromecast address AniBox can use.", "bad_answer") from None
    host, port = u
    given = port is not None
    port = port or CAST_PORT
    try:
        ipaddress.ip_address(host)
        ip = host
    except ValueError:
        if not _LOCAL_NAME.fullmatch(host):
            raise TvError(f"{host} isn't a name in your home network. Use the TV's address (numbers).", "bad_answer")
        try:
            ip = socket.getaddrinfo(host, None, socket.AF_INET)[0][4][0]
        except (OSError, UnicodeError, IndexError):
            raise TvError(f"AniBox can't find \"{host}\" in your network. Use the TV's address (numbers).",
                          "unreachable") from None
    if not _home_ip(ip):
        raise TvError(f"{host} isn't in your home network.", "bad_answer")
    return ip, port, given


def _netloc(text: str) -> Tuple[str, Optional[int]]:
    """"host", "host:8009", "[fe80::1]:8009" (an optional "/..." after it is ignored) -> (host, port)."""
    u = urllib.parse.urlsplit("//" + text.split("/", 1)[0])
    host = u.hostname or ""
    if not host or u.username or u.password:
        raise ValueError("no host")
    port = u.port  # raises ValueError for a bad port
    return host, port


def is_cast_address(text: str) -> bool:
    """Whether a typed address is meant for Google Cast: "cast://..." or port 8009."""
    raw = (text or "").strip()
    if raw.lower().startswith("cast://"):
        return True
    try:
        return _netloc(raw.split("://", 1)[-1])[1] == CAST_PORT
    except ValueError:
        return False


# ---- finding Cast devices: multicast DNS ------------------------------------------------------------

TYPE_A, TYPE_PTR, TYPE_TXT, TYPE_SRV = 1, 12, 16, 33
CLASS_IN = 1
QU_BIT = 0x8000  # "answer me by unicast"


class Record(NamedTuple):
    name: str
    rtype: int
    ttl: int
    data: object


def build_query(name: str, qtype: int = TYPE_PTR, unicast: bool = True, qid: int = 0) -> bytes:
    """A DNS question (one entry) for multicast DNS; ``unicast`` sets the QU bit."""
    out = bytearray(struct.pack(">HHHHHH", qid, 0, 1, 0, 0, 0))
    for label in name.rstrip(".").split("."):
        raw = label.encode("utf-8")
        if not 0 < len(raw) < 64:
            raise ValueError("bad label")
        out.append(len(raw))
        out += raw
    out.append(0)
    out += struct.pack(">HH", qtype, CLASS_IN | (QU_BIT if unicast else 0))
    return bytes(out)


def _read_name(packet: bytes, pos: int) -> Tuple[str, int]:
    labels = []
    end = -1
    jumps = 0
    while True:
        if pos >= len(packet):
            raise ValueError("truncated name")
        n = packet[pos]
        if n == 0:
            pos += 1
            break
        if n & 0xC0 == 0xC0:
            if pos + 1 >= len(packet):
                raise ValueError("truncated pointer")
            if end < 0:
                end = pos + 2
            jumps += 1
            if jumps > 32:
                raise ValueError("pointer loop")
            pos = (n & 0x3F) << 8 | packet[pos + 1]
            continue
        if n & 0xC0:
            raise ValueError("bad label")
        if pos + 1 + n > len(packet):
            raise ValueError("truncated label")
        labels.append(packet[pos + 1:pos + 1 + n].decode("utf-8", "replace"))
        pos += 1 + n
    return ".".join(labels), (end if end >= 0 else pos)


def _parse_txt(data: bytes) -> Dict[str, str]:
    out: Dict[str, str] = {}
    pos = 0
    while pos < len(data):
        n = data[pos]
        pos += 1
        entry = data[pos:pos + n].decode("utf-8", "replace")
        pos += n
        if not entry:
            continue
        key, sep, value = entry.partition("=")
        if key and key.lower() not in out:
            out[key.lower()] = value if sep else ""
    return out


def parse_dns(packet: bytes) -> List[Record]:
    """Every resource record (answers, authority and additional) of a DNS message; [] if broken.

    A, PTR, SRV (``(priority, weight, port, target)``) and TXT (a dict, keys in lower case) are
    read; other types keep ``data`` None.
    """
    if len(packet) < 12:
        return []
    try:
        _, _, qd, an, ns, ar = struct.unpack(">HHHHHH", packet[:12])
        pos = 12
        for _ in range(qd):
            pos = _read_name(packet, pos)[1] + 4
        records: List[Record] = []
        for _ in range(an + ns + ar):
            name, pos = _read_name(packet, pos)
            if pos + 10 > len(packet):
                break
            rtype, _, ttl, length = struct.unpack(">HHIH", packet[pos:pos + 10])
            pos += 10
            start, end = pos, pos + length
            if end > len(packet):
                break
            data: object = None
            if rtype == TYPE_A and length == 4:
                data = socket.inet_ntoa(packet[start:end])
            elif rtype == TYPE_PTR:
                data = _read_name(packet, start)[0]
            elif rtype == TYPE_SRV and length >= 7:
                prio, weight, port = struct.unpack(">HHH", packet[start:start + 6])
                data = (prio, weight, port, _read_name(packet, start + 6)[0])
            elif rtype == TYPE_TXT:
                data = _parse_txt(packet[start:end])
            records.append(Record(name, rtype, ttl, data))
            pos = end
        return records
    except (ValueError, struct.error, IndexError):
        return []


def _device(instance: str, ip: str, port: int, txt: Dict[str, str]) -> Optional[dict]:
    """A device dict (the shape of ``tv.describe``, plus ``kind``, ``host``, ``port``), or None for
    speakers, speaker groups and addresses outside the home network."""
    ca = int(txt["ca"]) if str(txt.get("ca", "")).isdigit() else None
    model = (txt.get("md") or "").strip()
    group = (ca is not None and ca & CAP_GROUP) or model == "Google Cast Group"
    if group or (ca is not None and not ca & CAP_VIDEO_OUT):
        return None
    if not ip or not _home_ip(ip):
        return None
    name = (txt.get("fn") or "").strip()
    if not name:
        name = instance.split("._googlecast", 1)[0]
        name = re.sub(r"-[0-9a-f]{32}$", "", name, flags=re.I) or "Chromecast"
    uid = re.sub(r"[^0-9a-z]", "", (txt.get("id") or "").lower())[:64]
    port = int(port or CAST_PORT)
    return {
        "id": ID_PREFIX + (uid or f"{ip}:{port}"), "name": name[:120], "location": f"cast://{ip}:{port}",
        "manufacturer": "", "model": model[:120], "castapp": False, "kind": KIND, "host": ip, "port": port,
        "avtransport": "", "rendering": "", "avtransport_type": "", "rendering_type": "",
    }


def devices_from_records(records: Sequence[Record], sender_ip: str = "") -> List[dict]:
    """The Cast devices described by one mDNS answer (its PTR/SRV/TXT/A records)."""
    instances: List[str] = []
    suffix = "." + SERVICE

    def add(name: str) -> None:
        if name and name.casefold() not in (i.casefold() for i in instances):
            instances.append(name)

    for r in records:
        if r.rtype == TYPE_PTR and r.name.casefold() == SERVICE and isinstance(r.data, str):
            add(r.data)
        elif r.rtype in (TYPE_SRV, TYPE_TXT) and r.name.casefold().endswith(suffix):
            add(r.name)
    out = []
    for inst in instances:
        key = inst.casefold()
        srv = next((r.data for r in records if r.rtype == TYPE_SRV and r.name.casefold() == key), None)
        txt = next((r.data for r in records if r.rtype == TYPE_TXT and r.name.casefold() == key), None) or {}
        ip = ""
        if srv:
            target = str(srv[3]).casefold()
            ip = next((r.data for r in records if r.rtype == TYPE_A and r.name.casefold() == target), "") or ""
        dev = _device(inst, ip or sender_ip, srv[2] if srv else CAST_PORT, txt if isinstance(txt, dict) else {})
        if dev:
            out.append(dev)
    return out


def _query_sockets(targets) -> List[Tuple[socket.socket, Tuple[str, int]]]:
    """One UDP socket per network adapter for the multicast question, or one for unicast test targets."""
    out = []
    if targets:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.bind(("", 0))
        s.setblocking(False)
        return [(s, (str(t[0]), int(t[1]))) for t in targets]
    for ip in _local_ipv4s() or ["0.0.0.0"]:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 255)
            s.bind((ip, 0))
            if ip != "0.0.0.0":
                s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_IF, socket.inet_aton(ip))
            s.setblocking(False)
        except OSError:
            s.close()
            continue
        out.append((s, MDNS_GROUP))
    return out


def _listen_socket(windows: Optional[bool] = None) -> Optional[socket.socket]:
    """Port 5353 for the regular multicast answers (other programs share it; may be refused).

    On Windows the port isn't shared: there SO_REUSEADDR would let AniBox take messages meant for
    Windows' own mDNS (the DNS Client service). If Windows holds the port, the bind fails and the
    search uses only the answers sent straight back to its question sockets, which Cast devices send."""
    if windows is None:
        windows = os.name == "nt"
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        if not windows:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        if not windows and hasattr(socket, "SO_REUSEPORT"):
            try:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
            except OSError:
                pass
        s.bind(("", MDNS_GROUP[1]))
        joined = False
        for ip in _local_ipv4s() or ["0.0.0.0"]:
            try:
                s.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP,
                              socket.inet_aton(MDNS_GROUP[0]) + socket.inet_aton(ip))
                joined = True
            except OSError:
                continue
        if not joined:
            s.close()
            return None
        s.setblocking(False)
        return s
    except OSError:
        s.close()
        return None


def discover(timeout: float = 3.0, targets: Optional[Iterable[Tuple[str, int]]] = None) -> List[dict]:
    """Searches the home network for Cast devices with a picture (Chromecast, Google TV, the Shield).

    Asks ``_googlecast._tcp.local`` on every network adapter (``targets``: a list of ``(host, port)``
    to ask by unicast instead, for tests), three times within ``timeout`` seconds in case a packet
    gets lost, and listens for the answers. Returns device dicts (see :func:`devices_from_records`),
    one per device id, sorted by name. Speakers and speaker groups are left out.
    """
    timeout = max(0.2, float(timeout))
    targets = list(targets) if targets else None
    socks = _query_sockets(targets)
    listener = None if targets else _listen_socket()
    if not socks and listener is None:
        return []
    query = build_query(SERVICE, TYPE_PTR, unicast=True)
    rounds = [r for r in (0.0, 0.7, 1.8) if r == 0.0 or r < timeout - 0.4]
    found: Dict[str, dict] = {}
    readers = list({id(s): s for s, _ in socks}.values()) + ([listener] if listener else [])
    start = time.monotonic()
    deadline = start + timeout
    sent = 0
    try:
        while True:
            now = time.monotonic()
            while sent < len(rounds) and now >= start + rounds[sent]:
                for s, dest in socks:
                    try:
                        s.sendto(query, dest)
                    except OSError:
                        pass
                sent += 1
            if now >= deadline:
                break
            wait = deadline - now
            if sent < len(rounds):
                wait = min(wait, start + rounds[sent] - now)
            readable, _, _ = select.select(readers, [], [], max(0.0, wait))
            for s in readable:
                try:
                    data, addr = s.recvfrom(9000)
                except OSError:
                    continue
                for dev in devices_from_records(parse_dns(data), addr[0]):
                    found.setdefault(dev["id"], dev)
    finally:
        for s in readers:
            s.close()
    return sorted(found.values(), key=lambda d: (d["name"].casefold(), d["id"]))


def _ask(ip: str, port: int = MDNS_GROUP[1], timeout: float = MDNS_ASK_TIMEOUT) -> List[dict]:
    """Asks one device directly (a unicast mDNS question to its port 5353) what it is."""
    try:
        return discover(timeout, targets=[(ip, port)])
    except OSError:
        return []


def _checked(ip: str, port: int, name: str, timeout: float = CONNECT_TIMEOUT) -> None:
    """Connects to the Cast port and asks for the receiver's status (raises :class:`TvError`)."""
    client = CastClient(ip, port, name=name, timeout=timeout)
    try:
        client.connect()
        client.receiver_status(timeout)
    finally:
        client.close()


def address_device(text: str, timeout: float = CONNECT_TIMEOUT, mdns_port: int = MDNS_GROUP[1]) -> dict:
    """A Cast device typed in by hand ("192.168.1.60", "192.168.1.60:8009", "cast://shield.local").

    Asks the device itself for its name and model (mDNS to its port 5353); if it doesn't answer that,
    checks that port 8009 (or the one given) speaks Google Cast and names it "Chromecast at <ip>".
    Only home-network addresses. Raises :class:`TvError`.
    """
    ip, port, given = _parse_address(text)
    for dev in _ask(ip, mdns_port, min(timeout, MDNS_ASK_TIMEOUT)):
        if dev["host"] == ip and (not given or dev["port"] == port):
            return dev
    _checked(ip, port, f"The device at {ip}", timeout)
    return {
        "id": f"{ID_PREFIX}{ip}:{port}", "name": f"Chromecast at {ip}", "location": f"cast://{ip}:{port}",
        "manufacturer": "", "model": "", "castapp": False, "kind": KIND, "host": ip, "port": port,
        "avtransport": "", "rendering": "", "avtransport_type": "", "rendering_type": "",
    }


def locate(device_id: str, location: str = "", saved: Optional[dict] = None, timeout: float = 3.0,
           targets: Optional[Iterable[Tuple[str, int]]] = None, mdns_port: int = MDNS_GROUP[1]) -> Optional[dict]:
    """Finds a remembered Cast device: first at its last address, then (its IP may have changed) by searching.

    ``saved``: what the app remembered about it; used when the device answers on its Cast port but
    not to mDNS questions. Returns its device dict, or None if it isn't on the network right now.
    """
    if location:
        try:
            ip, port, _ = _parse_address(location)
        except TvError:
            ip = ""
        if ip:
            for dev in _ask(ip, mdns_port, min(timeout, MDNS_ASK_TIMEOUT)):
                if dev["id"] == device_id or not device_id:
                    return dev
            try:
                _checked(ip, port, f"The device at {ip}", min(timeout, CONNECT_TIMEOUT))
            except TvError:
                pass
            else:
                dev = dict(saved or {})
                dev.update(id=device_id or f"{ID_PREFIX}{ip}:{port}", host=ip, port=port, kind=KIND,
                           location=f"cast://{ip}:{port}", castapp=False)
                dev.setdefault("name", f"Chromecast at {ip}")
                for k in ("manufacturer", "model", "avtransport", "rendering", "avtransport_type", "rendering_type"):
                    dev.setdefault(k, "")
                return dev
    for dev in discover(timeout, targets):
        if dev["id"] == device_id:
            return dev
    return None


# ---- the Cast v2 connection ----------------------------------------------------------------------------

def _tls_context() -> ssl.SSLContext:
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    # Cast devices present self-signed certificates and the connection never leaves the home network,
    # so (like every other Cast sender) the certificate isn't checked.
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


class _Waiter:
    __slots__ = ("match", "event", "reply", "error")

    def __init__(self, match: Callable[[str, dict], bool]):
        self.match = match
        self.event = threading.Event()
        self.reply: Optional[dict] = None
        self.error = ""


class CastClient:
    """One TLS connection to a Cast device (port 8009). Thread-safe.

    A reader thread takes the messages apart, answers the device's PINGs, keeps the latest receiver
    and media status and hands replies to the request waiting for them (by ``requestId``). A second
    thread sends a PING every 5 s and gives up when nothing came for 20 s. ``on_media(status)`` is
    called for every media status, ``on_close(reason)`` once when the connection ends (not after
    :meth:`close`), ``on_app_closed(transport_id)`` when the receiver app closes.
    """

    def __init__(self, host: str, port: int = CAST_PORT, name: str = "", timeout: float = CONNECT_TIMEOUT,
                 on_media: Optional[Callable[[dict], None]] = None, on_close: Optional[Callable[[str], None]] = None,
                 on_app_closed: Optional[Callable[[str], None]] = None):
        self.host = str(host)
        self.port = int(port)
        self.name = name or "The TV"
        if not _home_ip(self.host):
            raise TvError(f"{self.host} isn't in your home network.", "bad_answer")
        self.timeout = timeout
        self.on_media = on_media
        self.on_close = on_close
        self.on_app_closed = on_app_closed
        self.local_ip = ""
        self.receiver: dict = {}
        self.media_status: List[dict] = []
        self._sock: Optional[ssl.SSLSocket] = None
        self._io = threading.Lock()  # one TLS operation at a time (reading or writing)
        self._lock = threading.Lock()
        self._waiters: List[_Waiter] = []
        self._ids = itertools.count(1)
        self._connected_to: set = set()
        self._closed = True
        self._stop = threading.Event()
        self._last_rx = 0.0
        self.close_reason = ""

    # -- connection

    @property
    def connected(self) -> bool:
        return self._sock is not None and not self._closed

    def connect(self) -> None:
        """Opens the connection (TCP + TLS) and the virtual connection to the receiver. Raises :class:`TvError`."""
        hint = f"{self.name} doesn't answer. Check that it's switched on and on the same network as this PC."
        try:
            raw = socket.create_connection((self.host, self.port), timeout=self.timeout)
        except (OSError, UnicodeError) as exc:
            raise TvError(hint, "unreachable") from exc
        try:
            raw.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            sock = _tls_context().wrap_socket(raw, server_hostname=None)
        except (OSError, ssl.SSLError) as exc:
            raw.close()
            raise TvError(f"{self.name} doesn't speak Google Cast on port {self.port}.", "unsupported") from exc
        try:
            self.local_ip = sock.getsockname()[0]
        except OSError:
            self.local_ip = ""
        with self._lock:
            self._sock = sock
            self._closed = False
            self._stop.clear()
            self._last_rx = time.monotonic()
            self.close_reason = ""
            self._connected_to = set()
        threading.Thread(target=self._read_loop, args=(sock,), daemon=True, name="anibox-cast-read").start()
        threading.Thread(target=self._heartbeat_loop, daemon=True, name="anibox-cast-ping").start()
        self.connect_to(RECEIVER_ID)

    def connect_to(self, destination: str) -> None:
        """The virtual connection to the receiver or to an app's transport (once each)."""
        with self._lock:
            if destination in self._connected_to:
                return
            self._connected_to.add(destination)
        self.send(NS_CONNECTION, destination, {
            "type": "CONNECT", "origin": {}, "userAgent": "AniBox",
            "senderInfo": {"sdkType": 2, "version": "15.605.1.3", "browserVersion": "44.0.2403.30",
                           "platform": 4, "systemVersion": "AniBox", "connectionType": 1},
        })

    def close(self) -> None:
        """Says goodbye (CLOSE) and closes the connection. Requests still waiting fail."""
        if self._closed:
            return
        try:
            self.send(NS_CONNECTION, RECEIVER_ID, {"type": "CLOSE"})
        except TvError:
            pass
        self._shutdown("closed by AniBox", notify=False)

    def __enter__(self) -> "CastClient":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    def _shutdown(self, reason: str, notify: bool = True) -> None:
        with self._lock:
            if self._closed:
                return
            self._closed = True
            self.close_reason = reason
            sock, self._sock = self._sock, None
            waiters, self._waiters = list(self._waiters), []
        self._stop.set()
        if sock is not None:
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                sock.close()
            except OSError:
                pass
        for w in waiters:
            w.error = reason
            w.event.set()
        if notify and self.on_close:
            try:
                self.on_close(reason)
            except Exception:
                log.exception("Cast: close handler")

    # -- sending and receiving

    def send(self, namespace: str, destination: str, payload: dict) -> None:
        data = frame(CastMessage(SENDER_ID, destination, namespace, _json(payload)))
        sock = self._sock
        if sock is None or self._closed:
            raise TvError(f"AniBox lost the connection to {self.name}.", "unreachable")
        try:
            with self._io:
                sock.settimeout(self.timeout)
                sock.sendall(data)
        except (OSError, ValueError) as exc:
            self._shutdown(f"sending failed ({exc})")
            raise TvError(f"AniBox lost the connection to {self.name}.", "unreachable") from exc

    def _read_loop(self, sock: ssl.SSLSocket) -> None:
        buf = bytearray()
        reason = "the TV closed the connection"
        try:
            while not self._closed:
                if not sock.pending():
                    readable, _, _ = select.select([sock], [], [], 0.25)
                    if not readable:
                        continue
                try:
                    with self._io:
                        sock.settimeout(0.0)
                        chunk = sock.recv(65536)
                except (ssl.SSLWantReadError, ssl.SSLWantWriteError, BlockingIOError, socket.timeout):
                    continue
                if not chunk:
                    break
                buf += chunk
                for msg in read_frames(buf):
                    self._dispatch(msg)
        except (OSError, ValueError) as exc:
            reason = f"connection error ({exc})"
        self._shutdown(reason)

    def _heartbeat_loop(self) -> None:
        while not self._stop.wait(HEARTBEAT):
            if self._closed:
                return
            if time.monotonic() - self._last_rx > DEAD_AFTER:
                self._shutdown("the TV stopped answering")
                return
            try:
                self.send(NS_HEARTBEAT, RECEIVER_ID, {"type": "PING"})
            except TvError:
                return

    def _dispatch(self, msg: CastMessage) -> None:
        self._last_rx = time.monotonic()
        try:
            data = json.loads(msg.payload_utf8 or "")
        except ValueError:
            return
        if not isinstance(data, dict):
            return
        ns, kind = msg.namespace, data.get("type")
        if ns == NS_HEARTBEAT and kind == "PING":
            try:
                self.send(NS_HEARTBEAT, msg.source_id or RECEIVER_ID, {"type": "PONG"})
            except TvError:
                pass
        elif ns == NS_CONNECTION and kind == "CLOSE":
            if msg.source_id in ("", RECEIVER_ID):
                self._shutdown("the TV closed the connection")
                return
            with self._lock:
                self._connected_to.discard(msg.source_id)
            if self.on_app_closed:
                self.on_app_closed(msg.source_id)
        elif ns == NS_RECEIVER and kind == "RECEIVER_STATUS" and isinstance(data.get("status"), dict):
            self.receiver = data["status"]
        elif ns == NS_MEDIA and kind == "MEDIA_STATUS":
            statuses = [s for s in data.get("status") or [] if isinstance(s, dict)]
            self.media_status = statuses
            if self.on_media:
                for st in statuses or [{}]:
                    try:
                        self.on_media(st)
                    except Exception:
                        log.exception("Cast: media status handler")
        with self._lock:
            waiters = list(self._waiters)
        for w in waiters:
            if not w.event.is_set() and w.match(ns, data):
                w.reply = data
                w.event.set()

    def _await(self, match: Callable[[str, dict], bool], send: Callable[[], None], timeout: float, what: str) -> dict:
        w = _Waiter(match)
        with self._lock:
            if self._closed:
                raise TvError(f"AniBox lost the connection to {self.name}.", "unreachable")
            self._waiters.append(w)
        try:
            send()
            if not w.event.wait(timeout):
                raise TvError(f"{self.name} didn't answer in time ({what}).", "unreachable")
            if w.reply is None:
                raise TvError(f"AniBox lost the connection to {self.name}.", "unreachable")
            return w.reply
        finally:
            with self._lock:
                if w in self._waiters:
                    self._waiters.remove(w)

    def request(self, namespace: str, destination: str, payload: dict, timeout: float = REQUEST_TIMEOUT) -> dict:
        """Sends ``payload`` with a new ``requestId`` and returns the reply that carries it."""
        rid = next(self._ids)
        payload = dict(payload, requestId=rid)
        return self._await(lambda ns, d: ns == namespace and d.get("requestId") == rid,
                           lambda: self.send(namespace, destination, payload), timeout,
                           str(payload.get("type") or "request").lower())

    # -- the receiver

    def receiver_status(self, timeout: float = REQUEST_TIMEOUT) -> dict:
        reply = self.request(NS_RECEIVER, RECEIVER_ID, {"type": "GET_STATUS"}, timeout)
        status = reply.get("status")
        if reply.get("type") != "RECEIVER_STATUS" or not isinstance(status, dict):
            raise TvError(f"{self.name} sent an answer AniBox doesn't understand.", "bad_answer")
        return status

    @staticmethod
    def app_in(status: Optional[dict], app_id: str) -> Optional[dict]:
        for app in (status or {}).get("applications") or []:
            if isinstance(app, dict) and app.get("appId") == app_id and app.get("transportId"):
                return {"appId": app_id, "sessionId": str(app.get("sessionId") or ""),
                        "transportId": str(app["transportId"])}
        return None

    def launch(self, app_id: str = DEFAULT_RECEIVER, timeout: float = LAUNCH_TIMEOUT) -> dict:
        """Starts (or joins, if it already runs) a receiver app and connects to it.

        Returns ``{"appId", "sessionId", "transportId"}``. Raises :class:`TvError`.
        """
        app = self.app_in(self.receiver_status(), app_id)
        if app is None:
            rid = next(self._ids)
            payload = {"type": "LAUNCH", "appId": app_id, "requestId": rid}

            def match(ns: str, d: dict) -> bool:
                if ns != NS_RECEIVER:
                    return False
                if d.get("type") == "RECEIVER_STATUS":  # the answer, or news that the app runs now
                    return self.app_in(d.get("status"), app_id) is not None
                return d.get("requestId") == rid  # LAUNCH_ERROR, INVALID_REQUEST ...

            reply = self._await(match, lambda: self.send(NS_RECEIVER, RECEIVER_ID, payload), timeout, "launch")
            if reply.get("type") != "RECEIVER_STATUS":
                why = reply.get("reason") or reply.get("type") or "unknown"
                raise TvError(f"{self.name} couldn't start its video player ({why}).", "refused")
            app = self.app_in(reply.get("status"), app_id)
            if app is None:
                raise TvError(f"{self.name} didn't start its video player.", "refused")
        self.connect_to(app["transportId"])
        return app

    def stop_app(self, session_id: str) -> None:
        """Closes the receiver app (the TV goes back to its home screen)."""
        self.request(NS_RECEIVER, RECEIVER_ID, {"type": "STOP", "sessionId": session_id}, REQUEST_TIMEOUT)

    def set_volume(self, level: Optional[float] = None, muted: Optional[bool] = None) -> dict:
        vol: dict = {}
        if level is not None:
            vol["level"] = max(0.0, min(1.0, float(level)))
        if muted is not None:
            vol["muted"] = bool(muted)
        reply = self.request(NS_RECEIVER, RECEIVER_ID, {"type": "SET_VOLUME", "volume": vol})
        return reply.get("status") if isinstance(reply.get("status"), dict) else {}

    # -- the media player

    MEDIA_ERRORS = ("LOAD_FAILED", "LOAD_CANCELLED", "INVALID_PLAYER_STATE", "INVALID_REQUEST", "ERROR")

    def media(self, transport: str, payload: dict, timeout: float = REQUEST_TIMEOUT) -> dict:
        """One media command; returns the reply (MEDIA_STATUS). Raises :class:`TvError` for error replies."""
        reply = self.request(NS_MEDIA, transport, payload, timeout)
        kind = reply.get("type")
        if kind in self.MEDIA_ERRORS:
            detail = reply.get("detailedErrorCode") or reply.get("reason") or ""
            what = str(payload.get("type") or "").lower()
            if kind in ("LOAD_FAILED", "LOAD_CANCELLED"):
                raise TvError(f"{self.name} couldn't play this video" + (f" ({detail})." if detail else "."),
                              "refused")
            raise TvError(f"{self.name} refused {what}" + (f" ({kind}, {detail})." if detail else f" ({kind})."),
                          "refused")
        return reply



# ---- one Cast device for TvPlayer ----------------------------------------------------------------------

_STATES = {"PLAYING": "PLAYING", "PAUSED": "PAUSED_PLAYBACK", "BUFFERING": "TRANSITIONING", "LOADING": "TRANSITIONING"}


def _seconds(value) -> float:
    try:
        v = float(value)
    except (TypeError, ValueError):
        return 0.0
    return v if 0 < v < float("inf") else 0.0


def _default_tools() -> Dict[str, Optional[str]]:
    return {"ffmpeg": shutil.which("ffmpeg"), "ffprobe": shutil.which("ffprobe")}


class CastRenderer:
    """Controls one Cast device through Google's Default Media Receiver.

    Same public interface as ``tv.Renderer`` (``load``, ``play``, ``pause``, ``seek``, ``stop``,
    ``status``, ``volume``, ``pair``, ``capabilities``, ``name``, ``device``, ``host``, ``base``,
    ``castapp`` False, ``token``), plus:

    - :meth:`prepare`: how a video reaches the device (``castserve.py``) and what to LOAD;
    - ``note``: a short line while this PC converts ("converting on this PC (uses the CPU)");
    - :meth:`subtitle_tracks`, ``subtitles_off``, :meth:`set_subtitle`: the playing bar's subtitle picker;
    - :meth:`activity`: whether the device fetched the video (the firewall hint);
    - :meth:`close`: ends running conversions and the connection.

    ``status()`` adds ``"error"`` (a sentence) when the device couldn't play the video. Positions are
    in the episode's time: a converted stream that started at 12:00 reports 12:00 + what the device
    played. Every method raises :class:`tv.TvError`. A dropped connection is opened again once per
    call (without starting the receiver app again, unless a new video is loaded).
    """

    kind = KIND
    castapp = False

    def __init__(self, device: dict, server: Optional[castserve.CastServer] = None,
                 tools: Optional[Callable[[], dict]] = None, tv_copy: Optional[Callable[[str], Optional[str]]] = None,
                 timeout: float = CONNECT_TIMEOUT):
        self.device = dict(device)
        self.name = str(device.get("name") or "The Chromecast")
        self._host = str(device.get("host") or "")
        self._port = int(device.get("port") or CAST_PORT)
        if not self._host:
            try:
                self._host, self._port, _ = _parse_address(str(device.get("location") or ""))
            except TvError:
                self._host = ""
        if not self._host or not _home_ip(self._host):
            raise TvError(f"{self.name} isn't in your home network.", "bad_answer")
        self.token = ""
        self.timeout = timeout
        self._own_server = server is None
        self.server = server if server is not None else castserve.CastServer()
        self.tools = tools or _default_tools
        self.tv_copy = tv_copy
        self.caps = castserve.device_caps(str(device.get("model") or ""))
        self._lock = threading.RLock()
        self._client: Optional[CastClient] = None
        self._app: Optional[dict] = None
        self._session: Optional[int] = None
        self._item: Optional[castserve.Item] = None  # the video playing
        self._pending: Optional[castserve.Item] = None  # prepared, not loaded yet
        self._url = ""  # what TvPlayer thinks plays (the first address of the item)
        self._urls: set = set()  # every address of that video (a jump in a stream makes a new one)
        self._offset = 0.0
        self._duration = 0.0
        self._title = ""
        self._image = ""
        self._paused = False
        self._finished = False
        self._error = ""
        self._app_closed = False
        self._last_pos = 0.0
        self._active: List[int] = []
        self._tracks: List[dict] = []
        self.note = ""
        self._loaded = ("", "")  # the address and type last sent with LOAD (a seek in a stream makes a new one)
        self._streamed = False  # the video is a stream made on this PC (remuxed or converted)
        self._live = False  # sent as a live stream (after the device refused it as a normal video)
        self._played = False  # the device reported PLAYING for this video

    @property
    def host(self) -> str:
        return self._host

    @property
    def base(self) -> str:
        return f"cast://{self._host}:{self._port}"

    # -- the connection

    def _on_media(self, st: dict) -> None:
        if not st or self._session is None or st.get("mediaSessionId") not in (None, self._session):
            return  # while a video loads, and other sessions' news, don't count
        if st.get("playerState") == "IDLE":
            reason = st.get("idleReason")
            if reason == "FINISHED":
                self._finished = True
            elif reason == "ERROR":
                self._error = self._error_text(st)

    def _on_app_closed(self, transport: str) -> None:
        if self._app and transport == self._app.get("transportId"):
            self._app_closed = True
            self._app = None

    def _ensure(self, launch: bool, need_app: bool = True) -> Tuple[CastClient, Optional[dict]]:
        client = self._client
        if client is None or not client.connected:
            client = CastClient(self._host, self._port, name=self.name, timeout=self.timeout,
                                on_media=self._on_media, on_app_closed=self._on_app_closed)
            client.connect()
            self._client, self._app = client, None
        if self._app is None and need_app:
            if launch:
                self._app = client.launch(DEFAULT_RECEIVER)
                self._app_closed = False
            else:
                app = client.app_in(client.receiver_status(), DEFAULT_RECEIVER)
                if app is None:
                    self._app_closed = True
                    raise TvError(f"{self.name} closed its video player.", "refused")
                client.connect_to(app["transportId"])
                self._app = app
        return client, self._app

    def _find_session(self, client: CastClient, app: dict) -> None:
        try:
            reply = client.media(app["transportId"], {"type": "GET_STATUS"}, STATUS_TIMEOUT)
        except TvError:
            return
        for st in reply.get("status") or []:
            if isinstance(st, dict) and (((st.get("media") or {}).get("contentId") in self._urls)
                                         or st.get("mediaSessionId") == self._session):
                self._session = st.get("mediaSessionId")
                return

    def _call(self, fn: Callable[[CastClient, Optional[dict]], object], launch: bool = False, need_app: bool = True):
        with self._lock:
            client, app = self._ensure(launch, need_app)
            try:
                return fn(client, app)
            except TvError as exc:
                if exc.reason != "unreachable" or client.connected:
                    raise
            # The connection dropped: once more on a new one (the receiver app keeps playing meanwhile).
            log.info("Cast: connection to %s dropped (%s); connecting again", self.name, client.close_reason)
            self._client, self._app = None, None
            client, app = self._ensure(launch, need_app)
            if app is not None and not launch and self._urls:
                self._find_session(client, app)
            return fn(client, app)

    def local_ip(self) -> str:
        client = self._client
        if client is not None and client.connected and client.local_ip:
            return client.local_ip
        return tv.lan_ip_for(self._host)

    # -- what to play

    def prepare(self, path: str = "", title: str = "", start: float = 0.0, langs: Sequence[str] = (),
                subs: str = "auto", audio_langs: Sequence[str] = (), *, url: str = "", relay=None, name: str = "",
                locate: Optional[Callable[[], str]] = None, sub_files: Sequence[Tuple[str, Callable[[], bytes]]] = (),
                sub_path: str = "") -> dict:
        """Gets a video ready for this device and returns what to LOAD:
        ``{"url", "mime", "tracks", "active", "offset", "start", "duration", "mode", "note", "warnings"}``.

        ``mode``: "direct" (the file as it is), "remux" (repackaged on the fly: the picture copied, the
        sound converted if needed), "convert" (the picture converted on this PC), "tvcopy" (a TV copy
        made earlier). ``offset``: where the URL starts in the episode (a remuxed or converted stream
        starts at the resume point, then ``start`` is 0; the file itself starts at 0 and ``start`` is
        the resume point). ``langs``: subtitle languages, best first; ``subs`` "off" sends the
        subtitles but shows none. A video from an address (Internet Archive): ``url`` and ``relay``
        (``tvstream.Relay``); a cache file: ``path`` and ``locate``. ``sub_files``: ``(name, loader)``.
        Nothing changes on the device until :meth:`load`.
        """
        with self._lock:
            if self._pending is not None:
                self._pending.release()
                self._pending = None
            tools = self.tools() or {}
            try:
                local = self.local_ip()
            except OSError:
                local = ""
            item = castserve.prepare_item(
                self.server, path, url=url, relay=relay, name=name, locate=locate, title=title, start=start,
                caps=self.caps, ffmpeg=tools.get("ffmpeg"), ffprobe=tools.get("ffprobe"), tv_ip=self._host,
                local_ip=local, sub_langs=langs, subs_on=subs != "off", audio_langs=audio_langs, tv_copy=self.tv_copy,
                sub_files=sub_files, sub_path=sub_path)
            self._pending = item
            info = item.load_info()
            for w in info.get("warnings") or []:
                log.info("Cast: %s", w)
            log.info("Cast: %s for %s on %s", info["mode"], title or name or path, self.name)
            return info

    @staticmethod
    def _error_text(st: dict) -> str:
        detail = st.get("detailedErrorCode") or (st.get("extendedStatus") or {}).get("detailedErrorCode") or ""
        return "The TV couldn't play this video" + (f" (error {detail})" if detail else "") + ". Play it on this PC instead."

    def load(self, url: str, title: str, mime: str, subtitle_url: Optional[str] = None, start: float = 0.0,
             wait: float = 10.0, subtrack: Optional[str] = None, audiotrack: Optional[str] = None,
             tracks: Optional[List[dict]] = None, active: Optional[Sequence[int]] = None, offset: float = 0.0,
             duration: float = 0.0, image: str = "") -> None:
        """Plays ``url`` on the device (LOAD in the Default Media Receiver).

        Like ``tv.Renderer.load``. ``start``: where playback starts in the URL's own time (a stream
        prepared at an offset starts at 0). ``tracks``/``active``: subtitle tracks as :meth:`prepare`
        returns them; a single ``subtitle_url`` (WebVTT) becomes one track. ``offset``: where the URL
        starts in the episode; ``duration``: the episode's length if known (a stream has none).
        CastApp TV's hints (``subtrack``, ``audiotrack``) are ignored; ``wait`` isn't needed (LOAD
        takes the start time). The video playing before keeps working if this fails.
        """
        tracks = list(tracks or [])
        active = list(active or [])
        if subtitle_url and not tracks:
            tracks = [{"trackId": 1, "type": "TEXT", "subtype": "SUBTITLES", "trackContentId": subtitle_url,
                       "trackContentType": "text/vtt", "name": "Subtitles"}]
            active = [] if subtrack == "off" else [1]
        with self._lock:
            pending = self._pending
            if pending is not None and url in pending.urls():
                item = pending
            elif self._item is not None and url in self._item.urls():
                item = self._item
            else:
                item = None
            before = (self._url, self._urls, self._offset, self._duration, self._title, self._image, self._tracks,
                      self._active, self._session, self.note)
            self._url, self._urls = url, set(item.urls()) if item is not None else {url}
            self._offset = max(0.0, float(offset or 0.0))
            self._duration = _seconds(duration)
            self._title, self._image = title, image
            self._tracks, self._active = tracks, active
            streamed = bool(item is not None and getattr(item, "streamed", False))
            try:
                try:
                    self._load(url, mime, start, autoplay=True)
                except TvError:
                    if not streamed:
                        raise
                    # Some devices take a stream that's still being made only as a live stream.
                    log.info("Cast: %s refused the stream as a normal video; trying it as a live stream", self.name)
                    self._load(url, mime, start, autoplay=True, live=True)
            except Exception:
                (self._url, self._urls, self._offset, self._duration, self._title, self._image, self._tracks,
                 self._active, self._session, self.note) = before
                if item is pending and pending is not None:
                    pending.release()
                    self._pending = None
                raise
            if item is not self._item:
                old, self._item = self._item, item
                if old is not None:
                    old.release()
            self._pending = None
            self.note = item.note if item is not None else ""
            self._streamed, self._played = streamed, False

    def _media_info(self, url: str, mime: str, live: bool = False) -> dict:
        meta: dict = {"metadataType": 0, "title": self._title or "Video"}
        if self._image:
            meta["images"] = [{"url": self._image}]
        media = {"contentId": url, "contentUrl": url, "contentType": mime, "streamType": "LIVE" if live else "BUFFERED",
                 "metadata": meta}
        if self._duration and self._offset < self._duration and not live:
            media["duration"] = round(self._duration - self._offset, 3)
        if self._tracks:
            media["tracks"] = self._tracks
            media["textTrackStyle"] = TEXT_STYLE
        return media

    def _load(self, url: str, mime: str, start: float, autoplay: bool, live: bool = False) -> None:
        media = self._media_info(url, mime, live)
        self._live, self._loaded = live, (url, mime)

        def do(client: CastClient, app: Optional[dict]):
            payload = {"type": "LOAD", "sessionId": app["sessionId"], "media": media, "autoplay": bool(autoplay),
                       "currentTime": round(max(0.0, float(start or 0.0)), 3)}
            if self._tracks:
                payload["activeTrackIds"] = list(self._active)
            return client.media(app["transportId"], payload, LOAD_TIMEOUT)

        self._session = None
        self._finished, self._error, self._paused = False, "", not autoplay
        reply = self._call(do, launch=True)
        statuses = [s for s in reply.get("status") or [] if isinstance(s, dict)]
        st = next((s for s in statuses if (s.get("media") or {}).get("contentId") == url),
                  statuses[0] if statuses else {})
        self._session = st.get("mediaSessionId")
        self._last_pos = self._offset + (_seconds(st.get("currentTime")) if st else float(start or 0))
        if st.get("playerState") == "IDLE" and st.get("idleReason") == "ERROR":
            self._error = self._error_text(st)
            raise TvError(f"{self.name} couldn't play this video.", "refused")

    # -- controls

    def _media_cmd(self, kind: str, **extra) -> dict:
        def do(client: CastClient, app: Optional[dict]):
            if self._session is None:
                raise TvError(f"Nothing is playing on {self.name}.", "refused")
            return client.media(app["transportId"], {"type": kind, "mediaSessionId": self._session, **extra})
        return self._call(do)

    def play(self) -> None:
        """Continues after a pause."""
        with self._lock:
            self._media_cmd("PLAY")
            self._paused = False

    def pause(self) -> None:
        with self._lock:
            self._media_cmd("PAUSE")
            self._paused = True

    def seek(self, seconds: float) -> None:
        """Jumps to ``seconds`` from the start of the episode.

        In the file itself: a SEEK. A remuxed or converted stream can't seek, so ffmpeg starts again
        at the new position and the device loads the new stream (as CastApp does).
        """
        seconds = max(0.0, float(seconds or 0))
        with self._lock:
            item = self._item
            if item is not None and item.streamed and self._url in item.urls():
                info = item.restart(seconds)
                self._urls = set(item.urls())
                self._offset = info["offset"]
                ids = {t["trackId"] for t in info["tracks"]}
                self._tracks, self._active = info["tracks"], [t for t in self._active if t in ids]
                self._load(info["url"], info["mime"], info["start"], autoplay=not self._paused, live=self._live)
                return
            self._media_cmd("SEEK", currentTime=round(max(0.0, seconds - self._offset), 3))

    def stop(self) -> None:
        """Stops playback and closes the receiver app (the TV goes back to its home screen)."""
        with self._lock:
            client, app = self._client, self._app
            if client is not None and client.connected and app is not None:
                try:
                    if self._session is not None:
                        client.media(app["transportId"], {"type": "STOP", "mediaSessionId": self._session})
                except TvError:
                    pass
                try:
                    client.stop_app(app["sessionId"])
                except TvError:
                    pass
            self._app = None
            self._session = None
            self._release()

    def _release(self) -> None:
        for item in (self._item, self._pending):
            if item is not None:
                item.release()
        self._item = self._pending = None
        self.note = ""

    def status(self) -> dict:
        """``{"state", "position", "duration", "uri"}`` like ``tv.Renderer.status``, plus ``"error"``
        (a sentence) when the device couldn't play the video. States: PLAYING, PAUSED_PLAYBACK,
        TRANSITIONING, STOPPED (also after the end: then ``position`` is the duration) and
        NO_MEDIA_PRESENT."""
        with self._lock:
            out = {"state": "NO_MEDIA_PRESENT", "position": self._last_pos, "duration": self._duration, "uri": "",
                   "error": ""}
            if self._error and self._retry_live():
                out.update(state="TRANSITIONING", uri=self._url)
                return out
            if self._error:
                out.update(state="STOPPED", error=self._with_copy_hint(self._error))
                return out
            if self._session is None and not self._urls:
                return out

            def closed() -> dict:
                out["state"] = "STOPPED"
                other = self._other_app()
                if other:
                    out["uri"] = f"cast-app:{other}"
                elif self._finished:
                    out.update(position=self._duration or self._last_pos, uri=self._url)
                return out

            if self._app_closed:
                return closed()

            def do(client: CastClient, app: Optional[dict]):
                return client.media(app["transportId"], {"type": "GET_STATUS"}, STATUS_TIMEOUT)

            try:
                reply = self._call(do)
            except TvError:
                if self._app_closed:
                    return closed()
                raise
            statuses = [s for s in reply.get("status") or [] if isinstance(s, dict)]
            st = next((s for s in statuses if s.get("mediaSessionId") == self._session), None)
            if st is None and statuses:
                other = (statuses[0].get("media") or {}).get("contentId") or ""
                if other and other not in self._urls:  # another sender loaded something else
                    out.update(state=_STATES.get(statuses[0].get("playerState"), "STOPPED"), uri=other)
                    return out
                st = statuses[0]
            if st is None:  # no media session any more: ended (or stopped on the TV)
                out.update(state="STOPPED", uri=self._url)
                if self._finished:
                    out["position"] = self._duration or self._last_pos
                return out
            media = st.get("media") or {}
            url = media.get("contentId") or ""
            out["uri"] = self._url if (not url or url in self._urls) else url
            reported = _seconds(media.get("duration"))
            if not self._duration and reported and self._offset == 0:
                self._duration = reported  # the file itself: the device knows its length
            out["duration"] = self._duration or (reported + self._offset if reported else 0.0)
            pos = self._offset + _seconds(st.get("currentTime"))
            player = st.get("playerState") or ""
            if player == "IDLE":
                reason = st.get("idleReason") or ""
                if reason == "ERROR":
                    self._error = self._error_text(st)
                    if self._retry_live():
                        out.update(state="TRANSITIONING")
                        return out
                    out.update(state="STOPPED", error=self._with_copy_hint(self._error))
                    return out
                if reason == "FINISHED" or self._finished:
                    self._finished = True
                    out.update(state="STOPPED", position=out["duration"] or max(pos, self._last_pos))
                    return out
                out.update(state="STOPPED", position=max(pos, self._last_pos))
                return out
            out["state"] = _STATES.get(player, "TRANSITIONING")
            if player == "PLAYING":
                self._played = True
            if player in ("PLAYING", "PAUSED") or _seconds(st.get("currentTime")):
                self._last_pos = pos
            out["position"] = self._last_pos
            self._paused = player == "PAUSED"
            return out

    def _with_copy_hint(self, error: str) -> str:
        """A stream made on this PC failed both ways (as a normal video and as a live stream): a TV copy is a
        finished file with a known length, which the device then gets instead."""
        if not (self._streamed and self._live) or "TV copy" in error:
            return error
        return error.rstrip(".") + (". It was being repackaged or converted on this PC: making a TV copy of this "
                                    "episode (show page, Plays on the TV? → Make TV copies) gives the TV a finished file instead.")

    def _retry_live(self) -> bool:
        """A stream made on this PC that failed before it ever played: load it once more as a live stream
        (some devices want a stream without a known end that way). True when that worked."""
        url, mime = self._loaded
        if not self._streamed or self._live or self._played or not url:
            return False
        log.info("Cast: %s couldn't play the stream as a normal video (%s); trying it as a live stream",
                 self.name, self._error or "error")
        try:
            self._load(url, mime or "video/mp4", max(0.0, self._last_pos - self._offset), autoplay=True, live=True)
        except TvError as exc:
            self._error = self._error or str(exc)
            return False
        return True

    def _other_app(self) -> str:
        """The app another sender started on the device (it replaced ours), "" if none."""
        client = self._client
        if client is None or not client.connected:
            return ""
        try:
            status = client.receiver_status(STATUS_TIMEOUT)
        except TvError:
            return ""
        for app in status.get("applications") or []:
            if isinstance(app, dict) and app.get("appId") and app.get("appId") != DEFAULT_RECEIVER \
                    and not app.get("isIdleScreen"):
                return str(app["appId"])
        return ""

    def volume(self, level: Optional[int] = None) -> int:
        """Sets the device's volume (0-100) and returns it; without ``level`` just reads it."""
        with self._lock:
            if level is None:
                status = self._call(lambda client, app: client.receiver_status(), need_app=False)
                try:
                    return int(round(float(((status or {}).get("volume") or {}).get("level")) * 100))
                except (TypeError, ValueError) as exc:
                    raise TvError(f"{self.name} sent an answer AniBox doesn't understand (volume).", "bad_answer") from exc
            level = max(0, min(100, int(level)))
            self._call(lambda client, app: client.set_volume(level / 100.0), need_app=False)
            return level

    # -- subtitles (the playing bar's track picker)

    def subtitle_tracks(self) -> List[dict]:
        """The subtitle tracks like the mpv player lists them (``id``, ``label``, ``info``, ``lang``, ``selected``)."""
        item = self._item
        infos = [s.info for s in item.subs] if item is not None else []
        out = []
        for t in self._tracks:
            i = t["trackId"]
            out.append({"id": i, "label": t.get("name") or f"Track {i}", "info": infos[i - 1] if 0 < i <= len(infos) else "",
                        "lang": t.get("language") or "", "selected": i in self._active})
        return out

    @property
    def subtitles_off(self) -> bool:
        return bool(self._tracks) and not self._active

    def set_subtitle(self, value) -> str:
        """Shows subtitle track ``value`` (a track id), or none ("no"). Returns the track's language ("no" for none)."""
        with self._lock:
            if value in ("no", None, "", False):
                ids: List[int] = []
                lang = "no"
            else:
                track = next((t for t in self._tracks if t["trackId"] == int(value)), None)
                if track is None:
                    raise TvError("That subtitle track isn't in this episode.", "refused")
                ids, lang = [track["trackId"]], track.get("language") or ""
            self._media_cmd("EDIT_TRACKS_INFO", activeTrackIds=ids)
            self._active = ids
            return lang

    # -- the rest of tv.Renderer's interface

    def pair(self, code: Optional[str] = None) -> dict:
        """Cast devices need no pairing code."""
        return {"needed": False, "paired": False, "token": ""}

    def capabilities(self) -> dict:
        """What AniBox assumes this model plays (castserve's table; not asked from the device)."""
        return dict(self.caps)

    def castapp_status(self) -> dict:
        return {}

    def activity(self, url: str = "") -> dict:
        """``{"requests", "bytes", "last"}``: did the device fetch the video? (0 requests = firewall)."""
        item = self._item
        if item is not None and (not url or url in item.urls()):
            return item.activity()
        return self.server.activity(url or self._url)

    def close(self) -> None:
        """Ends conversions, forgets the addresses and closes the connection (the TV keeps what it shows)."""
        with self._lock:
            self._release()
            client, self._client, self._app = self._client, None, None
            if client is not None:
                client.close()
            if self._own_server:
                self.server.stop()
