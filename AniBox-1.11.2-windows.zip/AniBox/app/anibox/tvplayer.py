"""Play on TV: AniBox's episode logic (resume, watched, next episode, sleep timer) for a TV.

The TV side (finding TVs, streaming the file, UPnP commands) is in ``tv.py``. This module keeps
one TV session at a time and looks like the mpv player to the rest of the app: ``play()``,
``command()`` and ``state()`` behave the same, so the playing bar and the phone remote work
unchanged. The file streams from this PC to the TV (it's read from the Shield's share), so AniBox
has to stay open while the TV plays.

Internet Archive videos and series playlists play on the TV too (``ia:`` keys, like ``Player``):
``tvstream.py`` decides which file goes and how it reaches the TV; resume, watched and next follow
the show they were played from (the item or the playlist), and the cache loads the next ones ahead.

CastApp TV is told which subtitle track inside the file to show: the exact one when AniBox can read
the file's track list (``tv.exact_subtitle_hint``), else the languages to prefer.

Openings and endings can be skipped on the TV as on this PC: the file's chapters (read with ffprobe)
and the ones found by sound (introdetect.py) give "Skip" in the bar and on the phone remote, or skip by
themselves when that's switched on (Settings, per profile).

Chromecasts and other Google Cast devices (the Shield's built-in receiver too) are TVs here as well:
``chromecast.CastRenderer`` has ``tv.Renderer``'s methods, and ``castserve.py`` decides per file how
it goes (as it is, remuxed, converted on this PC, or a TV copy) and serves it with its WebVTT subtitles.
"""

from __future__ import annotations

import logging
import os
import re
import struct
import threading
import time
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

from . import castserve, chromecast, introdetect, media, tv, tvcopy, tvstream
from .ffmpegsetup import find_tools
from .stream import PREFIX as STREAM_PREFIX
from .watching import next_up, resume_from

log = logging.getLogger("anibox.tvplayer")

POLL = 2.0  # seconds between status questions to the TV
SAVE_EVERY = 10.0
MAX_FAILURES = 6  # status questions in a row without an answer, then the session ends
END_SLACK = 20.0  # stopped this close to the end = finished
CAPS_SECONDS = 600.0  # how long CastApp TV's capabilities answer is kept
SAVED_KEYS = ("id", "name", "location", "manufacturer", "model", "castapp", "avtransport", "avtransport_type",
              "rendering", "rendering_type", "kind", "host", "port")  # what's remembered of a TV


def file_info(path: str, kind: str = "", cache: Optional[media.InfoCache] = None) -> Optional[dict]:
    """What's inside a video on this PC, for its subtitle tracks: what ffprobe found earlier (AniBox's
    media cache, from "Plays on the TV?"), else AniBox's own quick reading of an MKV or MP4 file (only
    its start; ``kind``'s extension says which, since the cache's files end in ``.part``)."""
    if cache is not None:
        hit = cache.peek(path)
        if hit:
            return hit
    ext = os.path.splitext(kind or path)[1].lower()
    try:
        if ext in (".mkv", ".mk3d", ".webm"):
            return media.probe_mkv_info(path)
        if ext in (".mp4", ".m4v", ".mov"):
            return media.probe_mp4_info(path)
    except (OSError, ValueError, struct.error, IndexError):
        return None
    return None


class TvPlayer:
    def __init__(self, store, library, media: Optional[tv.MediaServer] = None):
        self.store = store
        self.library = library
        self.media = media or tv.MediaServer()
        self.devices = []  # from the last search
        self._lock = threading.RLock()
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self.renderer: Optional[tv.Renderer] = None
        self.error = ""
        self.streams = None  # set by the App: Internet Archive videos (stream.py), as for Player.streams
        self.probe: Optional[Callable[[str, str], Optional[dict]]] = None  # set by the App: file_info with its cache
        self._caps: Dict[str, Tuple[float, dict]] = {}  # TV id -> (when, CastApp TV's capabilities)
        self.cast_server: Optional[castserve.CastServer] = None  # for Chromecasts, made on first use
        self._reset()

    def _reset(self) -> None:
        self.profile = None  # the profile the TV session started in (profiles): progress goes there
        self.key = ""
        self.show_id = ""
        self.url = ""
        self.sub_url = ""
        self.how = ""  # how the video reaches the TV: "file" (this PC), "relay" or "direct" (archive.org)
        self.pos = 0.0
        self.dur = 0.0
        self.tv_state = ""
        self.stage = "idle"  # idle, playing, ended
        self.started = 0.0
        self.played = False  # the TV reported PLAYING for this episode
        self.marked = False
        self.last_saved = 0.0
        self.failures = 0
        self.list_version = getattr(self, "list_version", 0)
        self.sleep_mode = None
        self.sleep_until = 0.0
        self.sleep_label = ""
        self.segments: List[Tuple[str, float, float]] = []  # openings/endings of this episode
        self.skipped = set()  # segment starts already skipped by themselves
        self.skip = None  # {"kind", "to"} while inside one

    @property
    def active(self) -> bool:
        return self.renderer is not None and self.stage != "idle"

    # -- TVs ---------------------------------------------------------------------------------------

    def known(self) -> list:
        """TVs found before (remembered), newest search first."""
        saved = self.store.meta("tv_devices") or {}
        seen = {d["id"] for d in self.devices}
        return list(self.devices) + [d for i, d in saved.items() if i not in seen]

    @staticmethod
    def _label(d: dict) -> str:
        return " (CastApp TV)" if d.get("castapp") else " (Chromecast)" if d.get("kind") == chromecast.KIND else ""

    def discover(self, timeout: float = 3.0) -> list:
        """DLNA TVs (CastApp TV, smart TVs, Kodi) and, unless switched off, Cast devices, searched at the same time."""
        casts: list = []
        search = None
        if self.store.settings().get("chromecast", True):
            def cast_search() -> None:
                try:
                    casts.extend(chromecast.discover(timeout))
                except OSError as exc:
                    log.info("Chromecast search failed: %s", exc)

            search = threading.Thread(target=cast_search, daemon=True, name="anibox-cast-search")
            search.start()
        devices = tv.discover(timeout)
        if search is not None:
            search.join(timeout + 2)
        self.devices = sorted(devices + list(casts), key=lambda d: (d["name"].casefold(), d.get("kind") or "", d["id"]))
        log.info("TV search: %s", ", ".join(f"{d['name']}{self._label(d)}" for d in self.devices) or "none")
        return self.devices

    def add(self, address: str) -> dict:
        """A TV typed in by hand (when the search doesn't find it): read its description, remember it.

        "…:8009" or "cast://…" is a Chromecast; an address without a port where no DLNA TV answers is
        tried as a Chromecast too."""
        if chromecast.is_cast_address(address):
            dev = chromecast.address_device(address)
        else:
            try:
                dev = tv.describe(tv.address_location(address))
            except tv.TvError as exc:
                if exc.reason not in ("unreachable", "bad_answer", "unsupported") or ":" in address.split("]")[-1] \
                        or not self.store.settings().get("chromecast", True):
                    raise
                try:
                    dev = chromecast.address_device(address)
                except tv.TvError:
                    raise exc from None
        self.devices = [d for d in self.devices if d["id"] != dev["id"]] + [dev]
        saved = self.store.meta("tv_devices") or {}
        saved[dev["id"]] = {k: dev.get(k) for k in SAVED_KEYS}
        self.store.set_meta("tv_devices", saved)
        log.info("TV added by address: %s%s", dev["name"], self._label(dev))
        return dev

    def _device(self, device_id: str) -> dict:
        for d in self.devices:
            if d["id"] == device_id:
                return d
        saved = (self.store.meta("tv_devices") or {}).get(device_id) or {}
        if device_id.startswith(chromecast.ID_PREFIX):
            dev = chromecast.locate(device_id, saved.get("location", ""), saved=saved)
        else:
            dev = tv.locate(device_id, saved.get("location", ""))
        if not dev:
            raise tv.TvError("That TV isn't on the network right now. Switch it on and search again.", "unreachable")
        return dev

    def _remember(self, dev: dict) -> None:
        saved = self.store.meta("tv_devices") or {}
        saved[dev["id"]] = {k: dev.get(k) for k in SAVED_KEYS}
        self.store.set_meta("tv_devices", saved)
        self.store.update_settings({"tv_device": dev["id"]})

    def _renderer_for(self, dev: dict):
        """``tv.Renderer`` for DLNA TVs, ``chromecast.CastRenderer`` for Cast devices (kept while the same one plays)."""
        if dev.get("kind") != chromecast.KIND:
            return tv.Renderer(dev, token=self._token(dev["id"]))
        r = self.renderer
        if isinstance(r, chromecast.CastRenderer) and r.device.get("id") == dev["id"]:
            return r
        if self.cast_server is None:
            self.cast_server = castserve.CastServer()
        return chromecast.CastRenderer(dev, server=self.cast_server, tools=self._tools)

    def _tools(self) -> dict:
        """ffmpeg and ffprobe for Chromecasts (remuxing, converting): the ones "Plays on the TV?" uses."""
        return find_tools(Path(self.store.path).parent, self.store.settings().get("ffmpeg_path") or "")

    def _token(self, device_id: str) -> str:
        return (self.store.meta("tv_tokens") or {}).get(device_id, "")

    def pair(self, device_id: str, code: Optional[str] = None) -> dict:
        """CastApp TV in "only paired devices" mode: the 4-digit code shown on the TV."""
        if device_id.startswith(chromecast.ID_PREFIX):
            return {"needed": False, "paired": False}  # Cast devices need no code
        r = tv.Renderer(self._device(device_id), token=self._token(device_id))
        result = r.pair(code)
        if result.get("token"):
            tokens = self.store.meta("tv_tokens") or {}
            tokens[device_id] = result["token"]
            self.store.set_meta("tv_tokens", tokens)
        return {k: v for k, v in result.items() if k != "token"}

    # -- playing -------------------------------------------------------------------------------------

    def lookup(self, key: str):
        """(show, index) of an episode key: the library's, or an Internet Archive video's (as ``Player``)."""
        if key.startswith(STREAM_PREFIX) and self.streams:
            return self.streams.episode(key)
        return self.library.episode(key)

    def show_of(self, show_id: str):
        if show_id.startswith(STREAM_PREFIX) and self.streams:
            return self.streams.show(show_id)
        return self.library.show(show_id)

    def play(self, device_id: str, show_id: str = "", key: str = "", from_start: bool = False,
             start: Optional[float] = None) -> None:
        settings = self.store.settings()
        if (key or show_id).startswith(STREAM_PREFIX) and self.streams:
            self.streams.prepare(key or show_id, show_id=show_id)  # the item's videos (archive.org asked once)
        if not key:
            show = self.show_of(show_id)
            if not show:
                raise RuntimeError("Show not found. Scan again in Settings.")
            ep, _ = next_up(show, self.store.all_progress())
            key = (ep or show["episodes"][0])["key"]
            if show.get("stream") and self.streams:
                self.streams.prepare(key, show_id=show_id)  # a playlist: next/previous follow it
        if start is None:
            p = self.store.progress(key) or {}
            start = 0.0 if from_start or p.get("watched") else resume_from(
                float(p.get("position") or 0), float(p.get("duration") or 0), int(settings.get("resume_back", 10)))
        dev = self._device(device_id)
        with self._lock:
            if self.renderer and self.renderer.device.get("id") != dev["id"]:
                self._end("switched to another TV")
            self.renderer = self._renderer_for(dev)
            self._load(key, start, profile=self.store.profile)
            self._remember(dev)
        self._ensure_thread()

    def _load(self, key: str, start: float, profile: Optional[str] = None) -> None:
        show, idx = self.lookup(key)
        if not show or idx < 0:
            raise RuntimeError("That episode isn't in the library any more. Scan again in Settings.")
        ep = show["episodes"][idx]
        if self.key and self.key != key:
            self._save()
        if profile is not None:
            self.profile = profile
        if getattr(self.renderer, "kind", "") == chromecast.KIND:
            return self._load_cast(key, start, show, idx)
        if not self.media.running:
            self.media.start()
        r = self.renderer
        title = f"{show['title']} · {ep['label']}"
        s = self.store.settings(self.profile)
        pref = self.store.show_pref(show["id"], profile=self.profile)
        show_sub = pref["sub"]
        mode = s.get("subs") or "auto"
        hint = tv.subtitle_hint(show_sub, s.get("sub_langs", ""), mode)
        langs = [x for x in [show_sub] + re.split(r"[,;\s]+", s.get("sub_langs", "") or "") if x and x != "no"]
        caps = self._capabilities(r) if r.castapp else {}
        keep_ass = tv.ass_sidecars_ok(caps)  # CastApp TV 3 shows ASS files with their styling
        stream = bool(show.get("stream") and self.streams)
        url = sub_url = None
        how = ""
        try:  # until the TV has the new video, the one playing keeps working (e.g. the next one can't play there)
            if stream:
                how, url, mime, local, kind, subs, note = self._stream_source(ep, title, r, langs if hint != "off" else [],
                                                                              keep_ass)
            else:
                video = tvcopy.copy_for(ep["path"]) or ep["path"]  # a TV copy (tvcopy.py) when there is one
                how, url, mime, local, kind = "file", self.media.add(video, title, tv_ip=r.host), \
                    tv.mime_for(video), video, video
                note = " (TV copy)" if video != ep["path"] else ""
                subs = [(lambda video_url, p=p: self.media.add_subtitle(p, video_url=video_url, tv_ip=r.host, keep_ass=keep_ass))
                        for p in (tv.find_subtitles(ep["path"], langs, prefer_ass=keep_ass) if hint != "off" else [])]
            for add in subs:
                try:
                    sub_url = add(url)
                    break
                except (tv.TvError, OSError, ValueError) as exc:
                    log.info("TV: a subtitle file couldn't go along (%s)", exc)
            info = self._file_tracks(local, kind) if r.castapp and local else None  # the tracks inside, if readable
            if sub_url is None and hint != "off" and info:
                # No subtitle file goes along (one would always win on CastApp TV): name the exact track.
                hint = self._exact_hint(info, show_sub, s.get("sub_langs", ""), mode, r) or hint
            # CastApp TV only, like the subtitle hint: the exact sound track when AniBox can read the file's
            # tracks, else the languages to prefer.
            audio = (tv.exact_audio_hint(tv.castapp_audio_tracks(info.get("audio")), pref.get("audio") or "",
                                         s.get("audio_langs", "")) if info else None) \
                or tv.audio_hint(pref.get("audio") or "", s.get("audio_langs", ""))
            r.load(url, title, mime, sub_url, start=start, subtrack=None if sub_url else hint, audiotrack=audio)
        except Exception:
            self._drop(url or "", sub_url or "", how)
            raise
        log.info("Playing on %s: %s%s", r.name, title, note)
        self._forget_urls()  # the last video's addresses stop working
        self.key, self.show_id, self.url, self.sub_url, self.how = key, show["id"], url, sub_url or "", how
        self.pos, self.dur, self.tv_state = start, 0.0, "PLAYING"  # load() ended with Play
        self.stage, self.started, self.played, self.marked = "playing", time.time(), False, False
        self.last_saved, self.failures, self.error = time.time(), 0, ""
        self.list_version += 1
        self.store.save_position(key, show["id"], start, 0, profile=self.profile)
        self._find_segments(key, "" if stream else ep["path"])
        if stream:  # the cache loads the next episodes ahead (the files the TV will get)
            self.streams.played(tvstream.tv_view(self.streams, show, idx, r.castapp, self._capabilities(r)), idx)

    def _load_cast(self, key: str, start: float, show: dict, idx: int) -> None:
        """A Chromecast: castserve.py decides how the video goes (as it is, remuxed, converted on this PC or a
        TV copy) and serves it with its subtitles; resume, progress, watched and next work as for other TVs."""
        ep = show["episodes"][idx]
        r = self.renderer
        title = f"{show['title']} · {ep['label']}"
        s = self.store.settings(self.profile)
        pref = self.store.show_pref(show["id"], profile=self.profile)
        hint = tv.subtitle_hint(pref["sub"], s.get("sub_langs", ""), s.get("subs") or "auto")
        langs = [x for x in [pref["sub"]] + re.split(r"[,;\s]+", s.get("sub_langs", "") or "") if x and x != "no"]
        audio = [x for x in [pref.get("audio") or ""] + re.split(r"[,;\s]+", s.get("audio_langs", "") or "") if x]
        stream = bool(show.get("stream") and self.streams)
        source = self._cast_stream_source(ep, r, langs) if stream else {"path": ep["path"]}
        how = source.pop("how", "file")
        prep = r.prepare(title=title, start=start, langs=langs, subs="off" if hint == "off" else "auto",
                         audio_langs=audio, **source)
        r.load(prep["url"], title, prep["mime"], start=prep["start"], tracks=prep["tracks"], active=prep["active"],
               offset=prep["offset"], duration=prep["duration"])  # the video before keeps playing if this fails
        log.info("Playing on %s: %s (%s%s)", r.name, title, prep["mode"], f", {prep['note']}" if prep.get("note") else "")
        self._forget_urls()
        self.key, self.show_id, self.url, self.sub_url, self.how = key, show["id"], prep["url"], "", how
        self.pos, self.dur, self.tv_state = start, prep["duration"], "PLAYING"
        self.stage, self.started, self.played, self.marked = "playing", time.time(), False, False
        self.last_saved, self.failures, self.error = time.time(), 0, ""
        self.list_version += 1
        self.store.save_position(key, show["id"], start, 0, profile=self.profile)
        self._find_segments(key, "" if stream else ep["path"])
        if stream:  # the cache loads the next episodes ahead (as for other TVs: archive.org's MP4 copies first)
            self.streams.played(tvstream.tv_view(self.streams, show, idx, False, {}), idx)

    def _find_segments(self, key: str, path: str) -> None:
        """Openings/endings of the episode now on the TV, in the background (ffprobe reads the file's start
        over the network): its chapters, plus the ones found by sound for kinds the chapters don't name.
        Times are the original file's; a TV copy keeps them."""
        self.segments, self.skipped, self.skip = [], set(), None
        if not path:
            return

        def work() -> None:
            chapters = []
            ffprobe = (self._tools() or {}).get("ffprobe")
            if ffprobe:
                try:
                    chapters = introdetect.probe(path, ffprobe)["chapters"]
                except (introdetect.DetectError, OSError, KeyError) as exc:
                    log.info("TV: chapters couldn't be read (%s)", exc)
            segments = introdetect.with_markers(list(chapters), path, Path(self.store.path).parent)
            with self._lock:
                if self.key == key:
                    self.segments = segments
                    if segments:
                        log.info("TV: openings/endings to skip: %s", ", ".join(f"{k} {a:.0f}-{b:.0f}s" for k, a, b in segments))

        threading.Thread(target=work, daemon=True, name="anibox-tv-skip").start()

    def _check_skip(self, r, paused: bool) -> None:
        """Inside an opening/ending: offer "Skip", or skip by itself (settings skip_openings/skip_endings)."""
        self.skip = None
        if not self.segments or self.stage != "playing":
            return
        settings = self.store.settings(self.profile)
        for kind, start, end in self.segments:
            if start <= self.pos < end - 2:
                mode = settings.get("skip_openings" if kind == "opening" else "skip_endings") or "button"
                if mode == "auto" and start not in self.skipped and not paused:
                    self._skip_to(r, end, kind)  # a seek that fails is tried again on the next question
                    self.skipped.add(start)
                elif mode != "off":
                    self.skip = {"kind": kind, "to": end}
                break

    def _skip_to(self, r, to: float, kind: str) -> None:
        to = max(0.0, min(float(to), self.dur - 1 if self.dur else float(to)))
        r.seek(to)
        self.pos, self.skip = to, None
        log.info("TV: skipped the %s", kind)

    def _cast_stream_source(self, ep: dict, r, langs: List[str]) -> dict:
        """An Internet Archive video for a Chromecast (see tvstream.plan): the whole file from this PC when it's
        there, else the cache's or archive.org's address, relayed (with CORS) or read by ffmpeg to remux it."""
        p = tvstream.plan(self.streams, ep["key"], False, {}, r.name)
        ident, name = p["item"], p["name"]
        out = {"how": p["how"], "name": name}
        if p["how"] == "file":
            out.update(path=p["path"], locate=lambda: self.streams.local_file(ident, name))
        else:
            out.update(url=p["url"], relay=tvstream.Relay(p["url"], self.streams.client.base, tv.mime_for(name)))
        played = ep.get("file") or name
        out["sub_files"] = [(sub, lambda sub=sub: tvstream.fetch_subtitle(self.streams.client, ident, sub))
                            for sub in (tvstream.item_subtitles(self.streams, ident, [name, played], langs) if langs else [])[:2]]
        return out

    def _stream_source(self, ep: dict, title: str, r: tv.Renderer, langs: List[str], keep_ass: bool = False):
        """An Internet Archive video for the TV (see tvstream.py): (how, url, mime, local path or "",
        the file's name, subtitle adders, a note for the log)."""
        caps = self._capabilities(r)
        p = tvstream.plan(self.streams, ep["key"], r.castapp, caps, r.name)
        ident, name = p["item"], p["name"]
        mime = tv.mime_for(name)
        if p["how"] == "file":
            url = self.media.add(p["path"], title, tv_ip=r.host, kind=name,
                                 locate=lambda: self.streams.local_file(ident, name))
            note = " (from this PC)"
        elif p["how"] == "relay":
            url = self.media.add_source(tvstream.Relay(p["url"], self.streams.client.base, mime), name, title,
                                        tv_ip=r.host)
            note = " (through the cache)" if p["cache"] else " (relayed from archive.org)"
        else:
            url, note = p["url"], " (straight from archive.org)"
        if p["swapped"]:
            note += f", archive.org's copy {name}"
        played = ep.get("file") or name
        subs = [(lambda video_url, sub=sub: self.media.add_subtitle_data(
                    sub, tvstream.fetch_subtitle(self.streams.client, ident, sub), video_url=video_url, tv_ip=r.host,
                    keep_ass=keep_ass))
                for sub in (tvstream.item_subtitles(self.streams, ident, [name, played], langs, keep_ass) if langs else [])[:2]]
        return p["how"], url, mime, p.get("path") or "", name, subs, note

    def _capabilities(self, r: tv.Renderer) -> dict:
        """What CastApp TV says it decodes ({} for other TVs), asked at most every 10 minutes."""
        if not r.castapp:
            return {}
        dev = str(r.device.get("id") or r.host)
        hit = self._caps.get(dev)
        if hit and time.time() - hit[0] < CAPS_SECONDS:
            return hit[1]
        caps = r.capabilities()
        self._caps[dev] = (time.time(), caps)
        return caps

    def _file_tracks(self, path: str, kind: str) -> Optional[dict]:
        """What's inside a file on this PC (its sound and subtitle tracks), None if it can't be read."""
        try:
            return self.probe(path, kind) if self.probe else file_info(path, kind)
        except Exception:
            log.info("TV: couldn't read the tracks of %s", os.path.basename(kind or path), exc_info=True)
            return None

    def _exact_hint(self, info: dict, show_sub: str, sub_langs: str, mode: str, r: tv.Renderer) -> Optional[str]:
        """CastApp TV's hint for the exact subtitle track inside a file on this PC, None if unknown."""
        tracks = tv.castapp_tracks((info or {}).get("subs"))
        if not tracks:
            return None
        return tv.exact_subtitle_hint(tracks, show_sub, sub_langs, mode, self._capabilities(r))

    def _forget_urls(self) -> None:
        """The addresses of the last video and its subtitle stop working (the TV gets 404 for them)."""
        self._drop(self.url, self.sub_url, self.how)
        self.url = self.sub_url = ""

    def _drop(self, url: str, sub_url: str, how: str) -> None:
        if url and how != "direct":
            self.media.remove(url)
        if sub_url:
            self.media.remove(sub_url)

    def _neighbour(self, step: int) -> Optional[str]:
        if not self.key:
            return None
        show, idx = self.lookup(self.key)
        if not show or idx < 0:
            return None
        j = idx + step
        return show["episodes"][j]["key"] if 0 <= j < len(show["episodes"]) else None

    def command(self, cmd: str, value=None, ident=None) -> None:
        with self._lock:
            if cmd == "play-episode":
                self._need()._load(str(ident or value), 0.0)
                return
            if cmd == "sleep-set":
                minutes = int(value or 0)
                if minutes < 0:
                    self.sleep_mode, self.sleep_label = "episode", "end of this episode"
                else:
                    self.sleep_mode, self.sleep_until, self.sleep_label = "minutes", time.time() + 60 * minutes, f"{minutes} min"
                return
            if cmd == "sleep-stop":
                self.sleep_mode, self.sleep_label = None, ""
                return
            r = self._need().renderer
            if cmd == "play-pause":
                if self.tv_state == "PLAYING":
                    r.pause()
                    self.tv_state = "PAUSED_PLAYBACK"
                else:
                    r.play()
                    self.tv_state = "PLAYING"
            elif cmd in ("seek-rel", "seek-to"):
                target = (self.pos + float(value or 0)) if cmd == "seek-rel" else float(value or 0)
                target = max(0.0, min(target, self.dur - 1 if self.dur else target))
                r.seek(target)
                self.pos = target
            elif cmd in ("next", "prev"):
                key = self._neighbour(1 if cmd == "next" else -1)
                if not key:
                    raise RuntimeError("There's no " + ("next" if cmd == "next" else "previous") + " episode.")
                self._load(key, 0.0)
            elif cmd == "volume":
                r.volume(int(max(0, min(100, float(value or 0)))))
            elif cmd in ("stop", "still-stop"):
                try:
                    r.stop()
                except tv.TvError:
                    pass
                self._end("stopped")
            elif cmd == "sub" and getattr(r, "kind", "") == chromecast.KIND:
                lang = r.set_subtitle(value)  # a Chromecast switches its subtitle tracks (EDIT_TRACKS_INFO)
                if lang:
                    self.store.set_show_pref(self.show_id, sub=lang)
            elif cmd == "skip":
                if not self.skip:
                    raise RuntimeError("There's no opening or ending to skip right now.")
                self._skip_to(r, self.skip["to"], self.skip["kind"])
            elif cmd in ("audio", "sub", "mute"):
                raise RuntimeError("That isn't available while playing on the TV.")
            else:
                raise RuntimeError(f"Unknown command: {cmd}")

    def _need(self) -> "TvPlayer":
        if not self.active:
            raise RuntimeError("Nothing is playing on the TV.")
        return self

    def stop(self) -> None:
        with self._lock:
            if self.renderer:
                try:
                    self.renderer.stop()
                except tv.TvError:
                    pass
            self._end("stopped")

    def shutdown(self) -> None:
        self._stop.set()
        with self._lock:
            self._end("AniBox closed")
        self.media.stop()
        if self.cast_server is not None:
            self.cast_server.stop()

    def _end(self, why: str) -> None:
        if self.renderer and self.key:
            self._save()
            log.info("TV session ended (%s)", why)
        self._forget_urls()
        if getattr(self.renderer, "kind", "") == chromecast.KIND:
            self.renderer.close()  # its conversions and the connection end
        self.renderer = None
        self._reset()

    def _save(self, watched: Optional[bool] = None) -> None:
        if not self.key:
            return
        at = float(self.store.settings().get("watched_at", 95)) / 100
        if watched is None and self.dur > 0 and self.pos >= self.dur * at:
            watched = True
        self.store.save_position(self.key, self.show_id, self.pos, self.dur, watched, profile=self.profile)
        self.last_saved = time.time()

    # -- watching the TV -------------------------------------------------------------------------------

    def _ensure_thread(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True, name="anibox-tv")
        self._thread.start()

    def _loop(self) -> None:
        while not self._stop.wait(POLL):
            with self._lock:
                if not self.active:
                    break
                try:
                    self.tick()
                except Exception as exc:
                    log.exception("TV problem")
                    self.error = str(exc)

    def tick(self) -> None:
        r = self.renderer
        try:
            st = r.status()
        except tv.TvError as exc:
            self.failures += 1
            if self.failures >= MAX_FAILURES:
                self.error = str(exc)
                self._end("the TV stopped answering")
            return
        self.failures = 0
        if st.get("error") and st["state"] in ("STOPPED", "NO_MEDIA_PRESENT"):
            # The TV says playing failed (CastApp TV 3 also says why): no waiting, no firewall guess.
            self.error = st["error"] if isinstance(st["error"], str) else self._failure_text(r)  # a Chromecast says it
            self._end("the TV couldn't play it")
            return
        if st.get("uri") and self.url and st["uri"] != self.url and self.played:
            self._end("something else is playing on the TV now")
            return
        self.tv_state = st["state"]
        if st["state"] == "PLAYING":
            self.played = True
        if st["position"]:
            self.pos = st["position"]
        if st["duration"]:
            self.dur = st["duration"]
        at = float(self.store.settings().get("watched_at", 95)) / 100
        if self.dur and self.pos >= self.dur * at and not self.marked:
            self.marked = True
            self._save(True)
        elif time.time() - self.last_saved >= SAVE_EVERY and st["state"] == "PLAYING":
            self._save()
        try:
            self._check_skip(r, st["state"] != "PLAYING")
        except tv.TvError as exc:  # the seek didn't go through: try again on the next question
            log.info("TV: skipping didn't work (%s)", exc)
        if self.sleep_mode == "minutes" and time.time() >= self.sleep_until:
            self.sleep_mode, self.sleep_label = None, ""
            try:
                r.pause()
            except tv.TvError:
                pass
        if not self.played and not self.error and time.time() - self.started > 12 and self.how != "direct" \
                and self.url and self._activity(r)["requests"] == 0:
            # The TV never asked for the file: almost always the Windows firewall.
            self.error = ("The TV couldn't reach this PC. Allow Python (pythonw.exe) in the Windows firewall for "
                          "private networks, and check that your home network is set to Private.")
        finished = st["state"] in ("STOPPED", "NO_MEDIA_PRESENT") and self.played
        if not finished:
            if st["state"] in ("STOPPED", "NO_MEDIA_PRESENT") and time.time() - self.started > 45:
                self.error = ("The TV didn't start the video. It plays this one straight from archive.org: check the TV's "
                              "internet connection, or switch the Internet Archive cache on (Settings)." if self.how == "direct" else
                              "The TV didn't start the video. If it's CastApp TV, open it once on the TV; also allow AniBox "
                              "in the Windows firewall (private networks).")
                self._end("the TV never played")
            return
        near_end = self.dur and self.pos >= self.dur - END_SLACK
        if not near_end:
            self._end("stopped on the TV")
            return
        self.pos = self.dur
        self._save(True)
        nxt = self._neighbour(1)
        if self.sleep_mode == "episode":
            self.sleep_mode, self.sleep_label = None, ""
            self._end("sleep timer")
        elif nxt and self.store.settings(self.profile).get("autoplay", True):
            try:
                self._load(nxt, 0.0)
            except (tv.TvError, RuntimeError) as exc:  # e.g. the next video is a kind this TV can't play
                self.error = str(exc)
                self._end("the next episode can't play on this TV")
        else:
            self._end("last episode finished")

    def _activity(self, r) -> dict:
        """Did the TV fetch the video? (A Chromecast's videos come from castserve's server.)"""
        if getattr(r, "kind", "") == chromecast.KIND:
            return r.activity(self.url)
        return self.media.activity(self.url)

    def _failure_text(self, r: tv.Renderer) -> str:
        """What to tell the user when the TV says playing failed (ERROR_OCCURRED): CastApp TV says why."""
        err = (r.castapp_status() or {}).get("error") if r.castapp else None
        message = str(err.get("message") or "").strip() if isinstance(err, dict) else ""
        if message:
            return f"{r.name} couldn't play this video: {message.rstrip('.')}."
        return f"{r.name} couldn't play this video. Play it on this PC instead."

    def state(self) -> dict:
        show = self.show_of(self.show_id) if self.show_id else None
        ep = None
        if show:
            _, idx = self.lookup(self.key)
            ep = show["episodes"][idx] if idx >= 0 else None
        active = self.active and bool(ep)
        cast = active and getattr(self.renderer, "kind", "") == chromecast.KIND
        note = getattr(self.renderer, "note", "") if cast else ""  # e.g. "converting on this PC (uses the CPU)"
        out = {
            "active": active, "target": "tv", "device": self.renderer.name if self.renderer else "",
            "stage": "playing" if active else "idle", "showId": self.show_id,
            "malId": (show or {}).get("mal_id") or "" if (show or {}).get("picture") else "",
            "key": self.key, "title": show["title"] if show else "",
            "kicker": f"On {self.renderer.name}" + (f" · {note}" if note else "") if active else "",
            "sub": ep["label"] if ep else "",
            "art": (show or {}).get("art") or "",  # Internet Archive streams: the item's picture
            "stream": bool(show and show.get("stream")),
            "pos": round(self.pos, 1), "dur": round(self.dur, 1),
            "paused": self.tv_state != "PLAYING", "volume": 100, "muted": False,
            "hasPrev": bool(self._neighbour(-1)) if active else False,
            "hasNext": bool(self._neighbour(1)) if active else False,
            "countdown": 0,
            "sleep": {"active": bool(self.sleep_mode), "label": self.sleep_label,
                      "remaining": max(0, round(self.sleep_until - time.time())) if self.sleep_mode == "minutes" else 0},
            "still": {"stage": "", "next": ""}, "listVersion": self.list_version, "showIdle": "",
            "tracks": {"audio": [], "sub": self.renderer.subtitle_tracks() if cast else []},
            "subOff": bool(cast and self.renderer.subtitles_off), "skip": self.skip if active else None,
            "error": self.error, "mpv": True, "tvState": self.tv_state,
        }
        if show:
            progress = self.store.all_progress()
            out["count"] = len(show["episodes"])
            out["seen"] = sum(1 for e in show["episodes"] if (progress.get(e["key"]) or {}).get("watched"))
        return out
