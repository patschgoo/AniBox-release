"""Kodi-style .nfo files with MyAnimeList information, written next to your videos.

Plex Media Server 1.43.1+ has a "Plex NFO" agent that reads Kodi-format .nfo files from the
show folders, and Jellyfin and Kodi read the same files. AniBox can write such files so these
apps show MAL titles and descriptions without an always-on metadata server.

This is the one place where AniBox writes onto your drives, so it is careful:

- ``plan()`` only reads. It works out what would happen to every file, and nothing is written
  until ``write()`` is called with that plan (after you've looked at ``preview_text()``).
- Only three kinds of files are ever written: ``tvshow.nfo`` in a show folder, ``<video
  name>.nfo`` next to a video, and (if asked) ``poster.jpg`` in a show folder that has no
  poster image yet. No folders are created, and nothing is renamed, moved or deleted.
- Every .nfo AniBox writes has ``MARKER`` right after the XML declaration, then a checksum
  line. A file without the marker is yours and is never touched ("skip-foreign"). A file with
  the marker whose checksum no longer fits was edited by you and is left alone too
  ("skip-edited").
- Protected shows are skipped completely: their folders aren't even listed. Which names are
  protected is the user's choice (``protected``). One Piece follows the lock rule like every other
  show (user, 2026-11-22): the app skips episodes that were already there until a show is unlocked.
- ``write()`` checks every file again right before replacing it, writes through a temporary
  file in the same folder plus ``os.replace``, and logs every written file (with its checksum
  and the previous AniBox content) to an undo file. ``undo()`` removes or restores only files
  that are still exactly as AniBox wrote them.

Numbering: AniBox's folders hold one MyAnimeList entry each, so a file ``Show 05.mkv`` is
season 1, episode 5 of that entry's show. Files in ``Season NN`` folders keep that season,
``Specials`` is season 0, and an explicit ``S02E05`` in a file name is kept (the same numbering
the library view and Plex's scanner use).
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import stat
import time
import unicodedata
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Optional, Sequence, Tuple

from anibox_check.folders import VIDEO_EXTENSIONS, looks_like_season_dir, season_number

MARKER = "<!-- written by AniBox -->"
XML_DECLARATION = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
# Names protected whatever the caller passes. Empty since the user moved One Piece to the lock rule
# (2026-11-22): what was already there is locked by the app, new episodes are open.
ALWAYS_PROTECTED: Tuple[str, ...] = ()

TVSHOW_NFO = "tvshow.nfo"
POSTER_FILE = "poster.jpg"
# Any of these images in a show folder means it already has a poster (Plex, Kodi and Jellyfin names).
POSTER_NAMES = {"poster", "folder", "show", "cover", "default"}
IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".tbn", ".webp", ".gif"}
MAX_NFO_BYTES = 2 * 1024 * 1024  # AniBox's files are a few KB; anything bigger isn't ours
MAX_POSTER_BYTES = 20 * 1024 * 1024
TMP_SUFFIX = ".anibox-tmp"

# What plan() decides for each file.
NEW = "new"  # the file doesn't exist yet
UPDATE = "update"  # an unchanged AniBox file whose content would change
SAME = "same"  # already exactly what AniBox would write
SKIP_FOREIGN = "skip-foreign"  # the user's own file (no MARKER): never touched
SKIP_EDITED = "skip-edited"  # an AniBox file the user edited afterwards: never touched
SKIP_PROTECTED = "skip-protected"  # a show on the protected list: nothing is read or written
SKIP_UNMATCHED = "skip-unmatched"  # no MyAnimeList ID
SKIP_NO_NUMBER = "skip-no-number"  # the video's file name has no episode number
SKIP_ERROR = "skip-error"  # folder unreadable, video gone, odd layout ... (see "reason")
SKIP_LOCKED = "skip-locked"  # an episode/show that was already there: locked until the user unlocks the show
ACTIONS = (NEW, UPDATE, SAME, SKIP_FOREIGN, SKIP_EDITED, SKIP_PROTECTED, SKIP_LOCKED, SKIP_UNMATCHED, SKIP_NO_NUMBER,
           SKIP_ERROR)
WRITE_ACTIONS = (NEW, UPDATE)

# Kodi <mpaa> values for MAL's age ratings (official MAL API "rating" field).
MAL_RATINGS = {"g": "G", "pg": "PG", "pg_13": "PG-13", "r": "R", "r+": "R+", "rx": "Rx"}
STATUS = {"FINISHED": "Ended", "ONGOING": "Continuing"}

_CHECK_LINE = "<!-- AniBox checksum {}: once you edit this file, AniBox leaves it alone -->"
_CHECK_RE = re.compile(rb"^<!-- AniBox checksum ([0-9a-f]{16})[^\n]*-->\n", re.MULTILINE)
_BAD_XML_CHARS = re.compile("[^\t\n\r -퟿-�\U00010000-\U0010ffff]")
_UNKNOWN_LAYOUT = -1


class _Abort(Exception):
    """A file isn't in the state the plan expected; it is left alone."""


# -- small helpers ---------------------------------------------------------------------------------


def _is_int(value) -> bool:
    return isinstance(value, int) and not isinstance(value, bool)


def _text(value) -> str:
    """Text safe for XML 1.0: control characters removed, line breaks as \\n, trimmed."""
    if value is None:
        return ""
    s = str(value).replace("\r\n", "\n").replace("\r", "\n")
    return _BAD_XML_CHARS.sub("", s).strip()


def _split_parts(path: str) -> List[str]:
    return [p for p in re.split(r"[\\/]+", path or "") if p]


def _compact(text: str) -> str:
    """Lower case, letters and digits only ("One_Piece", "ONE PIECE", "one.piece" -> "onepiece")."""
    return re.sub(r"[\W_]+", "", unicodedata.normalize("NFKC", str(text or "")).casefold())


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S%z")


def _lookup(mapping, mal_id: str):
    if not mapping:
        return None
    found = mapping.get(mal_id)
    if found is None and mal_id.isdigit():
        found = mapping.get(int(mal_id))
    return found


def _first(value) -> Optional[str]:
    if isinstance(value, (list, tuple)):
        value = value[0] if value else None
    if value is None or isinstance(value, bool):
        return None
    s = str(value).strip()
    return s or None


def _year(value) -> Optional[int]:
    if _is_int(value):
        year = value
    else:
        m = re.match(r"\s*(\d{4})", str(value or ""))
        year = int(m.group(1)) if m else None
    return year if year and 1900 <= year <= 2100 else None


def _score(value) -> Optional[str]:
    try:
        v = float(value)
    except (TypeError, ValueError):
        return None
    if not 0 < v <= 10:
        return None
    return ("%.2f" % v).rstrip("0").rstrip(".")


def _names(values) -> List[str]:
    """Genre or studio names: plain strings or MAL API objects like {"id": 1, "name": "Action"}."""
    out: List[str] = []
    for v in values or ():
        name = _text(v.get("name") if isinstance(v, dict) else v)
        if name and name not in out:
            out.append(name)
    return out


def _mpaa(value) -> Optional[str]:
    """Kodi <mpaa> from MAL's rating: the API code ("pg_13") or AniBox's display text ("PG-13",
    "R - 17+", "G - All Ages")."""
    code = _text(value).split(" - ")[0].strip().lower().replace("-", "_")
    return MAL_RATINGS.get(code)


def _sort_title(title: str) -> str:
    """Titles that start with punctuation ('"Oshi no Ko"', '.hack//Sign') sort by their first word."""
    stripped = re.sub(r"^[\W_]+", "", title)
    if stripped == title:
        return title
    return re.sub(r"[\W_]+$", "", stripped) or title


def _read(path: str, limit: int) -> Optional[bytes]:
    """The file's bytes, or None if it is bigger than ``limit``."""
    with open(path, "rb") as fh:
        data = fh.read(limit + 1)
    return None if len(data) > limit else data


# -- the AniBox marker and checksum -------------------------------------------------------------------


def _checksum(data: bytes) -> str:
    return _sha256(data)[:16]


def _finish(body: str) -> str:
    """Declaration, MARKER, checksum line, then the XML. The checksum covers everything else."""
    head = f"{XML_DECLARATION}\n{MARKER}\n"
    tail = body.rstrip("\n") + "\n"
    check = _checksum((head + tail).encode("utf-8"))
    return f"{head}{_CHECK_LINE.format(check)}\n{tail}"


def anibox_state(data: bytes) -> str:
    """Who a file belongs to: "foreign" (no MARKER: the user's own file), "edited" (AniBox
    wrote it but it was changed since, or its checksum line is gone) or "ours" (unchanged)."""
    if MARKER.encode("utf-8") not in data:
        return "foreign"
    m = _CHECK_RE.search(data)
    if not m:
        return "edited"
    rest = data[: m.start()] + data[m.end():]
    return "ours" if _checksum(rest) == m.group(1).decode("ascii") else "edited"


# -- protection --------------------------------------------------------------------------------------


def protected_names(protected: Iterable[str] = ()) -> List[str]:
    """The protected names in effect: ``ALWAYS_PROTECTED`` plus ``protected`` (empty names dropped)."""
    if isinstance(protected, str):
        protected = [protected]
    out: List[str] = []
    for name in list(ALWAYS_PROTECTED) + list(protected or ()):
        name = str(name or "").strip()
        if _compact(name) and name not in out:
            out.append(name)
    return out


def _show_texts(show: dict) -> List[str]:
    texts = [show.get("library"), show.get("folder"), show.get("title")]
    texts += _split_parts(str(show.get("id") or ""))
    for ep in show.get("episodes") or ():
        for field in ("path", "file", "key"):
            texts += _split_parts(str(ep.get(field) or ""))
    return [str(t) for t in texts if t]


def _texts_protected(texts: Iterable[str], names: Sequence[str]) -> bool:
    keys = [_compact(n) for n in protected_names(names)]
    for text in texts:
        c = _compact(text)
        if c and any(k in c for k in keys):
            return True
    return False


def is_protected(show: dict, protected: Sequence[str] = ()) -> bool:
    """True if a protected name appears (ignoring case, spaces and punctuation) in the library
    name, the show folder, the MAL title, or any folder or file name of the show's episodes.

    Matching is deliberately loose (protecting "One Piece" also covers "One Piece Film Red" and
    "ONE_PIECE"): a false alarm only means nothing is
    written for that show.
    """
    return _texts_protected(_show_texts(show), protected)


# -- numbering ---------------------------------------------------------------------------------------


def _subfolder_season(ep: dict):
    """None for a file directly in the show folder, the season of a "Season NN" folder
    ("Specials" = 0), or _UNKNOWN_LAYOUT for anything else."""
    parts = _split_parts(str(ep.get("file") or ""))
    if len(parts) <= 1:
        return None
    if len(parts) > 2 or not looks_like_season_dir(parts[0]):
        return _UNKNOWN_LAYOUT
    return season_number(parts[0])


def _own_number(ep: dict) -> Optional[Tuple[int, int]]:
    number = ep.get("number")
    if not _is_int(number) or not 0 <= number <= 99999:
        return None
    season = ep.get("season")
    if _is_int(season) and 0 <= season <= 999:
        return season, number
    where = _subfolder_season(ep)
    if where == _UNKNOWN_LAYOUT:
        return None
    return (1 if where is None else where), number


def _single_episode_entry(show: dict) -> bool:
    eps = show.get("mal_episodes")
    return eps == 1 or (str(show.get("type") or "").upper() == "MOVIE" and eps in (None, 1))


def episode_numbering(show: dict) -> List[Optional[Tuple[int, int]]]:
    """(season, episode) for each of ``show["episodes"]`` (same order), or None if a file has
    no usable number.

    Two rules from the Library Check's episode counting: if three or more files all carry the
    same number, it's part of the title, not an episode number (all None); and a single file
    without a number in a one-episode MAL entry (a movie, a single OVA) is episode 1.
    """
    eps = list(show.get("episodes") or [])
    nums = [_own_number(ep) for ep in eps]
    found = {n for n in nums if n is not None}
    if len(found) == 1 and len(eps) >= 3:
        return [None] * len(eps)
    if len(eps) == 1 and nums[0] is None and _single_episode_entry(show):
        where = _subfolder_season(eps[0])
        if where != _UNKNOWN_LAYOUT:
            return [((1 if where is None else where), 1)]
    return nums


def _numbering_of(show: dict, ep: dict) -> Optional[Tuple[int, int]]:
    eps = show.get("episodes") or []
    nums = episode_numbering(show)
    for i, e in enumerate(eps):
        if e is ep:
            return nums[i]
    key = ep.get("key")
    if key:
        for i, e in enumerate(eps):
            if e.get("key") == key:
                return nums[i]
    return _own_number(ep)


# -- the XML -----------------------------------------------------------------------------------------


def _add(parent: ET.Element, tag: str, text: Optional[str] = None, attrs: Optional[Dict[str, str]] = None) -> ET.Element:
    el = ET.SubElement(parent, tag, attrs or {})
    if text is not None:
        el.text = text
    return el


def _xml(root: ET.Element) -> str:
    ET.indent(root, space="  ")
    return _finish(ET.tostring(root, encoding="unicode"))


def show_title(show: dict, info: Optional[dict] = None) -> str:
    """The MAL title (from the title data), else the show's title, else its folder name."""
    return _text((info or {}).get("title")) or _text(show.get("title")) or _text(show.get("folder"))


def external_ids(ids: Optional[dict], info: Optional[dict] = None, show: Optional[dict] = None) -> Dict[str, str]:
    """Other databases' IDs for ``<uniqueid>``, in a fixed order: anidb, anilist, tvdb, tmdb, imdb.

    Takes short keys (``tvdb``, ``tmdb``, ``anidb``, ``anilist``, ``imdb``) or Fribb's
    (``tvdb_id``, ``themoviedb_id``, ``anidb_id``, ``anilist_id``, ``imdb_id``). Only a TMDB
    *TV* ID is used: a plain ``tmdb`` value counts as one, and of Fribb's ``themoviedb_id``
    ({"tv": ..., "movie": ...}) only "tv" (a TMDB movie ID in a tvshow.nfo would be read as a TV
    ID). AniDB falls back to the title data's ``anidb``.
    """
    e = ids or {}
    out: Dict[str, str] = {}
    anidb = _first(e.get("anidb")) or _first(e.get("anidb_id")) or _first((info or {}).get("anidb")) \
        or _first((show or {}).get("anidb"))
    anilist = _first(e.get("anilist")) or _first(e.get("anilist_id"))
    tvdb = _first(e.get("tvdb")) or _first(e.get("tvdb_id"))
    tmdb = e.get("tmdb") if e.get("tmdb") is not None else e.get("tmdb_tv")
    if isinstance(tmdb, dict):
        tmdb = tmdb.get("tv")
    if tmdb is None and isinstance(e.get("themoviedb_id"), dict):
        tmdb = e["themoviedb_id"].get("tv")
    tmdb = _first(tmdb)
    imdb = _first(e.get("imdb")) or _first(e.get("imdb_id"))
    for kind, value in (("anidb", anidb), ("anilist", anilist), ("tvdb", tvdb), ("tmdb", tmdb)):
        if value and value.isdigit():
            out[kind] = value
    if imdb and re.fullmatch(r"tt\d+", imdb):
        out["imdb"] = imdb
    return out


def build_tvshow_nfo(show: dict, info: Optional[dict] = None, ids: Optional[dict] = None,
                     details: Optional[dict] = None) -> str:
    """The ``tvshow.nfo`` for one show (Kodi ``<tvshow>`` format), as text to save as UTF-8.

    ``info`` is the show's entry in the title data (``titles[mal_id]``), ``ids`` its external IDs
    (``ids[mal_id]``), ``details`` its official MAL API data (``details[mal_id]``, optional;
    the raw API shape or ``malapi.simplify()``'s: ``title_ja`` and display ratings work too).
    The MAL ``<uniqueid>`` comes first and is the default, so Plex builds the show's identity
    from it (MAL-shaped folders share TVDB/TMDB IDs between seasons). Raises ValueError if the
    show has no MAL ID.
    """
    mal = _text(show.get("mal_id"))
    if not mal.isdigit():
        raise ValueError(f"no MyAnimeList ID for {show.get('id')!r}")
    info = info or {}
    details = details or {}
    title = show_title(show, info)
    root = ET.Element("tvshow")
    _add(root, "title", title)
    alt = details.get("alternative_titles") if isinstance(details.get("alternative_titles"), dict) else {}
    original = _text(alt.get("ja") or details.get("title_ja"))  # raw MAL API, or malapi.simplify()
    if original and original != title:
        _add(root, "originaltitle", original)
    sort = _sort_title(title)
    if sort != title:
        _add(root, "sorttitle", sort)
    mean = _score(details.get("mean"))
    if mean is not None:
        rating = _add(_add(root, "ratings"), "rating", None, {"name": "mal", "max": "10", "default": "true"})
        _add(rating, "value", mean)
    plot = _text(details.get("synopsis"))
    if plot:
        _add(root, "plot", plot)
    picture = _text(info.get("picture") or show.get("picture"))
    if picture.startswith("https://"):
        _add(root, "thumb", picture, {"aspect": "poster"})
    mpaa = _mpaa(details.get("rating"))
    if mpaa:
        _add(root, "mpaa", mpaa)
    _add(root, "uniqueid", mal, {"type": "mal", "default": "true"})
    for kind, value in external_ids(ids, info, show).items():
        _add(root, "uniqueid", value, {"type": kind})
    for genre in _names(details.get("genres")):
        _add(root, "genre", genre)
    start = _text(details.get("start_date"))
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", start):
        _add(root, "premiered", start)
    year = _year(start) or _year(info.get("year")) or _year(show.get("year"))
    if year:
        _add(root, "year", str(year))
    status = STATUS.get(_text(info.get("status")).upper())
    if status:
        _add(root, "status", status)
    for studio in _names(details.get("studios")):
        _add(root, "studio", studio)
    return _xml(root)


def _episode_xml(show: dict, season: int, number: int, details: Optional[dict], online: Optional[dict] = None) -> str:
    """``online``: the episode's own title/plot/air date/picture if AniBox found them (episodes.py)."""
    details = details or {}
    online = online or {}
    title = show_title(show)
    plot = ""
    if len(show.get("episodes") or []) == 1 and _single_episode_entry(show) and (season, number) == (1, 1):
        name = title  # a movie or single OVA: its own title and description
        plot = _text(details.get("synopsis"))
    elif _text(online.get("title")):
        name = _text(online.get("title"))
        plot = _text(online.get("plot"))
    elif season == 0:
        name = f"Special {number}"
    else:
        name = f"Episode {number}"
    root = ET.Element("episodedetails")
    _add(root, "title", name)
    _add(root, "showtitle", title)
    _add(root, "season", str(season))
    _add(root, "episode", str(number))
    if plot:
        _add(root, "plot", plot)
    if re.match(r"^\d{4}-\d{2}-\d{2}$", _text(online.get("aired"))):
        _add(root, "aired", _text(online.get("aired")))
    if _text(online.get("image")).startswith("https://"):
        _add(root, "thumb", _text(online.get("image")))
    return _xml(root)


def build_episode_nfo(show: dict, ep: dict, details: Optional[dict] = None) -> str:
    """The ``<video name>.nfo`` for one episode (Kodi ``<episodedetails>``), as text.

    MAL has no episode titles, so the title is "Episode 5" (season 0: "Special 1"); a movie or
    other one-episode entry with a single file gets the MAL title and synopsis instead.
    ``showtitle`` is the show's title. Raises ValueError if the episode has no number.
    """
    numbering = _numbering_of(show, ep)
    if numbering is None:
        raise ValueError(f"no episode number in {ep.get('file')!r}")
    return _episode_xml(show, numbering[0], numbering[1], details, ep.get("online"))


# -- planning ----------------------------------------------------------------------------------------


class _Folders:
    """Read-only folder listings, each folder listed once per plan."""

    def __init__(self):
        self._cache: Dict[str, object] = {}

    def names(self, folder: str) -> List[str]:
        key = os.path.normcase(folder)
        if key not in self._cache:
            try:
                self._cache[key] = sorted(os.listdir(folder))
            except OSError as exc:
                self._cache[key] = exc
        found = self._cache[key]
        if isinstance(found, OSError):
            raise found
        return found  # type: ignore[return-value]

    def find(self, folder: str, name: str) -> Optional[str]:
        """The existing entry called ``name`` (exact, else in other letter case), or None."""
        names = self.names(folder)
        if name in names:
            return name
        folded = name.casefold()
        return next((n for n in names if n.casefold() == folded), None)


def _layout(show: dict):
    """Where the show's files are, from the paths alone (nothing is read from the drives).

    Returns (show folders, entries) with one entry per episode: (video path, nfo path, show
    folder, problem). Usually there's one show folder; the same library\\show on two drives
    gives two.
    """
    folder_name = str(show.get("folder") or "")
    folders: List[str] = []
    seen = set()
    entries = []
    for ep in show.get("episodes") or []:
        path = str(ep.get("path") or "")
        parts = _split_parts(str(ep.get("file") or ""))
        if not path or not parts:
            entries.append((path or None, None, None, "the episode has no file path"))
            continue
        stem, ext = os.path.splitext(os.path.basename(path))
        nfo = os.path.join(os.path.dirname(path), stem + ".nfo") if stem else None
        problem = None
        if not stem or ext.lower() not in VIDEO_EXTENSIONS:
            problem = "not a video file name"
        elif len(parts) > 2 or (len(parts) == 2 and not looks_like_season_dir(parts[0])):
            problem = "unexpected folder layout"
        top = path
        tail: List[str] = []
        for _ in parts:
            top, last = os.path.split(top)
            tail.insert(0, last)
        if problem is None and [t.casefold() for t in tail] != [p.casefold() for p in parts]:
            problem = "the file path doesn't fit the library"
        if problem is None and os.path.basename(top).casefold() != folder_name.casefold():
            problem = "the show folder's name doesn't fit the library"
        if problem is None:
            key = os.path.normcase(top)
            if key not in seen:
                seen.add(key)
                folders.append(top)
        entries.append((path, nfo, None if problem else top, problem))
    return folders, entries


def _item(path: str, action: str, kind: str, show_id: str, title: str, **extra) -> dict:
    item = {"path": path, "action": action, "show": show_id, "kind": kind, "title": title}
    item.update({k: v for k, v in extra.items() if v is not None})
    return item


def _target(fs: _Folders, folder: str, name: str, content: bytes, kind: str, meta: dict, **extra) -> dict:
    """Decide what happens to one .nfo file."""
    path = os.path.join(folder, name)
    try:
        actual = fs.find(folder, name)
    except OSError as exc:
        return _item(path, SKIP_ERROR, kind, reason=f"can't read the folder ({exc.strerror or exc})", **meta, **extra)
    if actual is None:
        return _item(path, NEW, kind, content=content, **meta, **extra)
    path = os.path.join(folder, actual)
    try:
        st = os.lstat(path)
        if stat.S_ISLNK(st.st_mode) or not stat.S_ISREG(st.st_mode):
            return _item(path, SKIP_FOREIGN, kind, reason="not a regular file", **meta, **extra)
        data = _read(path, MAX_NFO_BYTES)
    except OSError as exc:
        return _item(path, SKIP_ERROR, kind, reason=f"can't read the file ({exc.strerror or exc})", **meta, **extra)
    if data is None:
        return _item(path, SKIP_FOREIGN, kind, **meta, **extra)
    if data == content:
        return _item(path, SAME, kind, **meta, **extra)
    state = anibox_state(data)
    if state == "foreign":
        return _item(path, SKIP_FOREIGN, kind, **meta, **extra)
    if state == "edited":
        return _item(path, SKIP_EDITED, kind, **meta, **extra)
    return _item(path, UPDATE, kind, content=content, old_sha256=_sha256(data), **meta, **extra)


def _is_jpeg(data) -> bool:
    return isinstance(data, bytes) and data[:3] == b"\xff\xd8\xff" and len(data) <= MAX_POSTER_BYTES


def _poster_target(fs: _Folders, folder: str, mal: str, posters: Callable[[str], Optional[bytes]],
                   meta: dict) -> Optional[dict]:
    """poster.jpg only for show folders without any poster image. None = no poster to offer."""
    path = os.path.join(folder, POSTER_FILE)
    try:
        names = fs.names(folder)
    except OSError as exc:
        return _item(path, SKIP_ERROR, "poster", reason=f"can't read the folder ({exc.strerror or exc})", **meta)
    existing = [n for n in names
                if os.path.splitext(n)[0].casefold() in POSTER_NAMES and os.path.splitext(n)[1].lower() in IMAGE_EXTENSIONS]
    try:
        if existing:
            actual = fs.find(folder, POSTER_FILE)
            if actual:
                data = posters(mal)
                if _is_jpeg(data) and _read(os.path.join(folder, actual), MAX_POSTER_BYTES) == data:
                    return _item(os.path.join(folder, actual), SAME, "poster", **meta)
            return _item(os.path.join(folder, actual or existing[0]), SKIP_FOREIGN, "poster",
                         reason=f"the folder already has a poster ({existing[0]})", **meta)
        data = posters(mal)
    except Exception as exc:  # a failed download must not stop the plan
        return _item(path, SKIP_ERROR, "poster", reason=f"couldn't get the poster ({exc})", **meta)
    if not _is_jpeg(data):
        return None
    return _item(path, NEW, "poster", content=data, **meta)


def _plan_show(show: dict, titles, ids, details, names: List[str], fs: _Folders,
               posters: Optional[Callable[[str], Optional[bytes]]]) -> List[dict]:
    show_id = str(show.get("id") or "")
    folders, entries = _layout(show)
    if is_protected(show, names):
        meta = {"show_id": show_id, "title": show_title(show)}
        reason = "protected: AniBox writes nothing here"
        return [_item(os.path.join(f, TVSHOW_NFO), SKIP_PROTECTED, "tvshow", reason=reason, **meta) for f in folders] \
            or [_item(show_id, SKIP_PROTECTED, "tvshow", reason=reason, **meta)]
    mal = _text(show.get("mal_id"))
    if not mal.isdigit():
        meta = {"show_id": show_id, "title": show_title(show)}
        return [_item(os.path.join(f, TVSHOW_NFO), SKIP_UNMATCHED, "tvshow", **meta) for f in folders] \
            or [_item(show_id, SKIP_UNMATCHED, "tvshow", **meta)]

    info = _lookup(titles, mal) or {}
    det = _lookup(details, mal) or {}
    view = dict(show)
    view["title"] = show_title(show, info)
    view["type"] = info.get("type") or show.get("type")
    view["mal_episodes"] = info.get("episodes", show.get("mal_episodes"))
    meta = {"show_id": show_id, "title": view["title"]}

    episode_items: List[dict] = []
    has_videos = set()  # show folders where at least one video was found
    for (video, nfo_path, top, problem), number, ep in zip(entries, episode_numbering(view), view.get("episodes") or []):
        if problem:
            episode_items.append(_item(nfo_path or video or show_id, SKIP_ERROR, "episode", reason=problem,
                                       video=video, **meta))
            continue
        folder = os.path.dirname(video)
        try:
            found = fs.find(folder, os.path.basename(video))
        except OSError as exc:
            episode_items.append(_item(nfo_path, SKIP_ERROR, "episode", video=video,
                                       reason=f"can't read the folder ({exc.strerror or exc})", **meta))
            continue
        if found is None:
            episode_items.append(_item(nfo_path, SKIP_ERROR, "episode", video=video,
                                       reason="video not found (drive not connected, or scan again)", **meta))
            continue
        has_videos.add(os.path.normcase(top))
        if number is None:
            episode_items.append(_item(nfo_path, SKIP_NO_NUMBER, "episode", video=video, **meta))
            continue
        content = _episode_xml(view, number[0], number[1], det, ep.get("online")).encode("utf-8")
        episode_items.append(_target(fs, folder, os.path.basename(nfo_path), content, "episode", meta,
                                     video=video, season=number[0], episode=number[1]))

    show_items: List[dict] = []
    tvshow = build_tvshow_nfo(view, info, _lookup(ids, mal), det).encode("utf-8")
    for top in folders:
        if os.path.normcase(top) not in has_videos:
            show_items.append(_item(os.path.join(top, TVSHOW_NFO), SKIP_ERROR, "tvshow",
                                    reason="no videos found in this folder", **meta))
            continue
        show_items.append(_target(fs, top, TVSHOW_NFO, tvshow, "tvshow", meta))
        if posters is not None:
            poster = _poster_target(fs, top, mal, posters, meta)
            if poster is not None:
                show_items.append(poster)
    return show_items + episode_items


def _dedupe(items: List[dict]) -> List[dict]:
    """One item per file. Two videos that would share one .nfo with different content
    ("Show 01.mkv" and "Show 01.mp4" always agree) make it a problem instead."""
    by_path: Dict[str, dict] = {}
    order: List[str] = []
    for it in items:
        key = os.path.normcase(os.path.normpath(it["path"]))
        first = by_path.get(key)
        if first is None:
            by_path[key] = it
            order.append(key)
        elif first["action"] != it["action"] or first.get("content") != it.get("content"):
            by_path[key] = _item(first["path"], SKIP_ERROR, first["kind"], first["show"], first["title"],
                                 reason="two files would be written under this name")
    return [by_path[k] for k in order]


def plan(shows: Iterable[dict], titles: Dict[str, dict], ids: Dict[str, dict], details: Optional[Dict[str, dict]] = None,
         protected: Sequence[str] = (), posters: Optional[Callable[[str], Optional[bytes]]] = None,
         write_posters: bool = False) -> dict:
    """Work out which .nfo files (and posters) would be written. Only reads; changes nothing.

    For every show with a MAL ID: ``tvshow.nfo`` in each show folder (the folder holding the
    videos, or the parent of its ``Season NN`` folders), ``<video name>.nfo`` next to each
    numbered video and, with ``write_posters`` and a ``posters`` callable (MAL ID -> JPEG bytes
    or None), ``poster.jpg`` where the folder has no poster image. ``posters`` is only called for
    those folders. Protected shows aren't listed or read at all.

    Returns ``{"items": [...], "counts": {action: n}, "shows": n, "shows_checked": n,
    "protected": [...]}``. Each item has ``path``, ``action`` (see ``ACTIONS``), ``show`` (the
    show id), ``kind`` ("tvshow", "episode", "poster") and ``title``; skips may have a
    ``reason``; episodes have ``video`` (and ``season``/``episode`` when numbered); new/update
    items carry ``content`` (bytes) for ``write()``, updates also ``old_sha256``. ``shows``
    counts the shows with something to write. Strip ``content`` before sending items anywhere.
    """
    names = protected_names(protected)
    fs = _Folders()
    shows = list(shows)
    items: List[dict] = []
    for show in shows:
        items.extend(_plan_show(show, titles or {}, ids or {}, details or {}, names, fs,
                                posters if write_posters else None))
    items = _dedupe(items)
    counts = {a: 0 for a in ACTIONS}
    for it in items:
        counts[it["action"]] = counts.get(it["action"], 0) + 1
    changing = {it["show"] for it in items if it["action"] in WRITE_ACTIONS}
    return {"items": items, "counts": counts, "shows": len(changing), "shows_checked": len(shows),
            "protected": names}


# -- writing -----------------------------------------------------------------------------------------


def _atomic_write(path: str, data: bytes, check: Callable[[], None]) -> None:
    """Write via a temporary file next to ``path``; ``check()`` runs right before the replace."""
    folder, name = os.path.split(path)
    fd = tmp = None
    for _ in range(10):
        candidate = os.path.join(folder, f"{name}.{secrets.token_hex(4)}{TMP_SUFFIX}")
        try:
            fd = os.open(candidate, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_BINARY", 0), 0o666)
        except FileExistsError:
            continue
        tmp = candidate
        break
    if tmp is None or fd is None:
        raise OSError(f"couldn't create a temporary file in {folder}")
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
            fh.flush()
            try:
                os.fsync(fh.fileno())
            except OSError:
                pass  # some network drives don't support it
        check()
        os.replace(tmp, path)
        tmp = None
    finally:
        if tmp is not None:
            try:
                os.remove(tmp)
            except OSError:
                pass


def _check_item(it: dict, names: List[str]) -> None:
    """Everything that must still hold before AniBox writes this file (raises _Abort)."""
    path = str(it.get("path") or "")
    kind = it.get("kind")
    content = it.get("content")
    folder, name = os.path.split(path)
    if not isinstance(content, bytes) or not name:
        raise _Abort("nothing to write")
    if _texts_protected(_split_parts(path) + [str(it.get("show") or "")], names):
        raise _Abort("protected: AniBox writes nothing here")
    if kind in ("tvshow", "episode") and not content.startswith(f"{XML_DECLARATION}\n{MARKER}\n".encode("utf-8")):
        raise _Abort("the content has no AniBox marker")
    if kind == "tvshow":
        if name.casefold() != TVSHOW_NFO:
            raise _Abort("unexpected file name")
    elif kind == "episode":
        video = str(it.get("video") or "")
        v_folder, v_name = os.path.split(video)
        v_stem, v_ext = os.path.splitext(v_name)
        if (not name.casefold().endswith(".nfo") or os.path.normcase(v_folder) != os.path.normcase(folder)
                or v_stem.casefold() != os.path.splitext(name)[0].casefold() or v_ext.lower() not in VIDEO_EXTENSIONS):
            raise _Abort("the .nfo doesn't belong to a video")
        if not os.path.isfile(video):
            raise _Abort("the video is no longer there")
    elif kind == "poster":
        if name.casefold() != POSTER_FILE or it.get("action") != NEW or not _is_jpeg(content):
            raise _Abort("unexpected poster")
    else:
        raise _Abort("unknown kind of file")
    if not os.path.isdir(folder):
        raise _Abort("the folder is no longer there (AniBox never creates folders)")


def _write_item(it: dict, names: List[str]) -> dict:
    _check_item(it, names)
    path = it["path"]
    previous: List[str] = []

    def still_as_planned() -> None:
        if it["action"] == NEW:
            if os.path.lexists(path):
                raise _Abort("a file with this name appeared after the plan was made")
            return
        try:
            st = os.lstat(path)
            if stat.S_ISLNK(st.st_mode) or not stat.S_ISREG(st.st_mode):
                raise _Abort("no longer a regular file")
            data = _read(path, MAX_NFO_BYTES)
        except FileNotFoundError:
            raise _Abort("the file is gone")
        if data is None or _sha256(data) != it.get("old_sha256"):
            raise _Abort("the file changed after the plan was made")
        if MARKER.encode("utf-8") not in data:
            raise _Abort("the file no longer has AniBox's marker")
        try:
            previous[:] = [data.decode("utf-8")]
        except UnicodeDecodeError:
            raise _Abort("the old content can't be kept for undo")

    _atomic_write(path, it["content"], still_as_planned)
    return {"path": path, "kind": it["kind"], "show": it.get("show"), "action": it["action"],
            "sha256": _sha256(it["content"]), "previous": previous[0] if previous else None, "time": _now()}


def write(plan_result: dict, undo_file: Path, only_shows: Optional[Sequence[str]] = None) -> dict:
    """Write the "new" and "update" items of a plan (optionally only those of ``only_shows``,
    a list of show ids).

    Each file is checked again right before it is written: a new file must still not exist; a
    file to update must still be exactly what the plan saw (same checksum, MARKER inside); the
    folder must still exist (folders are never created) and an episode's video must still be
    there. Files are written through a temporary file in the same folder and ``os.replace``.
    One JSON line per written file goes to ``undo_file`` (path, kind, show, sha256 of what was
    written, previous content for updates, time). A problem with one file doesn't stop the
    others. Written items are marked ``done`` so the same plan isn't written twice.

    Returns ``{"written", "new", "updated", "aborted", "failed", "errors": [{"path", "show",
    "error", "aborted"}]}``; "aborted" = left alone because something changed since the plan.
    """
    undo_file = Path(undo_file)
    names = protected_names(plan_result.get("protected") or ())
    wanted = None if only_shows is None else {str(s) for s in only_shows}
    result = {"written": 0, "new": 0, "updated": 0, "aborted": 0, "failed": 0, "errors": []}
    todo = [it for it in plan_result.get("items") or []
            if it.get("action") in WRITE_ACTIONS and not it.get("done")
            and (wanted is None or it.get("show") in wanted)]
    if not todo:
        return result
    try:
        undo_file.parent.mkdir(parents=True, exist_ok=True)
        log = open(undo_file, "a", encoding="utf-8", newline="\n")
    except OSError as exc:
        result["failed"] = len(todo)
        result["errors"].append({"path": str(undo_file), "show": "", "aborted": False,
                                 "error": f"can't open the undo file, nothing was written ({exc})"})
        return result
    with log:
        for it in todo:
            try:
                record = _write_item(it, names)
            except _Abort as exc:
                result["aborted"] += 1
                result["errors"].append({"path": it.get("path"), "show": it.get("show"), "error": str(exc), "aborted": True})
                continue
            except OSError as exc:
                result["failed"] += 1
                result["errors"].append({"path": it.get("path"), "show": it.get("show"), "aborted": False,
                                         "error": exc.strerror or str(exc)})
                continue
            it["done"] = True
            result["written"] += 1
            result["new" if it["action"] == NEW else "updated"] += 1
            try:
                log.write(json.dumps(record, ensure_ascii=False) + "\n")
                log.flush()
                os.fsync(log.fileno())
            except OSError as exc:
                result["errors"].append({"path": it.get("path"), "show": it.get("show"), "aborted": False,
                                         "error": f"written, but the undo file couldn't be updated; stopped ({exc})"})
                break
    return result


# -- undo --------------------------------------------------------------------------------------------


def _undo_one(rec: dict) -> str:
    path = str(rec.get("path") or "")
    kind = rec.get("kind")
    name = os.path.basename(path)
    if kind in ("tvshow", "episode"):
        if not name.casefold().endswith(".nfo"):
            raise ValueError("not an .nfo file; left alone")
        limit = MAX_NFO_BYTES
    elif kind == "poster":
        if name.casefold() != POSTER_FILE or rec.get("previous") is not None:
            raise ValueError("unexpected poster entry; left alone")
        limit = MAX_POSTER_BYTES
    else:
        raise ValueError("unknown kind of file; left alone")
    if not os.path.lexists(path):
        return "missing"
    st = os.lstat(path)
    if stat.S_ISLNK(st.st_mode) or not stat.S_ISREG(st.st_mode):
        return "kept"
    data = _read(path, limit)
    if data is None or _sha256(data) != rec.get("sha256"):
        return "kept"
    previous = rec.get("previous")
    if previous is None:
        os.remove(path)
        return "removed"

    def unchanged() -> None:
        now = _read(path, limit)
        if now is None or _sha256(now) != rec.get("sha256"):
            raise _Abort("changed")

    try:
        _atomic_write(path, str(previous).encode("utf-8"), unchanged)
    except (_Abort, FileNotFoundError):
        return "kept"
    return "restored"


def undo(undo_file: Path) -> dict:
    """Undo the writes logged in ``undo_file`` since its last undo, newest first.

    A file is removed (or, for an update, its previous AniBox content put back) only if its
    checksum still equals what AniBox wrote; anything changed since is kept and listed in
    ``kept_paths``. Entries that don't point at an .nfo or poster.jpg are never acted on.
    A line ``{"undo": time, ...}`` is appended afterwards so the same entries aren't undone twice.

    Returns ``{"removed", "restored", "kept", "missing", "failed", "kept_paths", "errors"}``.
    """
    undo_file = Path(undo_file)
    result = {"removed": 0, "restored": 0, "kept": 0, "missing": 0, "failed": 0, "kept_paths": [], "errors": []}
    try:
        lines = undo_file.read_text(encoding="utf-8").splitlines()
    except FileNotFoundError:
        return result
    entries: List[dict] = []
    for line in lines:
        try:
            rec = json.loads(line)
        except ValueError:
            continue
        if not isinstance(rec, dict):
            continue
        if "undo" in rec:
            entries = []
        elif rec.get("path") and rec.get("sha256"):
            entries.append(rec)
    if not entries:
        return result
    for rec in reversed(entries):
        try:
            outcome = _undo_one(rec)
        except (OSError, ValueError) as exc:
            result["failed"] += 1
            result["errors"].append({"path": rec.get("path"), "error": getattr(exc, "strerror", None) or str(exc)})
            continue
        result[outcome] += 1
        if outcome == "kept":
            result["kept_paths"].append(rec.get("path"))
    summary = {"undo": _now(), **{k: result[k] for k in ("removed", "restored", "kept", "missing", "failed")}}
    try:
        with open(undo_file, "a", encoding="utf-8", newline="\n") as fh:
            fh.write(json.dumps(summary) + "\n")
    except OSError as exc:
        result["errors"].append({"path": str(undo_file), "error": f"couldn't note the undo ({exc})"})
    return result


# -- preview -----------------------------------------------------------------------------------------

_PREVIEW = {
    NEW: ("NEW", "new", ""),
    UPDATE: ("UPDATE", "to update", ""),
    SAME: ("SAME", "already up to date", ""),
    SKIP_FOREIGN: ("SKIP", "your own files (kept)", "your own file, not touched"),
    SKIP_EDITED: ("SKIP", "edited by you (kept)", "edited after AniBox wrote it, not touched"),
    SKIP_PROTECTED: ("SKIP", "protected", "protected: AniBox writes nothing here"),
    SKIP_LOCKED: ("SKIP", "locked (already there before)", "locked: was already there; unlock the show to include it"),
    SKIP_UNMATCHED: ("SKIP", "not matched to MyAnimeList", "no MyAnimeList match"),
    SKIP_NO_NUMBER: ("SKIP", "without episode number", "no episode number in the file name"),
    SKIP_ERROR: ("SKIP", "problems", "problem"),
}


def preview_text(plan_result: dict, limit: int = 200) -> str:
    """The plan as plain text for the user to review: a summary line, then one line per file
    ("NEW     <path>", "UPDATE  <path>", "SKIP    <path>  (reason)"), changes first."""
    items = list(plan_result.get("items") or [])
    counts = plan_result.get("counts") or {}
    summary = ", ".join(f"{counts[a]} {_PREVIEW[a][1]}" for a in ACTIONS if counts.get(a))
    lines = [f"AniBox .nfo files for {plan_result.get('shows', 0)} shows: {summary or 'nothing to do'}"]
    order = {a: i for i, a in enumerate(ACTIONS)}
    order[SAME] = len(ACTIONS)  # unchanged files last
    items.sort(key=lambda it: (order.get(it.get("action"), len(ACTIONS) + 1), str(it.get("path"))))
    for it in items[: max(0, limit)]:
        label, _, default_reason = _PREVIEW.get(it.get("action"), ("?", "", ""))
        reason = it.get("reason") or default_reason
        lines.append(f"{label:<7} {it.get('path')}" + (f"  ({reason})" if reason else ""))
    if len(items) > limit:
        lines.append(f"... and {len(items) - max(0, limit)} more")
    return "\n".join(lines) + "\n"
