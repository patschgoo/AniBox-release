"""Which archive.org file to play, and what a file name says about it (series, air date, S01E01).

Both rules come from Frostbox (Martin's archive.org player, used with permission):

- **File names** (Frostbox's ``FileNameParser``): the air date ("WWE.Monday.Night.Raw.2008.01.07…"),
  season and episode ("Chicago.Fire.S01E05…") and the series name, the part of the file name before
  the date or the S01E01 ("WWE Monday Night Raw"). Without either, the name without its number at
  the end ("Sweep 3" → "Sweep", but "Folge 12" stays "Folge 12").
- **The better copy** (Frostbox's ``CollectionScanner.PickVideos`` and decision E73): an item often
  holds the original (an ``.avi`` or ``.mkv``) plus archive.org's own MP4 copy of it (``.ia.mp4`` or
  ``.mp4``, ``source: derivative``). The copy starts and jumps quickly (its index is at the start of
  the file), so it is preferred, **unless archive.org says the original has more lines** (e.g. a
  1080p MKV and a 480p copy). Without a resolution the copy stays. One file per episode.

Works on the file dicts of ``iarchive.file_json`` (and the shorter ones ``stream.IaStreams`` keeps):
``name``, ``source``, ``format``, ``size``, ``original``, ``width``, ``height``.
"""

from __future__ import annotations

import datetime
import os
import re
from typing import Dict, List, Optional, Tuple

from .iarchive import VIDEO_EXT

_DATE_RE = re.compile(r"(?<!\d)(19\d{2}|20\d{2})[.\-_ ](0[1-9]|1[0-2])[.\-_ ](0[1-9]|[12]\d|3[01])(?!\d)", re.ASCII)
_SXE_RE = re.compile(r"[Ss](\d{1,2})[Ee](\d{1,3})", re.ASCII)
# "Folge 12", "Part.3", "E12" at the end; \b so that "Game 3" doesn't become "Gam"
_TRAILING_NR_RE = re.compile(r"[\s._-]*(?:\b(?:ep(?:isode)?|e|folge|teil|part|pt))?[\s._-]*\d+$", re.I)
# an episode number right before the date, e.g. "SmackDown - E12 - 2011-03-25" (only with a word for it)
_EP_BEFORE_DATE_RE = re.compile(r"[\s._-]*\b(?:ep(?:isode)?|e|folge|teil|part|pt)[\s._-]*\d{1,4}[\s._-]*$", re.I)
IA_MP4 = ".ia.mp4"


def base_name(name: str) -> str:
    return str(name or "").replace("\\", "/").rsplit("/", 1)[-1]


def air_date(name: str) -> Optional[str]:
    """The date in a file name as ``yyyy-mm-dd`` (``Raw.2008.01.07``, ``2011-01-07``), else None."""
    m = _DATE_RE.search(base_name(name))
    if not m:
        return None
    try:
        return datetime.date(int(m.group(1)), int(m.group(2)), int(m.group(3))).isoformat()
    except ValueError:  # 2008-02-30
        return None


def season_episode(name: str) -> Optional[Tuple[int, int]]:
    """(season, episode) from "S01E05" in a file name, else None."""
    m = _SXE_RE.search(base_name(name))
    return (int(m.group(1)), int(m.group(2))) if m else None


def series_name(name: str) -> str:
    """The series a file belongs to: the part of the name before the date or S01E01, dots as spaces."""
    name = base_name(name)
    cut = len(name)
    d = _DATE_RE.search(name)
    if d:
        cut = min(cut, d.start())
    e = _SXE_RE.search(name)
    if e:
        cut = min(cut, e.start())
    if cut == len(name):
        # neither: the name without its extension and without a number at the end ("Folge 12", "Part.3")
        stem = name[: -len(IA_MP4)] if name.lower().endswith(IA_MP4) else os.path.splitext(name)[0]
        no_nr = _TRAILING_NR_RE.sub("", stem)
        name = no_nr if no_nr else stem
        cut = len(name)
    head = name[:cut]
    if d and cut == d.start():
        no_ep = _EP_BEFORE_DATE_RE.sub("", head)
        if no_ep.strip(" -._"):
            head = no_ep
    return head.replace(".", " ").replace("_", " ").strip(" -")


def stem(name: str) -> str:
    """A file name without its extension (and without ".ia.mp4"): the same for an original and its copy."""
    name = str(name or "")
    if name.lower().endswith(IA_MP4):
        return name[: -len(IA_MP4)]
    ext = os.path.splitext(name)[1]
    return name[: -len(ext)] if ext else name


def episode_key(name: str) -> str:
    return stem(name).casefold()


def natural_key(text: str):
    """Natural order: "Folge 2" before "Folge 10", upper/lower case alike."""
    parts = re.split(r"(\d+)", str(text or ""))
    return [int(p) if i % 2 else p.upper() for i, p in enumerate(parts)]


# -- the better copy ------------------------------------------------------------------------------------

def is_video(f: dict) -> bool:
    name = str(f.get("name") or "")
    return os.path.splitext(name)[1].lower() in VIDEO_EXT and ".thumbs/" not in name.lower()


def is_copy(f: dict) -> bool:
    """archive.org's own copy (a "derivative"), not a file someone uploaded."""
    return (f.get("source") or "original").lower() == "derivative" or str(f.get("name") or "").lower().endswith(IA_MP4)


def _is_mp4(name: str) -> bool:
    return os.path.splitext(name)[1].lower() in (".mp4", ".m4v")


def _format_rank(name: str) -> int:
    return {".mp4": 0, ".m4v": 0, ".mkv": 1, ".webm": 1, ".mov": 2}.get(os.path.splitext(name)[1].lower(), 3)


def _num(v) -> int:
    try:
        return max(0, int(v or 0))
    except (TypeError, ValueError):
        return 0


def _pixels(f: dict) -> int:
    return _num(f.get("width")) * _num(f.get("height"))


def _best(files: List[dict]) -> dict:
    """The same episode in several formats: the sharpest, then MP4 before MKV before the rest, then the biggest."""
    return min(files, key=lambda f: (-_pixels(f), _format_rank(f["name"]), -_num(f.get("size"))))


def original_is_sharper(original: dict, copy: dict) -> bool:
    """Only when archive.org gives both heights and the original's is higher (Frostbox E73)."""
    ho, hc = _num(original.get("height")), _num(copy.get("height"))
    return bool(ho and hc and ho > hc)


def pick_videos(files: List[dict]) -> List[Tuple[str, dict]]:
    """One file per episode, in the item's order: ``[(episode key, file)]``.

    The episode key is the original's name without extension (case ignored), so an episode keeps its
    key when AniBox later switches between the original and the copy."""
    videos = [f for f in files if isinstance(f, dict) and f.get("name") and is_video(f)]
    originals = [f for f in videos if not is_copy(f)]
    # archive.org's .ia.mp4 of an original: through "original", else the same name
    ia_copies: Dict[str, dict] = {}
    for f in videos:
        if f["name"].lower().endswith(IA_MP4):
            ia_copies[episode_key(f.get("original") or f["name"])] = f
    # an MP4 copy (h.264) of an original that isn't an MP4: same name, or linked through "original"
    mp4_copies: Dict[str, dict] = {}
    others = [f for f in videos if is_copy(f) and _is_mp4(f["name"]) and not f["name"].lower().endswith(IA_MP4)]
    for f in others:
        mp4_copies.setdefault(episode_key(f["name"]), f)
    for f in others:
        if f.get("original") and "h.264" in str(f.get("format") or "").lower():
            mp4_copies.setdefault(episode_key(f["original"]), f)
    out: List[Tuple[str, dict]] = []
    used = set()
    groups: Dict[str, List[dict]] = {}
    for f in originals:
        groups.setdefault(episode_key(f["name"]), []).append(f)
    for key, group in groups.items():
        o = _best(group)
        copy = ia_copies.get(key) or (mp4_copies.get(key) if not _is_mp4(o["name"]) else None)
        pick = copy if copy is not None and not original_is_sharper(o, copy) else o
        if pick["name"] not in used:
            used.add(pick["name"])
            out.append((key, pick))
    # an .ia.mp4 whose original isn't a video AniBox knows: take it anyway (unless that episode is in)
    have = {k for k, _ in out}
    for key, f in ia_copies.items():
        if key not in have and f["name"] not in used:
            used.add(f["name"])
            have.add(key)
            out.append((key, f))
    # episodes that only exist as copies (their original isn't a video AniBox plays): the best copy of each
    rest: Dict[str, List[dict]] = {}
    for f in videos:
        if episode_of(f) not in have:
            rest.setdefault(episode_of(f), []).append(f)
    out += [(key, _best(group)) for key, group in rest.items()]
    order = {f["name"]: i for i, f in enumerate(videos)}
    first: Dict[str, int] = {}
    for f in videos:
        first.setdefault(episode_of(f), order[f["name"]])
    out.sort(key=lambda kv: first.get(kv[0], order.get(kv[1]["name"], 0)))
    return out


def episode_of(f: dict) -> str:
    """The episode a file belongs to: a copy's original (archive.org names it), else the file itself."""
    return episode_key(f.get("original") or f["name"]) if is_copy(f) else episode_key(f["name"])
