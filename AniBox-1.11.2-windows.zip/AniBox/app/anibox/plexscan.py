"""Ask Plex to look at a new folder ("Scan Library Files" for one folder), after Add new videos.

This is the one thing AniBox asks Plex to *do*. It's only ever sent:
- when the user picked a Plex library for it (Add new videos → "Then ask Plex to scan"),
- to that library only, and only if it uses a modern agent (never one of the old libraries on the
  dead MyAnimeList agent, where a scan could mark files as unavailable),
- for the folders AniBox just added files to (the whole library only if the folder can't be found
  in Plex's paths).
It doesn't change any match, metadata or watch state; Plex adds what's new, as if the user had
clicked "Scan Library Files".

Plex sees the drives under its own paths (``/storage/ABCD-1234/NVIDIA_SHIELD/Anime``) while AniBox
sees them as network shares (``\\\\SHIELD\\External USB drive-ABCD1234\\NVIDIA_SHIELD\\Anime``):
``plex_path`` maps one to the other by the library folder names and the drive id.
"""

from __future__ import annotations

import json
import re
import urllib.parse
import urllib.request
from typing import List, Optional, Tuple

from . import __version__
from .plexdetails import is_legacy_agent

def _parts(path: str) -> List[str]:
    return [p for p in re.split(r"[\\/]+", path or "") if p]


def _get(base: str, token: str, client_id: str, path: str, params: Optional[dict] = None, timeout: float = 20.0) -> bytes:
    url = base.rstrip("/") + path + ("?" + urllib.parse.urlencode(params) if params else "")
    req = urllib.request.Request(url, headers={"X-Plex-Token": token, "Accept": "application/json",
                                               "X-Plex-Product": "AniBox", "X-Plex-Version": __version__,
                                               "X-Plex-Client-Identifier": client_id or "anibox"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def sections(creds: Tuple[str, str, str]) -> List[dict]:
    """The server's TV and movie libraries: key, title, type, agent, legacy, locations (Plex paths)."""
    data = json.loads(_get(*creds, "/library/sections").decode("utf-8") or "{}")
    out = []
    for d in (data.get("MediaContainer") or {}).get("Directory") or []:
        if d.get("type") not in ("show", "movie"):
            continue
        agent = str(d.get("agent") or "")
        out.append({"key": str(d.get("key")), "title": str(d.get("title") or ""), "type": d.get("type"),
                    "agent": agent, "legacy": is_legacy_agent(agent),
                    "locations": [str(loc.get("path")) for loc in d.get("Location") or [] if loc.get("path")]})
    return out


def _drive_id(parts: List[str]) -> str:
    """The drive's id: Plex's "/storage/ABCD-1234" or the share "External USB drive-ABCD1234"."""
    for p in parts:
        m = re.fullmatch(r"([0-9A-Fa-f]{4})-?([0-9A-Fa-f]{4})", p) or re.search(r"drive-([0-9A-Fa-f]{4})-?([0-9A-Fa-f]{4})$", p, re.I)
        if m:
            return (m.group(1) + m.group(2)).upper()
    return ""


def plex_path(local_folder: str, locations: List[str]) -> Optional[str]:
    """Plex's path for a folder AniBox knows by its share path, or None if it isn't in these locations."""
    local = _parts(local_folder)
    low = [p.casefold() for p in local]
    hits = []
    for loc in locations:
        lp = _parts(loc)
        anchor = [p.casefold() for p in lp[-2:]]  # e.g. NVIDIA_SHIELD/Anime
        for i in range(len(low) - len(anchor) + 1):
            if low[i:i + len(anchor)] == anchor:
                rest = local[i + len(anchor):]
                hits.append((loc, lp, rest, local[:i]))
                break
    if len(hits) > 1:  # the same library folder name on two drives: compare the drive ids
        same = [h for h in hits if _drive_id(h[1]) and _drive_id(h[1]) == _drive_id(h[3])]
        hits = same if len(same) == 1 else []
    if len(hits) != 1:
        return None
    loc, _, rest, _ = hits[0]
    return loc.rstrip("/\\") + ("/" + "/".join(rest) if rest else "")


def request_scan(creds: Tuple[str, str, str], section_key: str, path: Optional[str] = None) -> None:
    """Like "Scan Library Files" in Plex, for one folder if ``path`` is given."""
    _get(*creds, f"/library/sections/{urllib.parse.quote(str(section_key))}/refresh", {"path": path} if path else None)
