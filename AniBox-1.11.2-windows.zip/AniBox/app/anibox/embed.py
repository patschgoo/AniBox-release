"""Show mpv's picture inside the AniBox window (Windows).

The AniBox window is an Edge/Chrome "app" window showing a web page, and a web page can't play most
anime files itself (MKV with styled ASS subtitles, AC3/DTS sound ...). So mpv keeps playing, and
AniBox gives it a place in the window: a small window of AniBox's own (a child window) sits inside
the AniBox window exactly where the page's player area is, and mpv draws into it (mpv's ``--wid``).
The page reports where its player area is whenever that changes (big, mini, fill, full screen),
and AniBox moves the child window there.

How the AniBox window is found: the page briefly sets its title to a random marker and AniBox looks
for the window with exactly that title. Browser tabs add " - Microsoft Edge" to the title, so only
AniBox's own app window matches.

If anything doesn't work (another system, the window isn't found, a Windows call fails), ``wid()``
returns None and mpv opens its own window as before.
"""

from __future__ import annotations

import logging
import os
import queue
import threading
import time
from typing import Callable, List, Optional, Tuple

log = logging.getLogger("anibox")

IS_WINDOWS = os.name == "nt"
RENDER_WIDGET = "Chrome_RenderWidgetHostHWND"  # the window that holds the web page in Edge/Chrome


def physical_rect(origin: Tuple[int, int], x: float, y: float, w: float, h: float, dpr: float) -> Tuple[int, int, int, int]:
    """Page coordinates (CSS pixels) -> pixels inside the AniBox window."""
    dpr = dpr if dpr and dpr > 0 else 1.0
    left, top = origin[0] + round(x * dpr), origin[1] + round(y * dpr)
    return left, top, max(1, round(w * dpr)), max(1, round(h * dpr))


def fallback_origin(client_w: int, client_h: int, inner_w: float, inner_h: float, dpr: float) -> Tuple[int, int]:
    """Where the page starts inside the window when the page's own window can't be found: below a
    title bar that is drawn inside the window (if the window is taller than the page)."""
    dpr = dpr if dpr and dpr > 0 else 1.0
    return max(0, client_w - round(inner_w * dpr)) // 2, max(0, client_h - round(inner_h * dpr))


class Embedder:
    """The child window mpv draws into. All Windows calls run on one thread of its own."""

    def __init__(self):
        self.available = IS_WINDOWS
        self.reason = "" if IS_WINDOWS else "Playing inside the window works on Windows only."
        self.top = None  # the AniBox window
        self.hwnd = None  # AniBox's child window in it; mpv draws into this one
        self.on_gone: Optional[Callable[[], None]] = None  # the AniBox window was closed
        self.visible = False
        self._w = None  # Win32 helpers, made on the thread
        self._thread: Optional[threading.Thread] = None
        self._tid = 0
        self._jobs: "queue.Queue" = queue.Queue()
        self._ready = threading.Event()
        self._logged = False

    @property
    def attached(self) -> bool:
        return bool(self.hwnd)

    def wid(self) -> Optional[int]:
        return int(self.hwnd) if self.hwnd else None

    # -- public calls (any thread) -----------------------------------------------------------------

    def attach(self, marker: str, seconds: float = 3.0) -> dict:
        """Find the window titled ``marker`` and put the child window into it."""
        if not self.available:
            return {"ok": False, "reason": self.reason}
        if not marker or len(marker) < 8:
            return {"ok": False, "reason": "bad marker"}
        try:
            return self._call(lambda: self._attach(marker, seconds), timeout=seconds + 5)
        except Exception as exc:
            log.exception("Couldn't put the player into the AniBox window")
            self.reason = f"Couldn't put the player into the AniBox window ({exc})."
            return {"ok": False, "reason": self.reason}

    def place(self, x: float, y: float, w: float, h: float, dpr: float, inner_w: float, inner_h: float,
              visible: bool) -> None:
        if not self.hwnd:
            return
        try:
            self._call(lambda: self._place(x, y, w, h, dpr, inner_w, inner_h, visible))
        except Exception:
            log.exception("Couldn't move the player")

    # -- the thread ------------------------------------------------------------------------------

    def _call(self, fn, timeout: float = 5.0):
        self._start()
        done = threading.Event()
        box: List = [None, None]

        def job():
            try:
                box[0] = fn()
            except Exception as exc:  # handed back to the caller
                box[1] = exc
            finally:
                done.set()
        self._jobs.put(job)
        self._w.post_job(self._tid)
        if not done.wait(timeout):
            raise TimeoutError("the window thread didn't answer")
        if box[1] is not None:
            raise box[1]
        return box[0]

    def _start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._ready.clear()
        self._thread = threading.Thread(target=self._run, daemon=True, name="anibox-embed")
        self._thread.start()
        if not self._ready.wait(5):
            raise RuntimeError("the window thread didn't start")

    def _run(self) -> None:
        w = self._w = _Win32(self._destroyed)
        self._tid = w.thread_id()
        self._ready.set()
        w.loop(self._run_jobs)

    def _run_jobs(self) -> None:
        while True:
            try:
                job = self._jobs.get_nowait()
            except queue.Empty:
                return
            job()

    def _destroyed(self, hwnd) -> None:
        if hwnd and hwnd == self.hwnd:
            log.info("The AniBox window was closed; the player's place in it is gone")
            self.hwnd = self.top = None
            self.visible = False
            if self.on_gone:
                threading.Thread(target=self.on_gone, daemon=True).start()

    # -- on the thread ---------------------------------------------------------------------------

    def _attach(self, marker: str, seconds: float) -> dict:
        w = self._w
        end = time.time() + seconds
        top, near = None, []
        while time.time() < end:  # the browser takes a moment to pass the new title on
            top, near = w.find_window(marker)
            if top:
                break
            time.sleep(0.15)
        if not top:
            self.reason = "The AniBox window wasn't found, so videos open in their own window."
            log.info("Player stays in its own window: no window titled %r%s", marker,
                     f" (similar: {near[:3]})" if near else "")
            return {"ok": False, "reason": self.reason}
        if self.hwnd and self.top == top and w.is_window(self.hwnd):
            return {"ok": True, "reason": "", "again": True}
        if self.hwnd and w.is_window(self.hwnd):
            w.destroy(self.hwnd)
        self.hwnd = w.create_child(top)
        self.top = top
        self._logged = False
        self.visible = False
        self.reason = ""
        log.info("Player goes inside the AniBox window (window %s, place %s)", top, self.hwnd)
        return {"ok": True, "reason": ""}

    def _place(self, x, y, w_, h, dpr, inner_w, inner_h, visible) -> None:
        w = self._w
        if not self.hwnd or not w.is_window(self.hwnd):
            self.hwnd = None
            return
        if not visible:
            if self.visible:
                w.show(self.hwnd, False)
            self.visible = False
            return
        origin = w.content_origin(self.top)
        if origin is None:
            cw, ch = w.client_size(self.top)
            origin = fallback_origin(cw, ch, inner_w, inner_h, dpr)
        left, top, width, height = physical_rect(origin, x, y, w_, h, dpr)
        w.move_on_top(self.hwnd, left, top, width, height)
        if not self._logged:  # once per window: helps when the picture isn't where it should be
            self._logged = True
            log.info("Video area: page starts at %s in the window, video at %s,%s %sx%s (scale %s, page %sx%s)",
                     origin, left, top, width, height, dpr, inner_w, inner_h)
        self.visible = True


class _Win32:
    """The few Windows calls the embedding needs (ctypes, 32 and 64 bit)."""

    WM_DESTROY, WM_SIZE, WM_APP_JOB, WM_USER = 0x0002, 0x0005, 0x8000 + 7, 0x0400
    GW_CHILD, GW_HWNDNEXT, SWP_NOZORDER, SWP_ASYNCWINDOWPOS = 5, 2, 0x0004, 0x4000
    WS_CHILD, WS_CLIPSIBLINGS, WS_CLIPCHILDREN = 0x40000000, 0x04000000, 0x02000000
    SWP_NOACTIVATE, SWP_SHOWWINDOW = 0x0010, 0x0040
    CLASS = "AniBoxVideo"

    def __init__(self, on_destroy):
        import ctypes
        from ctypes import wintypes as wt
        self.ct, self.wt = ctypes, wt
        u = self.user32 = ctypes.WinDLL("user32", use_last_error=True)
        k = self.kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        g = ctypes.WinDLL("gdi32")
        LRESULT = ctypes.c_ssize_t
        self.WNDPROC = ctypes.WINFUNCTYPE(LRESULT, wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM)
        self.ENUMPROC = ctypes.WINFUNCTYPE(wt.BOOL, wt.HWND, wt.LPARAM)

        class WNDCLASSEXW(ctypes.Structure):
            _fields_ = [("cbSize", wt.UINT), ("style", wt.UINT), ("lpfnWndProc", self.WNDPROC),
                        ("cbClsExtra", ctypes.c_int), ("cbWndExtra", ctypes.c_int), ("hInstance", wt.HINSTANCE),
                        ("hIcon", wt.HICON), ("hCursor", wt.HANDLE), ("hbrBackground", wt.HBRUSH),
                        ("lpszMenuName", wt.LPCWSTR), ("lpszClassName", wt.LPCWSTR), ("hIconSm", wt.HICON)]
        self.WNDCLASSEXW = WNDCLASSEXW
        u.DefWindowProcW.argtypes = [wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM]
        u.DefWindowProcW.restype = LRESULT
        u.RegisterClassExW.argtypes = [ctypes.POINTER(WNDCLASSEXW)]
        u.RegisterClassExW.restype = wt.ATOM
        u.CreateWindowExW.argtypes = [wt.DWORD, wt.LPCWSTR, wt.LPCWSTR, wt.DWORD, ctypes.c_int, ctypes.c_int,
                                      ctypes.c_int, ctypes.c_int, wt.HWND, wt.HMENU, wt.HINSTANCE, wt.LPVOID]
        u.CreateWindowExW.restype = wt.HWND
        u.DestroyWindow.argtypes = [wt.HWND]
        u.GetMessageW.argtypes = [ctypes.POINTER(wt.MSG), wt.HWND, wt.UINT, wt.UINT]
        u.GetMessageW.restype = wt.BOOL
        u.PeekMessageW.argtypes = [ctypes.POINTER(wt.MSG), wt.HWND, wt.UINT, wt.UINT, wt.UINT]
        u.TranslateMessage.argtypes = [ctypes.POINTER(wt.MSG)]
        u.DispatchMessageW.argtypes = [ctypes.POINTER(wt.MSG)]
        u.DispatchMessageW.restype = LRESULT
        u.PostThreadMessageW.argtypes = [wt.DWORD, wt.UINT, wt.WPARAM, wt.LPARAM]
        u.EnumWindows.argtypes = [self.ENUMPROC, wt.LPARAM]
        u.EnumChildWindows.argtypes = [wt.HWND, self.ENUMPROC, wt.LPARAM]
        u.GetWindowTextLengthW.argtypes = [wt.HWND]
        u.GetWindowTextW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
        u.GetClassNameW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
        u.IsWindowVisible.argtypes = [wt.HWND]
        u.IsWindow.argtypes = [wt.HWND]
        u.GetWindowRect.argtypes = [wt.HWND, ctypes.POINTER(wt.RECT)]
        u.GetClientRect.argtypes = [wt.HWND, ctypes.POINTER(wt.RECT)]
        u.ScreenToClient.argtypes = [wt.HWND, ctypes.POINTER(wt.POINT)]
        u.SetWindowPos.argtypes = [wt.HWND, wt.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wt.UINT]
        u.ShowWindow.argtypes = [wt.HWND, ctypes.c_int]
        u.GetWindow.argtypes = [wt.HWND, wt.UINT]
        u.GetWindow.restype = wt.HWND
        k.GetModuleHandleW.argtypes = [wt.LPCWSTR]
        k.GetModuleHandleW.restype = wt.HMODULE
        g.GetStockObject.argtypes = [ctypes.c_int]
        g.GetStockObject.restype = wt.HGDIOBJ
        try:  # pixels as the screen has them, the same as Edge (per-monitor DPI aware)
            u.SetThreadDpiAwarenessContext.argtypes = [wt.HANDLE]
            u.SetThreadDpiAwarenessContext.restype = wt.HANDLE
            u.SetThreadDpiAwarenessContext(wt.HANDLE(-4))
        except (AttributeError, OSError):
            pass

        def wndproc(hwnd, msg, wparam, lparam):
            if msg == self.WM_DESTROY:
                on_destroy(hwnd)
            elif msg == self.WM_SIZE:  # keep mpv's window (our child) as big as ours
                width, height = lparam & 0xFFFF, (lparam >> 16) & 0xFFFF
                child = u.GetWindow(hwnd, self.GW_CHILD)
                while child:
                    u.SetWindowPos(child, None, 0, 0, width, height,
                                   self.SWP_NOZORDER | self.SWP_NOACTIVATE | self.SWP_ASYNCWINDOWPOS)
                    child = u.GetWindow(child, self.GW_HWNDNEXT)
            return u.DefWindowProcW(hwnd, msg, wparam, lparam)
        self._wndproc = self.WNDPROC(wndproc)  # keep a reference, or Windows calls freed memory
        self.hinst = k.GetModuleHandleW(None)
        wc = WNDCLASSEXW()
        wc.cbSize = ctypes.sizeof(WNDCLASSEXW)
        wc.lpfnWndProc = self._wndproc
        wc.hInstance = self.hinst
        wc.hbrBackground = g.GetStockObject(4)  # BLACK_BRUSH
        wc.lpszClassName = self.CLASS
        u.RegisterClassExW(ctypes.byref(wc))
        msg = wt.MSG()
        u.PeekMessageW(ctypes.byref(msg), None, self.WM_USER, self.WM_USER, 0)  # this thread gets a queue

    def thread_id(self) -> int:
        return self.kernel32.GetCurrentThreadId()

    def post_job(self, tid: int) -> None:
        self.user32.PostThreadMessageW(tid, self.WM_APP_JOB, 0, 0)

    def loop(self, run_jobs) -> None:
        msg = self.wt.MSG()
        u = self.user32
        while u.GetMessageW(self.ct.byref(msg), None, 0, 0) > 0:
            if msg.message == self.WM_APP_JOB and not msg.hWnd:
                run_jobs()
                continue
            u.TranslateMessage(self.ct.byref(msg))
            u.DispatchMessageW(self.ct.byref(msg))

    def _text(self, hwnd, fn) -> str:
        buf = self.ct.create_unicode_buffer(512)
        fn(hwnd, buf, 512)
        return buf.value

    def find_window(self, marker: str):
        found, near = [], []

        def cb(hwnd, _):
            if self.user32.IsWindowVisible(hwnd) and self.user32.GetWindowTextLengthW(hwnd) > 0:
                title = self._text(hwnd, self.user32.GetWindowTextW)
                if title == marker:
                    found.append(hwnd)
                elif marker in title:
                    near.append(title)
            return True
        self.user32.EnumWindows(self.ENUMPROC(cb), 0)
        return (found[0] if found else None), near

    def is_window(self, hwnd) -> bool:
        return bool(hwnd) and bool(self.user32.IsWindow(hwnd))

    def create_child(self, parent):
        hwnd = self.user32.CreateWindowExW(0, self.CLASS, "AniBox video",
                                           self.WS_CHILD | self.WS_CLIPSIBLINGS | self.WS_CLIPCHILDREN,
                                           0, 0, 640, 360, parent, None, self.hinst, None)
        if not hwnd:
            raise OSError(f"CreateWindowEx failed ({self.ct.get_last_error()})")
        return hwnd

    def destroy(self, hwnd) -> None:
        self.user32.DestroyWindow(hwnd)

    def content_origin(self, top) -> Optional[Tuple[int, int]]:
        """Where the web page starts inside the AniBox window (below a title bar Edge draws itself)."""
        best = []

        def cb(hwnd, _):
            if self.user32.IsWindowVisible(hwnd) and self._text(hwnd, self.user32.GetClassNameW) == RENDER_WIDGET:
                r = self.wt.RECT()
                self.user32.GetWindowRect(hwnd, self.ct.byref(r))
                best.append(((r.right - r.left) * (r.bottom - r.top), r.left, r.top))
            return True
        self.user32.EnumChildWindows(top, self.ENUMPROC(cb), 0)
        if not best:
            return None
        _, left, top_ = max(best)
        pt = self.wt.POINT(left, top_)
        self.user32.ScreenToClient(top, self.ct.byref(pt))
        return pt.x, pt.y

    def client_size(self, hwnd) -> Tuple[int, int]:
        r = self.wt.RECT()
        self.user32.GetClientRect(hwnd, self.ct.byref(r))
        return r.right - r.left, r.bottom - r.top

    def move_on_top(self, hwnd, x, y, w, h) -> None:
        self.user32.SetWindowPos(hwnd, None, x, y, w, h, self.SWP_NOACTIVATE | self.SWP_SHOWWINDOW)  # None = HWND_TOP

    def show(self, hwnd, on: bool) -> None:
        self.user32.ShowWindow(hwnd, 5 if on else 0)
