"""What a Chromecast gets: the file as it is, a remuxed or converted stream, and WebVTT subtitles.

Google's Default Media Receiver (the player every Cast device has) plays MP4 and WebM: H.264,
VP8/VP9, HEVC on newer devices; AAC, MP3, Opus, Vorbis, FLAC; AC3/E-AC3 usually only passed on to
an AV receiver. Subtitles come as separate WebVTT files. MKV isn't official: it sometimes plays on
Google TV devices and the Shield, but not reliably. The receiver needs CORS headers for the subtitle
files (and for media from another address), so this module has its own small HTTP server
(:class:`CastServer`) instead of ``tv.MediaServer``.

How each file goes (:func:`decide`, from what ffprobe or AniBox's own reading found):

- **direct**: an MP4/WebM whose picture and sound the device plays: the file itself, with byte
  ranges (the device seeks in it).
- **remux**: the picture fits (8-bit H.264 up to 1080p, or HEVC/VP9/AV1 on a device that takes it)
  but the box (MKV, AVI, TS ...) or the sound doesn't: ffmpeg repackages it on the fly into
  fragmented MP4, the picture copied as it is, the sound converted to AAC (stereo, or 5.1 when the
  source has 5.1 or more) unless it already fits. Light work for the PC.
- **convert**: the device can't decode the picture (10-bit H.264 "Hi10P", HEVC on an older
  Chromecast, MPEG-4 Part 2 ...): ffmpeg converts it to 8-bit H.264 while the TV watches, with a
  graphics-chip encoder when one works, else ``libx264 -preset veryfast``. That uses this PC's
  processor; the playing bar says so.
- **tvcopy**: instead of converting, a TV copy made earlier (``tvcopy.copy_for``) when one exists.

A remuxed or converted stream can't be seeked in: a jump starts ffmpeg again at the new position
(``-ss``) and the device loads the new stream; AniBox's position is the stream's start plus what the
device reports (CastApp converts the same way). Subtitle files next to the video
(``tv.find_subtitles``), text tracks inside an MKV (taken out with ffmpeg, once per file) and the
subtitle files of an Internet Archive item are sent as WebVTT; ASS/SSA lose their styling
(``tv.ass_to_srt``). Picture subtitles (PGS, VobSub) can't be sent.

The server answers only devices in the home network (private and link-local addresses), only URLs
with its random token, and stops ffmpeg when a stream ends, is replaced or forgotten. ffmpeg runs
without a console window on Windows, at low priority. Standard library only; untested with real
Cast devices so far.
"""

from __future__ import annotations

import collections
import html
import ipaddress
import json
import logging
import os
import re
import secrets
import shutil
import socket
import socketserver
import subprocess
import sys
import threading
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Callable, Dict, List, Optional, Sequence, Tuple

from . import languages, media, tv
from .tv import TvError

try:  # TV copies of files the TV can't decode (written by another part of AniBox; may not exist yet)
    from . import tvcopy as _tvcopy  # type: ignore
except ImportError:  # pragma: no cover - depends on the AniBox version
    _tvcopy = None

log = logging.getLogger("anibox.castserve")

IS_WINDOWS = sys.platform.startswith("win")
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
BELOW_NORMAL = getattr(subprocess, "BELOW_NORMAL_PRIORITY_CLASS", 0x00004000) if IS_WINDOWS else 0

DIRECT, REMUX, CONVERT, TVCOPY, NONE = "direct", "remux", "convert", "tvcopy", "none"
CHUNK = 256 * 1024
REQUEST_TIMEOUT = 30.0
STREAM_TIMEOUT = 3600.0  # a paused TV stops reading; don't drop it too early
SUB_WAIT = 300.0  # how long a subtitle request waits for the text taken out of the file
PROBE_TIMEOUT = 60.0
ENCODER_TEST_TIMEOUT = 20.0
MAX_TRACKS = 8  # text tracks taken out of one file
MAX_SUB_FILES = 6
SEEK_PAST_KEYFRAME = 0.2  # see Item._register

# Audio the Default Media Receiver plays; in fragmented MP4 (remux) AniBox copies only these
DIRECT_AUDIO = {"aac", "mp3", "opus", "vorbis", "flac"}
COPY_AUDIO = {"aac", "mp3", "opus", "flac"}
MP4_EXTS = (".mp4", ".m4v")
WEBM_EXTS = (".webm",)

# What each kind of Cast device decodes, by the model name it announces (mDNS TXT "md").
# From Google's "supported media" list and the devices' specifications; NOT tried on real devices.
# h264_max: the largest picture height for H.264. Matched in this order (substring, lower case).
DEVICES = (
    ("google tv streamer", {"label": "Google TV Streamer", "h264_max": 2160, "hevc": True, "hevc_10bit": True,
                            "vp9": True, "av1": True}),
    ("chromecast ultra", {"label": "Chromecast Ultra", "h264_max": 2160, "hevc": True, "hevc_10bit": True,
                          "vp9": True, "av1": False}),
    ("chromecast hd", {"label": "Chromecast with Google TV (HD)", "h264_max": 1080, "hevc": True, "hevc_10bit": True,
                       "vp9": True, "av1": True}),
    ("shield", {"label": "NVIDIA Shield (Cast receiver)", "h264_max": 2160, "hevc": True, "hevc_10bit": True,
                "vp9": True, "av1": False}),
    # 1st–3rd generation; the Chromecast with Google TV 4K announces the same name, so HEVC is off here
    ("chromecast", {"label": "Chromecast", "h264_max": 1080, "hevc": False, "hevc_10bit": False, "vp9": False,
                    "av1": False}),
)
DEFAULT_CAPS = {"label": "Cast device", "h264_max": 1080, "hevc": False, "hevc_10bit": False, "vp9": False, "av1": False}


def device_caps(model: str) -> dict:
    """What AniBox assumes a Cast device decodes, from its model name (``verified`` is always False)."""
    low = (model or "").lower()
    for key, caps in DEVICES:
        if key in low:
            return dict(caps, model=model, verified=False)
    return dict(DEFAULT_CAPS, model=model, verified=False)


# ---- reading a file --------------------------------------------------------------------------------

def _run(args: List[str], timeout: float) -> Optional[subprocess.CompletedProcess]:
    try:
        return subprocess.run(args, stdin=subprocess.DEVNULL, capture_output=True, timeout=timeout,
                              creationflags=NO_WINDOW)
    except (OSError, subprocess.TimeoutExpired, ValueError) as exc:
        log.info("%s didn't run: %s", os.path.basename(args[0]), exc)
        return None


def probe(source: str, ffprobe: Optional[str], timeout: float = PROBE_TIMEOUT) -> Optional[dict]:
    """``media.probe``'s info dict for a file or an http(s) address, plus ``duration`` (seconds, 0 if
    unknown). Without ffprobe only local MKV/MP4 files can be read (then without duration)."""
    if ffprobe:
        r = _run([ffprobe, "-v", "error", "-print_format", "json", "-show_streams", "-show_format", "-i", source], timeout)
        if r is not None and r.returncode == 0:
            try:
                obj = json.loads(r.stdout.decode("utf-8", "replace") or "{}")
                info = media.parse_ffprobe(obj)
                try:
                    info["duration"] = max(0.0, float((obj.get("format") or {}).get("duration") or 0))
                except (TypeError, ValueError):
                    info["duration"] = 0.0
                return info
            except ValueError:
                pass
        elif r is not None:
            log.info("ffprobe couldn't read %s: %s", os.path.basename(source),
                     (r.stderr or b"").decode("utf-8", "replace").strip()[:200])
    if "://" in source:
        return None
    info = media.probe_own(source)
    return dict(info, duration=0.0) if info else None


def keyframe_before(source: str, t: float, ffprobe: Optional[str]) -> float:
    """The time of the video key frame at or before ``t``: where a copied stream really starts.

    (ffmpeg's ``-ss`` with ``-c:v copy`` starts at that key frame, so the stream's 0 is there.)
    Reads only packet headers around ``t``. Falls back to ``t``."""
    if not ffprobe or t <= 0:
        return max(0.0, t)
    r = _run([ffprobe, "-v", "error", "-select_streams", "V:0", "-read_intervals", f"{max(0.0, t - 30):.3f}%{t + 0.5:.3f}",
              "-show_entries", "packet=pts_time,flags", "-of", "csv=p=0", "-i", source], PROBE_TIMEOUT)
    if r is None or r.returncode != 0:
        return t
    best = None
    for line in r.stdout.decode("utf-8", "replace").splitlines():
        parts = line.strip().split(",")
        if len(parts) < 2 or "K" not in parts[1]:
            continue
        try:
            pts = float(parts[0])
        except ValueError:
            continue
        if pts <= t + 0.001 and (best is None or pts > best):
            best = pts
    return t if best is None else max(0.0, best)


def pick_audio(info: Optional[dict], audio_langs: Sequence[str] = ()) -> int:
    """Which audio track to send (its index among the audio tracks): the first preferred language,
    else the one marked default, else the first."""
    audio = list((info or {}).get("audio") or [])
    if not audio:
        return 0
    want = []
    for x in audio_langs or []:
        code = languages.lang(str(x)) if x else ""
        if code and code not in want:
            want.append(code)
    for code in want:
        for i, a in enumerate(audio):
            if a.get("lang") == code:
                return i
    for i, a in enumerate(audio):
        if a.get("default"):
            return i
    return 0


# ---- the decision ----------------------------------------------------------------------------------------

def _video_fits(v: dict, caps: dict) -> Tuple[bool, str]:
    """(the device decodes this picture as it is?, why not)."""
    c = v.get("codec") or ""
    bits = v.get("bits") or 8
    height = int(v.get("height") or 0)
    profile = v.get("profile") or ""
    name = media.VIDEO_NAMES.get(c, c.upper() or "this video format")
    if c == "h264":
        if media.is_hi10p(v):
            return False, "10-bit H.264 (Hi10P): no Cast device decodes it"
        if "4:2:2" in profile or "4:4:4" in profile:
            return False, f"H.264 {profile}: Cast devices can't decode it"
        limit = int(caps.get("h264_max") or 1080)
        if height > (1088 if limit <= 1080 else limit):
            return False, f"H.264 at {height}p: bigger than this device plays"
        return True, ""
    if c == "hevc":
        if not caps.get("hevc"):
            return False, f"{name}: this Chromecast can't decode it"
        if bits > 10 or (bits == 10 and not caps.get("hevc_10bit")):
            return False, f"{bits}-bit H.265: this device can't decode it"
        return True, ""
    if c == "vp9":
        return (True, "") if caps.get("vp9") and bits <= (10 if caps.get("hevc_10bit") else 8) else \
            (False, "VP9: this Chromecast can't decode it")
    if c == "vp8":
        return True, ""
    if c == "av1":
        return (True, "") if caps.get("av1") and bits <= 10 else (False, "AV1: this device can't decode it")
    return False, f"{name}: Cast devices can't decode it"


def decide(info: Optional[dict], caps: dict, ext: str = "", have_ffmpeg: bool = True, audio_index: int = 0) -> dict:
    """How a file reaches a Cast device. Returns ``{"mode": direct|remux|convert|none, "video": "copy"|"h264"|"",
    "audio": "copy"|"aac"|"", "audio_index", "channels" (for "aac"), "hevc_tag", "scale" (max height or 0),
    "mime", "why"}`` (``why``: the reason for converting, or why it can't go at all)."""
    ext = (ext or "").lower()
    out = {"mode": NONE, "video": "", "audio": "", "audio_index": audio_index, "channels": 2, "hevc_tag": False,
           "scale": 0, "mime": "video/mp4", "why": ""}
    if not info:
        if ext in MP4_EXTS + WEBM_EXTS:
            out.update(mode=DIRECT, mime="video/webm" if ext in WEBM_EXTS else "video/mp4",
                       why="AniBox couldn't read the file; it's sent as it is")
        else:
            out["why"] = "AniBox couldn't read this file"
        return out
    v = info.get("video")
    audio = list(info.get("audio") or [])
    if not 0 <= audio_index < len(audio):
        audio_index = 0
    out["audio_index"] = audio_index
    a = audio[audio_index] if audio else None
    acodec = (a or {}).get("codec") or ""
    fits, why = _video_fits(v, caps) if v else (True, "")
    webm = ext in WEBM_EXTS or ("webm" in str(info.get("container") or "") and ext not in (".mkv", ".mk3d"))
    mp4 = ext in MP4_EXTS
    vcodec = (v or {}).get("codec") or ""
    if fits and out["audio_index"] == 0 and (a is None or acodec in DIRECT_AUDIO):
        if mp4 and vcodec in ("h264", "hevc", "av1", "vp9", "") and acodec in ("", "aac", "mp3", "opus", "flac"):
            out.update(mode=DIRECT, mime="video/mp4")
            return out
        if webm and vcodec in ("vp8", "vp9", "av1", "") and acodec in ("", "opus", "vorbis"):
            out.update(mode=DIRECT, mime="video/webm")
            return out
    if not have_ffmpeg:
        if fits and (a is None or acodec in DIRECT_AUDIO):
            # Without ffmpeg: the file as it is, called MP4 (the Default Media Receiver refuses the MKV type,
            # but often plays H.264 inside an MKV; Frostbox does the same). Not reliable.
            out.update(mode=DIRECT, mime="video/mp4",
                       why="without ffmpeg AniBox sends the file as it is; Chromecasts often play it, but not reliably")
            return out
        out["why"] = (why or f"the sound ({media.audio_text({'codec': acodec})}) doesn't play on a Chromecast") + \
            ". AniBox needs ffmpeg to convert it (Settings → Player → Download ffmpeg)"
        return out
    if a is not None:
        if acodec in COPY_AUDIO:
            out["audio"] = "copy"
        else:
            out.update(audio="aac", channels=6 if int(a.get("channels") or 2) >= 6 else 2)
    if not v:
        out.update(mode=REMUX)
        return out
    if fits:
        out.update(mode=REMUX, video="copy", hevc_tag=vcodec == "hevc")
        return out
    limit = 1080 if int(caps.get("h264_max") or 1080) <= 1080 else int(caps.get("h264_max"))
    out.update(mode=CONVERT, video="h264", why=why, scale=limit if int(v.get("height") or 0) > limit else 0)
    if out["audio"] == "copy" and acodec not in ("aac", "mp3"):
        out.update(audio="aac", channels=6 if int((a or {}).get("channels") or 2) >= 6 else 2)
    return out


# ---- ffmpeg --------------------------------------------------------------------------------------------

# Encoders tried for live conversion, in order, when ffmpeg lists them (each tested once with a tiny
# picture: a listed hardware encoder often has no hardware behind it). libx264 is the fallback.
_HW_ENCODERS = {
    "win": (("h264_nvenc", ["-preset", "p4", "-rc", "vbr", "-cq", "21", "-b:v", "0"], "yuv420p"),
            ("h264_qsv", ["-preset", "veryfast", "-global_quality", "23"], "nv12"),
            ("h264_amf", ["-quality", "speed", "-rc", "cqp", "-qp_i", "21", "-qp_p", "23"], "nv12")),
    "darwin": (("h264_videotoolbox", ["-q:v", "60"], "yuv420p"),),
    "linux": (("h264_nvenc", ["-preset", "p4", "-rc", "vbr", "-cq", "21", "-b:v", "0"], "yuv420p"),),
}
SOFTWARE = ("libx264", ["-preset", "veryfast", "-crf", "21", "-profile:v", "high", "-level:v", "4.1"], "yuv420p")
_encoders: Dict[str, Tuple[str, List[str], str]] = {}
_enc_lock = threading.Lock()


def _platform() -> str:
    return "win" if IS_WINDOWS else ("darwin" if sys.platform == "darwin" else "linux")


def pick_encoder(ffmpeg: str) -> Tuple[str, List[str], str]:
    """(encoder, its options, pixel format) for live conversion; tested once per ffmpeg program."""
    with _enc_lock:
        if ffmpeg in _encoders:
            return _encoders[ffmpeg]
    r = _run([ffmpeg, "-hide_banner", "-encoders"], 20)
    listed = r.stdout.decode("utf-8", "replace") if r is not None and r.returncode == 0 else ""
    chosen = SOFTWARE
    for name, opts, pix in _HW_ENCODERS.get(_platform(), ()):
        if re.search(rf"\b{re.escape(name)}\b", listed):
            t = _run([ffmpeg, "-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i", "color=c=black:s=320x240:r=10:d=0.5",
                      "-vf", f"format={pix}", "-c:v", name, *opts, "-frames:v", "5", "-f", "null", "-"], ENCODER_TEST_TIMEOUT)
            if t is not None and t.returncode == 0:
                chosen = (name, opts, pix)
                break
    log.info("Live conversion for Chromecasts uses %s", chosen[0])
    with _enc_lock:
        _encoders[ffmpeg] = chosen
    return chosen


def ffmpeg_args(ffmpeg: str, source: str, plan: dict, offset: float = 0.0,
                encoder: Optional[Tuple[str, List[str], str]] = None) -> List[str]:
    """The ffmpeg command for a remuxed or converted stream: fragmented MP4 to stdout."""
    args = [ffmpeg, "-nostdin", "-hide_banner", "-loglevel", "error"]
    if offset > 0:
        args += ["-ss", f"{offset:.3f}"]
    args += ["-i", source]
    if plan.get("video"):
        args += ["-map", "0:V:0"]
    if plan.get("audio"):
        args += ["-map", f"0:a:{int(plan.get('audio_index') or 0)}?"]
    if plan.get("video") == "copy":
        args += ["-c:v", "copy"] + (["-tag:v", "hvc1"] if plan.get("hevc_tag") else [])
    elif plan.get("video") == "h264":
        name, opts, pix = encoder or SOFTWARE
        filters = []
        if plan.get("scale"):
            h = int(plan["scale"])
            filters.append(f"scale=-2:'min({h},ih)'")
        filters.append(f"format={pix}")
        args += ["-vf", ",".join(filters), "-c:v", name, *opts, "-g", "48", "-keyint_min", "24",
                 "-maxrate", "12M", "-bufsize", "24M"]
    if plan.get("audio") == "copy":
        args += ["-c:a", "copy"]
    elif plan.get("audio") == "aac":
        six = int(plan.get("channels") or 2) >= 6
        args += ["-c:a", "aac", "-ac", "6" if six else "2", "-b:a", "384k" if six else "192k"]
    args += ["-sn", "-dn", "-map_metadata", "-1", "-map_chapters", "-1", "-avoid_negative_ts", "make_zero",
             "-max_muxing_queue_size", "4096", "-movflags", "frag_keyframe+empty_moov+default_base_moof",
             "-f", "mp4", "pipe:1"]
    return args


def _popen(args: List[str]) -> subprocess.Popen:
    """ffmpeg at low priority, without a console window on Windows."""
    if not IS_WINDOWS and shutil.which("nice"):
        args = ["nice", "-n", "10"] + args
    return subprocess.Popen(args, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0,
                            creationflags=NO_WINDOW | BELOW_NORMAL)


def _kill(proc: Optional[subprocess.Popen]) -> None:
    if proc is None:
        return
    if proc.poll() is None:
        try:
            proc.kill()
        except OSError:
            pass
    try:
        proc.wait(5)
    except (subprocess.TimeoutExpired, OSError):
        pass
    for f in (proc.stdout, proc.stderr):
        try:
            if f:
                f.close()
        except OSError:
            pass


# ---- subtitles --------------------------------------------------------------------------------------------

_CUE_TIME = re.compile(r"(?:(\d+):)?(\d{1,2}):(\d{1,2})[.,](\d{1,3})")
_ARROW = re.compile(r"^\s*(\S+)\s*-->\s*(\S+)")
_ALLOWED_TAGS = re.compile(r"&lt;(/?)(i|b|u)&gt;", re.I)
_SRT_TAGS = re.compile(r"\{\\[^}]*\}")


def _cue_seconds(text: str) -> Optional[float]:
    m = _CUE_TIME.fullmatch(text.strip())
    if not m:
        return None
    h, mnt, s, ms = m.groups()
    return int(h or 0) * 3600 + int(mnt) * 60 + int(s) + int(ms.ljust(3, "0")) / 1000


def parse_cues(text: str) -> List[Tuple[float, float, str]]:
    """SRT or WebVTT text -> [(start, end, text)] (styling tags other than i/b/u dropped)."""
    text = text.replace("\r\n", "\n").replace("\r", "\n").lstrip("﻿")
    out = []
    for block in re.split(r"\n\s*\n", text):
        lines = [x for x in block.split("\n")]
        for i, line in enumerate(lines):
            m = _ARROW.match(line)
            if not m:
                continue
            start, end = _cue_seconds(m.group(1)), _cue_seconds(m.group(2))
            body = "\n".join(x.strip() for x in lines[i + 1:] if x.strip())
            if start is None or end is None or end <= start or not body:
                break
            body = re.sub(r"<(?!/?[ibu]>)[^>]*>", "", _SRT_TAGS.sub("", body), flags=re.I)
            if body.strip():
                out.append((start, end, body.strip()))
            break
    out.sort(key=lambda c: (c[0], c[1]))
    return out


def _vtt_time(seconds: float) -> str:
    ms = int(round(max(0.0, seconds) * 1000))
    h, rest = divmod(ms, 3_600_000)
    m, rest = divmod(rest, 60_000)
    s, ms = divmod(rest, 1000)
    return f"{h:02d}:{m:02d}:{s:02d}.{ms:03d}"


def to_vtt(cues: Sequence[Tuple[float, float, str]], shift: float = 0.0) -> str:
    """WebVTT text; ``shift`` seconds are taken off every cue (a stream that starts at ``shift``)."""
    parts = ["WEBVTT", ""]
    for start, end, body in cues:
        s, e = start - shift, end - shift
        if e <= 0:
            continue
        text = _ALLOWED_TAGS.sub(lambda m: f"<{m.group(1)}{m.group(2).lower()}>", html.escape(body, quote=False))
        text = text.replace("-->", "--&gt;")
        parts += [f"{_vtt_time(max(0.0, s))} --> {_vtt_time(e)}", text, ""]
    return "\n".join(parts) + "\n"


def srt_to_vtt(text: str) -> str:
    return to_vtt(parse_cues(text))


def cues_from(raw: bytes, ext: str) -> List[Tuple[float, float, str]]:
    """A subtitle file's bytes (.srt, .vtt, .ass, .ssa) -> cues. ASS/SSA lose their styling."""
    text = tv._decode_text(raw)
    if ext.lower() in (".ass", ".ssa"):
        text = tv.ass_to_srt(text)
    return parse_cues(text)


_FORCED_WORDS = {"forced", "signs", "sign", "songs", "sns"}
_FORCED_TITLE = re.compile(r"\b(signs?|songs?|forced|karaoke|s\s*&\s*s)\b", re.I)


def _file_lang(name: str, video_stem: str) -> Tuple[str, bool]:
    """(language, signs only?) of a subtitle file from the part of its name after the video's name."""
    stem = os.path.splitext(name)[0]
    rest = stem[len(video_stem):] if stem.casefold().startswith(video_stem.casefold()) else stem
    tokens = [x.casefold() for x in re.split(r"[^A-Za-z]+", rest) if x]
    code = next((languages.LANG[x] for x in tokens if x in languages.LANG), "")
    return code, any(x in _FORCED_WORDS for x in tokens)


class Sub:
    """One subtitle track for the device: its cues, loaded now or later (taken out of the video)."""

    def __init__(self, label: str, lang: str, forced: bool, info: str, order: int):
        self.label = label
        self.lang = lang
        self.forced = forced
        self.info = info
        self.order = order
        self.cues: Optional[List[Tuple[float, float, str]]] = None
        self.error = ""
        self.ready = threading.Event()

    def set(self, cues: Optional[List[Tuple[float, float, str]]], error: str = "") -> None:
        self.cues, self.error = cues, error
        self.ready.set()

    def vtt(self, shift: float, stopping: Optional[threading.Event] = None, wait: float = SUB_WAIT) -> Optional[bytes]:
        """The WebVTT bytes for a stream starting at ``shift``; waits for cues still being read."""
        deadline = time.monotonic() + wait
        while not self.ready.wait(0.25):
            if time.monotonic() >= deadline or (stopping is not None and stopping.is_set()):
                return None
        if self.cues is None:
            return None
        return to_vtt(self.cues, shift).encode("utf-8")


def _label(lang: str, forced: bool, fallback: str) -> str:
    name = languages.NAMES.get(lang, lang.upper() if lang else "") or fallback
    return name + (" (signs)" if forced else "")


_extracted: "collections.OrderedDict[tuple, Dict[int, List[Tuple[float, float, str]]]]" = collections.OrderedDict()
_extract_lock = threading.Lock()


def _extract(video: str, subs: Dict[int, Sub], ffmpeg: str) -> None:
    """Takes text tracks out of a file (one pass, all tracks at once) and hands each its cues."""
    try:
        st = os.stat(video)
        key = (video, st.st_size, round(st.st_mtime, 3))
    except OSError:
        key = None
    with _extract_lock:
        hit = _extracted.get(key) if key else None
    todo = [n for n in subs if not hit or n not in hit]
    texts: Dict[int, str] = {}
    error = ""
    if todo:
        try:
            texts = media.extract_tracks(video, todo, ffmpeg)
        except (OSError, RuntimeError, subprocess.SubprocessError) as exc:
            error = str(exc)[:200]
            log.info("Cast: couldn't take the subtitles out of %s: %s", os.path.basename(video), error)
    cues = dict(hit or {})
    for n, text in texts.items():
        cues[n] = parse_cues(tv.ass_to_srt(text))
    if key:
        with _extract_lock:
            _extracted[key] = cues
            _extracted.move_to_end(key)
            while len(_extracted) > 4:
                _extracted.popitem(last=False)
    for n, sub in subs.items():
        sub.set(cues.get(n), "" if n in cues else (error or "track not found"))


def gather_subtitles(video_path: str, info: Optional[dict], ffmpeg: Optional[str], langs: Sequence[str],
                     sub_files: Sequence[Tuple[str, Callable[[], bytes]]] = (), embedded_from: str = "") -> Tuple[List[Sub], List[str]]:
    """The subtitle tracks for an episode, best first, and notes for the log.

    Files next to ``video_path`` (``tv.find_subtitles``), ``sub_files`` (``(name, loader)``, e.g. an
    Internet Archive item's), and the text tracks inside ``embedded_from`` (taken out with ffmpeg in
    the background). Picture tracks are left out with a note."""
    notes: List[str] = []
    want = []
    for x in langs or []:
        code = languages.lang(str(x)) if x else ""
        if code and code not in want:
            want.append(code)
    subs: List[Sub] = []
    order = 0
    if video_path and "://" not in video_path:
        stem = os.path.splitext(os.path.basename(video_path))[0]
        for p in tv.find_subtitles(video_path, want)[:MAX_SUB_FILES]:
            base = os.path.basename(p)
            lang, forced = _file_lang(base, stem)
            sub = Sub(_label(lang, forced, "Subtitles"), lang, forced, f"{os.path.splitext(base)[1][1:].upper()} file", order)
            order += 1
            try:
                with open(p, "rb") as f:
                    raw = f.read(tv.MAX_SUBTITLE + 1)
                sub.set(cues_from(raw, os.path.splitext(base)[1]) if len(raw) <= tv.MAX_SUBTITLE else None)
            except OSError as exc:
                sub.set(None, str(exc))
            if sub.cues:
                subs.append(sub)
    for name, loader in list(sub_files)[:MAX_SUB_FILES]:
        base = os.path.basename(name)
        stem = os.path.splitext(os.path.basename(video_path or base))[0]
        lang, forced = _file_lang(base, stem)
        sub = Sub(_label(lang, forced, "Subtitles"), lang, forced, f"{os.path.splitext(base)[1][1:].upper()} file", order)
        order += 1

        def load(sub=sub, loader=loader, ext=os.path.splitext(base)[1]):
            try:
                sub.set(cues_from(loader(), ext))
            except (OSError, ValueError, TvError) as exc:
                log.info("Cast: a subtitle file couldn't go along (%s)", exc)
                sub.set(None, str(exc))

        threading.Thread(target=load, daemon=True, name="anibox-cast-subfile").start()
        subs.append(sub)
    tracks = [s for s in (info or {}).get("subs") or [] if not s.get("external")]
    text_tracks = [s for s in tracks if s.get("type") in ("ass", "srt", "vtt", "text")]
    if any(s.get("type") in ("pgs", "vobsub") for s in tracks):
        notes.append("Picture subtitles (PGS/VobSub) inside the file can't be sent to a Chromecast.")
    if text_tracks and embedded_from and ffmpeg and "://" not in embedded_from:
        jobs: Dict[int, Sub] = {}
        for i, t in enumerate(text_tracks[:MAX_TRACKS]):
            n = int(t.get("n", i))
            forced = bool(t.get("forced")) or bool(_FORCED_TITLE.search(t.get("title") or ""))
            label = _label(t.get("lang") or "", forced, t.get("title") or f"Track {n + 1}")
            sub = Sub(label, t.get("lang") or "", forced, "In the video" + (f": {t['title']}" if t.get("title") else ""), order)
            order += 1
            jobs[n] = sub
            subs.append(sub)
        threading.Thread(target=_extract, args=(embedded_from, jobs, ffmpeg), daemon=True,
                         name="anibox-cast-subtracks").start()
    elif text_tracks and not ffmpeg:
        notes.append("The subtitles inside the file need ffmpeg to go to a Chromecast (Settings → Player).")

    def rank(s: Sub):
        r = want.index(s.lang) if s.lang in want else len(want) + (0 if not s.lang else 1)
        return (r, s.forced, s.order)

    subs.sort(key=rank)
    return subs, notes


def tv_copy_for(path: str) -> Optional[str]:
    """A TV copy of ``path`` made earlier (``tvcopy.copy_for``), if that part of AniBox is there and has one."""
    fn = getattr(_tvcopy, "copy_for", None) if _tvcopy is not None else None
    if fn is None or not path:
        return None
    try:
        res = fn(path)
    except Exception:  # another module: never let it stop playback
        log.info("Cast: asking for a TV copy failed", exc_info=True)
        return None
    if isinstance(res, dict):
        res = res.get("path")
    res = str(res) if res else ""
    return res if res and os.path.isfile(res) else None


# ---- the HTTP server ----------------------------------------------------------------------------------------

def _home_client(ip: str) -> bool:
    try:
        addr = ipaddress.ip_address(str(ip).split("%")[0])
    except ValueError:
        return False
    mapped = getattr(addr, "ipv4_mapped", None)
    if mapped:
        addr = mapped
    return (addr.is_private or addr.is_link_local) and not addr.is_multicast and not addr.is_unspecified


def _safe_name(text: str, fallback: str = "video") -> str:
    return tv._safe_name(text, fallback)


class _Entry:
    __slots__ = ("kind", "name", "mime", "path", "locate", "args", "proc", "get", "source", "requests", "sent", "last",
                 "errors", "lock")

    def __init__(self, kind: str, name: str, mime: str):
        self.kind = kind  # file, stream, text, source
        self.name = name
        self.mime = mime
        self.path = ""
        self.locate: Optional[Callable[[], str]] = None
        self.args: Optional[Callable[[], List[str]]] = None
        self.proc: Optional[subprocess.Popen] = None
        self.get: Optional[Callable[[threading.Event], Optional[bytes]]] = None
        self.source = None
        self.requests = 0
        self.sent = 0
        self.last = 0.0
        self.errors: "collections.deque[str]" = collections.deque(maxlen=20)
        self.lock = threading.Lock()


def _parse_range(header: Optional[str], size: int) -> Optional[Tuple[int, int]]:
    """A "bytes=" Range -> (first, last), None for the whole file; raises ValueError (416)."""
    if not header:
        return None
    unit, _, spec = header.partition("=")
    if unit.strip().lower() != "bytes" or "," in spec:
        return None
    m = re.fullmatch(r"\s*(\d*)\s*-\s*(\d*)\s*", spec)
    if not m or (not m.group(1) and not m.group(2)):
        raise ValueError(header)
    first, last = m.groups()
    if not first:
        count = int(last)
        if count == 0 or size == 0:
            raise ValueError(header)
        return max(0, size - count), size - 1
    start = int(first)
    if start >= size:
        raise ValueError(header)
    end = size - 1 if not last else min(int(last), size - 1)
    if end < start:
        raise ValueError(header)
    return start, end


class _HttpServer(ThreadingHTTPServer):
    daemon_threads = True
    request_queue_size = 16
    allow_reuse_address = not IS_WINDOWS
    owner: "CastServer"

    def server_bind(self) -> None:
        socketserver.TCPServer.server_bind(self)  # (HTTPServer's looks up the host name, which can be slow)
        host, port = self.server_address[:2]
        self.server_name, self.server_port = str(host), port

    def handle_error(self, request, client_address) -> None:
        log.debug("Cast server: error with %s", client_address, exc_info=True)


CORS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, HEAD, OPTIONS",
    "Access-Control-Allow-Headers": "Range, Content-Type, Accept, Accept-Encoding, Origin",
    "Access-Control-Expose-Headers": "Content-Length, Content-Range, Accept-Ranges, Content-Type",
}


class _Handler(BaseHTTPRequestHandler):
    server_version = "AniBox"
    sys_version = ""
    protocol_version = "HTTP/1.1"
    timeout = REQUEST_TIMEOUT
    server: _HttpServer

    def setup(self) -> None:
        super().setup()
        self.server.owner._track(self.connection, True)

    def finish(self) -> None:
        try:
            super().finish()
        except OSError:
            pass
        finally:
            self.server.owner._track(self.connection, False)

    def log_message(self, fmt, *args) -> None:
        log.debug("Cast media %s: " + fmt, self.client_address[0], *args)

    def end_headers(self) -> None:
        # Every answer (also a relay's, see tvstream.Relay) carries the CORS headers the receiver needs.
        for k, v in CORS.items():
            self.send_header(k, v)
        super().end_headers()

    def _plain(self, status: int, extra: Optional[dict] = None) -> None:
        body = f"{status} {self.responses.get(status, ('Error',))[0]}\n".encode("ascii")
        self.send_response(status)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.send_header("Connection", "close")
        self.end_headers()
        self.close_connection = True
        if self.command != "HEAD":
            self.wfile.write(body)

    def do_OPTIONS(self) -> None:
        if not self.server.owner.allowed(self.client_address[0]):
            return self._plain(403)
        self.send_response(204)
        self.send_header("Access-Control-Max-Age", "600")
        self.send_header("Content-Length", "0")
        self.send_header("Connection", "close")
        self.end_headers()
        self.close_connection = True

    def do_GET(self) -> None:
        self._serve(head=False)

    def do_HEAD(self) -> None:
        self._serve(head=True)

    def _serve(self, head: bool) -> None:
        owner = self.server.owner
        if not owner.allowed(self.client_address[0]):
            return self._plain(403)
        entry = owner._find(self.path)
        if entry is None:
            return self._plain(404)
        owner._count(entry, 0)
        count = lambda n: owner._count(entry, n, request=False)  # noqa: E731
        if entry.kind == "source":
            return entry.source.serve(self, head, count, owner._stopping)
        if entry.kind == "stream":
            return self._stream(entry, head, count)
        if entry.kind == "text":
            return self._text(entry, head, count)
        return self._file(entry, head, count)

    def _file(self, entry: _Entry, head: bool, count) -> None:
        path = entry.path
        if entry.locate is not None:
            try:
                path = entry.locate() or ""
            except Exception:
                path = ""
        try:
            f = open(path, "rb", buffering=0)
        except OSError:
            return self._plain(404)
        with f:
            size = os.fstat(f.fileno()).st_size
            try:
                rng = _parse_range(self.headers.get("Range"), size)
            except ValueError:
                return self._plain(416, {"Content-Range": f"bytes */{size}", "Accept-Ranges": "bytes"})
            start, end = rng if rng else (0, size - 1)
            length = max(0, end - start + 1)
            self.send_response(206 if rng else 200)
            self.send_header("Content-Type", entry.mime)
            self.send_header("Content-Length", str(length))
            if rng:
                self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Connection", "close")
            self.end_headers()
            self.close_connection = True
            if head or length == 0:
                return
            self.connection.settimeout(STREAM_TIMEOUT)
            f.seek(start)
            remaining = length
            try:
                while remaining > 0 and not self.server.owner._stopping.is_set():
                    chunk = f.read(min(CHUNK, remaining))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    remaining -= len(chunk)
                    count(len(chunk))
            except OSError:
                pass  # the device closed the connection (seeking, stopping): normal

    def _text(self, entry: _Entry, head: bool, count) -> None:
        data = entry.get(self.server.owner._stopping) if entry.get else None
        if data is None:
            return self._plain(503, {"Retry-After": "5"})
        self.send_response(200)
        self.send_header("Content-Type", entry.mime + "; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "close")
        self.end_headers()
        self.close_connection = True
        if not head:
            self.wfile.write(data)
            count(len(data))

    def _stream(self, entry: _Entry, head: bool, count) -> None:
        rng = (self.headers.get("Range") or "").strip()
        if rng and not re.fullmatch(r"bytes\s*=\s*0\s*-\s*", rng, re.I):
            # A stream can't start in the middle (AniBox seeks by starting a new stream).
            return self._plain(416, {"Content-Range": "bytes */*", "Accept-Ranges": "none"})
        self.send_response(200)
        self.send_header("Content-Type", entry.mime)
        self.send_header("Accept-Ranges", "none")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "close")
        self.end_headers()
        self.close_connection = True
        if head:
            return
        owner = self.server.owner
        args = entry.args() if entry.args else []
        with entry.lock:  # one ffmpeg per stream: a new request replaces the one before
            old, entry.proc = entry.proc, None
        _kill(old)
        try:
            proc = _popen(args)
        except OSError as exc:
            log.warning("Cast: ffmpeg didn't start: %s", exc)
            return
        with entry.lock:
            entry.proc = proc
        owner._procs_add(proc)
        threading.Thread(target=self._errors, args=(proc, entry), daemon=True, name="anibox-cast-ffmpeg-err").start()
        self.connection.settimeout(STREAM_TIMEOUT)
        try:
            while not owner._stopping.is_set():
                chunk = proc.stdout.read(CHUNK)
                if not chunk:
                    break
                self.wfile.write(chunk)
                count(len(chunk))
        except (OSError, ValueError):
            pass  # the device closed the connection, or the stream was replaced
        finally:
            killed = proc.poll() is None
            _kill(proc)
            owner._procs_remove(proc)
            with entry.lock:
                if entry.proc is proc:
                    entry.proc = None
            if not killed and proc.returncode not in (0, None) and entry.errors:
                log.warning("Cast: ffmpeg stopped (%s): %s", proc.returncode, " | ".join(entry.errors)[-600:])

    @staticmethod
    def _errors(proc: subprocess.Popen, entry: _Entry) -> None:
        try:
            for line in iter(proc.stderr.readline, b""):
                text = line.decode("utf-8", "replace").strip()
                if text:
                    entry.errors.append(text[:300])
        except (OSError, ValueError):
            pass


class CastServer:
    """Serves videos, streams and subtitles to Cast devices over HTTP, with CORS.

    URLs look like ``http://<lan ip>:<port>/c/<token>/<id>/<name>``; the token is random for each
    start, anything else gets 404, and only devices in the home network are answered (``allowed``).
    Files with byte ranges; streams from ffmpeg (one process per stream, replaced by a new request,
    stopped when the stream is forgotten); text (WebVTT) made on request; and ``source`` entries that
    answer themselves (``tvstream.Relay`` for Internet Archive videos). Nothing listens before
    :meth:`start` (which :meth:`add_file` and the others do by themselves).
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._entries: Dict[str, _Entry] = {}
        self._next_id = 0
        self._token = secrets.token_hex(16)
        self._httpd: Optional[_HttpServer] = None
        self._conns: set = set()
        self._procs: set = set()
        self._stopping = threading.Event()
        self.host = ""

    @property
    def running(self) -> bool:
        return self._httpd is not None

    @property
    def port(self) -> Optional[int]:
        httpd = self._httpd
        return httpd.server_address[1] if httpd else None

    @staticmethod
    def allowed(ip: str) -> bool:
        """Only devices in the home network (private or link-local addresses)."""
        return _home_client(ip)

    def start(self, host: str = "0.0.0.0", port: int = 0) -> int:
        with self._lock:
            if self._httpd:
                return self._httpd.server_address[1]
            try:
                httpd = _HttpServer((host, port), _Handler)
            except OSError as exc:
                raise TvError(f"AniBox couldn't open port {port} for the Chromecast ({exc}).", "server") from exc
            httpd.owner = self
            self._stopping.clear()
            self._token = secrets.token_hex(16)
            self._entries.clear()
            self.host = host
            self._httpd = httpd
        threading.Thread(target=httpd.serve_forever, kwargs={"poll_interval": 0.25}, daemon=True,
                         name="anibox-cast-media").start()
        log.info("Cast media server on %s:%s", host, httpd.server_address[1])
        return httpd.server_address[1]

    def stop(self) -> None:
        """Stops listening, ends transfers and ffmpeg, forgets every URL."""
        with self._lock:
            httpd, self._httpd = self._httpd, None
            entries = list(self._entries.values())
            self._entries.clear()
            procs = list(self._procs)
        self._stopping.set()
        for e in entries:
            _kill(e.proc)
        for p in procs:
            _kill(p)
        if not httpd:
            return
        httpd.shutdown()
        httpd.server_close()
        with self._lock:
            conns = list(self._conns)
            self._conns.clear()
        for c in conns:
            try:
                c.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass

    # -- registering

    def add_file(self, path: str, mime: str, name: str = "", tv_ip: str = "", local_ip: str = "",
                 locate: Optional[Callable[[], str]] = None) -> str:
        now = locate() if locate is not None else path
        if not now or not os.path.isfile(now):
            raise TvError(f"AniBox can't find \"{os.path.basename(name or path)}\". Is the drive connected?", "file")
        e = _Entry("file", self._name(name or now, "video"), mime)
        e.path, e.locate = now, locate
        return self._register(e, tv_ip, local_ip)

    def add_stream(self, args: Callable[[], List[str]], name: str, tv_ip: str = "", local_ip: str = "",
                   mime: str = "video/mp4") -> str:
        e = _Entry("stream", self._name(name, "video") + ".mp4", mime)
        e.args = args
        return self._register(e, tv_ip, local_ip)

    def add_source(self, source, name: str, mime: str, tv_ip: str = "", local_ip: str = "") -> str:
        e = _Entry("source", self._name(name, "video"), mime)
        e.source = source
        return self._register(e, tv_ip, local_ip)

    def add_text(self, get: Callable[[threading.Event], Optional[bytes]], name: str, tv_ip: str = "", local_ip: str = "",
                 mime: str = "text/vtt") -> str:
        e = _Entry("text", self._name(name, "subtitles") + ".vtt", mime)
        e.get = get
        return self._register(e, tv_ip, local_ip)

    def remove(self, url: str) -> None:
        """Forgets one URL (404 from now on) and stops its ffmpeg."""
        with self._lock:
            parts = urllib.parse.urlsplit(url).path.split("/")
            e = self._lookup(url)
            if e is not None:
                self._entries.pop(parts[3], None)
        if e is not None:
            with e.lock:
                proc, e.proc = e.proc, None
            _kill(proc)

    def clear(self) -> None:
        with self._lock:
            entries = list(self._entries.values())
            self._entries.clear()
        for e in entries:
            _kill(e.proc)

    def activity(self, url: str) -> dict:
        """``{"requests", "bytes", "last"}``: did the device fetch it?"""
        with self._lock:
            e = self._lookup(url)
            if e is None:
                return {"requests": 0, "bytes": 0, "last": 0.0}
            return {"requests": e.requests, "bytes": e.sent, "last": e.last}

    def running_streams(self) -> int:
        """ffmpeg processes running right now (tests, the log)."""
        with self._lock:
            return sum(1 for p in self._procs if p.poll() is None)

    # -- internals

    @staticmethod
    def _name(text: str, fallback: str) -> str:
        base = os.path.basename(text)
        stem, ext = os.path.splitext(base)
        ext = _safe_name(ext[1:].lower(), "")
        if ext and len(ext) <= 5:
            return _safe_name(stem, fallback) + "." + ext
        return _safe_name(base, fallback)

    def _register(self, entry: _Entry, tv_ip: str, local_ip: str) -> str:
        if not self.running:
            self.start()
        with self._lock:
            httpd = self._httpd
            if httpd is None:
                raise TvError("AniBox's media server for the Chromecast isn't running.", "server")
            self._next_id += 1
            eid = str(self._next_id)
            self._entries[eid] = entry
            token = self._token
        host = self.host if self.host not in ("", "0.0.0.0") else (local_ip or tv.lan_ip_for(tv_ip or ""))
        if ":" in host:
            host = f"[{host}]"
        return f"http://{host}:{httpd.server_address[1]}/c/{token}/{eid}/{urllib.parse.quote(entry.name)}"

    def _lookup(self, url_or_path: str) -> Optional[_Entry]:
        try:
            path = urllib.parse.unquote(urllib.parse.urlsplit(url_or_path).path)
        except ValueError:
            return None
        parts = path.split("/")
        if len(parts) != 5 or parts[0] != "" or parts[1] != "c":
            return None
        if not secrets.compare_digest(parts[2].encode("utf-8", "replace"), self._token.encode("ascii")):
            return None
        entry = self._entries.get(parts[3])
        if entry is None or parts[4] != entry.name:
            return None
        return entry

    def _find(self, path: str) -> Optional[_Entry]:
        with self._lock:
            return self._lookup(path)

    def _count(self, entry: _Entry, sent: int, request: bool = True) -> None:
        with self._lock:
            if request:
                entry.requests += 1
            entry.sent += sent
            entry.last = time.time()

    def _track(self, conn: socket.socket, add: bool) -> None:
        with self._lock:
            (self._conns.add if add else self._conns.discard)(conn)

    def _procs_add(self, proc: subprocess.Popen) -> None:
        with self._lock:
            self._procs.add(proc)
        if self._stopping.is_set():
            _kill(proc)

    def _procs_remove(self, proc: subprocess.Popen) -> None:
        with self._lock:
            self._procs.discard(proc)


# ---- one episode, prepared -------------------------------------------------------------------------------

class Item:
    """One video prepared for a Cast device: its address (the file, a relay or an ffmpeg stream) and
    its subtitle tracks. :meth:`restart` starts a stream again at another position (a seek)."""

    def __init__(self, server: CastServer, *, mode: str, plan: dict, source: str, name: str, title: str,
                 duration: float, ffmpeg: Optional[str], ffprobe: Optional[str], tv_ip: str, local_ip: str,
                 subs: List[Sub], subs_on: bool, warnings: List[str], note: str, start: float,
                 locate: Optional[Callable[[], str]] = None, relay=None):
        self.server = server
        self.mode = mode
        self.plan = plan
        self.source = source
        self.name = name
        self.title = title
        self.duration = duration
        self.ffmpeg = ffmpeg
        self.ffprobe = ffprobe
        self.tv_ip = tv_ip
        self.local_ip = local_ip
        self.subs = subs
        self.warnings = warnings
        self.note = note
        self.locate = locate
        self.relay = relay
        self.streamed = plan["mode"] in (REMUX, CONVERT)
        self.encoder = pick_encoder(ffmpeg) if plan.get("video") == "h264" and ffmpeg else None
        if self.encoder and plan["mode"] == CONVERT:
            hw = self.encoder[0] != SOFTWARE[0]
            self.note = "converting on this PC" + (" (graphics chip)" if hw else " (uses the CPU)")
        self._lock = threading.Lock()
        self._media_urls: List[str] = []
        self._sub_urls: List[str] = []
        self.active = self._default_active(subs_on)
        self._released = False
        self._current: dict = {}
        self._register(start)

    def _default_active(self, on: bool) -> List[int]:
        if not on or not self.subs:
            return []
        full = next((i for i, s in enumerate(self.subs, 1) if not s.forced), None)
        return [full or 1]

    def _register(self, start: float) -> None:
        start = max(0.0, float(start or 0.0))
        if self.duration:
            start = min(start, max(0.0, self.duration - 1.0))
        if self.streamed:
            if self.plan.get("video") == "copy":
                # A copied picture starts at a key frame: find it, and ask ffmpeg for a moment after it, since
                # ffmpeg seeks 3/23 s early in files with B-frames (MKV) and would land on the key frame before.
                offset = keyframe_before(self.source, start, self.ffprobe)
                seek_at = offset + SEEK_PAST_KEYFRAME if offset > 0 else 0.0
            else:
                offset = seek_at = start  # converting: ffmpeg starts exactly there
            plan, src, ffmpeg, enc = self.plan, self.source, self.ffmpeg, self.encoder

            def args(seek_at=seek_at):
                source = self.locate() if self.locate is not None else src
                return ffmpeg_args(ffmpeg, source or src, plan, seek_at, enc)

            url = self.server.add_stream(args, self.title or self.name, self.tv_ip, self.local_ip)
            load_start = 0.0
        elif self.relay is not None:
            offset, load_start = 0.0, start
            url = self.server.add_source(self.relay, self.name, self.plan["mime"], self.tv_ip, self.local_ip)
        else:
            offset, load_start = 0.0, start
            url = self.server.add_file(self.source, self.plan["mime"], self.name, self.tv_ip, self.local_ip, self.locate)
        tracks, sub_urls = [], []
        for i, sub in enumerate(self.subs, 1):
            su = self.server.add_text(lambda stopping, sub=sub, offset=offset: sub.vtt(offset, stopping),
                                      f"{os.path.splitext(self.name)[0]}.{sub.lang or i}", self.tv_ip, self.local_ip)
            sub_urls.append(su)
            track = {"trackId": i, "type": "TEXT", "subtype": "SUBTITLES", "trackContentId": su,
                     "trackContentType": "text/vtt", "name": sub.label}
            if sub.lang:
                track["language"] = sub.lang
            tracks.append(track)
        with self._lock:
            self._media_urls.append(url)
            self._sub_urls += sub_urls
            self._current = {"url": url, "mime": "video/mp4" if self.streamed else self.plan["mime"], "tracks": tracks,
                             "active": list(self.active), "offset": offset, "start": load_start,
                             "duration": self.duration, "mode": self.mode, "note": self.note,
                             "warnings": list(self.warnings)}

    def load_info(self) -> dict:
        with self._lock:
            return dict(self._current)

    def restart(self, offset: float) -> dict:
        """A stream again from ``offset`` (seconds into the episode): new addresses, the old stream stops."""
        if not self.streamed:
            raise ValueError("only a stream starts again")
        with self._lock:
            old = [self._current.get("url", "")] + [t["trackContentId"] for t in self._current.get("tracks") or []]
        self._register(offset)
        for u in old:
            if u:
                self.server.remove(u)
        return self.load_info()

    def urls(self) -> List[str]:
        """Every address this video had (a jump in a stream makes a new one)."""
        with self._lock:
            return list(self._media_urls)

    def activity(self) -> dict:
        total = {"requests": 0, "bytes": 0, "last": 0.0}
        for u in self.urls():
            a = self.server.activity(u)
            total["requests"] += a["requests"]
            total["bytes"] += a["bytes"]
            total["last"] = max(total["last"], a["last"])
        return total

    def release(self) -> None:
        """Forgets every address of this video and stops its ffmpeg."""
        with self._lock:
            if self._released:
                return
            self._released = True
            urls = list(self._media_urls) + list(self._sub_urls)
        for u in urls:
            self.server.remove(u)


def _ext(name: str) -> str:
    base = os.path.basename(name or "")
    if base.lower().endswith(".part"):
        base = base[:-5]
    return os.path.splitext(base)[1].lower()


def prepare_item(server: CastServer, path: str = "", *, url: str = "", relay=None, name: str = "",
                 locate: Optional[Callable[[], str]] = None, title: str = "", start: float = 0.0,
                 caps: Optional[dict] = None, ffmpeg: Optional[str] = None, ffprobe: Optional[str] = None,
                 tv_ip: str = "", local_ip: str = "", sub_langs: Sequence[str] = (), subs_on: bool = True,
                 audio_langs: Sequence[str] = (), tv_copy: Optional[Callable[[str], Optional[str]]] = None,
                 sub_files: Sequence[Tuple[str, Callable[[], bytes]]] = (), sub_path: str = "") -> Item:
    """Decides how a video reaches a Cast device and registers its addresses (see the module text).

    The video is a file on this PC (``path``; ``locate`` asks for its path again at every request, for
    a cached Internet Archive file that may move to the Keep folder) or an address (``url`` with
    ``relay``, a ``tvstream.Relay`` that answers the device's requests). ``name``: the file's name
    (its extension says what it is; a cache file ends in ``.part``). ``sub_path``: where to look for
    subtitle files next to the video (default ``path``). Raises :class:`TvError`.
    """
    caps = caps or dict(DEFAULT_CAPS)
    name = name or os.path.basename(path or urllib.parse.urlsplit(url).path) or "video"
    ext = _ext(name)
    warnings: List[str] = []
    if path:
        current = locate() if locate is not None else path
        if not current or not os.path.isfile(current):
            raise TvError(f"AniBox can't find \"{os.path.basename(name)}\". Is the drive connected?", "file")
        source = current
        info = probe(current, ffprobe)
    elif url:
        source = url
        if ext in MP4_EXTS or not (ffmpeg and ffprobe):
            info = None  # archive.org's MP4 copies (H.264/AAC) go as they are, through the relay
        else:
            info = probe(url, ffprobe)
    else:
        raise TvError("Nothing to play.", "file")
    if relay is None and not path:
        raise TvError("AniBox can't send that address to a Chromecast.", "file")
    audio_index = pick_audio(info, audio_langs)
    plan = decide(info, caps, ext, bool(ffmpeg), audio_index)
    if info is None and url:
        # An address AniBox didn't look into (archive.org's MP4 copy, or no ffmpeg): as it is, through the relay.
        plan = dict(plan, mode=DIRECT, mime="video/mp4" if ext in MP4_EXTS else tv.mime_for(name),
                    why="" if ext in MP4_EXTS else "sent as it is (AniBox couldn't look inside it)")
    mode = plan["mode"]
    if plan.get("why") and mode != CONVERT:
        warnings.append(plan["why"])
    orig_info = info
    if mode == CONVERT and path:
        copy = (tv_copy or tv_copy_for)(path)
        copy_info = probe(copy, ffprobe) if copy else None
        if copy and copy_info:
            copy_plan = decide(copy_info, caps, _ext(copy), bool(ffmpeg), pick_audio(copy_info, audio_langs))
            if copy_plan["mode"] in (DIRECT, REMUX):
                log.info("Cast: playing the TV copy of %s", os.path.basename(path))
                source, info, plan, mode, locate = copy, copy_info, copy_plan, TVCOPY, None
                name = os.path.basename(copy)
    if mode == NONE:
        raise TvError(f"This video can't play on a Chromecast: {plan['why']}.", "format")
    if mode == CONVERT and not ffmpeg:
        raise TvError("This video needs converting for a Chromecast, and AniBox needs ffmpeg for that "
                      "(Settings → Player → Download ffmpeg).", "format")
    if mode == CONVERT:
        warnings.append(f"converting the picture: {plan['why']}")
    if plan["mode"] in (REMUX, CONVERT) and relay is not None and not path:
        relay = None  # ffmpeg reads the address itself
    # Subtitles always come from the original file (a TV copy has the same timing).
    subs, notes = gather_subtitles(sub_path or path or "", orig_info if path else None, ffmpeg, sub_langs, sub_files,
                                   embedded_from=path or "")
    warnings += notes
    duration = float((info or {}).get("duration") or 0.0)
    return Item(server, mode=mode, plan=plan, source=source, name=name, title=title, duration=duration, ffmpeg=ffmpeg,
                ffprobe=ffprobe, tv_ip=tv_ip, local_ip=local_ip, subs=subs, subs_on=subs_on, warnings=warnings,
                note="playing the TV copy" if mode == TVCOPY else "", start=start, locate=locate,
                relay=relay if plan["mode"] == DIRECT else None)
