"""Languages: dub/sub badges and subtitle types per show.

Part of the App class (see server.py); the methods use the App's attributes.
"""

from __future__ import annotations

import logging
import threading
from typing import Optional

from . import languages
from .apierror import ApiError

log = logging.getLogger("anibox.server")


class RoutesLangsMixin:
    def _langs(self, show: dict, stored: Optional[dict] = None) -> dict:
        st = (self.store.all_show_langs() if stored is None else stored).get(show["id"])
        guess = show.get("name_langs") or languages.from_names(
            [show["library"], show["folder"]] + [e["file"] for e in show["episodes"]])
        if st and st.get("manual"):
            m = st["manual"]
            audio, subs, types, src = m["audio"], m["subs"], m.get("subtypes") or [], "manual"
        elif st and (st["audio"] or st["subs"] or st.get("subtypes")):
            audio, subs, types, src = st["audio"], st["subs"], st.get("subtypes") or [], st["source"]
        else:
            audio, subs, types, src = guess["audio"], guess["subs"], guess.get("subtypes") or [], "names"
        return {"audio": audio, "subs": subs, "subtypes": types, "langSource": src,
                "subWarn": languages.picky(types), "badges": languages.badges(audio, subs, types)}

    def _cards_with_langs(self, pairs) -> list:
        """[(show, card)] -> cards with the language badges added (one database read for all)."""
        stored = self.store.all_show_langs()
        out = []
        for show, card in pairs:
            card.update(self._langs(show, stored))
            out.append(card)
        return out

    def _langs_info(self, show_id: str) -> dict:
        show = self.library.show(show_id)
        if not show:
            raise ApiError("Show not found", 404)
        st = self.store.all_show_langs().get(show_id) or {}
        if st.get("source") not in ("file", "player") and self._lang_busy.get(show_id) != "loading":
            self._probe_langs(show)
        out = self._langs(show)
        out.update(state=self._lang_busy.get(show_id) or "done", manual=bool(st.get("manual")),
                   names=languages.NAMES, typeNames=languages.SUBTYPE_NAMES, compat=languages.COMPAT)
        return out

    def _probe_langs(self, show: dict) -> None:
        """Read the track list of the first and a middle episode (a few hundred KB each), in the background."""
        self._lang_busy[show["id"]] = "loading"

        def run():
            audio, subs, types, found = set(), set(), set(), False
            eps = show["episodes"]
            for ep in ([eps[0], eps[len(eps) // 2]] if len(eps) > 1 else eps):
                tracks = languages.probe(ep["path"])
                if tracks:
                    found = True
                    sm = languages.summarize(tracks)
                    audio |= set(sm["audio"])
                    subs |= set(sm["subs"])
                    types |= set(sm["subtypes"])
                for code, kind in languages.external_subtitles(ep["path"]):
                    types.add(kind)
                    subs |= {code} - {""}
            guess = show.get("name_langs") or {}
            if found and not types and (guess.get("subs") or "hard" in (guess.get("subtypes") or [])):
                types.add("hard")  # the names say subtitled, but the files carry none: burned into the picture
            if found or types:
                self.store.set_show_langs(show["id"], audio, subs, "file", types)
                log.info("Languages of %s from its files: audio %s, subtitles %s %s", show["id"], sorted(audio),
                         sorted(subs), sorted(types))
            self._lang_busy.pop(show["id"], None)

        threading.Thread(target=run, daemon=True, name="anibox-langs").start()

    def _langs_post(self, body: dict) -> dict:
        show = self.library.show(str(body.get("show") or ""))
        if not show:
            raise ApiError("Show not found", 404)
        if body.get("reset"):
            self.store.set_manual_langs(show["id"], None, None)
        elif body.get("probe"):
            self._probe_langs(show)
        else:
            clean = lambda xs: sorted({languages.lang(str(x)) for x in xs or []} - {""})
            types = sorted({str(t) for t in body.get("subtypes") or []} & set(languages.SUBTYPES))
            self.store.set_manual_langs(show["id"], clean(body.get("audio")), clean(body.get("subs")), types)
        return {"ok": True, **self._langs(show)}
