"""The error the API answers with: a short message for the page, an HTTP status and a reason code."""


class ApiError(Exception):
    def __init__(self, message: str, status: int = 400, reason: str = ""):
        super().__init__(message)
        self.status = status
        self.reason = reason  # for the page, e.g. "pairing_required"
