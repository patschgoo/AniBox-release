"""Your anime lists in AniBox: reading them (cached), signing in, and sending what you watched back.

Everything lives in ``<data>/lists/``:

- ``mal-list.json`` / ``anilist-list.json``: the last copy of each list (read again after an hour, or
  when you press Refresh).
- ``accounts.json``: the sign-ins. The tokens in it are encrypted for the current Windows user
  (``anibox_check.secret``, Windows DPAPI); on Linux/macOS they stay as text in a file only you may
  read (chmod 600). The file also says whether sync is on for each account (off until you turn it on).
- ``queue.json``: changes waiting to be sent (kept, so they're sent after a restart too).
- ``sync-log.jsonl``: the changes AniBox made (or tried to make) to each account.

Sending (``ListService``):

- Nothing is ever written to an account whose sync is off. Turning it on shows what will change first
  (``preview`` + ``apply``); "Sync now" does the same.
- When the player marks an episode as watched (``Store.watched_hooks``), an update is queued for each
  account with sync on, but only for the profile that owns the account: the one that was active when
  it was connected (``profile`` in ``accounts.json``; accounts from before profiles belong to
  ``main``). What another profile watches never reaches these lists, and previews and updates are
  always worked out from the owner's progress. Right before writing, AniBox reads that one entry
  again and decides with ``animelists.plan_change`` (never lower, never remove, never a score; plan-to-watch → watching;
  completed only touched with the rewatch setting).
- Updates go out on a background thread, one at a time, with retries when the site is busy or
  unreachable.
"""

from __future__ import annotations

import copy
import hmac
import json
import logging
import os
import secrets as pysecrets
import threading
import time
from pathlib import Path
from typing import Dict, List, Optional

from anibox_check import secret  # the package's __init__ makes anibox_check importable

from .animelists import (
    SOURCES, AniListClient, ListError, MalClient, anilist_fields, compare, describe, marks_for, mal_fields,
    numbering_fits, pkce_pair, plan_change, show_numbers, watched_upto,
)
from .store import MAIN

log = logging.getLogger("anibox.lists")

MAX_AGE = 3600  # a list copy older than this is read again when a page needs it
SIGN_IN_WAIT = 15 * 60  # a sign-in started in AniBox must come back within this time
PLAN_AGE = 3600  # a preview can be confirmed for this long
SAME_EPISODE = 6 * 3600  # the player saves "watched" several times near the end: one update per episode
RETRY_WAIT = (15, 60, 300, 900, 1800, 3600, 3600, 3600)
SPACING = {"mal": 1.0, "anilist": 2.2}  # seconds between writes (AniList allows 30 requests a minute now)
LOG_KEEP = 1000
SECRET_KEYS = ("access", "refresh")
NAMES = SOURCES
USERNAME_SETTING = {"mal": "mal_username", "anilist": "anilist_username"}
CLIENT_SETTING = {"mal": "mal_client_id", "anilist": "anilist_client_id"}


def _write_json(path: Path, data, private: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".part")
    flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC
    fd = os.open(str(tmp), flags, 0o600 if private else 0o644)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)
    if private:
        try:
            os.chmod(tmp, 0o600)
        except OSError:
            pass
    os.replace(tmp, path)


def _read_json(path: Path, default):
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default
    return data if isinstance(data, type(default)) else default


class Accounts:
    """The sign-ins, encrypted on disk. ``get`` hands back plain tokens; they never go to the page."""

    def __init__(self, path: Path):
        self.path = path
        self._lock = threading.RLock()
        self.problems: Dict[str, str] = {}
        self._data: Dict[str, dict] = {}
        raw = _read_json(path, {})
        for src, info in raw.items():
            if src not in SOURCES or not isinstance(info, dict):
                continue
            info = dict(info)
            try:
                for k in SECRET_KEYS:
                    if info.get(k):
                        info[k] = secret.unprotect(str(info[k]))
            except secret.SecretError as exc:
                log.warning("Can't use the saved %s sign-in: %s", NAMES[src], exc)
                self.problems[src] = f"The saved sign-in can't be used on this PC ({exc}) Connect again."
                continue
            if info.get("access"):
                self._data[src] = info

    def get(self, src: str) -> Optional[dict]:
        with self._lock:
            info = self._data.get(src)
            return dict(info) if info else None

    def set(self, src: str, **changes) -> dict:
        with self._lock:
            info = dict(self._data.get(src) or {})
            info.update(changes)
            new = dict(self._data, **{src: info})
            self._save(new)  # raises before anything changes if Windows can't encrypt
            self._data = new
            if changes.get("access"):
                self.problems.pop(src, None)
            return dict(info)

    def remove(self, src: str) -> None:
        with self._lock:
            new = {k: v for k, v in self._data.items() if k != src}
            self._save(new)
            self._data = new
            self.problems.pop(src, None)

    def _save(self, data: Dict[str, dict]) -> None:
        out = copy.deepcopy(data)
        for info in out.values():
            for k in SECRET_KEYS:
                if info.get(k):
                    info[k] = secret.protect(str(info[k]))  # before writing: never a plain token on Windows
        _write_json(self.path, out, private=True)


class SyncLog:
    """The last changes made to each account (``sync-log.jsonl``, newest at the end)."""

    def __init__(self, path: Path):
        self.path = path
        self._lock = threading.Lock()

    def add(self, src: str, mal_id: str, title: str, before: str, after: str, result: str, message: str = "") -> None:
        line = json.dumps({"t": time.time(), "src": src, "mal_id": str(mal_id), "title": title, "from": before,
                           "to": after, "result": result, "message": message}, ensure_ascii=False)
        with self._lock:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(line + "\n")
            try:
                lines = self.path.read_text(encoding="utf-8").splitlines()
                if len(lines) > 2 * LOG_KEEP:
                    self.path.write_text("\n".join(lines[-LOG_KEEP:]) + "\n", encoding="utf-8")
            except OSError:
                pass

    def tail(self, src: str, n: int = 30) -> List[dict]:
        try:
            lines = self.path.read_text(encoding="utf-8").splitlines()
        except OSError:
            return []
        out = []
        for line in reversed(lines):
            try:
                row = json.loads(line)
            except ValueError:
                continue
            if row.get("src") == src:
                out.append(row)
                if len(out) >= n:
                    break
        return out


class ListService:
    def __init__(self, store, library, folder: Path, mal: Optional[MalClient] = None,
                 anilist: Optional[AniListClient] = None, spacing: Optional[Dict[str, float]] = None):
        self.store = store
        self.library = library
        self.folder = folder
        folder.mkdir(parents=True, exist_ok=True)
        self.clients = {"mal": mal or MalClient(), "anilist": anilist or AniListClient()}
        self.accounts = Accounts(folder / "accounts.json")
        self.log = SyncLog(folder / "sync-log.jsonl")
        self.spacing = dict(SPACING if spacing is None else spacing)
        self._lock = threading.RLock()
        self._token_lock = threading.Lock()
        self._loading: Dict[str, dict] = {s: {"state": "idle"} for s in SOURCES}
        self._cache: Dict[str, Optional[dict]] = {}
        self._pending: Dict[str, dict] = {}  # sign-ins waiting for the browser to come back
        self._plans: Dict[str, dict] = {}  # previews waiting for "OK"
        self._recent: Dict[tuple, float] = {}  # (profile, episode key) -> when it was last finished
        self._queue: List[dict] = _read_json(folder / "queue.json", [])
        self._sending: Dict[str, str] = {s: "" for s in SOURCES}
        self._last_write: Dict[str, float] = {s: 0.0 for s in SOURCES}
        self._wake = threading.Event()
        self._busy = threading.Lock()
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        if self._queue:
            self._ensure_worker()

    # -- settings -------------------------------------------------------------------------------------

    def _settings(self) -> dict:
        return self.store.settings()

    def username(self, src: str) -> str:
        return str(self._settings().get(USERNAME_SETTING[src]) or "").strip()

    def configured(self, src: str) -> bool:
        return bool(self.username(src) or self.accounts.get(src))

    def owner(self, src: str) -> str:
        """The profile whose watching this account follows (the one active when it was connected)."""
        return str((self.accounts.get(src) or {}).get("profile") or MAIN)

    def default_source(self) -> str:
        s = self._settings()
        choice = s.get("lists_source") or ""
        if choice in SOURCES and self.configured(choice):
            return choice
        for src in SOURCES:
            if self.configured(src):
                return src
        return choice if choice in SOURCES else "mal"

    # -- tokens ---------------------------------------------------------------------------------------

    def _token(self, src: str, failed: str = "") -> str:
        """A working access token. MyAnimeList's is renewed when it ran out or the site refused ``failed``
        (one renewal at a time: a new MyAnimeList token cancels the one before). Raises ListError(auth)."""
        with self._token_lock:
            return self._token_locked(src, failed)

    def _token_locked(self, src: str, failed: str) -> str:
        acct = self.accounts.get(src)
        if not acct:
            raise ListError(f"Connect your {NAMES[src]} account first.", auth=True)
        if failed and acct.get("access") != failed:
            return str(acct["access"])  # renewed meanwhile by another request
        if src == "mal" and (failed or float(acct.get("expires") or 0) < time.time() + 120):
            if not acct.get("refresh"):
                raise ListError("MyAnimeList's sign-in ran out. Connect again.", auth=True)
            client_id = str(self._settings().get("mal_client_id") or "")
            try:
                tok = self.clients["mal"].refresh(client_id, acct["refresh"])
            except ListError as exc:
                if exc.auth:
                    self._problem(src, "MyAnimeList stopped accepting AniBox's sign-in. Connect again.")
                raise
            acct = self.accounts.set(src, access=tok["access_token"], refresh=tok.get("refresh_token") or acct["refresh"],
                                     expires=time.time() + float(tok.get("expires_in") or 3600))
            log.info("MyAnimeList sign-in renewed")
        elif src == "anilist" and float(acct.get("expires") or 0) and float(acct["expires"]) < time.time():
            self._problem(src, "AniList's sign-in ran out (it lasts a year). Connect again.")
            raise ListError("AniList's sign-in ran out. Connect again.", auth=True)
        return str(acct["access"])

    def _problem(self, src: str, text: str) -> None:
        self.accounts.problems[src] = text
        log.warning("%s: %s", NAMES[src], text)

    def _call(self, src: str, fn):
        """``fn(token)``, once more with a renewed token if the site says the sign-in is no longer good."""
        token = self._token(src)
        try:
            return fn(token)
        except ListError as exc:
            if not exc.auth or src != "mal":
                if exc.auth:
                    self._problem(src, f"{NAMES[src]} stopped accepting AniBox's sign-in. Connect again.")
                raise
        return fn(self._token(src, failed=token))

    # -- reading lists ----------------------------------------------------------------------------------

    def _cache_path(self, src: str) -> Path:
        return self.folder / f"{src}-list.json"

    def _who(self, src: str) -> str:
        acct = self.accounts.get(src)
        return f"account:{acct.get('user', '')}" if acct else f"user:{self.username(src).casefold()}"

    def cached(self, src: str) -> Optional[dict]:
        """The last copy of the list (None if there's none for the current user name / account)."""
        with self._lock:
            if src not in self._cache:
                self._cache[src] = _read_json(self._cache_path(src), {}) or None
            c = self._cache[src]
        return c if c and c.get("who") == self._who(src) else None

    def stale(self, src: str) -> bool:
        c = self.cached(src)
        return not c or time.time() - float(c.get("fetched") or 0) > MAX_AGE

    def fetch(self, src: str) -> List[dict]:
        """Read the whole list now (blocks). Your own list with the sign-in, else the user name's public one."""
        client = self.clients[src]
        who = self._who(src)
        if self.accounts.get(src):
            if src == "mal":
                entries = self._call(src, lambda t: client.fetch_list(token=t))
            else:
                acct = self.accounts.get(src)
                entries = self._call(src, lambda t: client.fetch_list(token=t, user_id=acct.get("user_id")))
        elif src == "mal":
            entries = client.fetch_list(self.username(src), client_id=str(self._settings().get("mal_client_id") or ""))
        else:
            entries = client.fetch_list(self.username(src))
        data = {"who": who, "fetched": time.time(), "entries": entries}
        with self._lock:
            self._cache[src] = data
            _write_json(self._cache_path(src), data)
        log.info("%s list read: %d entries", NAMES[src], len(entries))
        return entries

    def refresh(self, src: str) -> dict:
        """Read the list again in the background (unless that's already running)."""
        with self._lock:
            if self._loading[src].get("state") == "loading":
                return dict(self._loading[src])
            if not self.configured(src):
                self._loading[src] = {"state": "idle"}
                return dict(self._loading[src])
            self._loading[src] = {"state": "loading"}

        def run():
            try:
                self.fetch(src)
                state = {"state": "done"}
            except ListError as exc:
                state = {"state": "error", "message": str(exc)}
            except Exception as exc:  # never let this take AniBox down
                log.exception("Reading the %s list failed", NAMES[src])
                state = {"state": "error", "message": str(exc) or exc.__class__.__name__}
            state.update(who=self._who(src), time=time.time())
            with self._lock:
                self._loading[src] = state

        threading.Thread(target=run, daemon=True, name=f"anibox-list-{src}").start()
        return {"state": "loading"}

    def ensure_fresh(self, src: str) -> None:
        """Read the list again in the background if the copy is old. After an error, only once the user
        name changed or 10 minutes passed (Refresh always tries)."""
        st = self._loading[src]
        if st.get("state") == "error" and st.get("who") == self._who(src) and time.time() - float(st.get("time") or 0) < 600:
            return
        if self.configured(src) and self.stale(src):
            self.refresh(src)

    def entries(self, src: str) -> List[dict]:
        return list((self.cached(src) or {}).get("entries") or [])

    def _remember(self, src: str, mal_id: str, state: dict, title: str = "", anilist_id=None) -> None:
        """Keep the list copy in step with a change AniBox just made."""
        with self._lock:
            c = self.cached(src)
            if not c:
                return
            for e in c["entries"]:
                if e.get("mal_id") == str(mal_id):
                    e.update(status=state["status"], progress=state["progress"], rewatching=state["rewatching"],
                             repeat=state.get("repeat", e.get("repeat")))
                    break
            else:
                c["entries"].append({"mal_id": str(mal_id), "anilist_id": anilist_id, "title": title,
                                     "status": state["status"], "progress": state["progress"],
                                     "episodes": state.get("episodes") or 0, "rewatching": state["rewatching"],
                                     "repeat": state.get("repeat", 0)})
            _write_json(self._cache_path(src), c)

    # -- the pages -----------------------------------------------------------------------------------

    def sources_info(self) -> dict:
        out = {}
        for src in SOURCES:
            acct = self.accounts.get(src) or {}
            c = self.cached(src)
            out[src] = {"name": NAMES[src], "user": acct.get("user") or self.username(src),
                        "configured": self.configured(src), "connected": bool(acct),
                        "fetched": (c or {}).get("fetched"), "count": len((c or {}).get("entries") or []),
                        "state": dict(self._loading[src])}
        return out

    def view(self, src: str, refresh: bool = False) -> dict:
        if src not in SOURCES:
            src = self.default_source()
        if refresh:
            self.refresh(src)
        else:
            self.ensure_fresh(src)
        entries = self.entries(src)
        progress = self.store.all_progress()
        sections = compare(entries, self.library.shows(all_libraries=True), self.library.shows(), progress) \
            if self.cached(src) else {"notOnDrives": [], "behind": [], "notOnList": []}
        for e in sections["notOnDrives"]:
            e["text"] = describe(e)
        return {"source": src, "sources": self.sources_info(), "sections": sections}

    def badges(self) -> dict:
        """mal id -> [status, progress, episodes, rewatching] per list, for the cards (no network)."""
        out = {"primary": self.default_source()}
        for src in SOURCES:
            self.ensure_fresh(src)
            out[src] = {e["mal_id"]: [e["status"], e["progress"], e["episodes"], e["rewatching"]]
                        for e in self.entries(src) if e.get("mal_id")} if self.cached(src) else None
        return out

    def show_lines(self, show: dict) -> List[dict]:
        out = []
        mal_id = str(show.get("mal_id") or "")
        if not mal_id:
            return out
        for src in SOURCES:
            if not self.cached(src):
                continue
            e = next((x for x in self.entries(src) if x.get("mal_id") == mal_id), None)
            url = (f"https://myanimelist.net/anime/{mal_id}" if src == "mal" else
                   f"https://anilist.co/anime/{e['anilist_id']}" if e and e.get("anilist_id") else "")
            out.append({"source": src, "name": NAMES[src], "text": describe(e), "on": bool(e), "url": url})
        return out

    def mark(self, src: str, show_ids: List[str]) -> dict:
        """Mark what the list counts as watched as watched in AniBox too. Only ever marks."""
        if not self.cached(src):
            raise ListError("Read the list first.")
        shows = self.library.shows()
        todo = marks_for(self.entries(src), shows, self.store.all_progress(), show_ids)
        count = 0
        for show_id, keys in todo.items():
            if keys:
                self.store.set_watched(keys, show_id, True)  # True only: nothing is ever un-marked here
                count += len(keys)
        log.info("Marked %d episodes in %d shows as watched from the %s list", count, len(todo), NAMES[src])
        return {"marked": count, "shows": len(todo)}

    # -- signing in -----------------------------------------------------------------------------------

    def connect(self, src: str) -> dict:
        """Start a sign-in: the address to open in the browser. The site sends the browser back to AniBox."""
        client_id = str(self._settings().get(CLIENT_SETTING[src]) or "").strip()
        if not client_id:
            raise ListError("Add the Client ID first (see the steps below)." if src == "anilist" else
                            "Add your MyAnimeList Client ID first (Settings → MyAnimeList).")
        profile = getattr(self.store, "profile", MAIN)  # the account will belong to the profile active now
        with self._lock:
            if src == "mal":
                verifier, challenge, _ = pkce_pair()
                state = pysecrets.token_urlsafe(24)
                self._pending[src] = {"time": time.time(), "verifier": verifier, "state": state, "profile": profile}
                url = self.clients["mal"].authorize_url(client_id, challenge, state)
            else:
                self._pending[src] = {"time": time.time(), "profile": profile}
                url = self.clients["anilist"].authorize_url(client_id)
        log.info("%s sign-in started", NAMES[src])
        return {"url": url}

    def _take_pending(self, src: str) -> dict:
        with self._lock:
            p = self._pending.pop(src, None)
        if not p or time.time() - p["time"] > SIGN_IN_WAIT:
            raise ListError("This sign-in wasn't started in AniBox (or it took too long). In AniBox, go to "
                            "Settings → Your anime lists and click Connect again.")
        return p

    def finish_mal(self, code: str, state: str, error: str = "") -> dict:
        with self._lock:
            p = self._pending.get("mal")
            if not p or not hmac.compare_digest(str(p.get("state") or ""), str(state or "")):
                raise ListError("This sign-in wasn't started in AniBox (or it took too long). In AniBox, go to "
                                "Settings → Your anime lists and click Connect again.")
        p = self._take_pending("mal")
        if error:
            raise ListError("You didn't allow AniBox on MyAnimeList, so nothing changed.")
        if not code:
            raise ListError("MyAnimeList didn't send a sign-in code.")
        client_id = str(self._settings().get("mal_client_id") or "")
        tok = self.clients["mal"].exchange(client_id, code, p["verifier"])
        access = tok["access_token"]
        name = self.clients["mal"].me(access)
        return self._save_account("mal", name, profile=p.get("profile"), access=access,
                                  refresh=tok.get("refresh_token") or "",
                                  expires=time.time() + float(tok.get("expires_in") or 3600))

    def finish_anilist(self, token: str, expires_in=None, error: str = "") -> dict:
        p = self._take_pending("anilist")
        if error:
            raise ListError("You didn't allow AniBox on AniList, so nothing changed.")
        if not token:
            raise ListError("AniList didn't send a sign-in.")
        viewer = self.clients["anilist"].viewer(token)
        try:
            life = float(expires_in or 0) or 365 * 86400
        except (TypeError, ValueError):
            life = 365 * 86400
        return self._save_account("anilist", viewer["name"], profile=p.get("profile"), access=token,
                                  user_id=viewer["id"], expires=time.time() + life)

    def _save_account(self, src: str, name: str, profile: Optional[str] = None, **tokens) -> dict:
        old = self.accounts.get(src) or {}
        profile = str(profile or MAIN)
        same = old.get("user") and old.get("user") == name and str(old.get("profile") or MAIN) == profile
        try:
            self.accounts.set(src, user=name, connected=time.time(), sync=bool(same and old.get("sync")),
                              since=old.get("since") if same else 0, profile=profile, **tokens)
        except secret.SecretError as exc:
            raise ListError(f"AniBox couldn't keep the sign-in safe, so it didn't save it ({exc}).")
        with self._lock:
            self._cache.pop(src, None)
        log.info("%s connected as %s", NAMES[src], name)
        if self.queued():
            self._ensure_worker()  # updates that waited for a new sign-in can go now
        self.refresh(src)
        return {"ok": True, "user": name, "source": src}

    def disconnect(self, src: str) -> dict:
        self.accounts.remove(src)
        with self._lock:
            self._queue = [j for j in self._queue if j["src"] != src]
            self._save_queue()
            self._cache.pop(src, None)
            self._plans = {k: v for k, v in self._plans.items() if v["src"] != src}
        log.info("%s disconnected", NAMES[src])
        return {"ok": True}

    def account_info(self, src: str) -> dict:
        acct = self.accounts.get(src) or {}
        with self._lock:
            pending = sum(1 for j in self._queue if j["src"] == src)
            waiting = src in self._pending and time.time() - self._pending[src]["time"] < SIGN_IN_WAIT
        return {"name": NAMES[src], "connected": bool(acct), "user": acct.get("user") or "",
                "sync": bool(acct.get("sync")), "since": acct.get("since") or 0, "profile": self.owner(src),
                "problem": self.accounts.problems.get(src, ""), "queued": pending, "sending": self._sending[src],
                "signingIn": waiting, "log": self.log.tail(src),
                "encrypted": secret.available()}

    # -- sync: preview, OK, and the queue ---------------------------------------------------------------

    def _groups(self) -> Dict[str, List[dict]]:
        groups: Dict[str, List[dict]] = {}
        for sh in self.library.shows():
            if sh.get("mal_id"):
                groups.setdefault(str(sh["mal_id"]), []).append(sh)
        return groups

    def preview(self, src: str) -> dict:
        """Everything a sync would change on this account right now (reads the list fresh, writes nothing)."""
        if not self.accounts.get(src):
            raise ListError(f"Connect your {NAMES[src]} account first.")
        entries = {e["mal_id"]: e for e in self.fetch(src) if e.get("mal_id")}
        progress = self.store.all_progress(profile=self.owner(src))  # the owner's watching, whoever looks
        rewatch = bool(self._settings().get("lists_rewatch"))
        changes, skipped, same = [], [], 0
        for mal_id, shows in self._groups().items():
            watched = watched_upto(shows, progress)
            if not watched:
                continue
            cur = entries.get(mal_id)
            title = (cur or {}).get("title") or shows[0].get("title") or shows[0]["folder"]
            total = (cur or {}).get("episodes") or shows[0].get("mal_episodes") or 0
            if not all(numbering_fits(sh, total) for sh in shows):
                skipped.append({"mal_id": mal_id, "title": title,
                                "why": f"the file numbers don't fit the {total} episodes on {NAMES[src]}"})
                continue
            new, why = plan_change(cur, watched, total, rewatch)
            if new:
                changes.append({"mal_id": mal_id, "title": title, "from": describe(cur), "to": describe(new),
                                "add": cur is None})
            else:  # already as far, or completed (rewatches only count while you watch)
                same += 1
        changes.sort(key=lambda c: c["title"].casefold())
        skipped.sort(key=lambda c: c["title"].casefold())
        token = pysecrets.token_urlsafe(12)
        with self._lock:
            now = time.time()
            self._plans = {k: v for k, v in self._plans.items() if now - v["time"] < PLAN_AGE}
            self._plans[token] = {"src": src, "time": now, "changes": changes}
        acct = self.accounts.get(src) or {}
        return {"token": token, "source": src, "user": acct.get("user", ""), "changes": changes,
                "skipped": skipped, "same": same, "sync": bool(acct.get("sync"))}

    def apply(self, src: str, token: str = "", turn_on: bool = False) -> dict:
        """The user's OK: turn sync on and/or send the changes of a preview."""
        if not self.accounts.get(src):
            raise ListError(f"Connect your {NAMES[src]} account first.")
        acct = self.accounts.get(src) or {}
        if not acct.get("sync") and not turn_on:
            raise ListError("Sync is off for this account. Turn it on first.")
        plan = None
        if token:
            with self._lock:
                plan = self._plans.pop(token, None)
            if not plan or plan["src"] != src or time.time() - plan["time"] > PLAN_AGE:
                raise ListError("This preview is too old. Look at the changes again.")
        if turn_on and not acct.get("sync"):
            self.accounts.set(src, sync=True, since=time.time())
            log.info("%s sync turned on", NAMES[src])
        queued = 0
        if plan:
            with self._lock:
                for ch in plan["changes"]:
                    self._enqueue({"src": src, "mal_id": ch["mal_id"], "kind": "plan", "title": ch["title"]})
                    queued += 1
                self._save_queue()
            self._ensure_worker()
        return {"ok": True, "queued": queued}

    def sync_off(self, src: str) -> dict:
        if self.accounts.get(src):
            self.accounts.set(src, sync=False)
        with self._lock:
            self._queue = [j for j in self._queue if j["src"] != src]
            self._save_queue()
        log.info("%s sync turned off", NAMES[src])
        return {"ok": True}

    def on_watched(self, key: str, show_id: str, profile: Optional[str] = None) -> None:
        """Called by the Store when the player marks an episode as watched (``Store.watched_hooks``),
        with the profile it was watched in. Only accounts that profile owns get an update."""
        try:
            profile = str(profile or getattr(self.store, "profile", MAIN))
            on = [src for src in SOURCES if (self.accounts.get(src) or {}).get("sync") and self.owner(src) == profile]
            if not on:
                return  # nothing is ever written while sync is off, nor for another profile's watching
            now = time.time()
            with self._lock:
                if now - self._recent.get((profile, key), 0) < SAME_EPISODE:
                    return
                self._recent[(profile, key)] = now
            show = self.library.show(show_id)
            if not show or not show.get("mal_id") or show["library"] not in self.library.selected_libraries():
                return
            number = next((n for ep, n in show_numbers(show) if ep["key"] == key), None)
            if not number:
                return
            with self._lock:
                for src in on:
                    self._enqueue({"src": src, "mal_id": str(show["mal_id"]), "kind": "event", "finished": number,
                                   "title": show.get("title") or show["folder"]})
                self._save_queue()
            self._ensure_worker()
        except Exception:
            log.exception("Couldn't queue the list update for %s", key)

    def _enqueue(self, job: dict) -> None:
        """One waiting update per account and entry: a newer one replaces the older (the latest episode wins)."""
        job.setdefault("tries", 0)
        job.setdefault("due", 0.0)
        for i, old in enumerate(self._queue):
            if old["src"] == job["src"] and old["mal_id"] == job["mal_id"]:
                if job["kind"] == "event":  # it knows which episode was just finished (rewatches need that)
                    self._queue[i] = job
                return
        self._queue.append(job)

    def _save_queue(self) -> None:
        try:
            _write_json(self.folder / "queue.json", self._queue)
        except OSError as exc:
            log.warning("Couldn't keep the list updates waiting to be sent: %s", exc)

    def queued(self) -> List[dict]:
        with self._lock:
            return [dict(j) for j in self._queue]

    # -- the background sender -------------------------------------------------------------------------

    def _ensure_worker(self) -> None:
        with self._lock:
            if self._thread and self._thread.is_alive():
                self._wake.set()
                return
            self._thread = threading.Thread(target=self._loop, daemon=True, name="anibox-list-sync")
            self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        self._wake.set()

    def _loop(self) -> None:
        while not self._stop.is_set():
            wait = self.run_once()
            if wait is None:  # nothing left: the thread ends, a new update starts it again
                with self._lock:
                    if not self._queue:
                        self._thread = None
                        return
                wait = 30
            self._wake.wait(max(0.05, min(wait, 60)))
            self._wake.clear()

    def run_once(self) -> Optional[float]:
        """Send every update that is due. Returns seconds until the next one is due (None: queue empty)."""
        with self._busy:
            while not self._stop.is_set():
                now = time.time()
                with self._lock:
                    if not self._queue:
                        return None
                    ready = [j for j in self._queue if j["due"] <= now and not self.accounts.problems.get(j["src"])]
                    if not ready:
                        dues = [j["due"] for j in self._queue if not self.accounts.problems.get(j["src"])]
                        return max(1.0, min(dues) - now) if dues else 60.0
                    job = ready[0]
                gap = self.spacing.get(job["src"], 1.0) - (time.time() - self._last_write[job["src"]])
                if gap > 0:
                    time.sleep(gap)
                self._sending[job["src"]] = f"Sending {job['title']} …"
                try:
                    done = self._send(job)
                finally:
                    self._sending[job["src"]] = ""
                    self._last_write[job["src"]] = time.time()
                with self._lock:
                    if done:
                        self._queue = [j for j in self._queue if j is not job]
                    self._save_queue()
            return None

    def _send(self, job: dict) -> bool:
        """Read the entry fresh, apply the rules, write. True when the job is finished (sent or not needed)."""
        src, mal_id = job["src"], job["mal_id"]
        acct = self.accounts.get(src)
        if not acct or not acct.get("sync"):
            return True  # sync was turned off: nothing is written
        client = self.clients[src]
        try:
            cur, info = self._call(src, lambda t: client.entry(mal_id, t))
            title = (cur or {}).get("title") or info.get("title") or job.get("title") or mal_id
            if src == "anilist" and not info.get("anilist_id"):
                self.log.add(src, mal_id, title, "", "", "skipped", "AniList doesn't have this entry.")
                return True
            shows = self._groups().get(mal_id) or []
            total = (cur or {}).get("episodes") or info.get("episodes") or (shows[0].get("mal_episodes") if shows else 0) or 0
            if not shows:
                return True
            if not all(numbering_fits(sh, total) for sh in shows):
                self.log.add(src, mal_id, title, describe(cur), describe(cur), "skipped",
                             f"The file numbers don't fit the {total} episodes on {NAMES[src]}.")
                return True
            watched = watched_upto(shows, self.store.all_progress(profile=self.owner(src)))
            rewatch = bool(self._settings().get("lists_rewatch"))
            new, why = plan_change(cur, watched, total, rewatch, job.get("finished") if job["kind"] == "event" else None)
            if not new:
                if job["kind"] == "plan" or why.startswith("completed"):
                    self.log.add(src, mal_id, title, describe(cur), describe(cur), "skipped", why[:1].upper() + why[1:] + ".")
                return True
            if src == "mal":
                self._call(src, lambda t: client.update(mal_id, t, mal_fields(cur, new)))
            else:
                f = anilist_fields(cur, new)
                self._call(src, lambda t: client.save(info["anilist_id"], t, f["status"], f["progress"], f.get("repeat")))
            self.log.add(src, mal_id, title, describe(cur), describe(new), "sent")
            log.info("%s: %s %s → %s", NAMES[src], title, describe(cur), describe(new))
            self._remember(src, mal_id, new, title, info.get("anilist_id"))
            return True
        except ListError as exc:
            if exc.auth:
                self._problem(src, f"{NAMES[src]} stopped accepting AniBox's sign-in. Connect again; the waiting "
                                   "updates are sent then.")
                return False
            job["tries"] = int(job.get("tries") or 0) + 1
            if exc.retry and job["tries"] <= len(RETRY_WAIT):
                job["due"] = time.time() + (exc.retry_after or RETRY_WAIT[job["tries"] - 1])
                log.info("%s: %s, trying again later (%s)", NAMES[src], job.get("title"), exc)
                return False
            self.log.add(src, mal_id, job.get("title") or mal_id, "", "", "failed", str(exc))
            return True
        except Exception as exc:
            log.exception("Sending to %s failed", NAMES[src])
            self.log.add(src, mal_id, job.get("title") or mal_id, "", "", "failed", str(exc) or exc.__class__.__name__)
            return True

    def wait_idle(self, timeout: float = 10.0) -> bool:
        """Tests: wait until nothing is due anymore."""
        end = time.time() + timeout
        while time.time() < end:
            with self._lock:
                due = [j for j in self._queue if j["due"] <= time.time() and not self.accounts.problems.get(j["src"])]
            if not due and not self._busy.locked():
                return True
            time.sleep(0.02)
        return False
