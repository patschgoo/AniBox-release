"""Start AniBox: one copy at a time, opened in its own window."""

from __future__ import annotations

import argparse
import json
import logging
import logging.handlers
import platform
import os
import shutil
import subprocess
import sys
import traceback
import urllib.request
import webbrowser
from pathlib import Path

from . import __version__
from .paths import data_dir, is_portable

DEFAULT_PORT = 43210


def _running_at(port: int) -> bool:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/ping", timeout=1.5) as r:
            return json.loads(r.read().decode("utf-8")).get("app") == "AniBox"
    except Exception:
        return False


def _browser_app_mode() -> list:
    """Microsoft Edge (or Chrome) can show a page as its own window without browser bars."""
    if not sys.platform.startswith("win"):
        return []
    roots = [os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
             os.environ.get("ProgramFiles", r"C:\Program Files"), os.environ.get("LOCALAPPDATA", "")]
    for rel in (r"Microsoft\Edge\Application\msedge.exe", r"Google\Chrome\Application\chrome.exe"):
        for root in roots:
            exe = os.path.join(root, rel) if root else ""
            if exe and os.path.isfile(exe):
                return [exe]
    found = shutil.which("msedge") or shutil.which("chrome")
    return [found] if found else []


def open_window(url: str) -> None:
    browser = _browser_app_mode()
    if browser:
        try:
            subprocess.Popen(browser + [f"--app={url}", "--window-size=1360,880"],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return
        except OSError:
            pass
    webbrowser.open(url)


def _setup_logging(folder: Path) -> None:
    """logs/anibox.log (kept small: 3 older copies of 1 MB). Send this file when something goes wrong."""
    logs = folder / "logs"
    logs.mkdir(exist_ok=True)
    handler = logging.handlers.RotatingFileHandler(str(logs / "anibox.log"), maxBytes=1_000_000, backupCount=3,
                                                   encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
    root = logging.getLogger()
    root.handlers[:] = [handler]
    root.setLevel(logging.INFO)
    if sys.stdout is None:  # started without a console (pythonw)
        sys.stdout = open(os.devnull, "w")
        sys.stderr = open(logs / "errors.log", "a", encoding="utf-8")
    sys.excepthook = lambda *exc: logging.getLogger("anibox").error("Unexpected error", exc_info=exc)


def _message_box(text: str) -> None:
    if sys.platform.startswith("win"):
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, text, "AniBox", 0x10)
            return
        except Exception:
            pass
    print(text, file=sys.stderr)


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="anibox", description="AniBox: a private player for the anime on your drives.")
    p.add_argument("--port", type=int, default=DEFAULT_PORT)
    p.add_argument("--no-window", action="store_true", help="don't open the AniBox window")
    p.add_argument("--stay", action="store_true", help="keep running after the window is closed")
    p.add_argument("--version", action="version", version=f"AniBox {__version__}")
    args = p.parse_args(argv)

    folder = data_dir()
    _setup_logging(folder)
    for port in range(args.port, args.port + 10):  # already open? Then just show its window.
        if _running_at(port):
            if not args.no_window:
                open_window(f"http://127.0.0.1:{port}/")
            return 0
    try:
        from .server import App
        app = None
        for port in range(args.port, args.port + 10):
            try:
                app = App(folder, port=port, idle_exit=not args.stay)
                break
            except OSError:
                continue
        if app is None:
            raise RuntimeError(f"No free port between {args.port} and {args.port + 9}.")
        logging.info("AniBox %s on %s · Python %s · %s · data in %s%s", __version__, app.url,
                     platform.python_version(), platform.platform(), folder.parent,
                     " (portable)" if is_portable() else "")
        if not args.no_window:
            open_window(app.url)
        print(f"AniBox is running: {app.url}")
        app.serve_forever()
        return 0
    except Exception as exc:
        logging.error("Start failed: %s\n%s", exc, traceback.format_exc())
        _message_box(f"AniBox couldn't start:\n\n{exc}\n\nDetails: {folder / 'logs' / 'anibox.log'}")
        return 1
