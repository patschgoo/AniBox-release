"""TV copies (tvcopy.py): the window's routes.

Part of the App class (see server.py); the methods use the App's attributes. Only the AniBox window
reaches these routes (``GET_ROUTES``/``POST_ROUTES`` are never served to the phone remote).

Nothing here writes next to your videos: copies go into their own folder, a preview comes first, and
Undo removes exactly the copies AniBox made (listed in its index).
"""

from __future__ import annotations

import logging
import secrets
import threading
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from . import media, tvcopy
from .apierror import ApiError
from .ffmpegsetup import find_tools
from .shortcut import open_folder

log = logging.getLogger("anibox.server")

_LOCK = threading.Lock()
PREVIEW_ROWS = 500


class RoutesTvCopyMixin:
    GET_ROUTES = {
        "/api/tvcopy": "_tvcopy_status",
        "/api/tvcopy/preview": "_tvcopy_preview_get",
        "/api/tvcopy/show": "_tvcopy_show",
    }
    POST_ROUTES = {
        "/api/tvcopy/preview": "_tvcopy_preview_post",
        "/api/tvcopy/start": "_tvcopy_start",
        "/api/tvcopy/pause": "_tvcopy_pause",
        "/api/tvcopy/resume": "_tvcopy_resume",
        "/api/tvcopy/cancel": "_tvcopy_cancel",
        "/api/tvcopy/remove": "_tvcopy_remove",
        "/api/tvcopy/remove-all": "_tvcopy_remove_all",
        "/api/tvcopy/settings": "_tvcopy_settings",
        "/api/tvcopy/detect": "_tvcopy_detect",
        "/api/tvcopy/open": "_tvcopy_open",
    }

    # -- life cycle (server.py calls these) --------------------------------------------------------------

    def _tvcopy_init(self) -> None:
        self.tvcopies = tvcopy.TvCopies(self.data_dir, self.store.settings, self._tvcopy_tools,
                                        forbidden=self._tvcopy_forbidden, on_done=self._tvcopy_done)
        tvcopy.activate(self.tvcopies)  # tvcopy.copy_for() answers from this App's copies
        self._tvcopy_previews: Dict[str, dict] = {}
        self._tvcopy_detecting = {"state": "idle"}

    def _tvcopy_busy(self) -> bool:
        tvc = self.__dict__.get("tvcopies")
        return bool(tvc and tvc.busy())

    def _tvcopy_close(self) -> None:
        tvc = self.__dict__.get("tvcopies")
        if tvc:
            tvc.shutdown()
            if tvcopy._active is tvc:
                tvcopy.activate(None)

    # -- helpers ------------------------------------------------------------------------------------------

    def _tvcopy_tools(self) -> Dict[str, Optional[str]]:
        return find_tools(self.data_dir, self.store.settings().get("ffmpeg_path") or "")

    def _tvcopy_forbidden(self) -> List[Tuple[str, str]]:
        """Folders a copies folder must stay out of: the library folders and the "Add new videos" folders."""
        out = [(f, "your library folder") for f in self.store.settings().get("folders") or []]
        try:
            inbox = self._inbox_roots()
        except Exception:
            inbox = []
        return out + [(f, 'the "Add new videos" folder') for f in inbox]

    def _tvcopy_show_of(self, show_id) -> dict:
        show = self.library.show(str(show_id or ""))
        if not show:
            raise ApiError("Show not found", 404)
        return show

    def _tvcopy_done(self, job: dict) -> None:
        """A copy is ready (or failed): the show's TV check is read again with "TV copy ready"."""
        st = self.__dict__.get("_media_state")
        if st and job.get("show"):
            st["checks"].pop(job["show"], None)

    # -- status and settings ------------------------------------------------------------------------------

    def _tvcopy_status(self, query: dict) -> dict:
        tools = self._tvcopy_tools()
        out = self.tvcopies.status()
        out.update(ffmpeg=bool(tools["ffmpeg"] and tools["ffprobe"]), detecting=self._tvcopy_detecting.get("state") == "running",
                   choices=list(tvcopy.CHOICES), names=tvcopy.ENCODER_NAMES)
        return out

    def _tvcopy_settings(self, body: dict) -> dict:
        changes = {}
        if "dir" in body:
            folder = str(body.get("dir") or "").strip().strip('"')
            if folder:
                problem = tvcopy.folder_problem(folder, self._tvcopy_forbidden())
                if problem:
                    raise ApiError(problem)
            changes["tv_copy_dir"] = folder
        if "encoder" in body:
            if body["encoder"] not in tvcopy.CHOICES:
                raise ApiError("Unknown encoder choice.")
            changes["tv_copy_encoder"] = body["encoder"]
        if "audio" in body:
            if body["audio"] not in tvcopy.AUDIO_MODES:
                raise ApiError("Unknown sound choice.")
            changes["tv_copy_audio"] = body["audio"]
        if changes:
            self.store.update_settings(changes)
            log.info("TV copies settings changed: %s", ", ".join(sorted(changes)))
        return self._tvcopy_status({})

    def _tvcopy_detect(self, body: dict) -> dict:
        """Test the encoders again (after a driver update, or a new ffmpeg)."""
        if self._tvcopy_detecting.get("state") == "running":
            return {"ok": True}
        tools = self._tvcopy_tools()
        if not tools["ffmpeg"]:
            raise ApiError("TV copies need ffmpeg (Settings → Player → Download ffmpeg).")
        self._tvcopy_detecting = {"state": "running"}

        def run():
            try:
                self.tvcopies.encoders.forget()
                self.tvcopies.encoders.pick(tools["ffmpeg"], self.tvcopies.choice())
                self._tvcopy_detecting = {"state": "done"}
            except Exception as exc:
                log.info("TV copies: encoder test failed: %s", exc)
                self._tvcopy_detecting = {"state": "error", "message": str(exc)}

        threading.Thread(target=run, daemon=True, name="anibox-tvcopy-detect").start()
        return {"ok": True}

    def _tvcopy_open(self, body: dict) -> dict:
        folder = Path(self.tvcopies.folder())
        problem = self.tvcopies.folder_problem(str(folder))
        if problem:
            raise ApiError(problem)
        try:
            folder.mkdir(parents=True, exist_ok=True)
            open_folder(folder)
        except (OSError, RuntimeError) as exc:
            raise ApiError(f"Couldn't open the folder ({exc}).")
        return {"ok": True}

    # -- the show page --------------------------------------------------------------------------------------

    def _tvcopy_show(self, query: dict) -> dict:
        show = self._tvcopy_show_of(query.get("id"))
        tvc = self.tvcopies
        copies = []
        for ep in show["episodes"]:
            if not tvc.index.get(ep["path"]):
                continue
            state, rec = tvc.state_of(ep["path"])
            copies.append({"key": ep["key"], "file": ep["file"], "label": ep["label"], "state": state,
                           "copy": rec["copy"], "size": rec.get("copy_size") or 0})
        st = tvc.status()
        mine = [j for j in ([st["current"]] if st["current"] else []) + st["queue"] if j.get("show") == show["id"]]
        return {"copies": copies, "ready": sum(1 for c in copies if c["state"] == "ready"),
                "outdated": sum(1 for c in copies if c["state"] == "outdated"), "jobs": mine,
                "paused": st["paused"], "message": st["message"], "folder": st["folder"]}

    def _tvcopy_preview_post(self, body: dict) -> dict:
        show = self._tvcopy_show_of(body.get("show"))
        with _LOCK:
            cur = self._tvcopy_previews.get(show["id"])
            if cur and cur.get("state") == "loading":
                return {"ok": True, "state": "loading"}
            entry = {"state": "loading", "done": 0, "total": len(show["episodes"])}
            self._tvcopy_previews[show["id"]] = entry

        def run():
            try:
                self._tvcopy_previews[show["id"]] = self._tvcopy_plan(show, entry)
            except Exception as exc:
                log.exception("TV copies preview of %s failed", show["id"])
                self._tvcopy_previews[show["id"]] = {"state": "error", "error": str(exc)}

        threading.Thread(target=run, daemon=True, name="anibox-tvcopy-preview").start()
        return {"ok": True, "state": "loading"}

    def _tvcopy_plan(self, show: dict, entry: dict) -> dict:
        tvc = self.tvcopies
        tools = self._tvcopy_tools()
        folder = tvc.folder()
        base = {"state": "done", "token": secrets.token_urlsafe(8), "folder": folder, "problem": tvc.folder_problem(folder),
                "free": tvc.free_space(folder), "audio": tvc.audio_mode(), "title": show.get("title") or show["folder"]}
        if not tools["ffmpeg"] or not tools["ffprobe"]:
            return dict(base, ffmpeg=False, items=[], offer=0)
        caps = {}
        try:
            caps = self._media_castapp()[1] or {}
        except Exception:
            log.info("TV copies: CastApp TV's list of what it plays wasn't available", exc_info=True)
        cache = self._media()["cache"]  # what's inside each file, kept by size + time (shared with the TV check)
        items = []
        for ep in show["episodes"]:
            state, rec = tvc.state_of(ep["path"])
            item = {"key": ep["key"], "file": ep["file"], "label": ep["label"], "state": state, "why": "", "video": "",
                    "duration": None, "size": 0, "est": 0, "offer": False}
            if state == "ready":
                item.update(why="a TV copy is ready", size=rec.get("copy_size") or 0)
            else:
                info = media.probe(ep["path"], tools["ffprobe"], cache)
                why = tvcopy.needs_copy(info, caps, ep["file"]) if info else ""
                pr = tvcopy.probe_streams(ep["path"], tools["ffprobe"]) if why else None  # the length, only when needed
                if info is None or (why and pr is None):
                    item["why"] = "AniBox couldn't read this file"
                    item["state"] = state or "unreadable"
                else:
                    item.update(video=media.video_text(info.get("video")), why=why or "plays directly", offer=bool(why))
                    if pr:
                        item.update(duration=pr["duration"], size=pr["size"], est=tvcopy.estimate_bytes(pr["size"], pr["duration"]))
            items.append(item)
            entry["done"] += 1
        cache.save()
        offered = [it for it in items if it["offer"]]
        encoder, enc_error = None, ""
        if offered:
            try:
                encoder = tvc.encoders.pick(tools["ffmpeg"], tvc.choice())
            except RuntimeError as exc:
                enc_error = str(exc)
        speed = tvc.speed(encoder["kind"]) if encoder else 0
        est = sum(it["est"] for it in offered)
        seconds = sum(it["duration"] or 0 for it in offered) / speed if speed else 0
        measured = bool(encoder and encoder["kind"] in tvc.index.speeds)
        log.info("TV copies preview for %s: %d of %d episodes need a copy", show["id"], len(offered), len(items))
        return dict(base, ffmpeg=True, items=items[:PREVIEW_ROWS], offer=len(offered), est=est, seconds=round(seconds),
                    speed=speed, measured=measured, encoder=encoder, encoderError=enc_error,
                    roomOk=base["free"] >= est * 1.2 + tvcopy.DISK_RESERVE,
                    ready=sum(1 for it in items if it["state"] == "ready"))

    def _tvcopy_preview_get(self, query: dict) -> dict:
        show = self._tvcopy_show_of(query.get("id"))
        cur = self._tvcopy_previews.get(show["id"]) or {"state": "none"}
        return dict(cur)

    def _tvcopy_start(self, body: dict) -> dict:
        show = self._tvcopy_show_of(body.get("show"))
        cur = self._tvcopy_previews.get(show["id"]) or {}
        if cur.get("state") != "done" or cur.get("token") != str(body.get("token") or ""):
            raise ApiError("Make a new preview first.")
        keys = {str(k) for k in body.get("keys") or []}
        chosen = [it for it in cur.get("items") or [] if it["offer"] and it["key"] in keys]
        if not chosen:
            raise ApiError("Tick at least one episode.")
        problem = self.tvcopies.folder_problem()
        if problem:
            raise ApiError(problem)
        by_key = {e["key"]: e for e in show["episodes"]}
        items = []
        for it in chosen:
            ep = by_key.get(it["key"])
            if not ep:
                continue
            items.append({"original": ep["path"], "show": show["id"], "key": ep["key"], "title": show.get("title") or show["folder"],
                          "label": ep["label"], "file": ep["file"], "library": show["library"], "folder": show["folder"],
                          "duration": it["duration"], "est": it["est"]})
        self._tvcopy_previews.pop(show["id"], None)  # a preview is used once
        jobs = self.tvcopies.enqueue(items)
        if self.tvcopies.paused:
            self.tvcopies.resume()  # "Make copies" means: go
        return {"ok": True, "queued": len(jobs), "status": self._tvcopy_status({})}

    # -- the queue ---------------------------------------------------------------------------------------------

    def _tvcopy_pause(self, body: dict) -> dict:
        self.tvcopies.pause()
        return {"ok": True, "status": self._tvcopy_status({})}

    def _tvcopy_resume(self, body: dict) -> dict:
        self.tvcopies.resume()
        return {"ok": True, "status": self._tvcopy_status({})}

    def _tvcopy_cancel(self, body: dict) -> dict:
        n = self.tvcopies.cancel(str(body.get("id") or "all"))
        return {"ok": True, "cancelled": n, "status": self._tvcopy_status({})}

    # -- removing copies (Undo) --------------------------------------------------------------------------------

    def _tvcopy_remove(self, body: dict) -> dict:
        """One copy (``show`` + ``key``) or all copies of a show (``show`` alone)."""
        show = self._tvcopy_show_of(body.get("show"))
        key = str(body.get("key") or "")
        eps = [e for e in show["episodes"] if not key or e["key"] == key]
        if key and not eps:
            raise ApiError("Episode not found", 404)
        originals = [e["path"] for e in eps if self.tvcopies.index.get(e["path"])]
        if not originals:
            raise ApiError("There's no TV copy to remove.")
        out = self.tvcopies.remove(originals, why="undo")
        self._tvcopy_done({"show": show["id"]})
        return {"ok": True, **{k: v for k, v in out.items() if k != "copies"}}

    def _tvcopy_remove_all(self, body: dict) -> dict:
        tvc = self.tvcopies
        if body.get("check"):
            return {"ok": True, **tvc.summary()}
        if tvc.current:
            raise ApiError("A TV copy is being made right now. Cancel it or wait until it's done.")
        out = tvc.remove_all()
        st = self.__dict__.get("_media_state")
        if st:
            st["checks"].clear()
        return {"ok": True, **{k: v for k, v in out.items() if k != "copies"}}

    def _tvcopy_history_undo(self, batch: str, check: bool) -> dict:
        """History page: Undo of one "Make TV copies" = remove those copies (the originals stay)."""
        originals = self.tvcopies.batch_originals(batch)
        if not originals:
            raise ApiError("These TV copies were removed already.")
        if check:
            return {"ok": True, "kind": "tvcopy", "files": len(originals), "problems": []}
        out = self.tvcopies.remove(originals, why="undo")
        st = self.__dict__.get("_media_state")
        if st:
            st["checks"].clear()
        return {"ok": True, **{k: v for k, v in out.items() if k != "copies"}}
