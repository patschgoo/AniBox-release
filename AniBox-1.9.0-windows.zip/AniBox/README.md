# AniBox

A private player for the anime on your own drives. AniBox shows your anime folders as a library
(matched to MyAnimeList), plays them with mpv, remembers where you stopped, and tells you which
seasons, OVAs, specials and movies you're missing. The look and many features come from
**Frostbox**, Martin's archive.org player (used with his permission).

AniBox only reads your video folders. It never renames, moves or deletes a video. The only things
it can write onto your drives are small `.nfo` info files, and only when you click **Write** under
Settings → Info files (see below), and the files you download from the Internet Archive, into the
download folder you choose (it never replaces a file that's already there). It never changes
anything in Plex. It can also add subtitle files (`.srt`, `.ass`) next to new or unlocked episodes,
only when you click **Add** or **Download** on a show's page (see "Subtitles for the TV" below).

## Start it (Windows)

Two ways to get AniBox onto the PC:

- **Ready package, no Python needed:** `AniBox-<version>-windows.zip` brings its own Python (the
  official "embeddable" Python from python.org, in the `python` folder). Unpack it anywhere, e.g.
  `Documents\AniBox`, and double-click **`AniBox.bat`** in the `AniBox` folder. For now the
  package is built from this repository with `python tools/build_windows.py` (it ends up in
  `dist/`, see [tools/](tools/)); later it will come from a release repository.
- **From the source, with Python installed:** install **Python 3.9 or newer** from
  [python.org](https://www.python.org/downloads/) (tick "Add python.exe to PATH"), download this
  repository (green **Code** button → **Download ZIP**), unpack it anywhere and double-click
  **`AniBox.bat`**.

Windows may warn once because the files come from the internet. To avoid that, right-click the
ZIP before unpacking → **Properties** → tick **Unblock** → **OK**.

Then, either way:

1. AniBox opens in its own window (Microsoft Edge in app mode).
   **Settings → Your data → Add to desktop** puts an AniBox icon on your desktop.
2. **Settings → Folders**: **Browse …** or paste any folder with videos (a Shield drive such as
   `\\SHIELD\External USB drive-1234abcd\NVIDIA_SHIELD`, a NAS, a USB disk, a folder on the PC),
   then **Scan now**. Later scans only read the folders that changed, so they're quick even on
   the Shield; **Full rescan** reads everything again (use it if a new episode doesn't show up).
3. **Settings → Player**: **Download mpv** once (about 34 MB, checked against a fixed checksum).
   Windows 11 unpacks it by itself; on older Windows install [7-Zip](https://7-zip.org) first.

Closing the window stops AniBox after about two minutes. Starting it again opens the same window.

On Linux or macOS: install `python3` and `mpv`, then run `./AniBox.sh`.

**New versions** are published in a public release repository (Settings → Updates; default
`patschgoo/AniBox-release`). Once a day AniBox reads its `latest.json`; when there's a newer
version, Home says so and **Download** fetches the zip into your Downloads folder and checks it (size
and SHA-256). Then **Update now** installs it. Nothing is downloaded or installed without a click.

**Updating (from 1.6.0 on):** put the new `AniBox-<version>-windows.zip` in your **Downloads**
folder, don't unpack it. AniBox shows **AniBox x.y is in your Downloads · Update now** on Home (and
under Settings → Updates). Click it: AniBox closes, a small helper puts the new version in place
and starts it, and AniBox opens again by itself. If the new version doesn't start, the helper puts
the old one back and AniBox says so. Your library, watch progress and settings are in a separate
folder (see "Your data") and are never touched; the old program files stay in `.previous-update`
inside the AniBox folder until the next update. The helper's log is `app\logs\update.log`.

By hand (and for versions before 1.6.0): close AniBox (it stops about two minutes after its window
closes), unpack the new ZIP over the old folder and start it again. If the repository is public,
AniBox tells you when a new version is out.

## What it does

- **Home**: Continue watching (with the next episode) and Recently added.
- **Library**: every show as a poster card, in sections **Anime** (with Series, Movies, OVAs,
  Specials, ONAs), **Series** and **Movies** (your non-anime folders) and **Everything**, with search
  and filters. AniBox guesses what each library folder holds; Settings → Libraries to show lets you
  set it (Auto / Anime / Series / Movies). **Franchises** groups the
  seasons, OVAs and movies of one franchise into one card, with a page that lists everything in
  that franchise (what you have and what's missing).
- **Show page**: episodes with progress, the franchise entries you don't have yet, and (with a
  MyAnimeList Client ID) the description, score, genres and studio. **Wrong match? / Match by
  hand** picks the right MyAnimeList entry for a folder; AniBox remembers it, the folder stays
  as it is.
- **Missing**: what's missing per franchise, which folders are incomplete, and which folders
  weren't recognized. Unrecognized folders can be matched by hand or hidden. Two tabs:
  **Your folders** (from your scanned folders, no Plex needed) and **Your Plex library** (reads the
  Plex libraries you pick and says where each missing entry would go in Plex's numbering, e.g.
  "Would go in Specials (S00E12)"). **Save as web page** / **Save as spreadsheet** export either
  one (the spreadsheet uses `;` for German Excel). This replaces the separate Library Check
  program (`run-check.bat`) of earlier versions.
- **Playing** (from Frostbox): resume where you stopped (10 s back), "watched" at 95 %, next
  episode after a short countdown, "Still watching?" after a few episodes in a row, sleep timer.
- **Plays inside the AniBox window** (Windows): a big player, a small one in the corner while you
  keep browsing (it switches to small when you open another page), **Fill the window** and **Full
  screen** (buttons above the video, `F`/`Esc`, or double-click / `F` in the video). mpv still does the
  playing, so every file and subtitle that worked before still works. Dialogs (audio/subtitles,
  "Still watching?") hide the video while they're open, because nothing can be drawn on top of it.
  If AniBox can't place the video in its window, it opens in its own window as before; Settings →
  Player → **Play inside the AniBox window** switches this off.
- **Audio and subtitles**: preferred languages (e.g. Japanese audio, German subtitles), a track
  picker in the playing bar and on the phone, and AniBox remembers your choice per show.
- **Skip opening / ending**: when the file has chapters called "Opening"/"OP" or
  "Ending"/"ED" (most fansub and Blu-ray releases), a **Skip** button appears, or AniBox skips by
  itself if you choose that.
- **Phone remote** (from Frostbox): switch it on in Settings and scan the QR code (same Wi-Fi).
  Play/pause, seek, skip, next episode, audio/subtitles, volume, sleep timer and the episode list.
  Windows asks once whether to allow AniBox in your network: allow **private networks** only.
- **Play on TV**: send an episode to CastApp TV on the Shield or another DLNA TV in your home
  network (see below).
- **Watch history from Plex**: copies which episodes you watched in Plex into AniBox
  (read-only in Plex).
- **Plex's details, copied**: what your Plex libraries already know about your shows (titles,
  descriptions, the MyAnimeList match from the old agent, episode titles, posters) is copied into
  AniBox and shown on each show page. A backup in case the Shield's SD card fails (see below).
- **Episode titles and pictures**: titles you typed into your file names come first; otherwise
  AniBox gets titles, air dates and pictures from Kitsu (free, no account) and, for One Piece,
  pictures from the One Piece Wiki. They're only shown in AniBox; your files are never renamed.
- **Sub/dub badges**: each show says whether it's Japanese, a German or English dub, and which
  subtitles it has ("DUB DE", "JA", "SUB DE·EN"). AniBox guesses from folder and file names, reads
  the track list at the start of an MKV/MP4 file when you open a show, and learns from the player;
  you can correct it by hand. Filter the library by Japanese, German dub, English dub, German subs or English subs, and by subtitle type: burned in, styled (ASS), plain text (SRT), image (PGS/VobSub), or "may not show on the TV" (styled or picture subtitles that the Plex app on the Shield and many TVs can't show as they are). The language editor explains which type works where.
- **Locked old episodes**: everything that was already in your folders is locked, new episodes
  are open. AniBox writes nothing for locked episodes (no info files) until you click **Unlock
  this show** on a show's page.
- **Subtitles for the TV and "Plays on the TV?"**: plain `.srt` copies of styled subtitles, subtitles
  from Jimaku or OpenSubtitles, and a check per show whether Plex on the Shield or CastApp TV plays it
  directly (see below).
- **Internet Archive**: search archive.org's free films, cartoons and TV recordings, open an item,
  tick the files you want and download them into a folder you choose; AniBox can add them to your
  library (see below).

In the mpv window: `N` / `P` next / previous episode, `Shift+S` skip the opening, `#` switch
audio, `j` switch subtitles, `v` subtitles on/off, `Q` close.

### Add new videos (from Downloads into your library)

**Library → Add new videos** (the number shows how many are waiting) looks in your Downloads folder
(or another folder you pick) for finished video downloads, recognizes them (release names like
`[Group] Title - 05 (1080p).mkv` or `Title.S01E05.mkv`), matches them to MyAnimeList and suggests:

- **where they go**: into the show's existing folder if you already have it (new episodes follow the
  names already there), otherwise a new folder named after the MyAnimeList title in the library that
  already holds most entries of that kind (series → `Anime`, movies → `Anime Movies`, OVAs → `OVA's`,
  German dubs → `Anime [ger dub]`; an empty folder of the same name on another drive is never used);
- **what they're called**: `<Title> 01.mkv`, `<Title> 02.mkv` … (movies `<Title> 01.mkv` too), like your
  library; subtitle files next to a video (`.ass`, `.srt`) go with it and get the same name.

Two options above the list do the rest in one go: **write info files (.nfo)** for the new episodes
(for a Plex NFO library), and **ask Plex to scan** the library you pick there (only libraries with a
modern agent are offered; the old MyAnimeList libraries are never scanned). AniBox maps its folder
(`\\SHIELD\…\NVIDIA_SHIELD\Anime\Show`) to Plex's own path (`/storage/…/NVIDIA_SHIELD/Anime/Show`) and
asks Plex to scan just that folder, like clicking "Scan Library Files".

Change any title (**Change title**), folder or file name, untick what you don't want (episodes that
are already in the folder start unticked), choose **Move** or **Copy**, check the list and confirm.
AniBox never overwrites a file; a move to another drive is copied, checked and only then removed from
Downloads. **Undo** puts the last batch back. The new episodes are "new" (not locked), so AniBox shows
their MyAnimeList details and episode titles right away, and **Settings → Info files → Write** gives
them info files for a Plex NFO library.

### New episodes, statistics, watch order

- **New episodes** (on Home): for the shows you're watching and the ones still airing, AniBox says
  "Episode 7 is out (2 days ago) · not on your drives", or "… waiting in Downloads → Add new videos"
  when a matching download is there, and when the next one comes ("Next: Episode 8 on Sat 29 Nov at
  17:30", your PC's time). Air dates come from [AniList](https://anilist.co)'s free public API, no
  account; AniBox only sends the MyAnimeList numbers of those shows, at most every 2 hours (**Check
  now** asks again) and keeps the answers in `app\airing.json`. Episodes before the first one in a
  folder don't count. Offline: nothing is shown. **Settings → New episodes** switches it off.
- **Statistics** (Library → Statistics): hours and episodes watched, the last 12 months, anime /
  series / movies, MyAnimeList types, genres (from the MyAnimeList details AniBox has loaded), the
  most watched shows, what you finished this year and your streak of days in a row. It counts
  episodes marked as watched on the day they were marked (also by hand or copied from Plex); when
  AniBox doesn't know an episode's length it uses the show's usual one ("about").
- **Watch order** (on a franchise's page): its series, movies, OVAs and specials in release order,
  each marked watched, partly watched, not started, not on your drives or not out yet; OVAs and
  specials are optional, short clips are hidden. When you finish a show, its page shows **Next in
  this franchise** (the main story before optional parts).

### Open folder, Move or rename

- **Open folder** on a show's page opens it in File Explorer; the folder icon on an episode shows that
  file in its folder.
- **Move or rename …** moves a show to another library folder and/or renames its folder and episode
  files (`<Folder> 01` …), with a preview first and Undo afterwards. Watch progress follows. It only
  works for shows that are new or that you **unlocked**: what was already there stays as it is. Shows
  in the old Plex libraries are flagged, because their old scanner can't pick moved files up again.

### Check my library, Move plan, History

**Library → Check my library** looks through AniBox's list of your files (from the last scan) and lists:

- **Same episode twice**: two files with the same number in one folder (another version or language), and
  the same show in two folders (e.g. one in `Anime2` and one in `Anime`), with the episodes that are in
  both and the ones that are only in one. A German dub next to the Japanese version counts as "another
  language", not as a copy.
- **Missing episodes**: numbers missing in the middle (1–5 and 7–12 but no 6). Where MyAnimeList knows the
  episode count, also at the start and, for finished shows, at the end; shows that are still airing aren't
  counted at the end. A show in two folders is counted over both.
- **Empty or broken files**, only when you tick **Check the files too**: AniBox opens every video and reads
  its first few KB (a few files at a time) to see whether it's empty, much smaller than the other episodes,
  doesn't start like a video file (an error page saved as `.mkv`, a renamed archive) or can't be read. On
  the Shield this takes a while; **Stop** keeps what was read so far.
- **Odd names**: files without a number among numbered ones, numbers that don't fit (101 in a 12-episode
  show), leftover download names (`[Group]`, `1080p`).
- **Not recognized**: how many folders no MyAnimeList entry fits (they're on the Missing page).

Each entry links to its show and has **Open folder** / **Show file**; **Save as web page** / **Save as
spreadsheet** export the list. Nothing on your drives changes. The last result is kept in `app\health.json`.

**Move plan** (the second tab) prepares moving `Anime2` into `Anime` (and `Anime [ger dub] 2` into
`Anime [ger dub]`, or any two libraries you pick): for each show folder, old path → new path, into the
show's folder in the target if it already has one (same MyAnimeList entry), named like the files there,
otherwise into a new folder of the same name in the target's fullest folder. It flags episodes that are
already in the target, files on another drive (copied, not just renamed) and locked shows. It's only a list,
with no button that moves anything; the page says when moving would be safe (only after a new Plex library
with working matching covers the target folder, because the old library doesn't see moved files; watched
marks in Plex don't follow the files). It can be saved as a web page or spreadsheet too.

**History** (Library → History, or Settings → History of changes) lists everything AniBox changed, newest
first: videos added, moved or renamed (one entry per batch), info files written, what Tidy up removed
(noted in `app\tidy-log.jsonl`), updates, and matches by hand. **Undo** works for file batches (the last
one, and an older one as long as no later change touched the same files and none of its files changed
since; watch progress follows the files back) and for the info files written since the last undo. AniBox
asks first every time. What Tidy up removed, updates and matches can't be undone there (matches are
changed on the show's page).

### Optional: descriptions and scores from MyAnimeList

AniBox works without any account. For descriptions, scores, genres and studios on the show pages,
create a free Client ID on myanimelist.net (Profile → Account settings → API → Create ID, app
type "other") and paste it under **Settings → MyAnimeList**. It's only used to read public
information; answers are kept for 30 days. MyAnimeList has no episode titles, so episodes stay
"Episode 1, 2, …".

### Optional: your MyAnimeList / AniList list

**Settings → Your anime lists**: type your MyAnimeList and/or AniList user name. AniBox then reads
your public list (MyAnimeList with the Client ID above, AniList with nothing else), keeps a copy for
an hour, and shows it:

- a small badge on every card ("MAL · Watching 5/12") and a line on each show page;
- **Library → Your lists** with three parts: *On your list but not on your drives* (watching, plan
  to watch, completed), *Watched on your list but not in AniBox* (with **Mark these as watched in
  AniBox**: shows exactly which episodes first, and only ever marks), and *In AniBox but not on
  your list*. A switch picks MyAnimeList or AniList.

**Sending what you watch to your list** (off until you turn it on, per account):

1. Connect the account. MyAnimeList: on myanimelist.net → Account settings → API, edit the app
   whose Client ID AniBox uses: App Type **other** (it has no Client Secret, none is needed) and
   App Redirect URL exactly `http://127.0.0.1:43210/oauth/mal`. AniList: anilist.co → Settings →
   Developer → Create New Client with the Redirect URL `http://127.0.0.1:43210/oauth/anilist`, and
   put its ID under Client ID. Then **Connect …** → **Open MyAnimeList/AniList** → Allow. (The
   Settings page shows the exact addresses; they contain the port AniBox runs on.)
2. **Turn on …** shows every change it would make now (from → to), and nothing is written before
   you click OK. **Sync now …** does the same later.
3. From then on, when you finish an episode (95 %, in AniBox or on a TV), AniBox updates that show
   on your list in the background (with retries): progress = the highest episode you watched,
   Plan to watch → Watching, Completed at the last episode. It never lowers progress, never
   removes entries and never changes scores. Completed entries are left alone unless you turn on
   "When I watch a finished show again: count it as a rewatch". Settings lists the last changes
   per account.

The sign-ins are kept in `app\lists\accounts.json`, encrypted for your Windows user (on Linux/macOS
in a file only you can read). **Disconnect** forgets them.

### Optional: series and movie info from TMDB

Anime gets its info from MyAnimeList. For your **series and movies** (libraries that count as
"Series" or "Movies" under Settings → Libraries to show), AniBox can show posters, descriptions,
genres, the year and episode titles from [TMDB](https://www.themoviedb.org), a free movie and TV
database. It needs a free key of your own: make an account on themoviedb.org, open Settings → API,
ask for an API key for personal use, and paste the **API Read Access Token** (or the shorter API
Key) under **Settings → Series and movie info (TMDB)**.

- AniBox searches TMDB by folder name ("Title (2019)" or "Title.2019…" give the year) and picks the
  same title first, then the same year, then the most popular one. **Wrong match?** on a show's
  page lets you search and pick another one, or mark it as not on TMDB.
- TMDB only learns your folder names. Answers and posters are kept in `app\tmdb` for 30 days; the
  window never talks to TMDB itself. Without a key AniBox never asks TMDB anything.
- Episode titles: the ones in your file names come first, then Plex's, then TMDB's
  (`S01E05` or a `Season 1` folder tells AniBox which episode it is).

### Optional: watch history from Plex

**Settings → Your Plex library → Sign in with a code** (the same code sign-in as the Library
Check; it adds "AniBox Library Check" to your Plex account under Authorized Devices, where you can
remove it). **Import watched episodes** then marks what you watched in Plex as watched in AniBox
and takes over resume points. Plex itself is only read. AniBox never un-marks anything.

### Copy Plex's details into AniBox

Five of the Plex libraries were matched by the old MyAnimeList agent, which no longer works. Their
titles, descriptions and MyAnimeList IDs can't be downloaded again; they only live in Plex's
database on the Shield's SD card. **Settings → Your Plex library → Copy now** reads them (Plex is
only read) and keeps a copy in AniBox's data folder (`app\plex-details.json`, posters in
`app\plexposters`), linked to your folders by file name, not by title.

- Each show page then has a **From your Plex library** box. For locked shows it stays exactly as
  copied; copying again later only adds what's new.
- Episode titles: the ones in your file names come first, then Plex's, then Kitsu's.
- Where Plex's old MyAnimeList match differs from AniBox's, the show page offers **Use Plex's
  match**, and Settings lists all of them.

### Info files for Plex and Jellyfin (NFO)

Plex Media Server 1.43 added a "Plex NFO Series" agent that reads Kodi-style `.nfo` files next to
the videos; Jellyfin and Kodi read the same files. AniBox can write such files with the
MyAnimeList title, description, genres and IDs, so a Plex library can show MyAnimeList data
again without an always-on server.

- Check first that your Plex server offers it: Plex Web → Settings → your server → Metadata
  Agents. Try it in a **new test library** with a copy of a few folders, never on an existing
  library.
- **Settings → Info files**: pick the libraries, click **Preview** (lists every file that would be
  written), then **Write**. Episodes that were already there are locked and skipped; only new
  episodes (and shows you unlocked) get files; One Piece follows the same rule. AniBox only adds `tvshow.nfo` and one `.nfo` per episode; it never
  replaces a file it didn't write itself, and folders on your protected list
  are never touched. **Undo** removes exactly the files AniBox wrote.

### Away from home (Tailscale)

Plex already works away from home (your router forwards Plex's port). For AniBox's phone remote and
anything else that should reach your PC or the Shield from outside without opening ports, install
[Tailscale](https://tailscale.com) (free for personal use) on the PC and the phone and sign in to the
same account. Settings → Phone remote then also shows a **Tailscale** link that works from anywhere.
Never open the file-sharing port (445) on the router.

### Play on TV

**Play on TV** (show page or playing bar) finds TVs in your home network: CastApp TV on the
Shield, smart TVs and Kodi with DLNA. AniBox then streams the episode from your PC to the TV and
keeps resume points and watched marks as usual; the playing bar and the phone remote control the
TV. If CastApp TV only accepts paired devices, AniBox asks for the 4-digit code shown on the TV.
The playing bar's TV button continues the current episode on a TV. The first time, Windows asks
whether to allow AniBox in your network; allow private networks. Keep AniBox open while the TV
plays (the file streams from your PC).

CastApp TV also learns your subtitle languages (Settings → Player, and the language you last picked
for the show), so it shows the right subtitle track inside the file; with subtitles switched off it
shows none. If CastApp TV doesn't appear in the list, open CastApp on the TV once so it says
"Ready to cast", or type the TV's address (shown on the TV) instead.

### Subtitles for the TV, subtitles online, "Plays on the TV?"

Each show page has an **On the TV** box. Some parts need **ffmpeg**: **Settings → Player → Download
ffmpeg** (once, about 114 MB: the FFmpeg 9.1 "essentials" build for Windows by Gyan Doshi, checked
against a fixed checksum; only `ffmpeg.exe` and `ffprobe.exe` are kept, in the `ffmpeg` folder of your
data folder). On Linux/macOS install `ffmpeg` with your package manager.

- **Plays on the TV?** reads the first and a middle episode (only their start) and says for **Plex on
  the Shield** and **CastApp TV** whether they play directly or need converting, and why (for example
  "10-bit H.264 (Hi10P): the Shield's hardware can't decode it; Plex converts it, which is slow on
  the Shield"). CastApp TV is asked what it can decode when AniBox knows it (Play on TV → Search);
  everything else comes from a built-in table, marked "probably" where it hasn't been tried on your
  Shield yet. Without ffmpeg AniBox reads only MKV/MP4 files, a bit less exactly.
  **Settings → Check every show** checks the whole library; **Library → May need converting** then
  lists the shows that won't play directly.
- **Make TV-friendly subtitles**: Plex on the Shield and many TVs can't show styled subtitles (ASS, the
  usual fansub format) and convert the whole video to burn them in, or show them plain. AniBox adds a
  plain `<video name>.<language>.srt` next to each episode (signs-only tracks as `.<language>.forced.srt`),
  taken from the MKV or from an `.ass` file next to it. The `.srt` keeps the text but loses colours,
  fonts and positions. Picture subtitles (PGS, VobSub) can't become text without OCR, so AniBox offers
  nothing for them. You see a preview first ("3 files would be added"); only episodes that aren't
  locked get files; nothing is ever replaced; **Undo added subtitles** removes exactly the files AniBox
  added (a file you changed since stays).
- **Find subtitles online**, per episode, from **Jimaku** (Japanese subtitles for anime) or
  **OpenSubtitles** (many languages). Each needs your own free key under **Settings → Subtitles online
  and the TV check**:
  - Jimaku: sign up on [jimaku.cc](https://jimaku.cc), open your account page, create an API key.
  - OpenSubtitles: sign up on [opensubtitles.com](https://www.opensubtitles.com), open
    [opensubtitles.com/consumers](https://www.opensubtitles.com/consumers), add a consumer (any name)
    and copy its API key. Downloads also need your OpenSubtitles username and password (free accounts
    get a few downloads a day).

  Without a key nothing is sent. With one, only the title (or the AniList/IMDb number), the episode
  number and, for OpenSubtitles, a short fingerprint of the video file (its size and a checksum of its
  first and last 64 KB) are sent. The keys are kept encrypted for your Windows user in
  `app\subtitle-accounts.json`, never shown in the window and never in a backup. The chosen file is
  saved next to the video as `<video name>.<language>.srt` (or `.ass`), only for new or unlocked
  episodes, never over an existing file, and Undo removes it again.

Files: `app\media-info.json` (what AniBox read from each file, by size and date), `app\media-checks.json`
(the results for the library filter), `app\subtitle-log.jsonl` (every subtitle file AniBox added, for
Undo).

### Internet Archive

The **Internet Archive** tab searches archive.org (no account needed). Search by title, subject
or maker, or paste an archive.org link; **Videos** / **Everything** and the sort order narrow it
down. Open an item to see its description and files: videos and subtitles are listed, the
original files are ticked already ("Copy by archive.org" are smaller versions archive.org made);
**Show all files** lists pictures and info files too. **Download selected** puts the ticked files
in the list under **Downloads**.

- **Where they go:** your Downloads folder → `AniBox Internet Archive` → one folder per item,
  named after its title. **Change …** picks another folder. AniBox only ever adds new files there:
  a file that's already there is never replaced (the new one gets " (2)"), and **Cancel** deletes
  only the unfinished `.part` file of that download.
- **Add to my AniBox library** (on by default, remembered): when an item's videos are done, AniBox
  adds the download folder to Settings → Folders (unless one of your folders already contains it)
  and scans. It reads it like a library folder, `<download folder>\<item>\<files>`, so each item
  becomes a show in the library "AniBox Internet Archive".
- Two files download at the same time; **Pause** and **Resume** go on where they stopped, also
  after a restart. Files are checked against archive.org's checksum when it has one. When
  archive.org is busy, AniBox waits and tries again by itself. If you close the AniBox window,
  AniBox finishes the downloads first and then closes.
- Every request carries only `AniBox/<version>` as its name; item pictures are fetched by AniBox
  and kept in `app\ia-thumbs`, the download list in `app\ia-downloads.json`.
- **Watch without downloading:** every video in an item has a **Play** button next to its tick box.
  AniBox's player then plays it straight from archive.org, like Frostbox does (nothing is saved on
  your drives). Resume, "watched at 95 %", the playing bar and the phone remote work as for your own
  episodes; next and previous are the item's other videos of the same kind (originals, or
  archive.org's copies in the same format), and subtitle files with the video's name come along.
  **Continue watching** on the Internet Archive tab (and on Home) lists the items you started.
  Progress is kept under keys like `ia:<item>/<file>`, the item list in `app\ia-streams.json`.

## Library layout it expects

`<library folder>\<show folder>\<episodes>`, the way the Shield drives are organized:

```
NVIDIA_SHIELD\
  Anime\
    Sousou no Frieren\
      Sousou no Frieren 01.mkv
  One Piece\
    One Piece\
      Season 01\One Piece 001.mkv
  Anime Movies\
    Mononoke Hime\Mononoke Hime.mkv
```

The folder holding the videos is the show and the folder above it the library. `Season NN`
folders are kept as seasons, and so are folders named after the show inside the show's folder
(`Rick and Morty\Rick and Morty - Season 1`); folders such as `Extras` or `Featurettes` are skipped.
An anime folder whose name ends in "Season 3" but sits directly in a library (`Anime\Shingeki no
Kyojin Season 3`) stays its own show, because it's its own MyAnimeList entry. Show
folders are matched to MyAnimeList by their name (MAL titles and alternative titles). After a
scan, AniBox picks the libraries where most folders are anime; you can change the choice in
Settings.

## Your data

Everything AniBox keeps is in **one folder**: `%LOCALAPPDATA%\AniBox` on Windows
(`~/.local/share/anibox` elsewhere). **Settings → Your data → Open data folder** shows it.

- `app\`: settings and watch progress (`anibox.db`), the library cache (`library.json`, plus
  `scan-cache.json` with the folder listings that make rescans quick), the copy of Plex's details,
  posters, logs
  (`app\logs\anibox.log`, send this file when something goes wrong), daily copies of the watch
  progress (`app\backups`, last 7 days).
- `data\`: the anime lists (shared with the Library Check, refreshed weekly).
- `mpv\`: the downloaded player.
- `settings.json` and `ignored.txt`: the Plex sign-in (on Windows encrypted for your user account, so a copy on another PC asks you to sign in again) and hidden items.

It's separate from the program folder so that a new version can replace the program folder
without losing anything. Versions up to 1.0 kept `settings.json`/`ignored.txt` in
`%APPDATA%\AniBox`; they are copied over once and the old folder can be deleted afterwards.

- **Back up watch progress** saves one file (to your Downloads) that **Restore a backup** reads
  back; for each episode the newer entry wins and nothing is deleted.
- **Tidy up** lists AniBox's own leftovers that aren't needed anymore (the old `run-check.bat`, the
  previous version kept after an update, update zips in Downloads you've already installed, the
  settings folder of AniBox 1.0) and removes each one only when you click **Remove**.
- **Portable mode**: if a folder named `data` sits next to `AniBox.bat`, AniBox keeps everything
  there instead (e.g. on a USB stick). **Copy to the program folder** sets this up; when you
  update, copy the `data` folder into the new version.

## Other parts of this repository

- **[library-check/](library-check/)**: the engine behind the Missing page (matching folders and
  Plex items to MyAnimeList, franchises, the HTML/CSV reports). Its command-line version still runs
  for developers; see its README.
- **[CLAUDE.md](CLAUDE.md)**: background research and decisions (Plex vs. Jellyfin, metadata
  agents, the Jikan shutdown, Shoko, remote access).

## For developers

Python 3.9+, standard library only. The app is a small local web server
(`app/anibox/server.py`) with the window as a web page (`app/anibox/web/`); mpv is controlled over
its JSON IPC.

```
cd app && python -m unittest discover -s tests -t .
cd library-check && python -m unittest discover -s tests -t .
```

The player tests need `mpv` and `ffmpeg` and are skipped without them.

`python tools/build_windows.py` builds the Windows package with Python's embeddable distribution inside
(pinned version and checksum; see `tools/README.md`); `python -m unittest tools/test_build_windows.py` tests it.

## Credits

- **Frostbox** by Martin: the design (colors, Sora/Inter typography, cards, the glow), the playing
  features and the phone remote page. Used and adapted with permission.
- [Fribb/anime-lists](https://github.com/Fribb/anime-lists): MyAnimeList ↔ AniDB/TVDB/TMDB mapping.
- [anime-offline-database](https://github.com/cedya77/anime-offline-database) (ODbL): titles,
  related entries and poster links.
- [MyAnimeList API](https://myanimelist.net/apiconfig/references/api/v2) (optional, your own Client ID).
- [AniList API](https://docs.anilist.co) (public, no account): air dates for the new-episode notices.
- [TMDB](https://www.themoviedb.org) (optional, your own key): series and movie info and posters.
  This product uses the TMDB API but is not endorsed or certified by TMDB.
- [mpv](https://mpv.io) (GPL/LGPL), Windows build by
  [shinchiro](https://github.com/shinchiro/mpv-winbuild-cmake); downloaded on request, not included.
- [FFmpeg](https://ffmpeg.org) (GPL), Windows build by [Gyan Doshi](https://www.gyan.dev/ffmpeg/builds/)
  ([GyanD/codexffmpeg](https://github.com/GyanD/codexffmpeg)); downloaded on request, not included.
- [Jimaku](https://jimaku.cc) and [OpenSubtitles](https://www.opensubtitles.com) (optional, your own keys).
- Fonts [Sora](https://github.com/sora-xor/sora-font) and [Inter](https://rsms.me/inter/),
  SIL Open Font License (`app/anibox/web/fonts/`).
- [qrcode-generator](https://github.com/kazuhikoarase/qrcode-generator) by Kazuhiko Arase, MIT.
