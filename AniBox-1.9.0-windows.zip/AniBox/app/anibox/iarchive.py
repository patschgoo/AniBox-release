"""Internet Archive (archive.org): search, look at an item, download its files into a folder you choose.

- Search uses archive.org's public advanced search (``/advancedsearch.php``), the item page its
  metadata API (``/metadata/<identifier>``). No account and no cookies: every request carries only
  ``User-Agent: AniBox/<version>``. ``ANIBOX_IA_BASE`` points AniBox at another server (tests).
- Downloads go into ``<download folder>/<item title>/<file>``. AniBox only ever creates new files
  there: an existing file is never replaced (a new one gets " (2)"), and Cancel deletes only the
  ``.part`` file AniBox itself started for that download.
- The list of downloads is kept in ``ia-downloads.json`` in AniBox's data folder, so it survives a
  restart. At most two run at the same time (one small pool of background threads); they resume
  where they stopped (HTTP ``Range``) and are checked against archive.org's MD5 checksum when the
  item lists one. When archive.org is busy (429/503) AniBox waits and tries again later.

The ideas follow Frostbox's archive client (Martin's, used with permission): resolve the download
through archive.org's redirect, retry with growing pauses, back off on 429/503, check the MD5.
"""

from __future__ import annotations

import hashlib
import http.client
import json
import logging
import math
import os
import queue
import re
import secrets
import threading
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
from html.parser import HTMLParser
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Optional, Tuple

from . import __version__

log = logging.getLogger("anibox.iarchive")

BASE_URL = "https://archive.org"
USER_AGENT = f"AniBox/{__version__}"
ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,100}$")
LINK_RE = re.compile(r"archive\.org/(?:details|download|metadata|embed)/([A-Za-z0-9._-]{1,100})", re.I)
VIDEO_EXT = (".mkv", ".mp4", ".m4v", ".avi", ".ogv", ".webm", ".mpg", ".mpeg", ".mov", ".wmv", ".ts")
SUB_EXT = (".srt", ".ass", ".ssa", ".vtt", ".sub", ".idx", ".sup")
SORTS = {"downloads": "downloads desc", "newest": "publicdate desc", "title": "titleSorter asc"}
MEDIA = ("video", "any")
FIELDS = ("identifier", "title", "year", "downloads", "item_size", "mediatype", "collection")
ROWS = 48
MAX_PAGES = 200  # archive.org's search doesn't page much deeper
MAX_ACTIVE = 2  # downloads at the same time
CHUNK = 256 * 1024
STATE_FILE = "ia-downloads.json"
DEFAULT_FOLDER_NAME = "AniBox Internet Archive"
# Windows: keep whole paths (plus " (99).part") under the old 260-character limit
MAX_PATH = 250 if os.name == "nt" else 0

NO_CONNECTION = "archive.org didn't answer. Check the internet connection and try again."
BUSY = "archive.org is busy right now. Try again in a minute."

# Job states: queued → running → (verifying) → done; waiting = try again later; paused, error, cancelled
LIVE = ("queued", "running", "waiting", "verifying")


class ArchiveError(Exception):
    def __init__(self, message: str, status: int = 0):
        super().__init__(message)
        self.status = status


# -- small helpers -----------------------------------------------------------------------------------

def valid_id(text) -> bool:
    return isinstance(text, str) and bool(ID_RE.match(text)) and text.strip(".") != ""


def link_id(text: str) -> str:
    """The item name in a pasted archive.org link ("https://archive.org/details/<id>"), else ""."""
    m = LINK_RE.search(text or "")
    return m.group(1) if m and valid_id(m.group(1)) else ""


def _as_list(v) -> list:
    if v is None:
        return []
    return list(v) if isinstance(v, (list, tuple)) else [v]


def _text(v) -> str:
    items = [str(x).strip() for x in _as_list(v) if x is not None and str(x).strip()]
    return items[0] if items else ""


def _int(v) -> Optional[int]:
    try:
        return int(float(_text(v)))
    except (TypeError, ValueError):
        return None


def _year(v) -> str:
    m = re.search(r"\b(1[89]\d\d|2[01]\d\d)\b", " ".join(str(x) for x in _as_list(v)))
    return m.group(1) if m else ""


def _length(v) -> Optional[float]:
    """archive.org writes lengths as seconds ("555.28") or as a clock ("09:14", "1:02:03")."""
    s = _text(v)
    if not s:
        return None
    try:
        if ":" in s:
            total = 0.0
            for part in s.split(":"):
                total = total * 60 + float(part)
            return total
        return float(s)
    except ValueError:
        return None


def _collections(v) -> List[str]:
    return [c for c in (str(x) for x in _as_list(v)) if c and not c.startswith("fav-") and valid_id(c)]


class _Text(HTMLParser):
    BLOCK = {"p", "div", "tr", "table", "ul", "ol", "blockquote", "pre", "h1", "h2", "h3", "h4", "h5", "h6", "hr"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.out: List[str] = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style"):
            self.skip += 1
        elif tag == "br":
            self.out.append("\n")
        elif tag == "li":
            self.out.append("\n• ")
        elif tag in self.BLOCK:
            self.out.append("\n\n")

    def handle_endtag(self, tag):
        if tag in ("script", "style"):
            self.skip = max(0, self.skip - 1)
        elif tag in self.BLOCK:
            self.out.append("\n\n")

    def handle_data(self, data):
        if not self.skip:
            self.out.append(data)


def html_to_text(html: str, limit: int = 8000) -> str:
    """An item description (often HTML) as plain text with paragraphs kept."""
    p = _Text()
    try:
        p.feed(str(html or ""))
        p.close()
    except Exception:  # broken markup: keep what was read
        pass
    text = "".join(p.out).replace("\r\n", "\n").replace("\r", "\n").replace("\xa0", " ")
    lines = [re.sub(r"[ \t\f\v]+", " ", line).strip() for line in text.split("\n")]
    text = re.sub(r"\n{3,}", "\n\n", "\n".join(lines)).strip()
    return text if len(text) <= limit else text[:limit].rstrip() + " …"


# -- file names for Windows ------------------------------------------------------------------------

_BAD_CHARS = re.compile(r'[<>:"/\\|?*\x00-\x1f\x7f]')
_RESERVED = {"CON", "PRN", "AUX", "NUL"} | {f"COM{i}" for i in range(1, 10)} | {f"LPT{i}" for i in range(1, 10)}


def safe_name(name: str, fallback: str = "file", limit: int = 120) -> str:
    """A file or folder name Windows accepts: no ``<>:"/\\|?*``, no trailing dots or spaces, no
    reserved names such as CON, not too long (the extension is kept)."""
    s = unicodedata.normalize("NFC", str(name or ""))
    s = _BAD_CHARS.sub("_", s)
    s = re.sub(r"\s+", " ", s).strip().rstrip(". ")
    if not s or set(s) <= {"_", "."}:
        s = _BAD_CHARS.sub("_", str(fallback or "file")).strip().rstrip(". ") or "file"
    if s.split(".")[0].strip().upper() in _RESERVED:
        s = "_" + s
    if len(s) > limit:
        stem, ext = os.path.splitext(s)
        if 1 < len(ext) <= 12:
            s = stem[: limit - len(ext)].rstrip(". ") + ext
        else:
            s = s[:limit].rstrip(". ")
    return s


def safe_relpath(name: str) -> List[str]:
    """An archive.org file name ("Season 1/Episode 01.mkv") as safe path parts. Subfolders are kept;
    ``..`` and empty parts can never lead outside the item's folder."""
    parts = [p for p in re.split(r"[\\/]+", str(name or "")) if p and p != "."]
    if not parts:
        return ["file"]
    out = [safe_name(p, "_", 80) for p in parts[:-1]] + [safe_name(parts[-1], "file", 120)]
    return [("_" if p in (".", "..") else p) for p in out]


def fit_path(folder: Path, parts: List[str], limit: int = MAX_PATH) -> Path:
    """Shorten the file name so the whole path stays under ``limit`` characters (Windows only)."""
    path = folder.joinpath(*parts)
    over = len(str(path)) + 10 - limit  # room for " (99)" and ".part"
    if limit and over > 0:
        stem, ext = os.path.splitext(parts[-1])
        stem = stem[: max(16, len(stem) - over)].rstrip(" .") or "file"
        path = folder.joinpath(*parts[:-1], stem + ext)
    return path


def _key(path) -> str:
    return os.path.normcase(os.path.abspath(str(path))).casefold()


def unique_path(path: Path, taken: Iterable[str] = ()) -> Path:
    """``path``, or "name (2).ext", "name (3).ext" … if that name is already used (on disk, by a
    ``.part`` file, or by another download in the list)."""
    taken = set(taken)
    stem, ext = os.path.splitext(path.name)
    cand, n = path, 1
    while cand.exists() or Path(str(cand) + ".part").exists() or _key(cand) in taken:
        n += 1
        cand = path.with_name(f"{stem} ({n}){ext}")
    return cand


def move_no_replace(src: Path, dst: Path) -> None:
    """Rename the finished ``.part`` file into place, never over an existing file."""
    if os.name == "nt":
        os.rename(src, dst)  # Windows refuses (FileExistsError) when dst exists
        return
    try:
        os.link(src, dst)  # fails when dst exists, even between the check and the move
    except FileExistsError:
        raise
    except OSError:  # a file system without hard links (FAT/exFAT USB disks, some network drives)
        if os.path.lexists(dst):
            raise FileExistsError(str(dst))
        os.rename(src, dst)
        return
    os.unlink(src)


def md5_file(path: Path, check: Callable[[], None] = lambda: None) -> str:
    h = _new_md5()
    with open(path, "rb") as f:
        while True:
            check()
            block = f.read(1 << 20)
            if not block:
                return h.hexdigest()
            h.update(block)


def _new_md5():
    try:
        return hashlib.md5(usedforsecurity=False)  # type: ignore[call-arg]
    except TypeError:
        return hashlib.md5()


# -- talking to archive.org ---------------------------------------------------------------------------

def clean_words(text: str) -> str:
    """Search words without archive.org's query syntax (so a typed ":" or "(" can't break the query)."""
    text = re.sub(r'[+\-&|!(){}\[\]^"~*?:\\/]', " ", str(text or ""))[:200]
    return " ".join(w for w in text.split() if w.upper() not in ("AND", "OR", "NOT", "TO"))


def build_query(text: str, media: str = "video", collection: str = "") -> str:
    parts = []
    words = clean_words(text)
    if words:
        fields = [f"title:({words})", f"subject:({words})", f"creator:({words})"]
        raw = str(text or "").strip()
        if valid_id(raw):  # an item name typed in
            fields.append("identifier:(" + raw.replace("-", "\\-") + ")")
        parts.append("(" + " OR ".join(fields) + ")")
    if collection:
        if not valid_id(collection):
            raise ArchiveError("That isn't an archive.org collection name.")
        parts.append(f"collection:({collection})")
    if not parts:
        raise ArchiveError("Type what you're looking for.")
    parts.append("mediatype:(movies)" if media == "video" else "NOT mediatype:(account)")
    return " AND ".join(parts)


def file_json(f: dict) -> Optional[dict]:
    name = str(f.get("name") or "").replace("\\", "/")
    parts = [p for p in name.split("/") if p and p != "."]
    if not parts or ".." in parts or name.startswith("/"):
        return None
    ext = os.path.splitext(name)[1].lower()
    source = _text(f.get("source")).lower()
    kind = "video" if ext in VIDEO_EXT else "subtitle" if ext in SUB_EXT else "other"
    md5 = _text(f.get("md5")).lower()
    return {
        "name": name, "size": _int(f.get("size")), "format": _text(f.get("format")),
        "md5": md5 if re.fullmatch(r"[0-9a-f]{32}", md5) else "",
        "length": _length(f.get("length")), "source": source or "original", "original": _text(f.get("original")),
        "kind": kind,
        "hidden": kind == "other",  # thumbnails, metadata, torrents … ("Show all files" shows them)
        "pick": False,
    }


def _natural(text: str):
    return [int(t) if t.isdigit() else t.casefold() for t in re.split(r"(\d+)", text)]


def _file_order(f: dict):
    group = {"video": 0, "subtitle": 1}.get(f["kind"], 2)
    return group, 0 if f["source"] == "original" else 1, _natural(f["name"])


class ArchiveClient:
    def __init__(self, base_url: Optional[str] = None, timeout: float = 30):
        base = (base_url or os.environ.get("ANIBOX_IA_BASE") or BASE_URL).rstrip("/")
        if not base.startswith(("https://", "http://")):
            base = BASE_URL
        self.base = base
        self.timeout = timeout
        self._items: Dict[str, Tuple[float, dict]] = {}
        self._lock = threading.Lock()

    # -- HTTP
    def open(self, url: str, headers: Optional[dict] = None, timeout: Optional[float] = None):
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept-Encoding": "identity", **(headers or {})})
        return urllib.request.urlopen(req, timeout=timeout or self.timeout)

    def _json(self, url: str, limit: int):
        try:
            with self.open(url) as resp:
                data = resp.read(limit + 1)
        except urllib.error.HTTPError as exc:
            exc.close()
            if exc.code in (429, 503):
                raise ArchiveError(BUSY, exc.code)
            raise ArchiveError(f"archive.org answered with an error ({exc.code}). Try again later.", exc.code)
        except (urllib.error.URLError, OSError, http.client.HTTPException) as exc:
            log.info("archive.org: %s (%s)", exc, url.split("?")[0])
            raise ArchiveError(NO_CONNECTION) from exc
        if len(data) > limit:
            raise ArchiveError("archive.org's answer was too big.")
        try:
            return json.loads(data.decode("utf-8"))
        except ValueError:
            raise ArchiveError("archive.org sent an answer AniBox can't read. Try again later.")

    def file_url(self, identifier: str, name: str) -> str:
        return f"{self.base}/download/{identifier}/{urllib.parse.quote(name, safe='/')}"

    def thumb_url(self, identifier: str) -> str:
        return f"{self.base}/services/img/{identifier}"

    # -- search
    def search(self, text: str = "", media: str = "video", sort: str = "downloads", page: int = 1,
               collection: str = "", rows: int = ROWS) -> dict:
        media = media if media in MEDIA else "video"
        sort = sort if sort in SORTS else "downloads"
        try:
            page = max(1, min(int(page), MAX_PAGES))
        except (TypeError, ValueError):
            page = 1
        q = build_query(text, media, collection)
        params = [("q", q)] + [("fl[]", f) for f in FIELDS] + [
            ("sort[]", SORTS[sort]), ("rows", str(rows)), ("page", str(page)), ("output", "json")]
        data = self._json(f"{self.base}/advancedsearch.php?{urllib.parse.urlencode(params)}", 10_000_000)
        resp = data.get("response") if isinstance(data, dict) else None
        if not isinstance(resp, dict):
            raise ArchiveError("archive.org couldn't search for that. Try other words.")
        total = _int(resp.get("numFound")) or 0
        results = []
        for d in resp.get("docs") or []:
            ident = d.get("identifier") if isinstance(d, dict) else None
            if not valid_id(ident):
                continue
            results.append({
                "id": ident, "title": _text(d.get("title")) or ident, "year": _year(d.get("year")),
                "size": _int(d.get("item_size")), "downloads": _int(d.get("downloads")),
                "mediatype": _text(d.get("mediatype")), "collections": _collections(d.get("collection"))[:3],
                "thumb": self.thumb_url(ident),
            })
        return {"query": str(text or ""), "media": media, "sort": sort, "collection": collection, "page": page,
                "pages": max(1, min(MAX_PAGES, math.ceil(total / rows))), "total": total, "results": results}

    # -- one item
    def item(self, identifier: str) -> dict:
        if not valid_id(identifier):
            raise ArchiveError("That isn't an archive.org item name.")
        data = self._json(f"{self.base}/metadata/{identifier}", 60_000_000)
        md = data.get("metadata") if isinstance(data, dict) else None
        if not isinstance(md, dict) or data.get("is_dark"):
            raise ArchiveError("This item isn't on archive.org (any more).", 404)
        files = [f for f in (file_json(x) for x in data.get("files") or [] if isinstance(x, dict)) if f]
        files.sort(key=_file_order)
        videos = [f for f in files if f["kind"] == "video"]
        picks = [f for f in videos if f["source"] == "original"] or \
            [f for f in videos if "h.264" in f["format"].lower()] or videos[:1]
        for f in picks:
            f["pick"] = True
        desc = md.get("description")
        desc = "\n\n".join(str(x) for x in desc) if isinstance(desc, list) else desc
        out = {
            "id": identifier, "title": _text(md.get("title")) or identifier,
            "description": html_to_text(desc or ""), "creator": ", ".join(str(c) for c in _as_list(md.get("creator")))[:300],
            "year": _year(md.get("year")) or _year(md.get("date")), "date": _text(md.get("date")),
            "mediatype": _text(md.get("mediatype")), "collections": _collections(md.get("collection")),
            "restricted": _text(md.get("access-restricted-item")).lower() == "true",
            "files": files, "size": sum(f["size"] or 0 for f in files),
            "thumb": self.thumb_url(identifier), "url": f"https://archive.org/details/{identifier}",
        }
        with self._lock:
            self._items[identifier] = (time.time(), out)
            if len(self._items) > 50:
                for k, _ in sorted(self._items.items(), key=lambda kv: kv[1][0])[:10]:
                    self._items.pop(k, None)
        return out

    def cached_item(self, identifier: str, max_age: float = 600) -> dict:
        with self._lock:
            hit = self._items.get(identifier)
        if hit and time.time() - hit[0] < max_age:
            return hit[1]
        return self.item(identifier)

    def thumb(self, identifier: str) -> Tuple[bytes, str]:
        if not valid_id(identifier):
            raise ArchiveError("Bad item name")
        try:
            with self.open(self.thumb_url(identifier), timeout=15) as resp:
                return resp.read(3_000_000), resp.headers.get("Content-Type") or ""
        except urllib.error.HTTPError as exc:
            exc.close()
            raise ArchiveError(f"No picture ({exc.code})", exc.code)
        except (urllib.error.URLError, OSError, http.client.HTTPException) as exc:
            raise ArchiveError(NO_CONNECTION) from exc


class ThumbCache:
    """Item pictures, fetched by AniBox (so the window never talks to archive.org itself) and kept a month."""

    MAX_AGE = 30 * 86400
    TYPES = ((b"\xff\xd8", ".jpg", "image/jpeg"), (b"\x89PNG", ".png", "image/png"), (b"GIF8", ".gif", "image/gif"))

    def __init__(self, folder: Path, client: ArchiveClient, max_files: int = 4000):
        self.folder = folder
        self.client = client
        self.max_files = max_files
        self._saved = 0

    def _name(self, identifier: str) -> str:  # identifiers differ in case; Windows file names don't
        return hashlib.sha1(identifier.encode("utf-8")).hexdigest()[:24]

    def get(self, identifier: str) -> Tuple[Optional[bytes], str]:
        if not valid_id(identifier):
            return None, ""
        base = self.folder / self._name(identifier)
        now = time.time()
        for magic, ext, ctype in self.TYPES + ((b"RIFF", ".webp", "image/webp"),):
            p = base.with_suffix(ext)
            try:
                if now - p.stat().st_mtime < self.MAX_AGE:
                    return p.read_bytes(), ctype
            except OSError:
                pass
        miss = base.with_suffix(".none")
        try:
            if now - miss.stat().st_mtime < 86400:  # no picture: ask again tomorrow
                return None, ""
        except OSError:
            pass
        try:
            data, _ = self.client.thumb(identifier)
        except ArchiveError as exc:
            if exc.status in (403, 404, 410):
                self._write(miss, b"")
            return None, ""
        for magic, ext, ctype in self.TYPES:
            if data.startswith(magic):
                self._write(base.with_suffix(ext), data)
                return data, ctype
        if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
            self._write(base.with_suffix(".webp"), data)
            return data, "image/webp"
        return None, ""

    def _write(self, path: Path, data: bytes) -> None:
        try:
            self.folder.mkdir(parents=True, exist_ok=True)
            tmp = path.with_name(path.name + ".tmp")
            tmp.write_bytes(data)
            os.replace(tmp, path)
            self._saved += 1
            if self._saved % 200 == 0:
                self._prune()
        except OSError:
            pass

    def _prune(self) -> None:
        files = sorted(self.folder.iterdir(), key=lambda p: p.stat().st_mtime)
        for p in files[: max(0, len(files) - self.max_files)]:
            try:
                p.unlink()  # AniBox's own picture cache, nothing else
            except OSError:
                pass


# -- downloads -----------------------------------------------------------------------------------------

class _Stop(Exception):
    def __init__(self, reason: str):
        super().__init__(reason)
        self.reason = reason  # pause, cancel, shutdown


class _Retry(Exception):
    def __init__(self, delay: float, message: str):
        super().__init__(message)
        self.delay = delay


class _Fail(Exception):
    pass


def _reason(exc: OSError) -> str:
    return exc.strerror or exc.__class__.__name__


def _wait_text(seconds: float) -> str:
    seconds = int(round(seconds))
    return f"{seconds} s" if seconds < 90 else f"{round(seconds / 60)} min"


PUBLIC_KEYS = ("id", "item", "itemTitle", "name", "folder", "target", "size", "done", "state", "message", "add",
               "added", "finished", "retryAt")


class Downloads:
    """The download list: a queue saved in ``ia-downloads.json``, at most ``max_active`` at once."""

    def __init__(self, data_dir: Path, client: ArchiveClient, on_done: Optional[Callable[[dict], None]] = None,
                 max_active: int = MAX_ACTIVE):
        self.path = Path(data_dir) / STATE_FILE
        self.client = client
        self.on_done = on_done
        self.max_active = max_active
        self.busy_delays: Tuple[float, ...] = (15, 30, 60, 120, 300)  # archive.org said 429/503
        self.net_delays: Tuple[float, ...] = (5, 15, 30, 60, 120)  # no connection; then "error"
        self.retry_floor = 5.0  # shortest wait a Retry-After header can ask for
        self.read_timeout = 30.0
        self._lock = threading.RLock()
        self._jobs: List[dict] = []
        self._folders: Dict[str, str] = {}  # item folder (key) -> archive.org item it was made for
        self._signals: Dict[str, str] = {}
        self._active: set = set()
        self._rate: Dict[str, list] = {}  # job id -> [window start, bytes at start, speed]
        self._queue: "queue.Queue[Optional[str]]" = queue.Queue()
        self._workers: List[threading.Thread] = []
        self._timer: Optional[threading.Timer] = None
        self._timer_at = 0.0
        self._closed = False
        self._last_save = 0.0
        self._load()

    # -- saving ------------------------------------------------------------------------------------

    def _load(self) -> None:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return
        except (OSError, ValueError) as exc:
            log.warning("The download list %s couldn't be read (%s); starting with an empty list", self.path, exc)
            try:
                os.replace(self.path, self.path.with_name(self.path.stem + ".damaged.json"))
            except OSError:
                pass
            return
        jobs = []
        for j in data.get("jobs") or [] if isinstance(data, dict) else []:
            if not isinstance(j, dict) or not all(isinstance(j.get(k), str) for k in ("id", "item", "name", "target", "state")):
                continue
            j.setdefault("retryAt", 0)
            for k, v in (("done", 0), ("attempts", 0), ("busy", 0), ("message", ""), ("partMade", False),
                         ("restart", False), ("check", ""), ("add", False), ("finished", 0), ("md5", ""),
                         ("itemTitle", j["item"]), ("folder", str(Path(j["target"]).parent)), ("dir", ""), ("size", None),
                         ("added", 0)):
                j.setdefault(k, v)
            if j["state"] in ("running", "verifying", "waiting"):
                j["state"], j["message"] = "queued", ""
            jobs.append(j)
        self._jobs = jobs
        folders = data.get("folders") if isinstance(data, dict) else None
        self._folders = {str(k): str(v) for k, v in folders.items()} if isinstance(folders, dict) else {}

    def _save(self) -> None:
        with self._lock:
            data = json.dumps({"version": 1, "jobs": self._jobs, "folders": self._folders}, ensure_ascii=False)
            self._last_save = time.time()
            try:
                self.path.parent.mkdir(parents=True, exist_ok=True)
                tmp = self.path.with_name(self.path.name + ".tmp")
                tmp.write_text(data, encoding="utf-8")
                os.replace(tmp, self.path)
            except OSError:
                log.warning("The download list couldn't be saved", exc_info=True)

    # -- looking -----------------------------------------------------------------------------------

    def jobs(self, item: str = "") -> List[dict]:
        with self._lock:
            out = []
            for j in self._jobs:
                if item and j["item"] != item:
                    continue
                d = {k: j.get(k) for k in PUBLIC_KEYS}
                d["file"] = Path(j["target"]).name
                rate = self._rate.get(j["id"])
                d["speed"] = round(rate[2]) if rate and j["state"] == "running" else 0
                out.append(d)
            return out

    def busy(self) -> bool:
        """Something is downloading or will start by itself (keeps AniBox from closing)."""
        with self._lock:
            return any(j["state"] in LIVE for j in self._jobs)

    def pending_for_item(self, item: str, exclude: str = "") -> bool:
        with self._lock:
            return any(j["item"] == item and j["add"] and j["state"] in LIVE and j["id"] != exclude for j in self._jobs)

    def folder_for(self, root: str, item: dict, claim: bool = False) -> Path:
        """``<root>/<item title>``; a second item with the same title gets "<title> (<id>)"."""
        base = safe_name(item.get("title") or item["id"], item["id"], 80)
        folder = Path(root) / base
        with self._lock:
            owner = self._folders.get(_key(folder))
            if owner and owner != item["id"]:
                folder = Path(root) / safe_name(f"{base} ({item['id']})", item["id"], 120)
            if claim:
                self._folders[_key(folder)] = item["id"]
        return folder

    # -- adding ------------------------------------------------------------------------------------

    def add(self, item: dict, names: List[str], root: str, add_to_library: bool) -> dict:
        """Queue files of an archive.org item. Returns ``{"added": n, "skipped": [names]}``."""
        if not names:
            raise ValueError("Tick at least one file.")
        if not os.path.isabs(str(root or "")):
            raise ValueError("Choose a full folder path for the downloads, e.g. C:\\Users\\…\\Downloads\\AniBox Internet Archive.")
        files = {f["name"]: f for f in item["files"]}
        unknown = [str(n) for n in names if not isinstance(n, str) or n not in files]
        if unknown:
            raise ValueError(f"This item has no file called {unknown[0]!r}.")
        added, skipped = [], []
        with self._lock:
            folder = self.folder_for(root, item, claim=True)
            taken = {_key(j["target"]) for j in self._jobs if j["state"] != "cancelled"}
            for name in dict.fromkeys(names):
                f = files[name]
                same = [j for j in self._jobs if j["item"] == item["id"] and j["name"] == name
                        and _key(j["folder"]) == _key(folder) and j["state"] != "cancelled"]
                if any(j["state"] != "done" or Path(j["target"]).is_file() for j in same):
                    skipped.append(name)
                    continue
                natural = fit_path(folder, safe_relpath(name))
                target = unique_path(natural, taken)
                job = {
                    "id": secrets.token_hex(6), "item": item["id"], "itemTitle": item.get("title") or item["id"],
                    "name": name, "dir": str(root), "folder": str(folder), "target": str(target),
                    "size": f.get("size"), "md5": f.get("md5") or "", "done": 0, "state": "queued", "message": "",
                    "add": bool(add_to_library), "added": time.time(), "finished": 0, "retryAt": 0,
                    "partMade": False, "restart": False, "attempts": 0, "busy": 0,
                    # a file with this name is already there: if it's the same file, nothing needs downloading
                    "check": str(natural) if natural != target and natural.is_file() else "",
                }
                taken.add(_key(target))
                self._jobs.append(job)
                added.append(job)
            self._save()
        if added:
            log.info("Internet Archive: %d file(s) of %s queued into %s", len(added), item["id"], folder)
        self._pump()
        return {"added": len(added), "skipped": skipped, "folder": str(folder)}

    # -- buttons -----------------------------------------------------------------------------------

    def action(self, action: str, job_id: str = "", item: str = "") -> dict:
        if action not in ("pause", "resume", "cancel", "clear"):
            raise ValueError("Unknown action")
        with self._lock:
            if action == "clear":
                before = len(self._jobs)
                self._jobs = [j for j in self._jobs if j["state"] not in ("done", "cancelled")
                              or (job_id and j["id"] != job_id) or (item and j["item"] != item)]
                self._save()
                return {"ok": True, "cleared": before - len(self._jobs)}
            targets = [j for j in self._jobs if (job_id and j["id"] == job_id) or (item and not job_id and j["item"] == item)]
            if not targets:
                raise KeyError("That download isn't in the list any more.")
            for j in targets:
                running = j["id"] in self._active
                if action == "pause" and j["state"] in LIVE:
                    if running:
                        self._signals[j["id"]] = "pause"
                    else:
                        j["state"], j["message"] = "paused", ""
                elif action == "resume" and j["state"] in ("paused", "error", "waiting"):
                    j.update(state="queued", message="", attempts=0, busy=0, retryAt=0)
                elif action == "cancel" and j["state"] not in ("done", "cancelled"):
                    if running:
                        self._signals[j["id"]] = "cancel"
                    else:
                        self._remove_part(j)
                        j.update(state="cancelled", message="", done=0)
            self._save()
        self._pump()
        return {"ok": True}

    def _remove_part(self, job: dict) -> None:
        """Delete the unfinished ``.part`` file of this download, and only that: AniBox made it itself
        (it never takes over a ``.part`` file that was already there)."""
        if not job.get("partMade"):
            return
        part = Path(job["target"] + ".part")
        try:
            if part.is_file():
                part.unlink()
        except OSError as exc:
            log.warning("Couldn't remove %s (%s)", part, exc)
            return
        job["partMade"] = False

    # -- running -----------------------------------------------------------------------------------

    def start(self) -> None:
        self._pump()

    def _pump(self) -> None:
        with self._lock:
            if self._closed:
                return
            now, wake = time.time(), None
            for j in self._jobs:
                if j["state"] == "waiting":
                    if j["retryAt"] <= now:
                        j["state"] = "queued"
                    else:
                        wake = min(wake or j["retryAt"], j["retryAt"])
            for j in self._jobs:
                if len(self._active) >= self.max_active:
                    break
                if j["state"] == "queued" and j["id"] not in self._active:
                    j.update(state="running", message="Connecting …")
                    self._active.add(j["id"])
                    self._ensure_workers()
                    self._queue.put(j["id"])
            if wake is not None:
                self._wake_at(wake)

    def _ensure_workers(self) -> None:
        self._workers = [t for t in self._workers if t.is_alive()]
        while len(self._workers) < self.max_active:
            t = threading.Thread(target=self._worker, daemon=True, name=f"anibox-ia-{len(self._workers) + 1}")
            t.start()
            self._workers.append(t)

    def _worker(self) -> None:
        while True:
            jid = self._queue.get()
            if jid is None:
                return
            self._run(jid)

    def _wake_at(self, when: float) -> None:
        # a timer that's still to come and comes early enough will do (a timer that's firing right now
        # doesn't count: it's the one asking)
        if self._timer and self._timer.is_alive() and time.time() < self._timer_at <= when:
            return
        if self._timer:
            self._timer.cancel()
        self._timer_at = when
        self._timer = threading.Timer(max(0.02, when - time.time()), self._pump)
        self._timer.daemon = True
        self._timer.start()

    def shutdown(self, wait: float = 3.0) -> None:
        """AniBox closes: stop the downloads (they go on next time) and save the list."""
        with self._lock:
            self._closed = True
            for jid in self._active:
                self._signals[jid] = "shutdown"
            if self._timer:
                self._timer.cancel()
        deadline = time.time() + wait
        while time.time() < deadline:
            with self._lock:
                if not self._active:
                    break
            time.sleep(0.05)
        for _ in self._workers:
            self._queue.put(None)
        self._save()

    def _job(self, jid: str) -> Optional[dict]:
        with self._lock:
            return next((j for j in self._jobs if j["id"] == jid), None)

    def _set(self, job: dict, **kw) -> None:
        with self._lock:
            job.update(kw)

    def _check(self, job: dict) -> None:
        sig = self._signals.get(job["id"])
        if sig:
            raise _Stop(sig)

    def _run(self, jid: str) -> None:
        job = self._job(jid)
        finished = False
        try:
            if job is None:
                return
            self._download(job)
            finished = True
        except _Stop as stop:
            with self._lock:
                if stop.reason == "cancel":
                    self._remove_part(job)
                    job.update(state="cancelled", message="", done=0)
                elif stop.reason == "shutdown":
                    job.update(state="queued", message="")
                else:
                    job.update(state="paused", message="")
        except _Retry as r:
            self._set(job, state="waiting", message=str(r), retryAt=time.time() + r.delay)
        except _Fail as f:
            log.info("Internet Archive download stopped: %s/%s: %s", job["item"], job["name"], f)
            self._set(job, state="error", message=str(f))
        except Exception as exc:  # shown in the list
            log.exception("Internet Archive download failed: %s/%s", job and job["item"], job and job["name"])
            if job is not None:
                self._set(job, state="error", message=f"The download stopped: {exc}")
        finally:
            with self._lock:
                self._active.discard(jid)
                self._signals.pop(jid, None)
                self._rate.pop(jid, None)
            self._save()
            self._pump()
        if finished and self.on_done:
            try:
                self.on_done(dict(job))
            except Exception:
                log.exception("After the download of %s", job["target"])

    # -- one download ----------------------------------------------------------------------------

    def _busy(self, job: dict, retry_after: Optional[str]) -> _Retry:
        n = job["busy"]
        job["busy"] = n + 1
        delay = self.busy_delays[min(n, len(self.busy_delays) - 1)]
        if retry_after and retry_after.strip().isdigit():
            delay = float(retry_after.strip())
        delay = max(self.retry_floor, min(900.0, delay))
        return _Retry(delay, f"archive.org is busy. AniBox tries again in {_wait_text(delay)} …")

    def _net(self, job: dict, what: str):
        job["attempts"] += 1
        if job["attempts"] > len(self.net_delays):
            job["attempts"] = 0
            return _Fail(f"{what}. Click Resume to try again.")
        delay = self.net_delays[job["attempts"] - 1]
        return _Retry(delay, f"{what}. AniBox tries again in {_wait_text(delay)} …")

    def _same_file(self, job: dict, existing: Path) -> bool:
        try:
            size = existing.stat().st_size
        except OSError:
            return False
        if job["size"] is not None and size != job["size"]:
            return False
        if job["md5"]:
            self._set(job, state="verifying", message="Checking the file that's already in the folder …")
            return md5_file(existing, lambda: self._check(job)) == job["md5"]
        return job["size"] is not None

    def _open_part(self, job: dict, offset: int):
        """The ``.part`` file to write into, made by AniBox itself (exclusive create: a file that's
        already there is never opened, AniBox picks a free name instead)."""
        if job["partMade"] and Path(job["target"] + ".part").is_file():
            f = open(job["target"] + ".part", "r+b")
            f.seek(offset)
            f.truncate()
            return f
        with self._lock:
            taken = {_key(j["target"]) for j in self._jobs if j is not job and j["state"] != "cancelled"}
        target = Path(job["target"])
        for _ in range(200):
            if target.exists() or _key(target) in taken:
                target = unique_path(target, taken)
                continue
            try:
                f = open(str(target) + ".part", "xb")
            except FileExistsError:
                target = unique_path(target, taken)
                continue
            self._set(job, target=str(target), partMade=True)
            self._save()
            return f
        raise _Fail("AniBox found no free file name in the folder.")

    def _download(self, job: dict) -> None:
        target = Path(job["target"])
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            raise _Fail(f"AniBox couldn't make the folder {target.parent} ({_reason(exc)}).")
        if job["check"]:
            existing = Path(job["check"])
            if existing.is_file() and self._same_file(job, existing):
                self._set(job, state="done", target=str(existing), check="", finished=time.time(),
                          message="It was already in the folder.", done=job["size"] or 0)
                return
            self._set(job, check="")
        part = Path(job["target"] + ".part")
        offset = 0
        if job["partMade"] and part.is_file() and not job["restart"]:
            offset = part.stat().st_size
        if job["size"] is not None and offset > job["size"]:
            offset = 0
        digest = None
        if not (job["size"] is not None and offset == job["size"] and offset > 0):
            offset, digest = self._fetch(job, offset)
        self._finish(job, offset, digest)

    def _fetch(self, job: dict, offset: int) -> Tuple[int, Optional[str]]:
        """Download from ``offset`` to the end into the ``.part`` file. Returns how much is there and,
        when the whole file came in one go, its MD5 (so it needn't be read again)."""
        self._check(job)
        self._set(job, state="running", message="Connecting …" if not offset else "Resuming …")
        url = self.client.file_url(job["item"], job["name"])
        headers = {"Range": f"bytes={offset}-"} if offset else {}
        try:
            resp = self.client.open(url, headers, timeout=self.read_timeout)
        except urllib.error.HTTPError as exc:
            code, retry_after = exc.code, exc.headers.get("Retry-After") if exc.headers else None
            exc.close()
            if code == 416 and offset:  # nothing after offset: the file is complete, or the start is wrong
                if job["size"] is None or offset >= job["size"]:
                    return offset, None
                self._set(job, restart=True)
                raise _Retry(0.05, "Starting again from the beginning …")
            if code in (429, 503):
                raise self._busy(job, retry_after)
            if code in (404, 410):
                raise _Fail("This file isn't on archive.org any more.")
            if code in (401, 403):
                raise _Fail("archive.org doesn't allow downloading this file. It may be for lending only or restricted.")
            if code >= 500:
                raise self._net(job, f"archive.org had a problem ({code})")
            raise _Fail(f"archive.org answered with an error ({code}).")
        except (urllib.error.URLError, OSError, http.client.HTTPException):
            raise self._net(job, "No connection to archive.org")
        with resp:
            status = resp.status
            if status not in (200, 206):
                raise _Fail(f"archive.org answered with an error ({status}).")
            total = None
            if status == 206:
                m = re.match(r"bytes (\d+)-\d+/(\d+|\*)", resp.headers.get("Content-Range") or "")
                if not m or int(m.group(1)) != offset:
                    self._set(job, restart=True)
                    raise _Retry(0.05, "Starting again from the beginning …")
                total = int(m.group(2)) if m.group(2) != "*" else None
            else:
                offset = 0  # the server sent the whole file (it ignored the Range): start from the beginning
                length = resp.headers.get("Content-Length")
                total = int(length) if length and length.isdigit() else None
            if total is not None and job["size"] != total:
                self._set(job, size=total)
            hasher = _new_md5() if offset == 0 and job["md5"] else None
            try:
                f = self._open_part(job, offset)
            except OSError as exc:
                raise _Fail(f"AniBox couldn't write into {Path(job['target']).parent} ({_reason(exc)}).")
            done = offset
            self._set(job, done=done, restart=False, message="")
            self._rate[job["id"]] = [time.time(), done, 0.0]
            with f:
                while True:
                    self._check(job)
                    try:
                        chunk = resp.read(CHUNK)
                    except (OSError, http.client.HTTPException):
                        f.flush()
                        raise self._net(job, "The connection to archive.org broke off")
                    if not chunk:
                        break
                    try:
                        f.write(chunk)
                    except OSError as exc:
                        raise _Fail("The disk is full. Make room and click Resume." if exc.errno == 28
                                    else f"AniBox couldn't write the file ({_reason(exc)}).")
                    if hasher:
                        hasher.update(chunk)
                    done += len(chunk)
                    job["done"] = done
                    job["attempts"] = job["busy"] = 0
                    self._note_speed(job["id"], done)
                    if time.time() - self._last_save > 5:
                        self._save()
                f.flush()
        if job["size"] is not None and done < job["size"]:
            raise self._net(job, "The connection to archive.org broke off")
        return done, (hasher.hexdigest() if hasher else None)

    def _note_speed(self, jid: str, done: int) -> None:
        rate = self._rate.get(jid)
        if not rate:
            return
        now = time.time()
        if now - rate[0] >= 1.0:
            speed = (done - rate[1]) / (now - rate[0])
            rate[:] = [now, done, speed if not rate[2] else 0.6 * speed + 0.4 * rate[2]]

    def _finish(self, job: dict, done: int, digest: Optional[str]) -> None:
        part = Path(job["target"] + ".part")
        if job["md5"]:
            self._set(job, state="verifying", message="Checking the file …")
            if not digest:
                try:
                    digest = md5_file(part, lambda: self._check(job))
                except OSError as exc:
                    raise _Fail(f"AniBox couldn't read the downloaded file ({_reason(exc)}).")
            if digest != job["md5"]:
                self._set(job, restart=True)
                raise _Fail("The downloaded file is damaged (its checksum doesn't match archive.org's). "
                            "Click Resume to download it again.")
        elif job["size"] is not None and done != job["size"]:
            self._set(job, restart=True)
            raise _Fail("The downloaded file has the wrong size. Click Resume to download it again.")
        with self._lock:
            taken = {_key(j["target"]) for j in self._jobs if j is not job and j["state"] != "cancelled"}
        target, busy_tries = Path(job["target"]), 0
        for _ in range(200):
            if not target.exists() and _key(target) not in taken:
                try:
                    move_no_replace(part, target)
                    break
                except FileExistsError:
                    pass
                except PermissionError as exc:  # Windows: a virus scanner may still be reading the new file
                    busy_tries += 1
                    if busy_tries > 10:
                        raise _Fail(f"AniBox couldn't rename the finished file ({_reason(exc)}). Click Resume to try again.")
                    time.sleep(0.5)
                    continue
                except OSError as exc:
                    raise _Fail(f"AniBox couldn't rename the finished file ({_reason(exc)}). Click Resume to try again.")
            target = unique_path(target, taken)
        else:
            raise _Fail("AniBox found no free file name in the folder.")
        self._set(job, state="done", target=str(target), finished=time.time(), done=done, message="")
        log.info("Internet Archive: downloaded %s/%s to %s", job["item"], job["name"], target)
