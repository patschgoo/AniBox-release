"""New AniBox versions from the public release repository (like Frostbox's frostbox-releases).

The release repository (setting ``release_repo``, default ``patschgoo/AniBox-release``) holds the
Windows zips and a small ``latest.json``::

    {"version": "1.9.0", "file": "AniBox-1.9.0-windows.zip", "sha256": "…", "size": 12345678,
     "date": "2026-11-24", "notes": "What's new, in a few lines"}

AniBox reads that file at most once a day (switch: Settings → Updates). When it names a newer version,
Home and Settings say so; **Download** fetches the zip into the Downloads folder (checked against the
size and SHA-256 in ``latest.json``), and then the usual **Update now** (selfupdate.py) installs it.
Nothing is downloaded or installed without a click. A GitHub release with the zip attached works too
(the repository's "latest release"), for when the zips are published as releases instead.

Only GitHub addresses are used, and nothing about the user is sent.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Optional, Tuple

from . import __version__

log = logging.getLogger("anibox.updates")

RELEASE_REPO = "patschgoo/AniBox-release"
RAW_BASE = "https://raw.githubusercontent.com/{repo}/main/"
API_LATEST = "https://api.github.com/repos/{repo}/releases/latest"
PAGE = "https://github.com/{repo}"
CHECK_EVERY = 20 * 3600
ZIP_RE = re.compile(r"^AniBox-(\d+(?:\.\d+){1,3})-windows\.zip$")
ALLOWED_HOSTS = ("raw.githubusercontent.com", "github.com", "objects.githubusercontent.com",
                 "release-assets.githubusercontent.com", "api.github.com")


def parse_version(text: str) -> Optional[Tuple[int, ...]]:
    m = re.search(r'__version__\s*=\s*["\'](\d+(?:\.\d+){0,3})["\']', text or "")
    return tuple(int(x) for x in m.group(1).split(".")) if m else None


def version_tuple(v: str) -> Tuple[int, ...]:
    return tuple(int(x) for x in re.findall(r"\d+", v or "")[:4])


def _get(url: str, limit: int = 2_000_000, timeout: float = 15) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": f"AniBox/{__version__}", "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read(limit)


class UpdateCheck:
    def __init__(self, store, base_url: Optional[str] = None, api_url: Optional[str] = None,
                 downloads: Optional[Path] = None):
        self.store = store
        self.base_url = base_url  # tests: a fake server instead of GitHub
        self.api_url = api_url
        self.downloads = downloads
        self.download_state = {"state": "idle"}
        self._lock = threading.Lock()

    # -- where ---------------------------------------------------------------------------------

    @property
    def repo(self) -> str:
        repo = str(self.store.settings().get("release_repo") or RELEASE_REPO).strip().strip("/")
        return repo if re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", repo) else RELEASE_REPO

    def _base(self) -> str:
        return self.base_url or RAW_BASE.format(repo=self.repo)

    def _allowed(self, url: str) -> bool:
        u = urllib.parse.urlsplit(url)
        if self.base_url:  # tests: the fake server stands in for GitHub
            b = urllib.parse.urlsplit(self.base_url)
            if (u.scheme, u.netloc) == (b.scheme, b.netloc):
                return True
        return u.scheme == "https" and u.hostname in ALLOWED_HOSTS

    # -- checking ------------------------------------------------------------------------------

    def info(self) -> dict:
        saved = self.store.meta("update") or {}
        latest = saved.get("latest") or ""
        return {
            "current": __version__, "latest": latest,
            "newer": bool(latest) and version_tuple(latest) > version_tuple(__version__),
            "checked": saved.get("checked", 0), "error": saved.get("error", ""),
            "notes": saved.get("notes", ""), "date": saved.get("date", ""), "file": saved.get("file", ""),
            "canDownload": bool(saved.get("url")), "repo": self.repo, "page": PAGE.format(repo=self.repo),
            "download": dict(self.download_state),
        }

    def due(self) -> bool:
        if not self.store.settings().get("update_check", True):
            return False
        return time.time() - (self.store.meta("update") or {}).get("checked", 0) > CHECK_EVERY

    def _from_manifest(self) -> dict:
        data = json.loads(_get(self._base() + "latest.json").decode("utf-8"))
        version, name = str(data.get("version") or ""), str(data.get("file") or "")
        if not version_tuple(version) or not ZIP_RE.match(name):
            raise ValueError("latest.json doesn't name a version and an AniBox zip")
        url = data.get("url") or (self._base() + urllib.parse.quote(name))
        return {"latest": version, "file": name, "url": url, "sha256": str(data.get("sha256") or "").lower(),
                "size": int(data.get("size") or 0), "notes": str(data.get("notes") or "")[:4000], "date": str(data.get("date") or "")}

    def _from_release(self) -> dict:
        data = json.loads(_get(self.api_url or API_LATEST.format(repo=self.repo)).decode("utf-8"))
        version = str(data.get("tag_name") or data.get("name") or "").lstrip("vV")
        assets = data.get("assets") or []
        zips = [a for a in assets if ZIP_RE.match(str(a.get("name") or ""))]
        if not version_tuple(version) or not zips:
            raise ValueError("the latest release has no AniBox zip")
        z = zips[0]
        sha = ""
        side = next((a for a in assets if a.get("name") == z["name"] + ".sha256"), None)
        if side:
            sha = _get(side["browser_download_url"], limit=1000).decode("utf-8", "replace").split()[0].lower()
        else:
            m = re.search(r"sha-?256[:\s]+([0-9a-fA-F]{64})", data.get("body") or "")
            sha = m.group(1).lower() if m else ""
        return {"latest": version, "file": z["name"], "url": z["browser_download_url"], "sha256": sha,
                "size": int(z.get("size") or 0), "notes": str(data.get("body") or "")[:4000],
                "date": str(data.get("published_at") or "")[:10]}

    def check(self) -> dict:
        with self._lock:
            saved = {"checked": time.time(), "latest": (self.store.meta("update") or {}).get("latest", ""), "error": ""}
            try:
                try:
                    found = self._from_manifest()
                except urllib.error.HTTPError as exc:
                    if exc.code != 404:
                        raise
                    found = self._from_release()
                if not self._allowed(found["url"]):
                    raise ValueError("the download isn't on GitHub")
                saved.update(found)
                log.info("Update check: newest version %s (this is %s)", found["latest"], __version__)
            except urllib.error.HTTPError as exc:
                saved["error"] = (f"No release repository yet ({self.repo} isn't there or isn't public)."
                                  if exc.code == 404 else "Couldn't check for a new version.")
                log.info("Update check: %s", exc)
            except Exception as exc:
                saved["error"] = "Couldn't check for a new version."
                log.warning("Update check failed: %s", exc)
            self.store.set_meta("update", saved)
            return self.info()

    def check_later(self) -> None:
        if self.due():
            threading.Thread(target=self.check, daemon=True, name="anibox-update").start()

    # -- downloading into Downloads -----------------------------------------------------------------

    def download(self) -> dict:
        """Fetch the newer zip into Downloads in the background, checked; then "Update now" sees it."""
        saved = self.store.meta("update") or {}
        if self.download_state.get("state") == "running":
            return dict(self.download_state)
        if not saved.get("url") or not (version_tuple(saved.get("latest", "")) > version_tuple(__version__)):
            raise ValueError("There's no newer version to download. Check again first.")
        if not self._allowed(saved["url"]) or not ZIP_RE.match(saved.get("file", "")):
            raise ValueError("That download doesn't look like an AniBox release.")
        from .selfupdate import downloads_dir
        folder = Path(self.downloads or downloads_dir())
        target = folder / saved["file"]
        self.download_state = {"state": "running", "bytes": 0, "total": int(saved.get("size") or 0), "file": str(target)}

        def run():
            part = target.with_name(target.name + ".part")
            try:
                folder.mkdir(parents=True, exist_ok=True)
                if target.exists():
                    if self._matches(target, saved):
                        self.download_state.update(state="done", bytes=target.stat().st_size)
                        return
                    raise ValueError(f"{target.name} is already in Downloads but isn't this release. Remove it first.")
                h = hashlib.sha256()
                req = urllib.request.Request(saved["url"], headers={"User-Agent": f"AniBox/{__version__}"})
                with urllib.request.urlopen(req, timeout=60) as r, open(part, "wb") as fh:
                    total = int(r.headers.get("Content-Length") or saved.get("size") or 0)
                    self.download_state["total"] = total
                    while True:
                        buf = r.read(1 << 20)
                        if not buf:
                            break
                        fh.write(buf)
                        h.update(buf)
                        self.download_state["bytes"] += len(buf)
                size = part.stat().st_size
                if saved.get("size") and size != int(saved["size"]):
                    raise ValueError("the download came out the wrong size")
                if saved.get("sha256") and h.hexdigest() != saved["sha256"]:
                    raise ValueError("the download's checksum doesn't match the release")
                os.replace(part, target)
                self.download_state.update(state="done")
                log.info("Downloaded %s to %s", saved["file"], folder)
            except Exception as exc:
                try:
                    part.unlink()
                except OSError:
                    pass
                self.download_state.update(state="error", error=str(exc))
                log.warning("Downloading the update failed: %s", exc)

        threading.Thread(target=run, daemon=True, name="anibox-update-download").start()
        return dict(self.download_state)

    @staticmethod
    def _matches(path: Path, saved: dict) -> bool:
        if saved.get("size") and path.stat().st_size != int(saved["size"]):
            return False
        if saved.get("sha256"):
            h = hashlib.sha256()
            with open(path, "rb") as fh:
                for chunk in iter(lambda: fh.read(1 << 20), b""):
                    h.update(chunk)
            return h.hexdigest() == saved["sha256"]
        return True
