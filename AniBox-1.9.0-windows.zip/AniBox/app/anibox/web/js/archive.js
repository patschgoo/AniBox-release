/* AniBox window · Internet Archive page: search archive.org, look at an item, download its files into
   your download folder (and, if you like, into your AniBox library). See iarchive.py / routes_ia.py.
   Plain scripts sharing one page: loaded in order by index.html. */
"use strict";

var ia = { q: "", media: "video", sort: "downloads", page: 1, c: "", key: "", data: null, scroll: 0, back: "#/archive",
  item: null, folderName: "", dir: "", add: true, picked: {}, showAll: false, jobs: [], dl: null, n: 0 };
var IA_LIVE = ["queued", "running", "waiting", "verifying"];
var IA_TYPE = { movies: "Video", texts: "Text", audio: "Audio", image: "Pictures", software: "Software", collection: "Collection", data: "Data", web: "Web page", etree: "Concert" };
var IA_SEARCH_ICON = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#93A0AF" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>';

function iaSize(b) {
  if (b == null) return "?";
  var u = ["B", "KB", "MB", "GB", "TB"], i = 0;
  while (b >= 1024 && i < 4) { b /= 1024; i++; }
  return (i ? b.toFixed(b < 10 ? 1 : 0) : b) + " " + u[i];
}
function iaHash(p) {
  return "#/archive/find/" + ["q", "media", "sort", "page", "c"].map(function (k) { return k + "=" + encodeURIComponent(p[k] == null ? "" : p[k]); }).join("&");
}
function iaParse(s) {
  var out = {};
  (s || "").split("&").forEach(function (kv) { var i = kv.indexOf("="); if (i > 0) out[kv.slice(0, i)] = decodeURIComponent(kv.slice(i + 1)); });
  return out;
}

// ---------- router entry (main.js): #/archive, #/archive/find/…, #/archive/item/<id>, #/archive/downloads
function archive(parts) {
  clearTimeout(archive.t);
  var sub = parts[0] || "";
  if (sub === "item") return iaItem(decodeURIComponent(parts.slice(1).join("/")));
  if (sub === "downloads") return iaDownloads();
  if (sub === "find") return iaSearch(iaParse(parts.slice(1).join("/")));
  return iaSearch(null);
}

function iaHead(tab) {
  return '<div class="section" style="margin-top:0"><div><div class="kicker">Internet Archive</div><h1 style="margin-top:6px">Find and download from archive.org</h1></div></div>' +
    '<div class="row" style="margin:4px 0 18px"><div class="seg" role="tablist">' +
    '<button role="tab" data-iatab="search"' + (tab === "search" ? ' class="on"' : "") + ">Search</button>" +
    '<button role="tab" data-iatab="downloads"' + (tab === "downloads" ? ' class="on"' : "") + '>Downloads <span id="iaCount"></span></button></div></div>';
}
function iaWireHead() {
  view.querySelectorAll("[data-iatab]").forEach(function (b) {
    b.onclick = function () { location.hash = b.getAttribute("data-iatab") === "downloads" ? "#/archive/downloads" : (ia.key ? iaHash(ia) : "#/archive"); };
  });
}

// ---------- search
function iaSearch(p) {
  if (p) {
    ia.q = p.q || ""; ia.media = p.media === "any" ? "any" : "video"; ia.sort = ["newest", "title"].indexOf(p.sort) >= 0 ? p.sort : "downloads";
    ia.page = Math.max(1, parseInt(p.page, 10) || 1); ia.c = p.c || "";
  }
  var key = [ia.q, ia.media, ia.sort, ia.page, ia.c].join("|");
  render(iaHead("search") +
    '<form class="toolbar" id="iaForm" autocomplete="off"><label class="search ia-search">' + IA_SEARCH_ICON +
    '<input id="iaQ" type="search" placeholder="Search archive.org, or paste an archive.org link" value="' + esc(ia.q) + '" aria-label="Search archive.org"></label>' +
    '<button class="btn primary" type="submit">Search</button>' +
    '<div class="chips" id="iaMedia"><button type="button" class="chip' + (ia.media === "video" ? " on" : "") + '" data-media="video">Videos</button>' +
    '<button type="button" class="chip' + (ia.media === "any" ? " on" : "") + '" data-media="any" title="Also books, music, pictures, collections …">Everything</button></div>' +
    '<select class="select" id="iaSort" aria-label="Sort">' + [["downloads", "Most downloaded"], ["newest", "Newest"], ["title", "Title A–Z"]].map(function (o) {
      return '<option value="' + o[0] + '"' + (ia.sort === o[0] ? " selected" : "") + ">" + o[1] + "</option>"; }).join("") + "</select></form>" +
    (ia.c ? '<div class="row" style="margin:-8px 0 18px"><span class="chip on" style="display:inline-flex;align-items:center">In the collection “' + esc(ia.c) + '”</span><button class="btn small" id="iaNoC">Search everywhere</button></div>' : "") +
    '<div id="iaCont"></div><div id="iaResults"></div>');
  iaWireHead();
  var go = function (changes) {
    var p2 = { q: ia.q, media: ia.media, sort: ia.sort, page: 1, c: ia.c };
    Object.keys(changes || {}).forEach(function (k) { p2[k] = changes[k]; });
    if (!p2.q && !p2.c) { if (changes && "q" in changes) toast("Type what you're looking for.", true); return; }
    location.hash = iaHash(p2);
  };
  $("iaForm").onsubmit = function (e) { e.preventDefault(); go({ q: $("iaQ").value.trim() }); };
  $("iaMedia").onclick = function (e) { var b = e.target.closest("[data-media]"); if (!b) return; ia.media = b.getAttribute("data-media"); go({}); if (!ia.q && !ia.c) iaSearch(null); };
  $("iaSort").onchange = function () { ia.sort = this.value; go({}); };
  if ($("iaNoC")) $("iaNoC").onclick = function () { go({ c: "" }); };
  $("iaResults").onclick = function (e) {
    var a = e.target.closest("a.card"); if (a) { ia.scroll = window.scrollY; ia.back = location.hash; }
    var ex = e.target.closest("[data-ex]"); if (ex) go({ q: ex.getAttribute("data-ex"), c: "" });
  };
  iaPoll();
  if (!ia.q && !ia.c) {
    $("iaResults").innerHTML = iaTipsHtml(); $("iaQ").focus();
    if (typeof streamContinue === "function") streamContinue($("iaCont"));  // videos you started watching (stream.js)
    return;
  }
  if (ia.data && ia.key === key) { $("iaResults").innerHTML = iaResultsHtml(ia.data); window.scrollTo(0, ia.scroll); return; }
  var n = ++ia.n;
  $("iaResults").innerHTML = '<div class="empty">Searching archive.org …</div>';
  api("/api/ia/search?" + ["q", "media", "sort", "page", "c"].map(function (k) { return k + "=" + encodeURIComponent(ia[k]); }).join("&")).then(function (d) {
    if (n !== ia.n || currentPage !== "archive" || !$("iaResults")) return;
    if (d.open) { location.replace("#/archive/item/" + encodeURIComponent(d.open)); return; }
    ia.data = d; ia.key = key; ia.scroll = 0;
    $("iaResults").innerHTML = iaResultsHtml(d);
  }).catch(function (e) { if (n === ia.n && $("iaResults")) $("iaResults").innerHTML = '<div class="note">' + esc(e.message) + "</div>"; });
}
function iaTipsHtml() {
  return '<section class="panel" style="max-width:820px"><h2>Free films, cartoons and TV from the Internet Archive</h2>' +
    '<p class="muted">The Internet Archive (archive.org) keeps millions of free videos. Search here, open an item, tick the files you want and click <b>Download selected</b>. ' +
    "AniBox saves them in your download folder and can add them to your library.</p>" +
    '<p class="muted">Tip: paste a link such as <code>https://archive.org/details/…</code> to open that item straight away.</p>' +
    '<div class="row" style="margin-top:14px"><span class="muted">Try:</span>' + ["Popeye", "Betty Boop", "Fleischer Superman", "Felix the Cat", "anime"].map(function (x) {
      return '<button type="button" class="chip" data-ex="' + esc(x) + '">' + esc(x) + "</button>"; }).join("") + "</div></section>";
}
function iaResultsHtml(d) {
  if (!d.results.length) return '<div class="empty">Nothing found. Try other or fewer words' + (d.media === "video" ? ", or search “Everything”." : ".") + "</div>";
  var pager = "";
  if (d.pages > 1) {
    var base = { q: d.query, media: d.media, sort: d.sort, c: d.collection };
    var to = function (pg) { var p = {}; Object.keys(base).forEach(function (k) { p[k] = base[k]; }); p.page = pg; return iaHash(p); };
    pager = '<div class="row ia-pager">' + (d.page > 1 ? '<a class="btn small" href="' + to(d.page - 1) + '">← Previous</a>' : "") +
      '<span class="muted">Page ' + d.page + " of " + d.pages + "</span>" + (d.page < d.pages ? '<a class="btn small" href="' + to(d.page + 1) + '">Next →</a>' : "") + "</div>";
  }
  return '<div class="muted" style="margin:0 0 14px">' + d.total.toLocaleString() + (d.total === 1 ? " result" : " results") + "</div>" +
    '<div class="grid ia-grid">' + d.results.map(iaCard).join("") + "</div>" + pager;
}
function iaCard(r) {
  var sub = [r.mediatype && r.mediatype !== "movies" ? IA_TYPE[r.mediatype] || r.mediatype : "", r.year, r.size ? iaSize(r.size) : "",
    r.downloads != null ? r.downloads.toLocaleString() + " downloads" : ""].filter(Boolean).join(" · ");
  return '<a class="card" href="#/archive/item/' + encodeURIComponent(r.id) + '"><div class="poster ph"><div class="ini">' + esc(r.title) + "</div>" +
    '<img loading="lazy" alt="" src="' + esc(r.img) + '" onerror="this.remove()"></div><div class="t">' + esc(r.title) + '</div><div class="s">' + esc(sub) + "</div></a>";
}

// ---------- one item
function iaItem(id) {
  render('<div class="empty">Loading the item from archive.org …</div>');
  api("/api/ia/item?id=" + encodeURIComponent(id)).then(function (d) {
    if (currentPage !== "archive") return;
    var it = d.item;
    ia.item = it; ia.dir = d.dir; ia.add = d.add; ia.jobs = d.jobs; ia.showAll = false; ia.picked = {};
    ia.folderName = d.folder ? d.folder.split(/[\\/]/).pop() : "";
    var busy = iaJobsByName(d.jobs);
    it.files.forEach(function (f) { if (f.pick && !busy[f.name]) ia.picked[f.name] = true; });
    var meta = [IA_TYPE[it.mediatype] || it.mediatype, it.year, it.creator, it.size ? iaSize(it.size) : "", plural(it.files.length, "file")].filter(Boolean);
    var html = '<div class="row" style="margin-bottom:18px"><a class="btn small" href="' + esc(ia.back || "#/archive") + '">← Back</a></div>' +
      '<div class="showhead ia-head"><div class="poster ph"><div class="ini">' + esc(it.title) + '</div><img alt="" src="' + esc(it.img) + '" onerror="this.remove()"></div><div>' +
      '<div class="kicker">Internet Archive</div><h1>' + esc(it.title) + "</h1>" +
      '<div class="meta">' + meta.map(function (m) { return "<span>" + esc(m) + "</span>"; }).join("") + "</div>" +
      (it.collections.length ? '<div class="muted" style="font-size:14px;margin-bottom:10px">In the collection' + (it.collections.length > 1 ? "s" : "") + " " + it.collections.slice(0, 6).map(function (c) {
        return '<a href="' + iaHash({ q: "", media: "any", sort: "downloads", page: 1, c: c }) + '">' + esc(c) + "</a>"; }).join(", ") + "</div>" : "") +
      (it.restricted ? '<div class="note">archive.org only lends this item or keeps it restricted, so downloading it probably won\'t work.</div>' : "") +
      (it.mediatype === "collection" ? '<div class="note">This is a collection of other items. <a href="' + iaHash({ q: "", media: "any", sort: "downloads", page: 1, c: it.id }) + '">Show what\'s in it →</a></div>' : "") +
      (it.description ? '<div class="ia-desc" id="iaDesc">' + esc(it.description) + '</div><button class="btn small" id="iaMore" hidden style="margin-top:8px">Show more</button>' : "") +
      '<div class="row" style="margin-top:16px"><a class="btn" href="' + esc(it.url) + '" target="_blank" rel="noopener noreferrer">Open on archive.org ↗</a></div>' +
      "</div></div>" +
      '<section class="panel" style="margin-top:28px"><h2>Download</h2>' +
      '<div class="field"><div class="lbl">Download folder<small id="iaWhere"></small></div><div class="row"><button class="btn small" id="iaChange">Change …</button><button class="btn small" id="iaOpenDir">Open folder</button></div></div>' +
      '<div class="row" style="margin:-4px 0 6px"><input class="input wide" id="iaDir" value="' + esc(ia.dir) + '" aria-label="Download folder" spellcheck="false" title="Type or paste a folder, then press Enter"></div>' +
      '<div class="field"><div class="lbl">Add to my AniBox library<small id="iaAddInfo"></small></div><button class="switch' + (ia.add ? " on" : "") + '" id="iaAdd" role="switch" aria-checked="' + ia.add + '" aria-label="Add to my AniBox library"></button></div>' +
      '<div id="iaLib"></div><div id="iaFiles"></div></section>' +
      '<div class="section"><h2>Downloads of this item</h2><a href="#/archive/downloads">All downloads →</a></div><div id="iaItemJobs"></div>';
    render(html);
    iaWhere();
    if ($("iaDesc") && $("iaDesc").scrollHeight > 230) {
      $("iaDesc").classList.add("clamp"); $("iaMore").hidden = false;
      $("iaMore").onclick = function () { var c = $("iaDesc").classList.toggle("clamp"); this.textContent = c ? "Show more" : "Show less"; };
    }
    $("iaChange").onclick = iaPickDir;
    $("iaOpenDir").onclick = function () { post("/api/ia/open", {}).catch(fail); };
    $("iaDir").onkeydown = function (e) { if (e.key === "Enter") this.blur(); };
    $("iaDir").onchange = function () { iaSetDir(this.value.trim()); };
    $("iaAdd").onclick = function () {
      ia.add = !ia.add; this.classList.toggle("on", ia.add); this.setAttribute("aria-checked", ia.add);
      post("/api/settings", { ia_add_to_library: ia.add }).catch(fail);  // remembered for next time
      iaWhere();
    };
    iaDrawFiles();
    if (typeof streamItemLoaded === "function") streamItemLoaded(it.id);  // Play buttons: where you stopped (stream.js)
    iaDrawJobList($("iaItemJobs"), d.jobs, "No files of this item are in your downloads yet.");
    iaPoll();
  }).catch(function (e) {
    render('<div class="row" style="margin-bottom:18px"><a class="btn small" href="' + esc(ia.back || "#/archive") + '">← Back</a></div><div class="note">' + esc(e.message) + "</div>");
  });
}
function iaSep() { return ia.dir.indexOf("\\") >= 0 || ia.dir.indexOf("/") < 0 ? "\\" : "/"; }
function iaWhere() {
  if (!$("iaWhere")) return;
  var sep = iaSep(), folder = ia.dir.replace(/[\\/]+$/, "") + sep + (ia.folderName || "…");
  $("iaWhere").innerHTML = "This item goes into its own folder: <code>" + esc(folder) + "</code>";
  var lib = ia.dir.replace(/[\\/]+$/, "").split(/[\\/]/).pop();
  $("iaAddInfo").innerHTML = ia.add ? "When it's done, AniBox reads the download folder like a library folder: <code>" + esc(lib + sep + (ia.folderName || "item") + sep + "files") +
    "</code>. The item then shows up in the Library as a show in “" + esc(lib) + "”. AniBox remembers this choice." :
    "Off: the files are only saved in the folder. AniBox remembers this choice.";
}
function iaPickDir() {
  toast("A folder window opens (it may be behind this one) …");
  post("/api/ia/pick-folder").then(function (r) {
    if (!r.changed) return;
    ia.dir = r.dir; if ($("iaDir")) $("iaDir").value = r.dir; if ($("iaDirShow")) $("iaDirShow").textContent = r.dir;
    iaWhere(); toast("Downloads now go to " + r.dir);
  }).catch(fail);
}
function iaSetDir(path) {
  post("/api/ia/dir", { path: path }).then(function (r) {
    ia.dir = r.dir; if ($("iaDir")) $("iaDir").value = r.dir; iaWhere(); toast("Downloads now go to " + r.dir);
  }).catch(function (e) { fail(e); if ($("iaDir")) $("iaDir").value = ia.dir; });
}
function iaJobsByName(jobs) {
  var out = {};
  (jobs || []).forEach(function (j) { if (j.state !== "cancelled") out[j.name] = j; });
  return out;
}
function iaDrawFiles() {
  var box = $("iaFiles"); if (!box || !ia.item) return;
  var files = ia.item.files, hiddenN = files.filter(function (f) { return f.hidden; }).length;
  var shown = [];
  files.forEach(function (f, i) { if (ia.showAll || !f.hidden) shown.push(i); });
  var max = 3000, cut = shown.length > max;
  if (cut) shown = shown.slice(0, max);
  var byName = iaJobsByName(ia.jobs);
  box.innerHTML = '<div class="row" style="justify-content:space-between;margin:16px 0 6px"><div class="row">' +
    '<button class="btn small" data-tick="videos">Tick all videos</button><button class="btn small" data-tick="none">Untick all</button></div>' +
    (hiddenN ? '<label class="check"><input type="checkbox" id="iaAll"' + (ia.showAll ? " checked" : "") + "> Show all files (" + hiddenN + " more: pictures, info files …)</label>" : "") + "</div>" +
    (shown.length ? '<div class="tw ia-files"><table><thead><tr><th></th><th>File</th><th>Type</th><th class="num">Length</th><th class="num">Size</th><th>Status</th></tr></thead><tbody>' +
      shown.map(function (i) {
        var f = files[i], j = byName[f.name];
        var tag = f.kind === "subtitle" ? "Subtitles" : f.kind === "video" ? (f.source === "original" ? "Original" : "Copy by archive.org") : "";
        return '<tr><td class="ia-pick"><input type="checkbox" data-fi="' + i + '"' + (ia.picked[f.name] ? " checked" : "") + ' aria-label="Download ' + esc(f.name) + '">' +
          (f.kind === "video" && typeof streamPlayButton === "function" ? streamPlayButton(f) : "") + "</td>" +
          '<td class="ia-name">' + esc(f.name) + (tag ? ' <span class="tag"' + (f.source !== "original" && f.original ? ' title="Made from ' + esc(f.original) + '"' : "") + ">" + tag + "</span>" : "") + "</td>" +
          "<td>" + esc(f.format) + '</td><td class="num">' + (f.length ? fmt(f.length) : "") + '</td><td class="num">' + (f.size != null ? iaSize(f.size) : "?") + "</td>" +
          '<td class="muted" data-fstat="' + i + '">' + esc(j ? iaShortState(j) : "") + "</td></tr>";
      }).join("") + "</tbody></table></div>" : '<div class="empty" style="padding:24px 0">This item has no video or subtitle files. Tick “Show all files” to see the rest.</div>') +
    (cut ? '<p class="muted">Only the first ' + max + " files are listed.</p>" : "") +
    '<div class="row" style="margin-top:16px"><button class="btn primary" id="iaGo">Download selected</button><span class="muted" id="iaSel"></span></div>';
  iaSelInfo();
  if ($("iaAll")) $("iaAll").onchange = function () { ia.showAll = this.checked; iaDrawFiles(); };
  box.onchange = function (e) {
    var c = e.target.closest("[data-fi]"); if (!c) return;
    var f = ia.item.files[Number(c.getAttribute("data-fi"))];
    if (c.checked) ia.picked[f.name] = true; else delete ia.picked[f.name];
    iaSelInfo();
  };
  box.querySelectorAll("[data-tick]").forEach(function (b) {
    b.onclick = function () {
      ia.picked = {};
      if (b.getAttribute("data-tick") === "videos") ia.item.files.forEach(function (f) { if (f.kind === "video") ia.picked[f.name] = true; });
      iaDrawFiles();
    };
  });
  $("iaGo").onclick = iaDownloadSelected;
}
function iaSelInfo() {
  var names = Object.keys(ia.picked), size = 0, unknown = false;
  ia.item.files.forEach(function (f) { if (ia.picked[f.name]) { if (f.size == null) unknown = true; else size += f.size; } });
  $("iaSel").textContent = names.length ? plural(names.length, "file") + " · " + (unknown ? "at least " : "") + iaSize(size) : "Nothing ticked";
  $("iaGo").disabled = !names.length;
}
function iaDownloadSelected() {
  var names = ia.item.files.filter(function (f) { return ia.picked[f.name]; }).map(function (f) { return f.name; });
  if (!names.length) return toast("Tick at least one file.", true);
  $("iaGo").disabled = true;
  post("/api/ia/download", { id: ia.item.id, files: names, dir: ia.dir, add: ia.add }).then(function (r) {
    toast(r.added ? plural(r.added, "file") + " added to your downloads." + (r.skipped.length ? " " + plural(r.skipped.length, "file") + " already there." : "") :
      "Those files are already in your downloads.");
    ia.picked = {};
    iaPoll();
  }).catch(fail).then(function () { if ($("iaGo")) iaDrawFiles(); });
}
function iaShortState(j) {
  if (j.state === "done") return "Downloaded ✓";
  if (j.state === "running") return j.size ? Math.floor(100 * j.done / j.size) + " %" : "Downloading";
  return { queued: "In the queue", waiting: "Waiting", verifying: "Checking", paused: "Paused", error: "Problem", cancelled: "" }[j.state] || "";
}

// ---------- downloads
function iaDownloads() {
  render(iaHead("downloads") +
    '<section class="panel"><div class="field"><div class="lbl">Download folder<small><code id="iaDirShow">' + esc(ia.dir || (ia.dl && ia.dl.dir) || "") + "</code></small></div>" +
    '<div class="row"><button class="btn small" id="iaOpenDir">Open folder</button><button class="btn small" id="iaChange">Change …</button><button class="btn small" id="iaClear">Clear finished</button></div></div>' +
    '<p class="muted" style="margin:6px 0 0">Two files download at the same time; the rest wait their turn. Paused downloads go on where they stopped, also after a restart. ' +
    "If you close the AniBox window, AniBox finishes the downloads first and then closes by itself. AniBox never replaces a file that's already in the folder.</p></section>" +
    '<div id="iaLib" style="margin-top:14px"></div><div id="iaDl" style="margin-top:18px"><div class="empty">Loading …</div></div>');
  iaWireHead();
  $("iaOpenDir").onclick = function () { post("/api/ia/open", {}).catch(fail); };
  $("iaChange").onclick = iaPickDir;
  $("iaClear").onclick = function () { post("/api/ia/downloads/action", { action: "clear" }).then(function () { iaPoll(); }).catch(fail); };
  iaPoll();
}
function iaJobLine(j) {
  var of = iaSize(j.done) + (j.size != null ? " of " + iaSize(j.size) : "");
  if (j.state === "running") {
    if (j.message) return j.message;
    return of + (j.speed ? " · " + iaSize(j.speed) + "/s" + (j.size ? " · " + fmt((j.size - j.done) / j.speed) + " left" : "") : "");
  }
  if (j.state === "queued") return "Waiting for its turn" + (j.done ? " · " + of : "");
  if (j.state === "waiting" || j.state === "verifying") return j.message || "Checking the file …";
  if (j.state === "paused") return "Paused · " + of;
  if (j.state === "done") return "Done" + (j.size != null ? " · " + iaSize(j.size) : "") + (j.message ? " · " + j.message : "") + " · " + j.target;
  if (j.state === "error") return j.message || "Something went wrong.";
  return "Cancelled";
}
function iaPct(j) { return j.state === "done" ? 100 : j.size ? Math.min(100, Math.floor(100 * j.done / j.size)) : 0; }
function iaJobRow(j) {
  var b = function (act, label, cls) { return '<button class="btn small' + (cls ? " " + cls : "") + '" data-ia-act="' + act + '" data-job="' + esc(j.id) + '">' + label + "</button>"; };
  var btns = j.state === "done" ? '<button class="btn small" data-ia-open="' + esc(j.id) + '">Show in folder</button>' :
    j.state === "cancelled" ? "" :
    (j.state === "paused" ? b("resume", "Resume") : j.state === "error" ? b("resume", "Try again") : j.state === "waiting" ? b("resume", "Try now") + b("pause", "Pause") : b("pause", "Pause")) + b("cancel", "Cancel", "danger");
  return '<div class="ia-job st-' + j.state + '" data-row="' + esc(j.id) + '"><div class="ia-jobmain"><div class="nm" title="' + esc(j.name) + '">' + esc(j.file) + "</div>" +
    '<div class="meter"><i style="width:' + iaPct(j) + '%"></i></div><div class="ia-jobline">' + esc(iaJobLine(j)) + '</div></div><div class="row">' + btns + "</div></div>";
}
function iaDrawJobList(box, jobs, empty, grouped) {
  if (!box) return;
  var sig = jobs.map(function (j) { return j.id + ":" + j.state + ":" + j.file; }).join("|");
  if (box.getAttribute("data-sig") === sig && sig) {  // same rows: only move the bars, so buttons don't jump under the mouse
    jobs.forEach(function (j) {
      var row = box.querySelector('[data-row="' + j.id + '"]'); if (!row) return;
      row.querySelector(".meter i").style.width = iaPct(j) + "%";
      row.querySelector(".ia-jobline").textContent = iaJobLine(j);
    });
    return;
  }
  box.setAttribute("data-sig", sig);
  if (!jobs.length) { box.innerHTML = '<div class="empty" style="padding:24px 0">' + esc(empty) + "</div>"; return; }
  if (!grouped) { box.innerHTML = '<div class="panel ia-jobs">' + jobs.map(iaJobRow).join("") + "</div>"; return; }
  var order = [], groups = {};
  jobs.forEach(function (j) { if (!groups[j.item]) { groups[j.item] = []; order.push(j.item); } groups[j.item].push(j); });
  box.innerHTML = order.map(function (id) {
    var g = groups[id];
    return '<div class="panel ia-jobs"><div class="ia-jobhead"><a href="#/archive/item/' + encodeURIComponent(id) + '">' + esc(g[0].itemTitle) + '</a><span class="muted">' + plural(g.length, "file") + "</span></div>" +
      g.map(iaJobRow).join("") + "</div>";
  }).join("");
}
function iaDrawLibrary(lib) {
  var box = $("iaLib"); if (!box) return;
  var show = lib && lib.state !== "idle" && lib.message && !(lib.state === "done" && lib.at && Date.now() / 1000 - lib.at > 600);
  var html = show ? '<div class="' + (lib.state === "error" ? "note" : "banner") + '" style="margin:10px 0"><div>' + esc(lib.message) +
    (lib.state === "done" ? ' <a href="#/library">Open the Library →</a>' : "") + "</div></div>" : "";
  if (box.getAttribute("data-html") !== html) { box.innerHTML = html; box.setAttribute("data-html", html); }
}
function iaPoll() {
  clearTimeout(archive.t);
  if (currentPage !== "archive") return;
  api("/api/ia/downloads").then(function (d) {
    if (currentPage !== "archive") return;
    ia.dl = d;
    if (!ia.dir) ia.dir = d.dir;
    var live = d.jobs.filter(function (j) { return IA_LIVE.indexOf(j.state) >= 0; }).length;
    if ($("iaCount")) $("iaCount").textContent = live ? "· " + live : d.jobs.length ? "· " + d.jobs.length : "";
    if ($("iaDirShow")) $("iaDirShow").textContent = d.dir;
    iaDrawJobList($("iaDl"), d.jobs.slice().reverse(), "No downloads yet. Search for something, open it and tick the files you want.", true);
    if (ia.item && $("iaItemJobs")) {
      ia.jobs = d.jobs.filter(function (j) { return j.item === ia.item.id; });
      iaDrawJobList($("iaItemJobs"), ia.jobs, "No files of this item are in your downloads yet.");
      var byName = iaJobsByName(ia.jobs);
      view.querySelectorAll("[data-fstat]").forEach(function (td) {
        var f = ia.item.files[Number(td.getAttribute("data-fstat"))], j = f && byName[f.name];
        td.textContent = j ? iaShortState(j) : "";
      });
    }
    iaDrawLibrary(d.library);
    var busy = live || (d.library && (d.library.state === "scanning" || d.library.state === "waiting"));
    archive.t = setTimeout(iaPoll, document.hidden ? 5000 : busy ? 1000 : 5000);
  }).catch(function () { archive.t = setTimeout(iaPoll, 5000); });
}

// Buttons in the download lists (search, item and downloads pages share them)
view.addEventListener("click", function (e) {
  if (currentPage !== "archive") return;
  var b = e.target.closest("[data-ia-act]"), o = e.target.closest("[data-ia-open]");
  if (o) { post("/api/ia/open", { id: o.getAttribute("data-ia-open") }).catch(fail); return; }
  if (!b) return;
  var act = b.getAttribute("data-ia-act");
  if (act === "cancel" && !confirm("Cancel this download? What's downloaded of it so far is deleted. Files that are already finished stay.")) return;
  b.disabled = true;
  post("/api/ia/downloads/action", { action: act, id: b.getAttribute("data-job") }).then(function () { iaPoll(); }).catch(fail);
});
