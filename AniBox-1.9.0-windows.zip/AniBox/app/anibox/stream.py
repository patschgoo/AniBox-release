"""Internet Archive videos played straight from archive.org, without downloading them first.

AniBox's player (mpv) opens ``https://archive.org/download/<identifier>/<file>`` like a file on
disk: it reads only what it plays and asks for another part when you jump (HTTP ranges). Nothing is
saved on your drives. Requests carry only ``AniBox/<version>`` as their name, like the rest of the
Internet Archive page.

- Every streamed file has the key ``ia:<identifier>/<file>``; the item is its "show"
  ``ia:<identifier>``. Watch progress is kept under these keys in AniBox's database like an
  episode's, so resume, "watched at 95 %", the playing bar and the phone remote work the same.
  The library never sees these keys (``Library.episode`` answers "not found" for them).
- Next/previous are the item's other videos of the same kind, in order: the original files, or
  archive.org's own copies in the same format (an item often has both, e.g. an ``.avi`` and an
  ``.mp4`` copy of every episode, and next should not jump from one to the other).
- Subtitle files of the item with the video's name (``Ep 1.srt``, ``Ep 1.en.srt``) are loaded too.
- The item's title and its list of videos are kept in ``ia-streams.json`` in AniBox's data folder,
  so "Continue watching" and the playing bar work without asking archive.org again.

The idea comes from Frostbox (Martin's archive.org player, used with permission), which streams
archive.org through its own cache; plain mpv streaming is enough here.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from .iarchive import SUB_EXT, USER_AGENT, ArchiveError, valid_id
from .watching import next_up

log = logging.getLogger("anibox.stream")

PREFIX = "ia:"
LIBRARY = "Internet Archive"
STATE_FILE = "ia-streams.json"
MAX_ITEMS = 300  # items remembered (the oldest one nobody watched lately goes first)
MAX_VIDEOS = 3000  # videos remembered per item


def stream_key(identifier: str, name: str) -> str:
    return f"{PREFIX}{identifier}/{name}"


def split_key(key: str) -> Optional[Tuple[str, str]]:
    """("identifier", "file name") of an ``ia:`` key, or None. A show id gives ("identifier", "")."""
    if not isinstance(key, str) or not key.startswith(PREFIX):
        return None
    ident, _, name = key[len(PREFIX):].partition("/")
    if not valid_id(ident):
        return None
    parts = [p for p in name.split("/") if p]
    if name and (".." in parts or not parts or name.startswith("/") or "\\" in name):
        return None
    return ident, name


def family(video: dict) -> str:
    """Which videos belong together for next/previous: the originals, or archive.org's copies of one format."""
    if (video.get("source") or "original") == "original":
        return "original"
    return "copy:" + (video.get("format") or os.path.splitext(video.get("name") or "")[1]).lower()


def _mpv_value(text: str) -> str:
    """A value for mpv's "a=b,c=d" option lists, quoted so commas and colons in it are kept."""
    return f"%{len(text.encode('utf-8'))}%{text}"


def _stem(name: str) -> str:
    return os.path.splitext(name.rsplit("/", 1)[-1])[0].casefold()


class IaStreams:
    def __init__(self, client, data_dir: Path, store=None):
        self.client = client  # iarchive.ArchiveClient
        self.store = store
        self.path = data_dir / STATE_FILE
        self._lock = threading.Lock()
        self._items: Dict[str, dict] = {}  # identifier -> {"title", "videos": [...], "subs": [...], "seen"}
        self._family: Dict[str, str] = {}  # identifier -> the kind of video played last (see family())
        self._load()

    # -- what AniBox knows about the items ---------------------------------------------------------

    def _load(self) -> None:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return
        except (OSError, ValueError):
            log.warning("%s couldn't be read; streamed items are asked from archive.org again", self.path.name)
            return
        items = data.get("items") if isinstance(data, dict) else None
        if isinstance(items, dict):
            self._items = {k: v for k, v in items.items() if valid_id(k) and isinstance(v, dict)
                           and isinstance(v.get("videos"), list)}

    def _save(self) -> None:
        tmp = self.path.with_suffix(".part")
        try:
            tmp.write_text(json.dumps({"version": 1, "items": self._items}, ensure_ascii=False), encoding="utf-8")
            os.replace(tmp, self.path)
        except OSError:
            log.warning("%s couldn't be saved", self.path.name, exc_info=True)

    def remember(self, item: dict) -> dict:
        """Keep the title and the videos of an item from ``ArchiveClient.item()``."""
        files = item.get("files") or []
        videos = [{"name": f["name"], "format": f.get("format") or "", "source": f.get("source") or "original",
                   "length": f.get("length")} for f in files if f.get("kind") == "video"][:MAX_VIDEOS]
        subs = [f["name"] for f in files if f.get("kind") == "subtitle"][:MAX_VIDEOS]
        entry = {"title": item.get("title") or item["id"], "videos": videos, "subs": subs, "seen": time.time()}
        with self._lock:
            self._items[item["id"]] = entry
            if len(self._items) > MAX_ITEMS:
                for ident in sorted(self._items, key=lambda k: self._items[k].get("seen") or 0)[: len(self._items) - MAX_ITEMS]:
                    self._items.pop(ident, None)
            self._save()
        return entry

    def known(self, identifier: str) -> Optional[dict]:
        with self._lock:
            return self._items.get(identifier)

    def prepare(self, key_or_show: str) -> None:
        """Make sure AniBox knows the item of this key (asks archive.org only if it doesn't yet)."""
        parts = split_key(key_or_show)
        if not parts:
            raise RuntimeError("That isn't an Internet Archive video.")
        ident, name = parts
        entry = self.known(ident)
        if entry and entry["videos"] and (not name or any(v["name"] == name for v in entry["videos"])):
            with self._lock:
                entry["seen"] = time.time()
            return
        try:
            item = self.client.cached_item(ident)
        except ArchiveError as exc:
            raise RuntimeError(str(exc)) from exc
        entry = self.remember(item)
        if not entry["videos"]:
            raise RuntimeError("This archive.org item has no videos.")
        if name and not any(v["name"] == name for v in entry["videos"]):
            raise RuntimeError("That video isn't in this archive.org item (any more).")

    # -- shows and episodes, shaped like the library's -------------------------------------------------

    def _show(self, ident: str, entry: dict, fam: str) -> dict:
        videos = [v for v in entry["videos"] if family(v) == fam] or entry["videos"]
        return {
            "id": PREFIX + ident, "library": LIBRARY, "folder": ident, "title": entry.get("title") or ident,
            "stream": True, "item": ident, "art": "/ia/thumb/" + ident, "mal_id": None, "picture": "",
            "episodes": [{"key": stream_key(ident, v["name"]), "path": self.client.file_url(ident, v["name"]),
                          "file": v["name"], "label": v["name"].rsplit("/", 1)[-1], "season": None, "number": None,
                          "length": v.get("length")} for v in videos],
        }

    def episode(self, key: str) -> Tuple[Optional[dict], int]:
        """(item as a show, index of the video) like ``Library.episode``; (None, -1) if unknown."""
        parts = split_key(key)
        entry = self.known(parts[0]) if parts else None
        if not entry or not entry["videos"]:
            return None, -1
        ident, name = parts
        video = next((v for v in entry["videos"] if v["name"] == name), None)
        if video is None:
            return self._show(ident, entry, self._family.get(ident) or family(entry["videos"][0])), -1
        fam = family(video)
        self._family[ident] = fam
        show = self._show(ident, entry, fam)
        idx = next((i for i, e in enumerate(show["episodes"]) if e["key"] == key), -1)
        return show, idx

    def show(self, show_id: str) -> Optional[dict]:
        """The item as a show (its videos of the kind played last), like ``Library.show``."""
        parts = split_key(show_id)
        entry = self.known(parts[0]) if parts and not parts[1] else None
        if not entry or not entry["videos"]:
            return None
        ident = parts[0]
        fam = self._family.get(ident)
        if fam is None:
            last = self._last_played(ident)
            video = next((v for v in entry["videos"] if v["name"] == last), None) if last else None
            fam = family(video or entry["videos"][0])
            self._family[ident] = fam
        return self._show(ident, entry, fam)

    def _last_played(self, ident: str, progress: Optional[dict] = None) -> str:
        if progress is None:
            progress = self.store.all_progress() if self.store else {}
        best, when = "", -1.0
        for key, p in progress.items():
            parts = split_key(key) if key.startswith(PREFIX) else None
            if parts and parts[0] == ident and parts[1] and float(p.get("updated") or 0) > when:
                best, when = parts[1], float(p.get("updated") or 0)
        return best

    def mpv_options(self, key: str) -> str:
        """Per-file mpv options for a stream: AniBox's name, no web-video helper, the item's subtitles."""
        opts = [f"user-agent={_mpv_value(USER_AGENT)}", "ytdl=no"]
        parts = split_key(key)
        entry = self.known(parts[0]) if parts else None
        if entry and parts[1]:
            stem = _stem(parts[1])
            for sub in entry.get("subs") or []:
                s = _stem(sub)
                if sub.lower().endswith(SUB_EXT) and (s == stem or s.startswith(stem + ".")):
                    opts.append(f"sub-files-append={_mpv_value(self.client.file_url(parts[0], sub))}")
        return ",".join(opts)

    # -- lists for the window ----------------------------------------------------------------------

    def progress_for(self, ident: str) -> Dict[str, dict]:
        """{file name: {"position", "duration", "watched"}} for the videos of one item you played."""
        progress = self.store.all_progress() if self.store else {}
        out = {}
        for key, p in progress.items():
            parts = split_key(key) if key.startswith(PREFIX) else None
            if parts and parts[0] == ident and parts[1]:
                out[parts[1]] = {"position": float(p.get("position") or 0), "duration": float(p.get("duration") or 0),
                                 "watched": bool(p.get("watched"))}
        return out

    def continue_watching(self, limit: int = 12) -> List[dict]:
        """Items you started streaming and haven't finished, newest first, with where to go on."""
        progress = self.store.all_progress() if self.store else {}
        latest: Dict[str, Tuple[float, str]] = {}
        for key, p in progress.items():
            parts = split_key(key) if key.startswith(PREFIX) else None
            if parts and parts[1]:
                when = float(p.get("updated") or 0)
                if when > latest.get(parts[0], (-1.0, ""))[0]:
                    latest[parts[0]] = (when, parts[1])
        out = []
        for ident, (when, name) in sorted(latest.items(), key=lambda kv: kv[1][0], reverse=True):
            entry = self.known(ident)
            if not entry or not entry["videos"]:
                continue
            video = next((v for v in entry["videos"] if v["name"] == name), entry["videos"][0])
            show = self._show(ident, entry, family(video))
            nxt, pos = next_up(show, progress)
            if not nxt:
                continue
            eps = show["episodes"]
            watched = sum(1 for e in eps if (progress.get(e["key"]) or {}).get("watched"))
            out.append({"id": show["id"], "item": ident, "title": show["title"], "img": show["art"],
                        "files": len(eps), "watched": watched, "last_played": when,
                        "next": {"key": nxt["key"], "label": nxt["label"], "position": pos,
                                 "duration": float((progress.get(nxt["key"]) or {}).get("duration") or 0)}})
            if len(out) >= limit:
                break
        return out

