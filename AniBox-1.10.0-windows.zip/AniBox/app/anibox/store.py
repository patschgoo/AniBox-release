"""Settings and watch progress, kept in a small SQLite database in AniBox's data folder.

Episodes are identified by their path *inside* the share (``Anime\\Show\\Show 01.mkv``), so
progress survives a changed IP address or drive letter.
"""

from __future__ import annotations

import json
import os
import secrets
import sqlite3
import threading
import time
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

DEFAULTS = {
    "folders": [],  # folders to scan (shares or library folders)
    "libraries": [],  # library folders to show; empty = all
    "mpv_path": "",
    "fullscreen": True,
    "resume_back": 10,  # seconds to go back when resuming (Frostbox default)
    "watched_at": 95,  # percent of an episode that counts as watched (Frostbox default)
    "autoplay": True,
    "countdown": 8,  # seconds before the next episode starts
    "still_watching_after": 3,  # episodes in a row without touching anything, then ask (0 = never)
    "remote_enabled": False,
    "remote_port": 43211,
    "remote_key": "",
    "posters": True,
    "audio_langs": "",  # preferred audio languages, e.g. "jpn,ger" (empty = what the file says)
    "sub_langs": "",  # preferred subtitle languages, e.g. "ger,eng"
    "subs": "auto",  # auto (what the file says), on (always pick one), off
    "skip_openings": "button",  # off, button, auto (needs chapters named Opening/OP in the file)
    "skip_endings": "button",
    "update_check": True,
    "release_repo": "patschgoo/AniBox-release",  # where new versions are published (updates.py)
    "mal_client_id": "",  # optional, for descriptions/scores/genres from the official MyAnimeList API
    "protected": [],  # folders AniBox never writes into (NFO export); old episodes are locked anyway
    "tv_device": "",  # last TV used for "Play on TV"
    "mpv_log": False,  # write mpv's own detailed log to logs/mpv.log
    "protect_existing": True,  # episodes that were already there are locked (see Store.lock_snapshot)
    "episode_info": True,  # episode titles and pictures from Kitsu (and the One Piece Wiki)
    "library_kinds": {},  # library folder -> anime / series / movies; missing = decided automatically
    "inbox_folders": [],  # where "Add new videos" looks; empty = the Downloads folder
    "import_mode": "move",
    "import_write_nfo": False,  # Add new videos: also write info files (.nfo) for the new episodes
    "plex_scan_section": "",  # Add new videos: then ask this Plex library (key) to scan; "" = don't  # move (the download disappears from Downloads) or copy
    "embed_player": True,  # Windows: play inside the AniBox window (embed.py), else in mpv's own window
    "plex_check_sections": [],  # Plex libraries the Missing page checks (keys); empty = all
    "ia_download_dir": "",  # Internet Archive downloads; empty = Downloads\AniBox Internet Archive
    "ia_add_to_library": True,  # scan finished Internet Archive downloads into the library
    "airing_notices": True,  # Home: "Episode 7 is out" for shows you watch, air dates from AniList (airing.py)
    "mal_username": "",  # your MyAnimeList user name (a public list is read with the Client ID)
    "anilist_username": "",  # your AniList user name (public profiles need no sign-in)
    "anilist_client_id": "",  # your own AniList app, only needed to connect for sync
    "lists_rewatch": False,  # when you watch a finished show again: count it as a rewatch on your lists
    "lists_source": "",  # mal or anilist: which list the cards and the Lists page show first
    "tmdb_api_key": "",  # optional, posters/descriptions/episode titles for series and movies from TMDB (tmdb.py)
    "ffmpeg_path": "",  # folder with ffmpeg/ffprobe (or ffmpeg.exe); empty = the downloaded copy, then PATH
    "ia_cache": True,  # Internet Archive streams load into a cache on this PC first (iacache.py)
    "ia_cache_dir": "",  # empty = <AniBox data folder>\app\ia-cache
    "ia_cache_gb": 20,  # the cache never grows over this (kept episodes don't count)
    "ia_cache_connections": 8,  # parallel connections to archive.org per file
    "ia_cache_ahead": 2,  # episodes loaded ahead of the one playing
    "ia_keep_dir": "",  # "Keep": empty = "AniBox Keep" beside the Internet Archive download folder
}

PRIVATE_SETTINGS = ("remote_key",)

SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS progress (
    key TEXT PRIMARY KEY,
    show TEXT NOT NULL DEFAULT '',
    position REAL NOT NULL DEFAULT 0,
    duration REAL NOT NULL DEFAULT 0,
    watched INTEGER NOT NULL DEFAULT 0,
    updated REAL NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS progress_show ON progress(show);
CREATE INDEX IF NOT EXISTS progress_updated ON progress(updated);
CREATE TABLE IF NOT EXISTS overrides (show TEXT PRIMARY KEY, mal_id TEXT NOT NULL, updated REAL NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS show_prefs (show TEXT PRIMARY KEY, audio TEXT NOT NULL DEFAULT '', sub TEXT NOT NULL DEFAULT '');
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS locked (key TEXT PRIMARY KEY);
CREATE TABLE IF NOT EXISTS unlocked_shows (show TEXT PRIMARY KEY);
CREATE TABLE IF NOT EXISTS show_langs (show TEXT PRIMARY KEY, audio TEXT NOT NULL DEFAULT '[]', subs TEXT NOT NULL DEFAULT '[]',
    source TEXT NOT NULL DEFAULT '', manual_audio TEXT, manual_subs TEXT, updated REAL NOT NULL DEFAULT 0);
"""


class Store:
    def __init__(self, path: Path):
        self.path = path
        self._lock = threading.RLock()
        self.watched_hooks = []  # fn(key, show), called when a player saves an episode as watched (routes_lists.py)
        self._db = sqlite3.connect(str(path), check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        with self._lock:
            self._db.executescript(SCHEMA)
            # Columns added after 1.3.0 (subtitle types)
            cols = {r[1] for r in self._db.execute("PRAGMA table_info(show_langs)").fetchall()}
            if "subtypes" not in cols:
                self._db.execute("ALTER TABLE show_langs ADD COLUMN subtypes TEXT NOT NULL DEFAULT '[]'")
            if "manual_subtypes" not in cols:
                self._db.execute("ALTER TABLE show_langs ADD COLUMN manual_subtypes TEXT")
            self._db.commit()
        if not self.settings().get("remote_key"):
            self.update_settings({"remote_key": secrets.token_urlsafe(9)})

    def close(self) -> None:
        with self._lock:
            self._db.close()

    # -- settings ----------------------------------------------------------------------------

    def settings(self) -> dict:
        with self._lock:
            rows = self._db.execute("SELECT key, value FROM settings").fetchall()
        out = dict(DEFAULTS)
        for r in rows:
            try:
                out[r["key"]] = json.loads(r["value"])
            except ValueError:
                continue
        return out

    def update_settings(self, changes: dict) -> dict:
        allowed = {k: v for k, v in changes.items() if k in DEFAULTS}
        with self._lock:
            for k, v in allowed.items():
                self._db.execute(
                    "INSERT INTO settings(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                    (k, json.dumps(v)),
                )
            self._db.commit()
        return self.settings()

    # -- progress ----------------------------------------------------------------------------

    def progress(self, key: str) -> Optional[dict]:
        with self._lock:
            r = self._db.execute("SELECT * FROM progress WHERE key=?", (key,)).fetchone()
        return dict(r) if r else None

    def all_progress(self) -> Dict[str, dict]:
        with self._lock:
            rows = self._db.execute("SELECT * FROM progress").fetchall()
        return {r["key"]: dict(r) for r in rows}

    def save_position(self, key: str, show: str, position: float, duration: float, watched: Optional[bool] = None) -> None:
        now = time.time()
        with self._lock:
            old = self._db.execute("SELECT watched FROM progress WHERE key=?", (key,)).fetchone()
            w = int(watched) if watched is not None else (old["watched"] if old else 0)
            self._db.execute(
                "INSERT INTO progress(key, show, position, duration, watched, updated) VALUES(?,?,?,?,?,?) "
                "ON CONFLICT(key) DO UPDATE SET show=excluded.show, position=excluded.position, "
                "duration=excluded.duration, watched=excluded.watched, updated=excluded.updated",
                (key, show, float(position or 0), float(duration or 0), w, now),
            )
            self._db.commit()
        if watched:
            for fn in list(self.watched_hooks):
                try:
                    fn(key, show)
                except Exception:  # a hook never stops the progress from being saved
                    pass

    def set_watched(self, keys: Iterable[str], show: str, watched: bool) -> None:
        now = time.time()
        with self._lock:
            for key in keys:
                self._db.execute(
                    "INSERT INTO progress(key, show, position, duration, watched, updated) VALUES(?,?,0,0,?,?) "
                    "ON CONFLICT(key) DO UPDATE SET watched=excluded.watched, position=0, updated=excluded.updated",
                    (key, show, int(watched), now),
                )
            self._db.commit()

    def recent_shows(self, limit: int = 12) -> List[str]:
        """Shows played most recently, newest first."""
        with self._lock:
            rows = self._db.execute(
                "SELECT show, MAX(updated) AS u FROM progress WHERE show != '' GROUP BY show ORDER BY u DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [r["show"] for r in rows]

    # -- manual matches ("this folder is MAL entry X", or "" = no MAL entry) --------------------

    def overrides(self) -> Dict[str, str]:
        with self._lock:
            rows = self._db.execute("SELECT show, mal_id FROM overrides").fetchall()
        return {r["show"]: r["mal_id"] for r in rows}

    def set_override(self, show: str, mal_id: Optional[str]) -> None:
        """``mal_id`` None removes the manual match (back to automatic)."""
        with self._lock:
            if mal_id is None:
                self._db.execute("DELETE FROM overrides WHERE show=?", (show,))
            else:
                self._db.execute(
                    "INSERT INTO overrides(show, mal_id, updated) VALUES(?,?,?) "
                    "ON CONFLICT(show) DO UPDATE SET mal_id=excluded.mal_id, updated=excluded.updated",
                    (show, str(mal_id), time.time()))
            self._db.commit()

    def override_times(self) -> List[Tuple[str, str, float]]:
        """(show, mal_id, when it was set) of every match by hand, for the History page."""
        with self._lock:
            rows = self._db.execute("SELECT show, mal_id, updated FROM overrides").fetchall()
        return [(r["show"], r["mal_id"], float(r["updated"] or 0)) for r in rows]

    # -- audio/subtitle choice per show -----------------------------------------------------------

    def show_pref(self, show: str) -> dict:
        with self._lock:
            r = self._db.execute("SELECT audio, sub FROM show_prefs WHERE show=?", (show,)).fetchone()
        return {"audio": r["audio"], "sub": r["sub"]} if r else {"audio": "", "sub": ""}

    def set_show_pref(self, show: str, audio: Optional[str] = None, sub: Optional[str] = None) -> None:
        cur = self.show_pref(show)
        audio = cur["audio"] if audio is None else audio
        sub = cur["sub"] if sub is None else sub
        with self._lock:
            self._db.execute(
                "INSERT INTO show_prefs(show, audio, sub) VALUES(?,?,?) "
                "ON CONFLICT(show) DO UPDATE SET audio=excluded.audio, sub=excluded.sub", (show, audio, sub))
            self._db.commit()

    # -- small internal values (last update check, ...) ---------------------------------------------

    def meta(self, key: str, default=None):
        with self._lock:
            r = self._db.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        if not r:
            return default
        try:
            return json.loads(r["value"])
        except ValueError:
            return default

    def set_meta(self, key: str, value) -> None:
        with self._lock:
            self._db.execute("INSERT INTO meta(key, value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                             (key, json.dumps(value)))
            self._db.commit()

    # -- backup ---------------------------------------------------------------------------------

    def export_data(self) -> dict:
        """Everything worth keeping, as plain JSON (no secrets)."""
        with self._lock:
            progress = [dict(r) for r in self._db.execute("SELECT * FROM progress").fetchall()]
            prefs = {r["show"]: {"audio": r["audio"], "sub": r["sub"]}
                     for r in self._db.execute("SELECT * FROM show_prefs").fetchall()}
        settings = {k: v for k, v in self.settings().items() if k not in PRIVATE_SETTINGS}
        return {"app": "AniBox", "kind": "backup", "format": 1, "exported": time.time(), "settings": settings,
                "progress": progress, "overrides": self.overrides(), "showPrefs": prefs}

    def import_data(self, data: dict) -> dict:
        """Merge a backup: for each episode the newer entry wins; nothing is deleted."""
        if not isinstance(data, dict) or data.get("app") != "AniBox" or data.get("kind") != "backup":
            raise ValueError("That isn't an AniBox backup file.")
        added = 0
        with self._lock:
            for p in data.get("progress") or []:
                if not isinstance(p, dict) or not p.get("key"):
                    continue
                old = self._db.execute("SELECT updated FROM progress WHERE key=?", (str(p["key"]),)).fetchone()
                if old and float(old["updated"]) >= float(p.get("updated") or 0):
                    continue
                self._db.execute(
                    "INSERT INTO progress(key, show, position, duration, watched, updated) VALUES(?,?,?,?,?,?) "
                    "ON CONFLICT(key) DO UPDATE SET show=excluded.show, position=excluded.position, "
                    "duration=excluded.duration, watched=excluded.watched, updated=excluded.updated",
                    (str(p["key"]), str(p.get("show") or ""), float(p.get("position") or 0),
                     float(p.get("duration") or 0), int(bool(p.get("watched"))), float(p.get("updated") or 0)))
                added += 1
            self._db.commit()
        for show, mal in (data.get("overrides") or {}).items():
            self.set_override(str(show), str(mal))
        for show, pref in (data.get("showPrefs") or {}).items():
            if isinstance(pref, dict):
                self.set_show_pref(str(show), str(pref.get("audio") or ""), str(pref.get("sub") or ""))
        settings = {k: v for k, v in (data.get("settings") or {}).items() if k in DEFAULTS and k not in PRIVATE_SETTINGS}
        if settings:
            self.update_settings(settings)
        return {"episodes": added, "overrides": len(data.get("overrides") or {})}

    def copy_to(self, dest: Path) -> None:
        """A consistent copy of the database file (safe while AniBox runs)."""
        dest.parent.mkdir(parents=True, exist_ok=True)
        tmp = dest.with_suffix(".part")
        target = sqlite3.connect(str(tmp))
        try:
            with self._lock:
                self._db.backup(target)
        finally:
            target.close()
        os.replace(tmp, dest)

    def auto_backup(self, folder: Path, keep: int = 7) -> Optional[Path]:
        """Once a day: a copy of the database in ``folder`` (the last ``keep`` days are kept)."""
        name = time.strftime("anibox-%Y-%m-%d.db")
        dest = folder / name
        if dest.exists():
            return None
        if not self.all_progress() and not self.overrides():
            return None  # nothing worth keeping yet
        self.copy_to(dest)
        old = sorted(folder.glob("anibox-????-??-??.db"))[:-keep]
        for f in old:
            try:
                f.unlink()  # AniBox's own copies only
            except OSError:
                pass
        return dest

    # -- locks: what was already there stays as it is until the user unlocks the show ------------------

    def lock_snapshot(self, keys: Iterable[str]) -> int:
        """Lock these episodes (the ones that exist right now). Returns how many are locked in total."""
        with self._lock:
            self._db.executemany("INSERT OR IGNORE INTO locked(key) VALUES(?)", [(k,) for k in keys])
            self._db.commit()
            return self._db.execute("SELECT COUNT(*) FROM locked").fetchone()[0]

    def move_keys(self, episodes: Dict[str, Tuple[str, str]], shows: Dict[str, str]) -> None:
        """Follow episodes and shows whose key changed although the file didn't (AniBox now reads the
        folder layout differently). ``episodes``: old key -> (new key, new show id); ``shows``: old show
        id -> new show id. Watch progress and locks move along; so do matches by hand and language
        choices, unless the new show has its own. "Unlocked" doesn't move: the show is locked again.
        Nothing is deleted except the old copies of rows that moved."""
        with self._lock:
            db = self._db
            for old, (new, show) in episodes.items():
                if db.execute("SELECT 1 FROM progress WHERE key=?", (new,)).fetchone() is None:
                    db.execute("UPDATE progress SET key=?, show=? WHERE key=?", (new, show, old))
                db.execute("INSERT OR IGNORE INTO locked(key) SELECT ? FROM locked WHERE key=?", (new, old))
                db.execute("DELETE FROM locked WHERE key=?", (old,))
            for old, new in shows.items():
                for table in ("overrides", "show_prefs", "show_langs"):
                    if db.execute(f"SELECT 1 FROM {table} WHERE show=?", (new,)).fetchone() is None:
                        db.execute(f"UPDATE {table} SET show=? WHERE show=?", (new, old))
            db.commit()

    def locked_keys(self) -> set:
        with self._lock:
            return {r["key"] for r in self._db.execute("SELECT key FROM locked").fetchall()}

    def unlocked_shows(self) -> set:
        with self._lock:
            return {r["show"] for r in self._db.execute("SELECT show FROM unlocked_shows").fetchall()}

    def set_unlocked(self, show: str, unlocked: bool) -> None:
        with self._lock:
            if unlocked:
                self._db.execute("INSERT OR IGNORE INTO unlocked_shows(show) VALUES(?)", (show,))
            else:
                self._db.execute("DELETE FROM unlocked_shows WHERE show=?", (show,))
            self._db.commit()

    # -- languages per show (languages.py): found automatically, or set by hand --------------------------

    def all_show_langs(self) -> Dict[str, dict]:
        with self._lock:
            rows = self._db.execute("SELECT * FROM show_langs").fetchall()
        out = {}
        for r in rows:
            out[r["show"]] = {"audio": json.loads(r["audio"]), "subs": json.loads(r["subs"]), "source": r["source"],
                              "subtypes": json.loads(r["subtypes"] or "[]"),
                              "manual": None if r["manual_audio"] is None else
                              {"audio": json.loads(r["manual_audio"]), "subs": json.loads(r["manual_subs"] or "[]"),
                               "subtypes": json.loads(r["manual_subtypes"] or "[]")}}
        return out

    def set_show_langs(self, show: str, audio, subs, source: str, subtypes=()) -> None:
        """What AniBox found (from the files or the player); a choice made by hand stays."""
        with self._lock:
            self._db.execute(
                "INSERT INTO show_langs(show, audio, subs, subtypes, source, updated) VALUES(?,?,?,?,?,?) "
                "ON CONFLICT(show) DO UPDATE SET audio=excluded.audio, subs=excluded.subs, subtypes=excluded.subtypes, "
                "source=excluded.source, updated=excluded.updated",
                (show, json.dumps(sorted(set(audio))), json.dumps(sorted(set(subs))), json.dumps(sorted(set(subtypes or ()))),
                 source, time.time()))
            self._db.commit()

    def set_manual_langs(self, show: str, audio, subs, subtypes=()) -> None:
        """Your own choice; ``audio`` None = back to automatic."""
        with self._lock:
            self._db.execute("INSERT OR IGNORE INTO show_langs(show) VALUES(?)", (show,))
            self._db.execute("UPDATE show_langs SET manual_audio=?, manual_subs=?, manual_subtypes=? WHERE show=?",
                             (None if audio is None else json.dumps(sorted(set(audio))),
                              None if audio is None else json.dumps(sorted(set(subs or []))),
                              None if audio is None else json.dumps(sorted(set(subtypes or []))), show))
            self._db.commit()
