"""Settings, your data folder, portable mode.

Part of the App class (see server.py); the methods use the App's attributes.
"""

from __future__ import annotations

import logging
import shutil

from .apierror import ApiError
from .paths import PROGRAM_DIR, home_dir, is_portable
from .player import clean_langs

log = logging.getLogger("anibox.server")


SETTING_TYPES = {
    "folders": list, "libraries": list, "mpv_path": str, "fullscreen": bool, "resume_back": int,
    "watched_at": int, "autoplay": bool, "countdown": int, "still_watching_after": int,
    "remote_enabled": bool, "remote_port": int, "posters": bool,
    "audio_langs": str, "sub_langs": str, "subs": str, "skip_openings": str, "skip_endings": str,
    "update_check": bool, "release_repo": str, "mal_client_id": str, "protected": list, "mpv_log": bool, "tv_device": str,
    "protect_existing": bool, "episode_info": bool, "embed_player": bool,
    "library_kinds": dict, "inbox_folders": list, "import_mode": str, "import_write_nfo": bool, "plex_scan_section": str,
    "ia_download_dir": str, "ia_add_to_library": bool,
    "airing_notices": bool,
    "mal_username": str, "anilist_username": str, "anilist_client_id": str, "lists_rewatch": bool, "lists_source": str,
    "tmdb_api_key": str,
    "ffmpeg_path": str,
    "ia_cache": bool, "ia_cache_dir": str, "ia_cache_gb": int, "ia_cache_connections": int, "ia_cache_ahead": int,
    "ia_keep_dir": str,
}
SETTING_CHOICES = {
    "import_mode": ("move", "copy"),
    "lists_source": ("", "mal", "anilist"),
    "subs": ("auto", "on", "off"),
    "skip_openings": ("off", "button", "auto"),
    "skip_endings": ("off", "button", "auto"),
}


class RoutesSettingsMixin:
    def _public_settings(self) -> dict:
        s = self.store.settings()
        s.pop("remote_key", None)
        return s

    def _folders_info(self) -> dict:
        home = self.data_dir.parent
        backups = sorted(self.backup_dir.glob("anibox-*.db")) if self.backup_dir.is_dir() else []
        return {
            "home": str(home), "app": str(self.data_dir), "logs": str(self.data_dir / "logs"),
            "backups": str(self.backup_dir), "lastBackup": backups[-1].name if backups else "",
            "portable": is_portable() and home == home_dir(), "programDir": str(PROGRAM_DIR),
            "portableDir": str(PROGRAM_DIR / "data"),
        }

    def _make_portable(self) -> dict:
        """Copy everything into a "data" folder next to AniBox.bat. The old folder stays as it is."""
        src = self.data_dir.parent
        dest = PROGRAM_DIR / "data"
        if src.resolve() == dest.resolve():
            raise ApiError("AniBox already keeps its data next to AniBox.bat.")
        if dest.exists() and any(dest.iterdir()):
            raise ApiError(f"There's already a folder with files in it: {dest}")
        log.info("Copying the data folder %s to %s (portable mode)", src, dest)
        shutil.copytree(src, dest, dirs_exist_ok=True,
                        ignore=shutil.ignore_patterns("anibox.db", "anibox.db-*", "*.part", "logs"))
        self.store.copy_to(dest / self.data_dir.name / "anibox.db")
        return {"ok": True, "dest": str(dest)}

    def _save_settings(self, body: dict) -> dict:
        changes = {}
        for k, v in body.items():
            t = SETTING_TYPES.get(k)
            if t is None:
                continue
            if t is list:
                if not isinstance(v, list):
                    raise ApiError(f"{k} must be a list")
                v = [str(x).strip().strip('"') for x in v if str(x).strip()]
            elif t is dict:  # library_kinds: {library: auto|anime|series|movies}
                if not isinstance(v, dict):
                    raise ApiError(f"{k} must be a list of names and values")
                v = {str(a): str(b) for a, b in v.items() if str(b) in ("anime", "series", "movies")}
            elif t is bool:
                v = bool(v)
            elif t is int:
                try:
                    v = int(v)
                except (TypeError, ValueError):
                    raise ApiError(f"{k} must be a number")
            else:
                v = str(v).strip().strip('"')
                if k in SETTING_CHOICES and v not in SETTING_CHOICES[k]:
                    raise ApiError(f"{k} must be one of: {', '.join(SETTING_CHOICES[k])}")
                if k in ("audio_langs", "sub_langs"):
                    v = clean_langs(v)
            changes[k] = v
        if "watched_at" in changes:
            changes["watched_at"] = max(50, min(100, changes["watched_at"]))
        if "remote_port" in changes:
            changes["remote_port"] = max(1024, min(65535, changes["remote_port"]))
        self.store.update_settings(changes)
        log.info("Settings changed: %s", ", ".join(sorted(k for k in changes if k != "mal_client_id")) or "none")
        if "libraries" in changes:
            self.library.forget_report()
        self.sync_remote()
        return {"settings": self._public_settings(), "remote": self.remote_info()}
