"""New-episode notices: which episodes of the shows you watch are out but not on your drives yet.

The air dates come from **AniList's** free public GraphQL API (``graphql.anilist.co``, no account).
AniBox asks for the MyAnimeList entries of

- the shows you're watching (started, not finished), and
- the shows whose MyAnimeList entry is still airing (the anime lists say "ONGOING").

Two kinds of questions, few requests:

1. ``Page { media(idMal_in: [50 ids]) { status episodes nextAiringEpisode endDate } }``: 50 entries
   per request.
2. For entries that are airing: the latest aired episode with its date. Several ``Page``
   questions under their own names ("aliases") in one request, ``ALIAS_BATCH`` at a time. (The
   ``airingSchedule`` list inside ``media`` is shorter than a long show and starts at the oldest
   episode, so it can't tell the latest one of One Piece.)

AniList allows 90 requests a minute (30 while it's busy), so AniBox waits ``interval`` seconds
between requests and, when AniList answers 429 "too many", as long as its ``Retry-After`` says.
Answers are kept in ``<data>/airing.json`` and asked again after ``MAX_AGE`` (2 hours) or on
"Check now". Nothing is ever sent to AniList except these MyAnimeList numbers.

AniList's numbering follows MyAnimeList's (one entry per season, episodes from 1), like AniBox's
folders, so a folder's episode numbers can be compared directly. Folders with "Season NN"
subfolders count up (``episodes.absolute_numbers``); a sequel folder numbered on from the first
season ("… 13.mkv" for episode 1) is recognized and shifted back. Episodes before the first one in
the folder don't count as missing (old ones you didn't keep aren't news).
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Optional, Set

from .episodes import absolute_numbers

log = logging.getLogger("anibox.airing")

ANILIST = "https://graphql.anilist.co"
BATCH = 50  # MyAnimeList ids per media question (AniList's largest page)
ALIAS_BATCH = 25  # "latest aired episode" questions per request
MAX_AGE = 2 * 3600  # ask again after this long
RETRY_AFTER_ERROR = 15 * 60  # after a failed check, wait this long before trying by itself again
SHOW_CACHE_FOR = 24 * 3600  # when AniList can't be reached, older answers are still shown this long
INTERVAL = 2.1  # seconds between requests: stays under AniList's 30 a minute when it's busy
MAX_RETRIES = 3  # 429 / 5xx answers tried again this often
MAX_WAIT = 90  # never wait longer than this for one retry
TIMEOUT = 20
CACHE_VERSION = 1
# Cloudflare in front of AniList refuses Python's default "Python-urllib" name (error 1010).
USER_AGENT = "AniBox (anime library on a home PC)"

MEDIA_QUERY = """query ($ids: [Int], $page: Int) {
  Page(page: $page, perPage: 50) {
    pageInfo { hasNextPage }
    media(idMal_in: $ids, type: ANIME) {
      id idMal status episodes
      endDate { year month day }
      nextAiringEpisode { episode airingAt }
    }
  }
}"""

AIRING = ("RELEASING", "HIATUS")


class AniListError(RuntimeError):
    pass


def _ended_at(end: Optional[dict]) -> float:
    """AniList's end date (year, month, day) as a time stamp at noon, or 0."""
    try:
        if end and end.get("year") and end.get("month") and end.get("day"):
            return time.mktime(datetime(int(end["year"]), int(end["month"]), int(end["day"]), 12).timetuple())
    except (TypeError, ValueError, OverflowError):
        pass
    return 0.0


class AniList:
    """A small client for AniList's GraphQL API: batching, a pause between requests, back-off on 429."""

    def __init__(self, base: str = ANILIST, interval: float = INTERVAL, sleep: Callable[[float], None] = time.sleep,
                 clock: Callable[[], float] = time.monotonic):
        self.base = base
        self.interval = interval
        self.sleep = sleep
        self.clock = clock
        self._last = None  # when the last request was sent
        self.requests = 0

    def _post(self, query: str, variables: Optional[dict] = None) -> dict:
        body = json.dumps({"query": query, "variables": variables or {}}).encode("utf-8")
        attempt = 0
        while True:
            if self._last is not None and self.interval > 0:
                wait = self.interval - (self.clock() - self._last)
                if wait > 0:
                    self.sleep(wait)
            self._last = self.clock()
            self.requests += 1
            req = urllib.request.Request(self.base, data=body, method="POST", headers={
                "Content-Type": "application/json", "Accept": "application/json", "User-Agent": USER_AGENT})
            try:
                with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
                    data = json.loads(r.read(5_000_000).decode("utf-8"))
            except urllib.error.HTTPError as exc:
                retry = exc.code == 429 or exc.code >= 500
                if not retry or attempt >= MAX_RETRIES:
                    raise AniListError(f"AniList answered {exc.code}") from exc
                attempt += 1
                wait = _retry_after(exc.headers.get("Retry-After"), 60.0 if exc.code == 429 else 5.0 * attempt)
                log.info("AniList answered %s; waiting %.0f s before trying again", exc.code, wait)
                self.sleep(wait)
                continue
            except (OSError, ValueError) as exc:
                raise AniListError(f"AniList isn't reachable ({exc})") from exc
            if not isinstance(data, dict) or not isinstance(data.get("data"), dict):
                errors = data.get("errors") if isinstance(data, dict) else None
                raise AniListError(f"AniList's answer doesn't look right ({str(errors)[:200]})")
            return data["data"]

    def media(self, mal_ids: Iterable[int]) -> Dict[str, dict]:
        """{"<mal id>": AniList's media fields} for these MyAnimeList ids, ``BATCH`` per request."""
        ids = sorted({int(m) for m in mal_ids})
        out: Dict[str, dict] = {}
        for i in range(0, len(ids), BATCH):
            chunk = ids[i:i + BATCH]
            page = 1
            while page <= 3:  # 50 ids give at most 50 entries; more pages only if AniList has doubles
                data = self._post(MEDIA_QUERY, {"ids": chunk, "page": page})
                p = data.get("Page") or {}
                for m in p.get("media") or []:
                    if isinstance(m, dict) and m.get("idMal") is not None:
                        out.setdefault(str(m["idMal"]), m)
                if not (p.get("pageInfo") or {}).get("hasNextPage"):
                    break
                page += 1
        return out

    def latest_aired(self, anilist_ids: Iterable[int]) -> Dict[int, dict]:
        """{AniList id: {"episode", "airingAt"}} of the newest episode that has aired."""
        ids = sorted({int(a) for a in anilist_ids})
        out: Dict[int, dict] = {}
        for i in range(0, len(ids), ALIAS_BATCH):
            chunk = ids[i:i + ALIAS_BATCH]
            query = "query { " + " ".join(
                f"a{a}: Page(perPage: 1) {{ airingSchedules(mediaId: {a}, notYetAired: false, sort: [TIME_DESC]) "
                f"{{ episode airingAt }} }}" for a in chunk) + " }"
            data = self._post(query)
            for a in chunk:
                nodes = ((data.get(f"a{a}") or {}).get("airingSchedules") or [])
                if nodes and isinstance(nodes[0], dict) and isinstance(nodes[0].get("episode"), int):
                    out[a] = {"episode": nodes[0]["episode"], "airingAt": int(nodes[0].get("airingAt") or 0)}
        return out


def _retry_after(value, default: float) -> float:
    try:
        wait = float(value)
    except (TypeError, ValueError):
        wait = default
    return max(1.0, min(MAX_WAIT, wait))


def summarize(media: dict, latest: Optional[dict]) -> dict:
    """What AniBox keeps per entry: the newest aired episode (and when), the next one, the total."""
    status = media.get("status") or ""
    nxt = media.get("nextAiringEpisode") or None
    next_ep = None
    if isinstance(nxt, dict) and isinstance(nxt.get("episode"), int) and nxt.get("airingAt"):
        next_ep = {"episode": nxt["episode"], "airingAt": int(nxt["airingAt"])}
    aired, aired_at = None, 0
    if latest:
        aired, aired_at = latest["episode"], latest["airingAt"]
    if next_ep and (aired is None or aired < next_ep["episode"] - 1):  # the schedule has gaps: the date is unknown
        aired, aired_at = next_ep["episode"] - 1, 0
    if status == "FINISHED" and isinstance(media.get("episodes"), int):
        if aired is None or media["episodes"] > aired:
            aired, aired_at = media["episodes"], _ended_at(media.get("endDate"))
    if status == "NOT_YET_RELEASED":
        aired, aired_at = 0, 0
    return {"anilist": media.get("id"), "status": status, "episodes": media.get("episodes"),
            "aired": aired if aired is None else max(0, int(aired)), "airedAt": int(aired_at or 0), "next": next_ep}


class AiringCheck:
    """Keeps AniList's answers for the shows AniBox asks about, refreshed in the background."""

    def __init__(self, cache_path: Path, base: str = ANILIST, interval: float = INTERVAL,
                 sleep: Callable[[float], None] = time.sleep):
        self.cache_path = cache_path
        self.base = base
        self.interval = interval
        self.sleep = sleep
        self._lock = threading.Lock()
        self.state = {"state": "idle", "error": "", "finished": 0.0}
        self._error_logged = False
        self._failed_at = 0.0

    # -- cache ---------------------------------------------------------------------------------------

    def cached(self) -> dict:
        try:
            data = json.loads(self.cache_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}
        if not isinstance(data, dict) or data.get("version") != CACHE_VERSION or not isinstance(data.get("media"), dict):
            return {}
        return data

    def _save(self, data: dict) -> None:
        self.cache_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.cache_path.with_suffix(".part")
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, self.cache_path)

    def needs_check(self, mal_ids: Set[str], now: Optional[float] = None) -> bool:
        now = time.time() if now is None else now
        if not mal_ids:
            return False
        if self._failed_at and now - self._failed_at < RETRY_AFTER_ERROR:
            return False
        data = self.cached()
        if not data or now - float(data.get("fetched") or 0) > MAX_AGE:
            return True
        return bool(mal_ids - set(data.get("asked") or []))

    def usable(self, now: Optional[float] = None) -> Dict[str, dict]:
        """The answers to show: the cache, unless the last check failed and it's older than a day."""
        now = time.time() if now is None else now
        data = self.cached()
        if not data:
            return {}
        if self.state["state"] == "error" and now - float(data.get("fetched") or 0) > SHOW_CACHE_FOR:
            return {}
        return data["media"]

    # -- checking ----------------------------------------------------------------------------------------

    def check(self, mal_ids: Set[str], force: bool = False) -> None:
        """Ask AniList now (in this thread). Only new ids if the cache is still fresh, unless ``force``."""
        now = time.time()
        old = self.cached()
        fresh = bool(old) and now - float(old.get("fetched") or 0) <= MAX_AGE and not force
        ask = sorted((set(mal_ids) - set(old.get("asked") or [])) if fresh else set(mal_ids), key=int)
        client = AniList(self.base, self.interval, self.sleep)
        media = client.media(int(m) for m in ask)
        want_latest = [m["id"] for m in media.values() if m.get("id") and (
            m.get("status") in AIRING or m.get("nextAiringEpisode")
            or (m.get("status") == "FINISHED" and now - _ended_at(m.get("endDate")) < 45 * 86400))]
        latest = client.latest_aired(want_latest) if want_latest else {}
        found = {mal: summarize(m, latest.get(m.get("id"))) for mal, m in media.items()}
        if fresh:
            merged = dict(old["media"])
            merged.update(found)
            data = {"version": CACHE_VERSION, "fetched": old["fetched"], "asked": sorted(set(old.get("asked") or []) | set(ask), key=int),
                    "media": merged}
        else:
            data = {"version": CACHE_VERSION, "fetched": now, "asked": ask, "media": found}
        self._save(data)
        log.info("Airing times from AniList: %d of %d entries found (%d requests)", len(found), len(ask), client.requests)

    def check_async(self, mal_ids: Set[str], force: bool = False) -> bool:
        with self._lock:
            if self.state["state"] == "loading":
                return False
            self.state = {"state": "loading", "error": "", "finished": 0.0}
        threading.Thread(target=self._check_safe, args=(set(mal_ids), force), daemon=True, name="anibox-airing").start()
        return True

    def _check_safe(self, mal_ids: Set[str], force: bool) -> None:
        try:
            self.check(mal_ids, force)
            self._error_logged, self._failed_at = False, 0.0
            self.state = {"state": "done", "error": "", "finished": time.time()}
        except Exception as exc:  # offline, AniList down: show nothing new, log once
            if not self._error_logged:
                log.warning("New-episode check failed: %s", exc)
                self._error_logged = True
            self._failed_at = time.time()
            self.state = {"state": "error", "error": "AniList isn't reachable right now.", "finished": time.time()}


# -- which episodes are out but not here --------------------------------------------------------------


def owned_numbers(episodes: List[dict]) -> Set[int]:
    """Episode numbers a show folder has (counted from 1 for the whole MyAnimeList entry)."""
    nums = {n for n in absolute_numbers(episodes) if n}
    if not nums and episodes:  # no numbers in the names: count the files
        nums = set(range(1, len(episodes) + 1))
    return nums


def ranges(numbers: Iterable[int]) -> List[List[int]]:
    """[1, 2, 3, 5] -> [[1, 3], [5, 5]]"""
    out: List[List[int]] = []
    for n in sorted(set(numbers)):
        if out and n == out[-1][1] + 1:
            out[-1][1] = n
        else:
            out.append([n, n])
    return out


def notice(owned: Set[int], info: dict, waiting: Set[int] = frozenset()) -> Optional[dict]:
    """The notice for one MyAnimeList entry, or None when AniList doesn't know enough.

    ``owned``: episode numbers on your drives; ``info``: ``summarize()``'s answer; ``waiting``:
    episode numbers of matching files in Downloads.

    Episodes before the first one on your drives don't count: those are old ones you chose not to
    keep (a One Piece folder that starts at 1170), not new ones.
    """
    aired = info.get("aired")
    if aired is None:
        return None
    have, waiting = set(owned), set(waiting)
    total = max(aired, info.get("episodes") or 0)
    if have and min(have) > 1 and max(have) > total:  # a sequel numbered on from season 1 ("13" = episode 1)
        shift = min(have) - 1
        have = {n - shift for n in have}
        waiting |= {n - shift for n in waiting if n > shift}
    first = min(have) if have else 1
    missing = [n for n in range(first, aired + 1) if n not in have]
    got = sorted(n for n in missing if n in waiting)
    return {
        "aired": aired, "airedAt": info.get("airedAt") or 0, "total": info.get("episodes"),
        "status": info.get("status") or "", "have": max(have) if have else 0,
        "missing": ranges(missing)[:8], "missingCount": len(missing),
        "latestMissing": bool(missing) and missing[-1] == aired,
        "waiting": got[:50], "waitingAll": bool(missing) and len(got) == len(missing),
        "next": info.get("next"),
    }
