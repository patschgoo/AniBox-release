"""Check my library (health check + move plan) and the History page.

The health check and the move plan only read (see health.py); the result of the last check is kept in
``health.json`` in AniBox's app folder. History (history.py) lists every change AniBox made; Undo works
for file batches (fileops.py) and info files (nfo.py), each after a confirmation in the window.

Part of the App class (see server.py); the methods use the App's attributes. The state lives in the
instance's ``__dict__`` (``_hc()``), so the App's ``__init__`` needs nothing for it.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from typing import Dict, List, Tuple

import anibox

from . import health, history
from .apierror import ApiError
from .fileops import FileOpError
from .library import group_files

log = logging.getLogger("anibox.server")
_INIT = threading.Lock()


class RoutesHealthMixin:
    GET_ROUTES = {
        "/api/health": "_health_get",
        "/api/health/moveplan": "_moveplan_get",
        "/api/health/export": "_health_export",
        "/api/history": "_history_get",
    }
    POST_ROUTES = {
        "/api/health/start": "_health_start",
        "/api/health/stop": "_health_stop",
        "/api/history/undo": "_history_undo",
    }

    # -- state -------------------------------------------------------------------------------------------

    def _hc(self) -> dict:
        with _INIT:
            st = self.__dict__.get("_health_state")
            if st is None:
                st = {"job": {"state": "idle"}, "result": None, "stop": threading.Event(), "lock": threading.Lock(),
                      "path": self.data_dir / "health.json"}
                try:
                    st["result"] = json.loads(st["path"].read_text(encoding="utf-8"))
                except (OSError, ValueError):
                    pass
                self.__dict__["_health_state"] = st
        return st

    # -- the health check --------------------------------------------------------------------------------

    def _health_get(self, query: dict) -> dict:
        st = self._hc()
        if query.get("job"):  # while a check runs, the window only asks how far it is
            return {"job": st["job"]}
        names = sorted(self.library.libraries(), key=str.casefold)
        return {"job": st["job"], "result": st["result"], "scannedAt": self.library.scanned_at,
                "libraries": names, "pairs": [list(p) for p in health.suggest_pairs(names)]}

    def _health_start(self, body: dict) -> dict:
        st = self._hc()
        files = bool(body.get("files"))
        with st["lock"]:
            if st["job"].get("state") == "running":
                return {"job": st["job"]}
            if not self.library.shows(all_libraries=True):
                raise ApiError("Scan your folders first (Settings → Folders).")
            st["stop"].clear()
            st["job"] = {"state": "running", "phase": "Looking at your library …", "done": 0, "total": 0,
                         "files": files, "started": time.time()}
        threading.Thread(target=self._health_run, args=(files,), daemon=True, name="anibox-health").start()
        return {"job": st["job"]}

    def _health_stop(self, body: dict) -> dict:
        st = self._hc()
        st["stop"].set()
        return {"job": st["job"]}

    def _health_run(self, files: bool) -> None:
        st = self._hc()
        job = st["job"]
        started = time.time()

        def progress(done: int, total: int) -> None:
            job.update(phase="Reading the start of every file …", done=done, total=total)

        try:
            shows = self.library.shows(all_libraries=True)
            try:
                titles = self.library.datasets().titles
            except Exception:  # the anime lists couldn't be loaded: the checks without MyAnimeList still work
                log.warning("Health check without the anime lists", exc_info=True)
                titles = {}
            if files:
                job.update(phase="Reading the start of every file …", total=sum(len(s["episodes"]) for s in shows))
            result = health.check(shows, titles, read_files=files, progress=progress, stop=st["stop"])
            job.update(phase="Counting folders that weren't recognized …")
            try:
                result["unrecognized"] = len(self.library.report().unidentified)
            except Exception:
                log.warning("Couldn't count the folders that weren't recognized", exc_info=True)
                result["unrecognized"] = None
            result["scannedAt"] = self.library.scanned_at
            tmp = st["path"].with_suffix(".part")
            tmp.write_text(json.dumps(result, ensure_ascii=False), encoding="utf-8")
            os.replace(tmp, st["path"])
            st["result"] = result
            st["job"] = {"state": "done", "finished": time.time()}
            log.info("Health check%s in %.1f s: %s", " with the files" if files else "", time.time() - started,
                     result["counts"])
        except Exception as exc:  # shown on the page
            log.exception("Health check failed")
            st["job"] = {"state": "error", "message": str(exc) or exc.__class__.__name__}

    # -- the move plan -----------------------------------------------------------------------------------

    def _moveplan(self, query: dict) -> dict:
        source, target = str(query.get("from") or ""), str(query.get("to") or "")
        if not source and not target:
            pairs = health.suggest_pairs(self.library.libraries())
            if pairs:
                source, target = pairs[0]
        locked, unlocked = self.store.locked_keys(), self.store.unlocked_shows()
        plan = health.move_plan(
            self.library.shows(all_libraries=True), source, target, self.library.library_roots(),
            self.library.show_folder_path, lock_of=lambda sh: self.library.lock_view(sh, locked, unlocked),
            protected=self.store.settings().get("protected") or [], plex_of=self._plex_for_show)
        return plan

    def _moveplan_get(self, query: dict) -> dict:
        names = sorted(self.library.libraries(), key=str.casefold)
        return {**self._moveplan(query), "libraries": names,
                "pairs": [list(p) for p in health.suggest_pairs(names)]}

    def _health_export(self, query: dict) -> dict:
        """The check or the move plan as a file: {"name", "mime", "data"} (the window saves it)."""
        fmt = query.get("format") or "html"
        if fmt not in ("html", "csv"):
            raise ApiError("Unknown format")
        made_by = f"AniBox {anibox.__version__}"
        if query.get("what") == "plan":
            plan = self._moveplan(query)
            if plan.get("error"):
                raise ApiError(plan["error"])
            data = health.plan_csv(plan) if fmt == "csv" else health.plan_html(plan, made_by)
            stem = "AniBox-Move-plan-" + "".join(c if c.isalnum() else "-" for c in plan["from"]).strip("-")
        else:
            result = self._hc()["result"]
            if not result:
                raise ApiError("Check your library first.")
            data = health.health_csv(result) if fmt == "csv" else health.health_html(result, made_by)
            stem = "AniBox-Health-check"
        name = time.strftime(f"{stem}-%Y-%m-%d.{fmt}")
        return {"name": name, "mime": "text/csv;charset=utf-8" if fmt == "csv" else "text/html;charset=utf-8",
                "data": data}

    # -- History -----------------------------------------------------------------------------------------

    def _history_get(self, query: dict) -> dict:
        # MyAnimeList titles as the library has them (no need to load the anime lists for this page)
        titles = {str(sh["mal_id"]): {"title": sh.get("title") or ""}
                  for sh in self.library.shows(all_libraries=True) if sh.get("mal_id")}
        items = history.collect(self.data_dir, self.fileops, self.store, titles,
                                self.store.settings().get("folders") or [])
        return {"items": items, "busy": self.fileops.state.get("state") == "running"}

    def _history_undo(self, body: dict) -> dict:
        """``check: true`` first (what would happen, nothing changes), then the undo itself."""
        hid = str(body.get("id") or "")
        check = bool(body.get("check"))
        if hid == history.NFO_PENDING:
            if not self.nfo_undo.is_file():
                raise ApiError("There's nothing to undo.")
            if check:
                pending = [e for e in history.nfo_entries(self.data_dir) if e["id"] == history.NFO_PENDING]
                return {"ok": True, "kind": "nfo", "files": pending[0]["count"] if pending else 0, "problems": []}
            return self._nfo_undo()
        if not hid.startswith("files:"):
            raise ApiError("This change can't be undone here.")
        batch = hid[len("files:"):]
        fo = self.fileops
        if fo.state.get("state") == "running":
            raise ApiError("AniBox is still busy with the last files.")
        b = next((x for x in fo.batches() if x["batch"] == batch), None)
        if not b:
            raise ApiError("That change isn't in the list anymore.")
        if b["undone"]:
            raise ApiError("That change was undone already.")
        last = fo.last_batch()
        is_last = bool(last and last["batch"] == batch)
        blocker = None if is_last else fo.undo_blocker(batch)
        if blocker:
            raise ApiError("A later change moved some of the same files. Undo that one first.")
        try:
            problems = fo.undo_problems(batch)
        except FileOpError as exc:
            raise ApiError(str(exc))
        if check:
            return {"ok": True, "kind": "files", "files": len(b["files"]), "problems": problems, "last": is_last,
                    "possible": is_last or not problems}
        keys = self._keys_before_undo(b["files"])
        try:
            out = fo.undo_last() if is_last else fo.undo_batch(batch)
        except FileOpError as exc:
            raise ApiError(str(exc))
        self._rekey_after_undo(b["files"], keys)
        log.info("History: undid %s (%s)", batch, out)
        folders = self.store.settings().get("folders") or []
        if folders:
            self.library.scan_async(folders)
        return {"ok": True, **out}

    def _keys_before_undo(self, files: List[dict]) -> Dict[str, Tuple[str, str]]:
        """Where each file AniBox put somewhere is in the library now: path -> (episode key, show id)."""
        wanted = {os.path.normcase(e["dst"]) for e in files}
        out = {}
        for sh in self.library.shows(all_libraries=True):
            for e in sh["episodes"]:
                p = os.path.normcase(e["path"])
                if p in wanted:
                    out[p] = (e["key"], sh["id"])
        return out

    def _rekey_after_undo(self, files: List[dict], before: Dict[str, Tuple[str, str]]) -> None:
        """A move that was undone: the watch progress and locks follow the files back to where they were
        (only for files that are back inside your library folders)."""
        folders = self.store.settings().get("folders") or []
        episodes: Dict[str, Tuple[str, str]] = {}
        shows: Dict[str, str] = {}
        for e in files:
            old = before.get(os.path.normcase(e["dst"]))
            if not old or e.get("op") == "copy" or not os.path.isfile(e["src"]) or os.path.exists(e["dst"]):
                continue
            if not history._inside(e["src"], folders):
                continue
            grouped = group_files([(e["src"], 0.0)])
            if not grouped:
                continue
            (library, folder), items = next(iter(grouped.items()))
            new_key, new_show = f"{library}\\{folder}\\{items[0]['file']}", f"{library}\\{folder}"
            if new_key != old[0]:
                episodes[old[0]] = (new_key, new_show)
                if new_show != old[1]:
                    shows.setdefault(old[1], new_show)
        if episodes:
            self.store.move_keys(episodes, shows)
            log.info("History: watch progress of %d episodes followed the files back", len(episodes))
