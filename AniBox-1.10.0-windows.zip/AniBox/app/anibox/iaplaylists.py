"""Series playlists: episodes from one or more archive.org items, in an order you choose.

The idea and the rules come from Frostbox (Martin's archive.org player, PLAN.md 4.2, used with
permission):

- **Making one:** a name and one or more archive.org items. AniBox reads each item's file list and
  groups its videos by series: the part of the file name before a date or S01E01 ("WWE Monday Night
  Raw" in ``WWE.Monday.Night.Raw.2008.01.07.720p.mp4``; see iafiles.py). You tick the series that go
  in; the others never slip in later, also when the item gets new files. Each series has a display
  name of its own ("Raw" instead of "WWE Monday Night Raw"). More items can be added later.
- **One file per episode:** archive.org's MP4 copy, unless the original is sharper (iafiles.py). When
  a refresh finds a better file for an episode, the episode switches to it and its watch progress
  moves along.
- **Order:** by air date (from the file name), by season & episode, by file name (2 before 10), by
  when it was added, or manual (your own order; it stays fixed, new episodes go to the end marked
  "new"). Episodes without a date (or without S01E01) go to the end, marked.
- **Hiding:** single episodes can be hidden and shown again.
- **Refresh:** reads the items again: new files come in, files that are gone are kept in the list
  as "No longer online" (their size, length and checksum stay known).
- **Progress is shared:** the episodes keep the plain ``ia:<item>/<file>`` keys of stream.py, so a
  video watched from its item page is watched in every playlist, and the other way round.

Playlists play through ``stream.IaStreams.providers``: a playlist is the show ``ia:@<id>``, so the
player's next/previous follow the playlist's order (hidden episodes are skipped).

Everything is kept in ``ia-playlists.json`` in AniBox's data folder (written as a whole, atomically).
A damaged file is copied aside (``ia-playlists.damaged.json``) and AniBox starts with an empty list.
Nothing here ever touches files on your drives.
"""

from __future__ import annotations

import copy
import json
import logging
import os
import re
import secrets
import threading
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from . import stream
from .iafiles import air_date, base_name, natural_key, pick_videos, season_episode, series_name, stem
from .iarchive import ArchiveError, link_id, valid_id
from .watching import next_up

log = logging.getLogger("anibox.iaplaylists")

STATE_FILE = "ia-playlists.json"
DAMAGED_FILE = "ia-playlists.damaged.json"
SORTS = ("date", "episode", "name", "added", "manual")
SORT_LABELS = {"date": "Air date", "episode": "Season & episode", "name": "File name", "added": "Added", "manual": "Manual"}
FILE_FIELDS = ("name", "size", "length", "md5", "format", "source", "original", "width", "height")
ID_RE = re.compile(r"^[a-z0-9]{6,16}$")
MAX_PLAYLISTS = 300
MAX_ITEMS = 40  # items in one playlist
MAX_SCAN = 20  # links read at once
MAX_NAME = 120
SHOW_TTL = 1.5  # seconds a built show is reused (the player asks several times a second)


class PlaylistError(Exception):
    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.status = status


# -- an item's files ------------------------------------------------------------------------------

def file_record(f: dict) -> dict:
    rec = {k: f.get(k) for k in FILE_FIELDS if f.get(k) not in (None, "")}
    rec.setdefault("source", "original")
    rec["online"] = True
    return rec


def item_record(item: dict) -> dict:
    """What a playlist keeps of an item from ``ArchiveClient.item()``: its videos (with size, length,
    checksum and resolution) and the names of its subtitle files."""
    files = item.get("files") or []
    return {"id": item["id"], "title": item.get("title") or item["id"],
            "files": [file_record(f) for f in files if f.get("kind") == "video"],
            "subs": [f["name"] for f in files if f.get("kind") == "subtitle"]}


def series_of(record: dict, include_gone: bool = False) -> List[dict]:
    """The series of an item (one file per episode), the biggest first."""
    files = [f for f in record.get("files") or [] if include_gone or f.get("online", True)]
    groups: Dict[str, dict] = {}
    for _, f in pick_videos(files):
        name = series_name(f["name"]) or stem(base_name(f["name"]))
        g = groups.setdefault(name.casefold(), {"name": name, "count": 0, "first": None, "last": None, "sample": f["name"],
                                                "dated": 0, "numbered": 0})
        g["count"] += 1
        d = air_date(f["name"])
        if d:
            g["first"] = min(g["first"] or d, d)
            g["last"] = max(g["last"] or d, d)
            g["dated"] += 1
        if season_episode(f["name"]):
            g["numbered"] += 1
    return sorted(groups.values(), key=lambda g: (-g["count"], g["name"].casefold()))


def parse_links(text) -> List[str]:
    """archive.org links or item names (one per line, or a list) → item names, each once."""
    parts = text if isinstance(text, list) else re.split(r"[\s,;]+", str(text or ""))
    out: List[str] = []
    for p in parts:
        p = str(p or "").strip()
        if not p:
            continue
        ident = link_id(p) or (p if valid_id(p) else "")
        if not ident:
            raise PlaylistError(f"“{p[:80]}” isn't an archive.org link or item name.")
        if ident not in out:
            out.append(ident)
    return out


# -- order ----------------------------------------------------------------------------------------------

def sort_key(mode: str, series_order: Dict[Tuple[str, str], int]):
    """Frostbox's Sorting.Order: without a date (or S01E01) at the end; ties by series, then file name."""
    def order(e):
        return series_order.get((e["item"], e["series"].casefold()), 9999)

    if mode == "date":
        def key(e):
            d = air_date(e["file"])
            return (d is None, d or "", order(e), natural_key(e["file"]))
    elif mode == "episode":
        def key(e):
            sxe = season_episode(e["file"])
            return (sxe is None, order(e), sxe or (0, 0), natural_key(e["file"]))
    elif mode == "name":
        def key(e):
            return natural_key(base_name(e["file"]))
    else:  # added, manual
        def key(e):
            return e.get("added", 0)
    return key


def unplaced(mode: str, name: str) -> bool:
    """No place found for this order: no date in the name (air date), no S01E01 (season & episode)."""
    if mode == "date":
        return air_date(name) is None
    if mode == "episode":
        return season_episode(name) is None
    return False


def episode_label(name: str, display: str, mode: str, several: bool) -> str:
    """"Raw · 2008-01-07", "S01E03" (with the series in front when the playlist has several)."""
    d, sxe = air_date(name), season_episode(name)
    if d and (mode == "date" or not sxe):
        return f"{display} · {d}" if display else d
    if sxe:
        code = f"S{sxe[0]:02d}E{sxe[1]:02d}"
        return f"{display} · {code}" if several and display else code
    return stem(base_name(name))


# -- the playlists --------------------------------------------------------------------------------------

def _clean_file(f) -> Optional[dict]:
    if not isinstance(f, dict) or not isinstance(f.get("name"), str) or not f["name"]:
        return None
    out = {k: f.get(k) for k in FILE_FIELDS if f.get(k) not in (None, "")}
    out["online"] = bool(f.get("online", True))
    return out


def _clean_playlist(d) -> Optional[dict]:
    """A playlist from the file, checked part by part (a damaged entry is left out, not the rest)."""
    if not isinstance(d, dict) or not isinstance(d.get("id"), str) or not ID_RE.match(d["id"]):
        return None
    items = []
    for it in d.get("items") or []:
        if not isinstance(it, dict) or not valid_id(it.get("id")):
            continue
        series = [{"name": str(s["name"]), "display": str(s.get("display") or s["name"]), "on": bool(s.get("on")),
                   "order": int(s.get("order") or 0)}
                  for s in it.get("series") or [] if isinstance(s, dict) and isinstance(s.get("name"), str) and s["name"]
                  and isinstance(s.get("order", 0), (int, float))]
        items.append({"id": it["id"], "title": str(it.get("title") or it["id"]), "checked": float(it.get("checked") or 0)
                      if isinstance(it.get("checked"), (int, float)) else 0.0, "gone": bool(it.get("gone")),
                      "files": [f for f in (_clean_file(x) for x in it.get("files") or []) if f],
                      "subs": [s for s in it.get("subs") or [] if isinstance(s, str)], "series": series})
    known = {it["id"] for it in items}
    episodes, seen = [], set()
    for e in d.get("episodes") or []:
        if not isinstance(e, dict) or not all(isinstance(e.get(k), str) and e.get(k) for k in ("item", "ep", "file", "series")):
            continue
        if e["item"] not in known or (e["item"], e["ep"]) in seen or not isinstance(e.get("added", 0), (int, float)):
            continue
        seen.add((e["item"], e["ep"]))
        episodes.append({"item": e["item"], "ep": e["ep"], "file": e["file"], "series": e["series"],
                         "added": int(e.get("added") or 0), "hidden": bool(e.get("hidden")), "new": bool(e.get("new"))})
    sort = d.get("sort") if d.get("sort") in SORTS else "date"
    seq = d.get("seq") if isinstance(d.get("seq"), int) else 0
    return {"id": d["id"], "name": str(d.get("name") or "Series playlist")[:MAX_NAME], "sort": sort,
            "created": float(d.get("created") or 0) if isinstance(d.get("created"), (int, float)) else 0.0,
            "changed": float(d.get("changed") or 0) if isinstance(d.get("changed"), (int, float)) else 0.0,
            "seq": max(seq, max((e["added"] for e in episodes), default=0)), "items": items, "episodes": episodes}


class IaPlaylists:
    """The series playlists, and their provider for stream.IaStreams (owns/show/prepare)."""

    def __init__(self, data_dir: Path, client, streams, store):
        self.client = client  # iarchive.ArchiveClient
        self.streams = streams  # stream.IaStreams
        self.store = store
        self.path = Path(data_dir) / STATE_FILE
        self._lock = threading.RLock()
        self._lists: Dict[str, dict] = {}
        self._version: Dict[str, int] = {}
        self._shows: Dict[str, Tuple[int, float, Optional[dict]]] = {}
        self.notice = ""  # for the window: the file was damaged
        self._readonly = False  # the file couldn't be read at all: don't write over it
        self._load()

    # -- the file ----------------------------------------------------------------------------------------

    def _load(self) -> None:
        try:
            raw = self.path.read_bytes()
        except FileNotFoundError:
            return
        except OSError as exc:
            log.warning("%s couldn't be read (%s)", self.path.name, exc)
            self.notice = "AniBox couldn't read your series playlists just now. Restart AniBox to try again."
            self._readonly = True
            return
        try:
            data = json.loads(raw.decode("utf-8"))
            lists = data.get("playlists") if isinstance(data, dict) else None
            if not isinstance(lists, list):
                raise ValueError("no playlists")
        except (ValueError, UnicodeDecodeError) as exc:
            self._keep_damaged(raw, exc)
            return
        bad = 0
        for d in lists:
            pl = _clean_playlist(d)
            if pl and pl["id"] not in self._lists:
                self._lists[pl["id"]] = pl
            else:
                bad += 1
        if bad:
            log.warning("%s: %d damaged playlist(s) left out", self.path.name, bad)
            self._keep_damaged(raw, None)

    def _keep_damaged(self, raw: bytes, exc) -> None:
        """Copy the damaged file aside, then write what could be read (so the next start doesn't copy it
        again). If the copy fails, the file is left alone and nothing is written over it."""
        target = self.path.with_name(DAMAGED_FILE)
        if target.exists():
            target = self.path.with_name(time.strftime("ia-playlists.damaged-%Y%m%d-%H%M%S.json"))
        try:
            target.write_bytes(raw)  # a copy: AniBox's own data file, kept as it was
        except OSError:
            log.warning("The damaged %s couldn't be copied aside; AniBox won't change it", self.path.name, exc_info=True)
            self._readonly = True
            self.notice = ("Your series playlists file is damaged and AniBox couldn't keep a copy of it, so it "
                           "doesn't change it. Look at ia-playlists.json in AniBox's data folder.")
            return
        try:
            self._save()
        except PlaylistError:
            pass
        if exc is not None:
            log.warning("%s is damaged (%s); a copy is in %s, starting with no playlists", self.path.name, exc, target.name)
            self.notice = (f"Your series playlists couldn't be read (the file was damaged). AniBox kept a copy as "
                           f"{target.name} in its data folder and started a new list.")
        else:
            self.notice = (f"Some series playlists were damaged and left out. AniBox kept a copy of the old file as "
                           f"{target.name} in its data folder.")

    def _save(self) -> None:
        if self._readonly:
            raise PlaylistError("AniBox couldn't read your series playlists, so it doesn't change them now. Restart AniBox.")
        data = {"version": 1, "playlists": list(self._lists.values())}
        tmp = self.path.with_name(self.path.name + ".tmp")
        try:
            tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
            os.replace(tmp, self.path)
        except OSError as exc:
            log.warning("%s couldn't be saved", self.path.name, exc_info=True)
            raise PlaylistError(f"AniBox couldn't save the playlists ({exc}).", 500)

    def _changed(self, pl: dict) -> None:
        pl["changed"] = time.time()
        self._version[pl["id"]] = self._version.get(pl["id"], 0) + 1
        self._shows.pop(pl["id"], None)
        self._save()

    def _get(self, pid: str) -> dict:
        pl = self._lists.get(str(pid or ""))
        if not pl:
            raise PlaylistError("That series playlist isn't there any more.", 404)
        return pl

    # -- reading archive.org ---------------------------------------------------------------------------

    def _fetch(self, ident: str, fresh: bool = False) -> dict:
        try:
            item = self.client.item(ident) if fresh else self.client.cached_item(ident)
        except ArchiveError as exc:
            raise PlaylistError(str(exc), 404 if exc.status == 404 else 502) from exc
        return item_record(item)

    def scan(self, links) -> List[dict]:
        """Read archive.org items for the editor: their series (nothing is saved)."""
        idents = parse_links(links)
        if not idents:
            raise PlaylistError("Paste an archive.org link or item name.")
        if len(idents) > MAX_SCAN:
            raise PlaylistError(f"At most {MAX_SCAN} items at once.")
        out = []
        for ident in idents:
            try:
                rec = self._fetch(ident)
            except PlaylistError as exc:
                out.append({"id": ident, "error": str(exc)})
                continue
            series = series_of(rec)
            several = any(s["count"] >= 2 for s in series)  # ticked at first: the series, not single extras
            for s in series:
                s["display"] = s["name"]
                s["on"] = s["count"] >= 2 if several else True
            out.append({"id": ident, "title": rec["title"], "videos": len(rec["files"]), "series": series,
                        "error": "" if series else "This item has no videos AniBox can play."})
        return out

    # -- building and changing a playlist -----------------------------------------------------------

    def _records_for(self, body_items: list, base: Optional[dict]) -> Dict[str, dict]:
        """Items of an editor body: the playlist's own copy, or read from archive.org (outside the lock)."""
        if not isinstance(body_items, list):
            raise PlaylistError("Add at least one archive.org item.")
        have = {it["id"]: it for it in (base or {}).get("items") or []}
        out = {}
        for b in body_items:
            ident = b.get("id") if isinstance(b, dict) else None
            if not valid_id(ident):
                raise PlaylistError("That isn't an archive.org item name.")
            if ident in out:
                continue
            out[ident] = copy.deepcopy(have[ident]) if ident in have else self._fetch(ident)
        if len(out) > MAX_ITEMS:
            raise PlaylistError(f"A playlist can hold at most {MAX_ITEMS} archive.org items.")
        return out

    def _apply_body(self, pl: dict, body_items: list, records: Dict[str, dict], mark_new: bool, dry: bool = False) -> None:
        """Take the editor's choice: which items, which series (ticked, display name), in which order.
        ``dry``: only for a preview (no watch progress moves)."""
        old_items = {it["id"]: it for it in pl["items"]}
        items, order = [], 0
        for b in body_items:
            ident = b["id"]
            if any(it["id"] == ident for it in items):
                continue
            it = old_items.get(ident) or {**records[ident], "checked": time.time(), "gone": False, "series": []}
            chosen = {}
            for s in b.get("series") or []:
                if isinstance(s, dict) and isinstance(s.get("name"), str) and s["name"]:
                    chosen[s["name"].casefold()] = s
            found = {s["name"].casefold(): s["name"] for s in series_of(it, include_gone=True)}
            for s in it["series"]:
                found.setdefault(s["name"].casefold(), s["name"])
            old = {s["name"].casefold(): s for s in it["series"]}
            series = []
            for fold, name in found.items():
                pick = chosen.get(fold)
                prev = old.get(fold) or {}
                on = bool(pick.get("on")) if pick else bool(prev.get("on"))
                display = str((pick or {}).get("display") or prev.get("display") or name).strip()[:MAX_NAME] or name
                series.append({"name": prev.get("name") or name, "display": display, "on": on, "order": 0})
            # the order of the series: as the editor listed them, the others after
            rank = {fold: i for i, fold in enumerate(chosen)}
            series.sort(key=lambda s: rank.get(s["name"].casefold(), len(rank)))
            for s in series:
                if s["on"]:
                    order += 1
                    s["order"] = order
            it["series"] = series
            items.append(it)
        if not items:
            raise PlaylistError("Add at least one archive.org item.")
        pl["items"] = items
        ticked = {(it["id"], s["name"].casefold()) for it in items for s in it["series"] if s["on"]}
        if not ticked:
            raise PlaylistError("Tick at least one series.")
        pl["episodes"] = [e for e in pl["episodes"] if (e["item"], e["series"].casefold()) in ticked]
        for it in items:
            self._sync_item(pl, it, mark_new, dry)
        if not pl["episodes"]:
            raise PlaylistError("The ticked series have no videos to play.")

    def _sync_item(self, pl: dict, it: dict, mark_new: bool, dry: bool = False) -> Tuple[int, int]:
        """Bring the playlist's episodes of one item up to date with its files: new episodes of ticked
        series come in, an episode with a better file switches to it. Returns (new, switched)."""
        online = [f for f in it["files"] if f.get("online", True)] if not it.get("gone") else []
        series = {s["name"].casefold(): s for s in it["series"]}
        mine = {e["ep"]: e for e in pl["episodes"] if e["item"] == it["id"]}
        added = switched = 0
        for key, f in pick_videos(online):
            ex = mine.get(key)
            if ex:
                if ex["file"] != f["name"] and self._switch(pl, it, ex, f, dry):
                    switched += 1
                continue
            name = series_name(f["name"]) or stem(base_name(f["name"]))
            s = series.get(name.casefold())
            if s is None:  # a series that wasn't there before: known, but not ticked
                s = {"name": name, "display": name, "on": False, "order": 0}
                it["series"].append(s)
                series[name.casefold()] = s
            if not s["on"]:
                continue
            pl["seq"] = pl.get("seq", 0) + 1
            e = {"item": it["id"], "ep": key, "file": f["name"], "series": s["name"], "added": pl["seq"],
                 "hidden": False, "new": bool(mark_new)}
            pl["episodes"].append(e)
            mine[key] = e
            added += 1
        return added, switched

    def _switch(self, pl: dict, it: dict, ep: dict, better: dict, dry: bool = False) -> bool:
        """A better file for an episode (e.g. the HD original instead of a small copy): switch, and move
        its watch progress along. A file the cache keeps (a url hook answers for it) stays. ``dry``: a
        preview, nothing moves."""
        old = next((f for f in it["files"] if f["name"] == ep["file"]), None)
        if old and self._local(it["id"], old):
            return False
        if dry:
            ep["file"] = better["name"]
            return True
        old_key, new_key = stream.stream_key(it["id"], ep["file"]), stream.stream_key(it["id"], better["name"])
        if self.store:
            row = self.store.progress(old_key)
            if row and not self.store.progress(new_key):
                self.store.move_keys({old_key: (new_key, row.get("show") or "")}, {})
        log.info("Series playlist %s: %s → %s (better file)", pl["name"], ep["file"], better["name"])
        ep["file"] = better["name"]
        return True

    def _local(self, ident: str, f: dict) -> bool:
        """Is the whole file on this PC (kept, or fully in the cache), so it plays without archive.org?"""
        return bool(self.streams) and self.streams.is_local(ident, f["name"])

    def _resort(self, pl: dict) -> None:
        if pl["sort"] == "manual":
            return
        pl["episodes"].sort(key=sort_key(pl["sort"], self._series_order(pl)))

    @staticmethod
    def _series_order(pl: dict) -> Dict[Tuple[str, str], int]:
        return {(it["id"], s["name"].casefold()): s["order"] for it in pl["items"] for s in it["series"] if s["on"]}

    # -- what the window asks for ---------------------------------------------------------------------

    def create(self, name: str, sort: str, body_items: list) -> dict:
        name = str(name or "").strip()[:MAX_NAME]
        if not name:
            raise PlaylistError("Give the playlist a name.")
        sort = sort if sort in SORTS else "date"
        records = self._records_for(body_items, None)
        with self._lock:
            if len(self._lists) >= MAX_PLAYLISTS:
                raise PlaylistError(f"AniBox keeps at most {MAX_PLAYLISTS} series playlists.")
            pid = secrets.token_hex(4)
            while pid in self._lists:
                pid = secrets.token_hex(4)
            pl = {"id": pid, "name": name, "sort": sort, "created": time.time(), "changed": 0.0, "seq": 0,
                  "items": [], "episodes": []}
            self._apply_body(pl, body_items, records, mark_new=False)
            pl["episodes"].sort(key=sort_key("added" if sort == "manual" else sort, self._series_order(pl)))
            self._lists[pid] = pl
            self._changed(pl)
            log.info("Series playlist made: %s (%d episodes, %s)", name, len(pl["episodes"]), SORT_LABELS[sort])
            return self.summary(pl)

    def save(self, pid: str, body_items: list, name: Optional[str] = None) -> dict:
        """The editor's changes: items, ticked series and their names. A manual order stays; what's new
        goes to its end, marked "new"."""
        with self._lock:
            base = copy.deepcopy(self._get(pid))
        records = self._records_for(body_items, base)
        with self._lock:
            pl = copy.deepcopy(self._get(pid))
            if name is not None:
                pl["name"] = str(name).strip()[:MAX_NAME] or pl["name"]
            self._apply_body(pl, body_items, records, mark_new=pl["sort"] == "manual")
            self._resort(pl)
            self._lists[pid] = pl
            self._changed(pl)
            return self.summary(pl)

    def preview(self, sort: str, body_items: Optional[list] = None, pid: str = "") -> List[dict]:
        """The order the episodes would have (nothing is saved)."""
        sort = sort if sort in SORTS else "date"
        with self._lock:
            base = copy.deepcopy(self._lists[pid]) if pid in self._lists else None
        if pid and base is None:
            raise PlaylistError("That series playlist isn't there any more.", 404)
        if body_items is not None:
            records = self._records_for(body_items, base)
            pl = base or {"id": "preview", "name": "", "sort": sort, "seq": 0, "items": [], "episodes": []}
            self._apply_body(pl, body_items, records, mark_new=pl["sort"] == "manual" and bool(pid), dry=True)
        else:
            pl = base
            if pl is None:
                raise PlaylistError("Nothing to show yet.")
        if sort != "manual":
            pl["episodes"].sort(key=sort_key(sort, self._series_order(pl)))
        elif pl["sort"] != "manual":  # becoming manual keeps the order it has now (saving sorts by the old one first)
            pl["episodes"].sort(key=sort_key(pl["sort"], self._series_order(pl)))
        pl["sort"] = sort
        return [{k: e[k] for k in ("key", "label", "file", "item", "display", "unplaced", "new", "hidden", "online")}
                for e in self._episodes(pl, progress={})]

    def rename(self, pid: str, name: str) -> dict:
        name = str(name or "").strip()[:MAX_NAME]
        if not name:
            raise PlaylistError("Give the playlist a name.")
        with self._lock:
            pl = self._get(pid)
            pl["name"] = name
            self._changed(pl)
            return self.summary(pl)

    def set_sort(self, pid: str, sort: str) -> dict:
        """Another order. "Manual" keeps the order as it is now; an automatic one sorts again (and the
        "new" marks go)."""
        if sort not in SORTS:
            raise PlaylistError("Pick one of the orders.")
        with self._lock:
            pl = self._get(pid)
            pl["sort"] = sort
            if sort != "manual":
                for e in pl["episodes"]:
                    e["new"] = False
                self._resort(pl)
            self._changed(pl)
            return self.summary(pl)

    def set_order(self, pid: str, keys: list) -> dict:
        """Your own order (manual from now on): these episodes first, as given; the rest after them."""
        if not isinstance(keys, list) or not all(isinstance(k, str) for k in keys):
            raise PlaylistError("Nothing to put in order.")
        with self._lock:
            pl = self._get(pid)
            by_key = {stream.stream_key(e["item"], e["file"]): e for e in pl["episodes"]}
            first, used = [], set()
            for k in keys:
                e = by_key.get(k)
                if e is not None and id(e) not in used:
                    used.add(id(e))
                    e["new"] = False
                    first.append(e)
            pl["episodes"] = first + [e for e in pl["episodes"] if id(e) not in used]
            pl["sort"] = "manual"
            self._changed(pl)
            return self.summary(pl)

    def set_hidden(self, pid: str, keys: list, hidden: bool) -> int:
        with self._lock:
            pl = self._get(pid)
            wanted = {str(k) for k in keys or []}
            n = 0
            for e in pl["episodes"]:
                if stream.stream_key(e["item"], e["file"]) in wanted and e["hidden"] != bool(hidden):
                    e["hidden"] = bool(hidden)
                    n += 1
            if n:
                self._changed(pl)
            return n

    def set_watched(self, pid: str, keys: list, watched: bool) -> int:
        with self._lock:
            pl = self._get(pid)
            mine = {stream.stream_key(e["item"], e["file"]) for e in pl["episodes"]}
        keys = [str(k) for k in keys or [] if str(k) in mine]
        if keys and self.store:
            self.store.set_watched(keys, stream.PLAYLIST_PREFIX + pid, bool(watched))
        return len(keys)

    def delete(self, pid: str) -> None:
        """Only the list goes: watch progress stays with the videos."""
        with self._lock:
            pl = self._get(pid)
            del self._lists[pid]
            self._shows.pop(pid, None)
            self._version[pid] = self._version.get(pid, 0) + 1
            try:
                self._save()
            except PlaylistError:
                self._lists[pid] = pl
                raise
            log.info("Series playlist deleted: %s", pl["name"])

    def refresh(self, pid: str) -> dict:
        """Read the items again: new files come in, gone ones are marked "No longer online"."""
        with self._lock:
            idents = [it["id"] for it in self._get(pid)["items"]]
        fresh, gone_items, errors = {}, set(), []
        for ident in idents:  # outside the lock: archive.org may take a while
            try:
                fresh[ident] = self._fetch(ident, fresh=True)
            except PlaylistError as exc:
                if exc.status == 404:
                    gone_items.add(ident)
                else:
                    errors.append(f"{ident}: {exc}")
        with self._lock:
            pl = self._get(pid)
            files = self._files(pl)
            before = {(e["item"], e["ep"]): self._online(files, e) for e in pl["episodes"]}
            series_before = {(it["id"], s["name"].casefold()) for it in pl["items"] for s in it["series"]}
            new = switched = 0
            for it in pl["items"]:
                if it["id"] in gone_items:
                    it["gone"] = True
                    it["checked"] = time.time()
                    for f in it["files"]:
                        f["online"] = False
                    continue
                rec = fresh.get(it["id"])
                if rec is None:
                    continue
                by_name = {f["name"]: f for f in rec["files"]}
                for f in it["files"]:
                    g = by_name.pop(f["name"], None)
                    if g is None:
                        f["online"] = False
                    else:
                        f.clear()
                        f.update(g)
                it["files"].extend(by_name.values())
                it.update(title=rec["title"], subs=rec["subs"], checked=time.time(), gone=False)
                a, s = self._sync_item(pl, it, mark_new=pl["sort"] == "manual")
                new, switched = new + a, switched + s
            self._resort(pl)
            files = self._files(pl)
            after = {(e["item"], e["ep"]): self._online(files, e) for e in pl["episodes"]}
            gone = sum(1 for k, v in before.items() if v and not after.get(k, False))
            back = sum(1 for k, v in before.items() if not v and after.get(k, False))
            new_series = sorted(s["name"] for it in pl["items"] for s in it["series"]
                                if (it["id"], s["name"].casefold()) not in series_before)
            self._changed(pl)
            log.info("Series playlist %s refreshed: %d new, %d no longer online, %d back, %d better files",
                     pl["name"], new, gone, back, switched)
            return {"new": new, "gone": gone, "back": back, "switched": switched, "newSeries": new_series,
                    "errors": errors, "playlist": self.summary(pl)}

    # -- views ----------------------------------------------------------------------------------------

    @staticmethod
    def _files(pl: dict) -> Dict[Tuple[str, str], dict]:
        """(item, file name) -> the file AniBox keeps for it."""
        return {(it["id"], f["name"]): f for it in pl["items"] for f in it["files"]}

    @staticmethod
    def _online(files: Dict[Tuple[str, str], dict], e: dict) -> bool:
        f = files.get((e["item"], e["file"]))
        return bool(f and f.get("online", True))

    def _episodes(self, pl: dict, progress: Dict[str, dict]) -> List[dict]:
        """Every episode for the window, in order (hidden ones too)."""
        displays = {(it["id"], s["name"].casefold()): s["display"] for it in pl["items"] for s in it["series"]}
        several = sum(1 for it in pl["items"] for s in it["series"] if s["on"]) > 1
        files = self._files(pl)
        out, nr = [], 0
        for e in pl["episodes"]:
            f = files.get((e["item"], e["file"])) or {"name": e["file"]}
            key = stream.stream_key(e["item"], e["file"])
            display = displays.get((e["item"], e["series"].casefold())) or e["series"]
            online = self._online(files, e)
            p = progress.get(key) or {}
            if not e["hidden"]:
                nr += 1
            d = air_date(e["file"])
            sxe = season_episode(e["file"])
            out.append({
                "key": key, "item": e["item"], "file": e["file"], "series": e["series"], "display": display,
                "label": episode_label(e["file"], display, pl["sort"], several),
                "date": d or "", "sxe": f"S{sxe[0]:02d}E{sxe[1]:02d}" if sxe else "",
                "nr": nr if not e["hidden"] else None, "added": e["added"], "hidden": e["hidden"], "new": e["new"],
                "online": online, "unplaced": unplaced(pl["sort"], e["file"]),
                "size": f.get("size"), "length": f.get("length"), "md5": f.get("md5") or "",
                "width": f.get("width"), "height": f.get("height"), "format": f.get("format") or "",
                "source": f.get("source") or "original",
                "position": float(p.get("position") or 0), "duration": float(p.get("duration") or 0),
                "watched": bool(p.get("watched")), "updated": float(p.get("updated") or 0),
            })
        return out

    def _counts(self, eps: List[dict]) -> dict:
        shown = [e for e in eps if not e["hidden"]]
        return {"episodes": len(shown), "watched": sum(1 for e in shown if e["watched"]),
                "hidden": len(eps) - len(shown), "gone": sum(1 for e in shown if not e["online"]),
                "new": sum(1 for e in shown if e["new"])}

    def summary(self, pl: dict, progress: Optional[Dict[str, dict]] = None) -> dict:
        if progress is None:
            progress = self.store.all_progress() if self.store else {}
        eps = self._episodes(pl, progress)
        first = pl["items"][0]["id"] if pl["items"] else ""
        show = self.show(stream.PLAYLIST_PREFIX + pl["id"])
        nxt, pos = next_up(show, progress) if show else (None, 0.0)
        return {"id": pl["id"], "show": stream.PLAYLIST_PREFIX + pl["id"], "name": pl["name"], "sort": pl["sort"],
                "sortLabel": SORT_LABELS[pl["sort"]], "img": "/ia/thumb/" + first if first else "",
                "items": [{"id": it["id"], "title": it["title"], "gone": it["gone"]} for it in pl["items"]],
                "changed": pl["changed"], "created": pl["created"],
                "lastPlayed": max((e["updated"] for e in eps), default=0.0),
                "next": {"key": nxt["key"], "label": nxt["label"], "position": pos} if nxt else None,
                **self._counts(eps)}

    def summaries(self) -> List[dict]:
        progress = self.store.all_progress() if self.store else {}
        with self._lock:
            out = [self.summary(pl, progress) for pl in self._lists.values()]
        out.sort(key=lambda s: (-max(s["lastPlayed"], s["created"]), s["name"].casefold()))
        return out

    def page(self, pid: str) -> dict:
        """One playlist for its page: the episodes with where you are in them."""
        progress = self.store.all_progress() if self.store else {}
        with self._lock:
            pl = self._get(pid)
            eps = self._episodes(pl, progress)
            show = self.show(stream.PLAYLIST_PREFIX + pid)
            playable = {e["key"] for e in (show or {}).get("episodes") or []}
            for e in eps:
                e["playable"] = e["key"] in playable
            out = self.summary(pl, progress)
            out["list"] = eps
            out["checked"] = max((it["checked"] for it in pl["items"]), default=0.0)
            out["sorts"] = [{"id": s, "label": SORT_LABELS[s]} for s in SORTS]
            return out

    def editor(self, pid: str) -> dict:
        """A playlist's items and all their series (ticked or not), from AniBox's own copy."""
        with self._lock:
            pl = self._get(pid)
            items = []
            for it in pl["items"]:
                counts = {s["name"].casefold(): s for s in series_of(it, include_gone=True)}
                series = []
                for s in sorted(it["series"], key=lambda s: (not s["on"], s["order"], -counts.get(s["name"].casefold(), {}).get("count", 0))):
                    c = counts.get(s["name"].casefold()) or {}
                    series.append({"name": s["name"], "display": s["display"], "on": s["on"], "count": c.get("count", 0),
                                   "first": c.get("first"), "last": c.get("last"), "sample": c.get("sample") or ""})
                for fold, c in counts.items():
                    if not any(s["name"].casefold() == fold for s in it["series"]):
                        series.append({**c, "display": c["name"], "on": False})
                items.append({"id": it["id"], "title": it["title"], "gone": it["gone"], "videos": len(it["files"]),
                              "series": series, "known": True})
            return {"id": pl["id"], "name": pl["name"], "sort": pl["sort"], "items": items}

    def playlists_with(self, ident: str) -> List[dict]:
        with self._lock:
            return [{"id": pl["id"], "name": pl["name"]} for pl in self._lists.values()
                    if any(it["id"] == ident for it in pl["items"])]

    # -- the provider for stream.IaStreams ------------------------------------------------------------

    def owns(self, show_id: str) -> bool:
        return isinstance(show_id, str) and show_id.startswith(stream.PLAYLIST_PREFIX) and \
            show_id[len(stream.PLAYLIST_PREFIX):] in self._lists

    def show(self, show_id: str) -> Optional[dict]:
        """The playlist as a show: its episodes that can play, in order (hidden ones left out). None when
        there's nothing to play."""
        pid = show_id[len(stream.PLAYLIST_PREFIX):] if isinstance(show_id, str) else ""
        with self._lock:
            pl = self._lists.get(pid)
            if not pl:
                return None
            ver = self._version.get(pid, 0)
            hit = self._shows.get(pid)
            if hit and hit[0] == ver and time.monotonic() - hit[1] < SHOW_TTL:
                return hit[2]
            displays = {(it["id"], s["name"].casefold()): s["display"] for it in pl["items"] for s in it["series"]}
            several = sum(1 for it in pl["items"] for s in it["series"] if s["on"]) > 1
            files = self._files(pl)
            eps = []
            for e in pl["episodes"]:
                if e["hidden"]:
                    continue
                f = files.get((e["item"], e["file"])) or {"name": e["file"]}
                video = {k: v for k, v in f.items() if k != "online"}
                display = displays.get((e["item"], e["series"].casefold())) or e["series"]
                ep = self.streams.episode_dict(e["item"], video, episode_label(e["file"], display, pl["sort"], several))
                if not self._online(files, e) and not self.streams.is_local(e["item"], e["file"]):
                    continue  # no longer on archive.org, and not on this PC either
                ep["number"] = len(eps) + 1
                ep["series"] = display
                eps.append(ep)
            first = pl["items"][0]["id"] if pl["items"] else ""
            show = {"id": stream.PLAYLIST_PREFIX + pid, "library": stream.LIBRARY, "folder": pl["name"],
                    "title": pl["name"], "stream": True, "item": first, "art": "/ia/thumb/" + first if first else "",
                    "mal_id": None, "picture": "", "playlist": pid, "episodes": eps} if eps else None
            self._shows[pid] = (ver, time.monotonic(), show)
            return show

    def prepare(self, show_id: str) -> None:
        """Before playing: make sure stream.IaStreams knows every file of the playlist (from AniBox's
        own copy, so archive.org isn't asked again, and a file that's gone but kept by the cache plays)."""
        pid = show_id[len(stream.PLAYLIST_PREFIX):]
        with self._lock:
            pl = self._lists.get(pid)
            if not pl:
                return
            wanted = {}
            for e in pl["episodes"]:
                wanted.setdefault(e["item"], set()).add(e["file"])
            items = [copy.deepcopy(it) for it in pl["items"] if it["id"] in wanted]
        for it in items:
            entry = self.streams.known(it["id"])
            have = {v["name"] for v in (entry or {}).get("videos") or []}
            if wanted[it["id"]] <= have:
                continue
            files = [{**{k: v for k, v in f.items() if k != "online"}, "kind": "video"} for f in it["files"]]
            subs = [{"name": s, "kind": "subtitle"} for s in it["subs"]]
            if entry:  # keep what the item page knows that the playlist doesn't
                names = {f["name"] for f in files}
                files += [{**v, "kind": "video"} for v in entry["videos"] if v["name"] not in names]
                subs += [{"name": s, "kind": "subtitle"} for s in entry.get("subs") or [] if s not in it["subs"]]
            self.streams.remember({"id": it["id"], "title": (entry or {}).get("title") or it["title"], "files": files + subs})
