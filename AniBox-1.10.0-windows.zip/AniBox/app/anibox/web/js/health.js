/* AniBox window · Check my library (health check + move plan) and the History of changes (routes_health.py).
   The health check and the move plan only read; every undo asks first.
   Plain scripts sharing one page: loaded in order by index.html. */
"use strict";

libraryLinks.push({ href: "#/health", label: "Check my library" });
libraryLinks.push({ href: "#/history", label: "History" });
settingsPanels.push(function (box) {
  if (box.previousElementSibling) box.style.marginTop = "18px";
  box.innerHTML = '<section class="panel"><h2>History of changes</h2><p class="muted">Everything AniBox changed, newest first: videos it added, moved or renamed, info files, Tidy up, updates and matches by hand. Undo where it\'s possible.</p>' +
    '<div class="row"><a class="btn small" href="#/history">Show the history</a><a class="btn small" href="#/health">Check my library</a></div></section>';
});
pageRoutes["health"] = function (parts) { setTab("library"); healthPage(parts[0] === "move" ? "move" : "check"); };
pageRoutes["history"] = function () { setTab("library"); historyPage(); };

// ---------- small helpers
function hcSave(url) {  // the server sends the file's text; the window saves it
  api(url).then(function (r) {
    var a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([r.data], { type: r.mime }));
    a.download = r.name; document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
  }).catch(fail);
}
function hcStat(n, label) { return '<div class="stat"><b>' + (n == null ? "?" : Number(n).toLocaleString()) + "</b>" + esc(label) + "</div>"; }
function hcShow(x) { return '<a href="#/show/' + encodeURIComponent(x.show) + '">' + esc(x.title) + '</a><div class="muted" style="font-size:12px">' + esc(x.library + "\\" + x.folder) + "</div>"; }
function hcOpen(show, key) {
  return '<button class="btn small" data-reveal="' + esc(show) + '"' + (key ? ' data-key="' + esc(key) + '" title="Show the file in File Explorer">Show file' : ' title="Open the folder in File Explorer">Open folder') + "</button>";
}
function hcFiles(files, max) {
  max = max || 8;
  return files.slice(0, max).map(function (f) { return '<div style="overflow-wrap:anywhere">' + esc(f) + "</div>"; }).join("") +
    (files.length > max ? '<div class="muted">… and ' + (files.length - max) + " more</div>" : "");
}
function hcWireReveal() {
  view.querySelectorAll("[data-reveal]").forEach(function (b) {
    b.onclick = function () { post("/api/reveal", { show: b.getAttribute("data-reveal"), key: b.getAttribute("data-key") || "" }).catch(fail); };
  });
}

// ---------- Health check page
var hcData = null, hcTab = "check", hcLib = "";
function healthPage(tab) {
  hcTab = tab; clearTimeout(healthPage.t);
  if (tab === "move") return movePlanPage();
  render(hcHead() + '<div class="empty">Loading …</div>');
  api("/api/health").then(function (d) { hcData = d; if (currentPage === "health" && hcTab === "check") hcDraw(); })
    .catch(function (e) { render(hcHead() + '<div class="empty">' + esc(e.message) + "</div>"); });
}
function hcHead() {
  return '<div class="section" style="margin-top:0"><div><div class="kicker">Check my library</div><h1 style="margin-top:6px">' + (hcTab === "move" ? "Move plan" : "Health check") +
    '</h1></div><a class="btn small" href="#/library">Back to the library</a></div>' +
    '<div class="row" style="margin:4px 0 18px"><div class="seg" role="tablist"><button role="tab" data-hctab="check"' + (hcTab === "check" ? ' class="on"' : "") + ">Health check</button>" +
    '<button role="tab" data-hctab="move"' + (hcTab === "move" ? ' class="on"' : "") + ">Move plan</button></div></div>";
}
function hcWireTabs() {
  view.querySelectorAll("[data-hctab]").forEach(function (b) {
    b.onclick = function () { location.hash = b.getAttribute("data-hctab") === "move" ? "#/health/move" : "#/health"; };
  });
}
function hcProgress(job) {
  var pct = job.total ? Math.round(100 * job.done / job.total) : 0;
  return '<div id="hcProg"><p style="color:var(--acc);margin:14px 0 0">' + esc(job.phase || "Working …") +
    (job.total ? " " + Number(job.done || 0).toLocaleString() + " of " + Number(job.total).toLocaleString() + " files" : "") + "</p>" +
    (job.total ? '<div class="progress"><i style="width:' + pct + '%"></i></div>' : "") + "</div>";
}
function hcDraw() {
  var d = hcData, job = d.job || {}, running = job.state === "running", r = d.result;
  var html = hcHead() +
    '<p class="muted" style="max-width:860px">AniBox looks through its list of your files (from the last scan) for the same episode twice, missing episodes and odd names, and if you like it also reads the start of every file to find empty or broken ones. It only reads: nothing on your drives changes.</p>' +
    '<section class="panel"><label class="check"><input type="checkbox" id="hcFiles"' + (running && job.files ? " checked" : "") + (running ? " disabled" : "") +
    '> Check the files too <span class="muted">(reads the start of every file; takes a while on the Shield)</span></label>' +
    '<div class="row" style="margin-top:14px"><button class="btn primary" id="hcGo"' + (running ? " disabled" : "") + ">" + (r ? "Check again" : "Check now") + "</button>" +
    (running ? '<button class="btn" id="hcStop">Stop</button>' : "") +
    (r && !running ? '<button class="btn small" id="hcHtml">Save as web page</button><button class="btn small" id="hcCsv" title="Opens in Excel; columns are split with semicolons">Save as spreadsheet</button>' : "") + "</div>" +
    (running ? hcProgress(job) : "") + (job.state === "error" ? '<div class="note">' + esc(job.message) + "</div>" : "") + "</section>";
  if (r) html += hcResult(r, d);
  render(html);
  hcWireTabs(); hcWireReveal();
  $("hcGo").onclick = function () {
    post("/api/health/start", { files: $("hcFiles").checked }).then(function (x) { hcData.job = x.job; hcDraw(); }).catch(fail);
  };
  if ($("hcStop")) $("hcStop").onclick = function () { post("/api/health/stop").then(function () { toast("Stopping …"); }).catch(fail); };
  if ($("hcHtml")) $("hcHtml").onclick = function () { hcSave("/api/health/export?format=html"); };
  if ($("hcCsv")) $("hcCsv").onclick = function () { hcSave("/api/health/export?format=csv"); };
  if ($("hcLib")) $("hcLib").onchange = function () { hcLib = this.value; hcFilter(); };
  hcFilter();
  if (running) hcPoll();
}
function hcPoll() {
  healthPage.t = setTimeout(function () {
    if (currentPage !== "health" || hcTab !== "check") return;
    api("/api/health?job=1").then(function (j) {
      if (currentPage !== "health" || hcTab !== "check") return;
      if (j.job.state === "running") {
        hcData.job = j.job; var p = $("hcProg"); if (p) p.outerHTML = hcProgress(j.job);
        hcPoll(); return;
      }
      return api("/api/health").then(function (d) {
        hcData = d;
        if (d.job.state === "done") toast(d.result && d.result.filesStopped ? "Stopped. The files read so far are in the list." : "Done.");
        if (currentPage === "health" && hcTab === "check") hcDraw();
      });
    }).catch(function () { hcPoll(); });
  }, 1000);
}
function hcFilter() {
  view.querySelectorAll("[data-libs]").forEach(function (row) {
    row.hidden = !!hcLib && row.getAttribute("data-libs").split("\n").indexOf(hcLib) < 0;
  });
}

function hcGroup(name, count, explain, body, open) {
  return '<details class="fr"' + (open ? " open" : "") + '><summary><span class="name">' + esc(name) + '</span><span class="muted">' + count + "</span></summary>" +
    '<p class="muted" style="margin:0 18px 10px;max-width:860px">' + explain + "</p>" + body + "</details>";
}
function hcTable(head, rows) {
  if (!rows.length) return '<p class="muted" style="margin:0 18px 14px">Nothing found.</p>';
  return '<div class="tw"><table><thead><tr>' + head.map(function (h) { return "<th>" + esc(h) + "</th>"; }).join("") + "</tr></thead><tbody>" + rows.join("") + "</tbody></table></div>";
}
function hcRow(libs, cells) {
  return '<tr data-libs="' + esc(libs.join("\n")) + '">' + cells.map(function (c) { return "<td>" + c + "</td>"; }).join("") + "</tr>";
}
function hcResult(r, d) {
  var c = r.counts, g = r.groups;
  var stale = d.scannedAt && r.scannedAt && d.scannedAt > r.scannedAt + 1;
  var html = '<p class="muted" style="margin:18px 0 0">Checked ' + esc(ago(r.checked)) + ": " + plural(r.shows, "show folder") + " in " + r.libraries.map(esc).join(", ") + "." +
    (r.filesChecked ? " Files read: " + Number(r.filesRead).toLocaleString() + " of " + Number(r.filesTotal).toLocaleString() + (r.filesStopped ? " (stopped)" : "") + "." : "") +
    (stale ? " <b>Your library was scanned again since; check again to include the changes.</b>" : "") + "</p>" +
    '<div class="stats" style="margin-top:14px">' + hcStat(c.dupes, "folders with an episode twice") + hcStat(c.twice, "shows in two folders") + hcStat(c.gaps, "folders with missing episodes") +
    (r.filesChecked ? hcStat(c.broken, "empty or broken files") : "") + hcStat(c.odd, "odd names") + (r.unrecognized != null ? hcStat(r.unrecognized, "folders not recognized") : "") + "</div>" +
    '<div class="row" style="margin:18px 0 6px"><label class="muted">Show <select class="input" id="hcLib"><option value="">all libraries</option>' +
    r.libraries.map(function (l) { return "<option" + (l === hcLib ? " selected" : "") + ">" + esc(l) + "</option>"; }).join("") + "</select></label></div>";

  html += hcGroup("Same episode twice", c.dupes,
    "Two or more files with the same episode number in one folder, usually another version or language. Both show up in AniBox as the same episode.",
    hcTable(["Show", "Episode", "Files", ""], g.dupes.map(function (x) {
      return hcRow([x.library], [hcShow(x), x.episodes.map(function (e) { return esc(e.label); }).join("<br>"),
        x.episodes.map(function (e) { return hcFiles(e.files); }).join('<div style="height:6px"></div>'), hcOpen(x.show)]);
    })), c.dupes > 0 && c.dupes < 20);

  html += hcGroup("Same show in two folders", c.twice + (c.twiceLanguage ? " · " + c.twiceLanguage + " in another language" : ""),
    "The same MyAnimeList entry in more than one folder, e.g. one in <b>Anime2</b> and one in <b>Anime</b>: which episodes are in both, and which only in one. The <a href=\"#/health/move\">Move plan</a> shows how they would come together.",
    hcTable(["Show", "Folders", "In more than one", ""], g.twice.map(function (t) {
      return hcRow(t.folders.map(function (f) { return f.library; }), [
        esc(t.title) + (t.mal_id ? ' <a class="muted" href="https://myanimelist.net/anime/' + esc(t.mal_id) + '" target="_blank" rel="noopener noreferrer">MAL ↗</a>' : "") +
          '<div class="muted" style="font-size:12px">' + esc(t.note) + "</div>",
        t.folders.map(function (f) {
          return '<div style="margin-bottom:6px"><a href="#/show/' + encodeURIComponent(f.show) + '">' + esc(f.library + "\\" + f.folder) + '</a> <span class="muted">· ' + plural(f.files, "file") +
            (f.only ? " · only here: " + esc(f.only) : "") + "</span></div>";
        }).join(""),
        esc(t.both || "none"),
        t.folders.map(function (f) { return hcOpen(f.show); }).join(" ")]);
    })), c.twice > 0 && c.twice < 20);

  html += hcGroup("Missing episodes", c.gaps,
    "Episode numbers missing in a folder, e.g. 1–5 and 7–12 but no 6. Where MyAnimeList knows how many episodes a show has, missing ones at the start, and for finished shows at the end, count too; shows that are still airing aren't counted at the end.",
    hcTable(["Show", "Missing", "Note", ""], g.gaps.map(function (x) {
      return hcRow([x.library], [hcShow(x), esc(x.missing), '<span class="muted">' + esc(x.note) + "</span>", hcOpen(x.show)]);
    })), false);

  html += hcGroup("Empty or broken files", r.filesChecked ? c.broken : "not checked",
    r.filesChecked ? "Files that are empty (0 bytes), much smaller than the other episodes, don't start like a video file, or can't be read. Try playing one; if it doesn't work, download or copy it again." :
      "Not checked this time. Tick <b>Check the files too</b> and check again: AniBox then reads the start of every file (only reads).",
    r.filesChecked ? hcTable(["Show", "File", "Problem", ""], g.broken.map(function (x) {
      return hcRow([x.library], [hcShow(x), '<span style="overflow-wrap:anywhere">' + esc(x.file) + "</span>", esc(x.problem), hcOpen(x.show, x.key)]);
    })) : "", r.filesChecked && c.broken > 0 && c.broken < 20);

  html += hcGroup("Odd names", c.odd,
    "Files without an episode number among numbered ones, numbers that don't fit the show, and names that still look like downloads ([Group], 1080p). AniBox never renames anything here.",
    hcTable(["Show", "What", "Files", "Note", ""], g.odd.map(function (x) {
      return hcRow([x.library], [hcShow(x), esc(x.label), hcFiles(x.files), '<span class="muted">' + esc(x.note) + "</span>", hcOpen(x.show)]);
    })), false);

  if (r.unrecognized != null) html += hcGroup("Not recognized", r.unrecognized,
    "Folders that no MyAnimeList entry fits. They're listed on the <a href=\"#/missing\">Missing page</a>, where you can match them by hand or hide them.", "", false);
  html += '<p class="muted" style="margin-top:24px">Read-only: nothing on your drives was changed.</p>';
  return html;
}

// ---------- Move plan (prepare only: there is no button that moves anything)
var mpChoice = { from: "", to: "" };
function movePlanPage() {
  var q = mpChoice.from && mpChoice.to ? "?from=" + encodeURIComponent(mpChoice.from) + "&to=" + encodeURIComponent(mpChoice.to) : "";
  render(hcHead() + '<div class="empty">Making the list …</div>');
  hcWireTabs();
  api("/api/health/moveplan" + q).then(function (p) {
    if (currentPage !== "health" || hcTab !== "move") return;
    mpChoice = { from: p.from, to: p.to };
    mpDraw(p);
  }).catch(function (e) { render(hcHead() + '<div class="empty">' + esc(e.message) + "</div>"); hcWireTabs(); });
}
function mpShort(path, p) {  // a path under the target library folder as "Anime\Show\file"
  var root = p.targetDir || "";
  return root && path.indexOf(root) === 0 ? p.to + path.slice(root.length) : path;
}
function mpDraw(p) {
  var opts = function (sel) { return p.libraries.map(function (l) { return "<option" + (l === sel ? " selected" : "") + ">" + esc(l) + "</option>"; }).join(""); };
  var t = p.totals, ok = !p.error && p.shows.length;
  var html = hcHead() +
    '<p class="muted" style="max-width:860px">Where the files of one library folder would go in another, e.g. <b>Anime2 → Anime</b>: into the show\'s folder there if it already has one, named like the files there; otherwise into a new folder with the same name. This only makes the list. Nothing is moved, and there\'s no button here that moves anything.</p>' +
    '<div class="note"><b>Before anything is moved</b><ul style="margin:8px 0 0;padding-left:20px">' + p.conditions.map(function (c) { return "<li>" + esc(c) + "</li>"; }).join("") + "</ul></div>" +
    '<section class="panel" style="margin-top:14px"><div class="row"><label class="muted">From <select class="input" id="mpFrom">' + opts(p.from) + '</select></label><label class="muted">into <select class="input" id="mpTo">' + opts(p.to) + "</select></label>" +
    '<button class="btn small" id="mpGo">Make the list</button>' +
    p.pairs.filter(function (x) { return x[0] !== p.from || x[1] !== p.to; }).map(function (x) {
      return '<button class="btn small" data-pair="' + esc(x[0]) + '" data-to="' + esc(x[1]) + '">' + esc(x[0] + " → " + x[1]) + "</button>"; }).join("") +
    (ok ? '<button class="btn small" id="mpHtml">Save as web page</button><button class="btn small" id="mpCsv" title="Opens in Excel; columns are split with semicolons">Save as spreadsheet</button>' : "") + "</div>" +
    (p.error ? '<div class="note">' + esc(p.error) + "</div>" : "") + "</section>";
  if (ok) {
    html += '<div class="stats" style="margin-top:14px">' + hcStat(t.shows, "shows") + hcStat(t.files, "files") + hcStat(t.merged, "into a folder that's there") + hcStat(t.newFolders, "new folders") +
      hcStat(t.renamed, "renamed") + hcStat(t.conflicts, "problems") + hcStat(t.locked, "locked shows") + hcStat(t.otherDrive, "on another drive") + "</div>" +
      '<p class="muted" style="margin:14px 0">Into <b>' + esc(p.targetDir) + "</b>. Subtitle and info files next to a video, and extras folders (Featurettes …), would move along; they aren't listed.</p>";
    html += p.shows.map(function (sh) {
      var pills = '<span class="pill ' + (sh.merge ? "owned" : "upcoming") + '">' + (sh.merge ? "into " + esc(sh.into) : "new folder") + "</span>" +
        (sh.conflicts ? ' <span class="pill missing">' + plural(sh.conflicts, "problem") + "</span>" : "") +
        (sh.locked ? ' <span class="pill partial">locked</span>' : "") + (sh.otherDrive ? ' <span class="pill unsure">another drive</span>' : "");
      return '<details class="fr"' + (sh.conflicts ? " open" : "") + '><summary><span><span class="name">' + esc(sh.folder) + "</span> " + pills + '</span><span class="muted">' + plural(sh.files.length, "file") + (sh.renamed ? " · " + sh.renamed + " renamed" : "") + "</span></summary>" +
        '<div style="margin:0 18px">' + sh.flags.map(function (f) { return '<div class="note">' + esc(f) + "</div>"; }).join("") +
        '<p class="muted" style="margin:6px 0">' + esc(sh.fromDir) + " → " + esc(sh.toDir) + (sh.merge ? "" : " · names like “" + esc(sh.pattern) + "”") +
        ' <a href="#/show/' + encodeURIComponent(sh.show) + '">Open the show</a> ' + hcOpen(sh.show) + "</p></div>" +
        hcTable(["Now", "", "Would go to", ""], sh.files.map(function (f) {
          return "<tr><td title=\"" + esc(f.from) + '" style="overflow-wrap:anywhere">' + esc(f.file) + '</td><td class="muted">→</td><td title="' + esc(f.to) + '" style="overflow-wrap:anywhere">' + esc(mpShort(f.to, p)) +
            (f.rename ? ' <span class="muted">(renamed)</span>' : "") + "</td><td>" + (f.conflict ? '<span style="color:var(--red)">' + esc(f.conflict) + "</span>" : "") + "</td></tr>";
        })) + "</details>";
    }).join("");
  }
  render(html);
  hcWireTabs(); hcWireReveal();
  $("mpGo").onclick = function () { mpChoice = { from: $("mpFrom").value, to: $("mpTo").value }; movePlanPage(); };
  view.querySelectorAll("[data-pair]").forEach(function (b) {
    b.onclick = function () { mpChoice = { from: b.getAttribute("data-pair"), to: b.getAttribute("data-to") }; movePlanPage(); };
  });
  var q = "&from=" + encodeURIComponent(p.from) + "&to=" + encodeURIComponent(p.to);
  if ($("mpHtml")) $("mpHtml").onclick = function () { hcSave("/api/health/export?what=plan&format=html" + q); };
  if ($("mpCsv")) $("mpCsv").onclick = function () { hcSave("/api/health/export?what=plan&format=csv" + q); };
}

// ---------- History of changes
var HIST_KIND = { files: "Files", nfo: "Info files", tidy: "Tidy up", update: "Update", match: "MyAnimeList match" };
function historyPage() {
  render('<div class="empty">Loading the history …</div>');
  api("/api/history").then(function (d) { if (currentPage === "history") histDraw(d); })
    .catch(function (e) { render('<div class="empty">' + esc(e.message) + "</div>"); });
}
function histDraw(d) {
  var html = '<div class="section" style="margin-top:0"><div><div class="kicker">History</div><h1 style="margin-top:6px">Everything AniBox changed</h1></div><a class="btn small" href="#/library">Back to the library</a></div>' +
    '<p class="muted" style="max-width:860px">Newest first. <b>Undo</b> puts moved files back and removes copies AniBox made (the originals stay); for info files it removes what AniBox wrote. AniBox always asks first, and only undoes an older change if nothing that came later touched the same files.</p>' +
    (d.busy ? '<div class="note">AniBox is moving files right now. Undo works again once that\'s done.</div>' : "");
  if (!d.items.length) html += '<section class="panel"><h2>Nothing yet</h2><p class="muted">When AniBox adds, moves or renames videos, writes info files, tidies up, updates itself or you match a folder by hand, it shows up here.</p></section>';
  html += d.items.map(histRow).join("");
  render(html);
  view.querySelectorAll("[data-undo]").forEach(function (b) { b.onclick = function () { histUndo(b.getAttribute("data-undo"), b.getAttribute("data-title")); }; });
}
function histRow(it) {
  var when = new Date((it.time || 0) * 1000);
  var right = it.undo && it.undo.can && !it.undone ? '<button class="btn small" data-undo="' + esc(it.id) + '" data-title="' + esc(it.title) + '">Undo</button>' :
    (it.undo && it.undo.why ? '<div class="muted" style="font-size:13px;max-width:260px;text-align:right">' + esc(it.undo.why) + "</div>" : "");
  var ex = it.examples || [];
  var files = ex.length ? '<details style="margin-top:8px"><summary class="muted" style="cursor:pointer">' + (it.count > 1 ? "Show the files" : "Show the file") + "</summary>" +
    '<div class="tw" style="padding:6px 0 0"><table><tbody>' + ex.map(function (e) {
      return "<tr>" + (e.from ? '<td style="overflow-wrap:anywhere">' + esc(e.from) + '</td><td class="muted">→</td>' : "") + '<td style="overflow-wrap:anywhere">' + esc(e.to || "") + "</td></tr>";
    }).join("") + "</tbody></table>" + (it.count > ex.length ? '<p class="muted">… and ' + (it.count - ex.length) + " more</p>" : "") + "</div></details>" : "";
  return '<section class="panel" style="margin:10px 0;padding:16px 20px"><div class="row" style="justify-content:space-between;align-items:flex-start;flex-wrap:nowrap">' +
    '<div style="min-width:0;flex:1"><div class="kicker">' + esc(HIST_KIND[it.kind] || it.kind) + " · " + esc(when.toLocaleString()) + ' <span class="muted" style="text-transform:none;letter-spacing:0">(' + esc(ago(it.time)) + ")</span></div>" +
    '<h3 style="margin:4px 0">' + esc(it.title) + (it.undone ? ' <span class="pill upcoming">undone ' + esc(ago(it.undone)) + "</span>" : "") + "</h3>" +
    '<div class="muted">' + esc(it.detail) + (it.show ? ' <a href="#/show/' + encodeURIComponent(it.show) + '">Open the show</a>' : "") + "</div>" +
    (it.note ? '<div class="muted" style="font-size:13px">' + esc(it.note) + "</div>" : "") + files + "</div>" + right + "</div></section>";
}
function histUndo(id, title) {
  post("/api/history/undo", { id: id, check: true }).then(function (c) {
    var probs = c.problems || [];
    var list = probs.length ? '<div class="tw" style="max-height:30vh;overflow:auto"><table><tbody>' + probs.map(function (p) {
      return '<tr><td style="overflow-wrap:anywhere">' + esc(p.file) + '</td><td class="muted">' + esc(p.error) + "</td></tr>"; }).join("") + "</tbody></table></div>" : "";
    if (c.kind === "files" && !c.possible) {
      openModal('<div class="kicker">Can\'t undo</div><h2>' + esc(title) + "</h2><p>" + plural(probs.length, "file") + " of this change changed since, so AniBox leaves the whole change as it is:</p>" + list +
        '<div class="row" style="margin-top:16px;justify-content:flex-end"><button class="btn" data-close>OK</button></div>');
      return;
    }
    var ask = c.kind === "nfo" ? "Remove the " + plural(c.files, "info file") + " AniBox wrote since the last undo? Files you changed since stay as they are." :
      "Put the " + plural(c.files, "file") + " of this change back where they were? Copies AniBox made are removed; the originals stay.";
    openModal('<div class="kicker">Undo</div><h2>' + esc(title) + "</h2><p>" + esc(ask) + "</p>" +
      (probs.length ? '<div class="note">' + plural(probs.length, "file") + " can't be put back (they changed since); the others are.</div>" + list : "") +
      '<div class="row" style="margin-top:16px;justify-content:flex-end"><button class="btn" data-close>Cancel</button><button class="btn primary" id="histYes">Yes, undo</button></div>');
    $("histYes").onclick = function () {
      closeModal();
      post("/api/history/undo", { id: id }).then(function (r) {
        if (c.kind === "nfo") toast("Removed " + (r.removed || 0) + ", put back " + (r.restored || 0) + (r.kept ? ", kept " + r.kept + " you had changed" : "") + ".");
        else toast(plural(r.undone || 0, "file") + " back" + (r.problems && r.problems.length ? "; " + r.problems.length + " couldn't be put back" : "") + ".", r.problems && r.problems.length);
        historyPage();
      }).catch(fail);
    };
  }).catch(fail);
}
