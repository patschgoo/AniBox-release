/* AniBox window · The Internet Archive cache (iacache.py): a small state badge and a Keep button on every
   streamed video, and the cache's panel in Settings.
   Pages mark a video's row with data-ia-key="ia:<item>/<file>" (optional: data-ia-title="<show title>" for
   the kept file's name, data-ia-cache on the element that should hold the badge) and call
   iaCacheDecorate(listElement[, {title: "…"}]) after drawing it. The Play buttons of an item page
   (data-ia-play) are decorated too.
   Plain scripts sharing one page: loaded in order by index.html. */
"use strict";

(function () {
  var css =
    // doubled classes: stronger than a page's own "row span" rules
    ".iac.iac { display: inline-flex; flex: 0 0 auto; align-items: center; gap: 6px; margin-left: 10px; vertical-align: middle; flex-wrap: wrap; font-family: var(--body); overflow: visible; }" +
    ".iac.iac:empty { display: none; }" +
    ".iac .iac-b { flex: 0 0 auto; overflow: visible; font-family: var(--body); }" +
    ".iac-b { font-size: 11px; font-weight: 700; letter-spacing: .03em; line-height: 18px; border-radius: 999px; padding: 1px 9px; border: 1px solid var(--line2); background: var(--s2); color: var(--soft); white-space: nowrap; }" +
    ".iac-b.st-loading, .iac-b.st-waiting, .iac-b.st-verifying, .iac-b.st-partial { color: var(--acc); border-color: rgba(127,211,255,.35); }" +
    ".iac-b.st-preloaded { color: var(--green); border-color: rgba(94,224,160,.4); }" +
    ".iac-b.st-loaded { color: var(--text); }" +
    ".iac-b.st-kept, .iac-b.st-keeping, .iac-b.st-moving { color: var(--violet); border-color: rgba(195,180,255,.45); }" +
    ".iac-b.st-paused, .iac-b.st-offline { color: var(--orange); border-color: rgba(255,122,47,.45); }" +
    ".iac-b.st-broken { color: var(--red); border-color: rgba(255,107,107,.5); }" +
    ".iac-b.st-gone { color: var(--muted); }" +
    ".iac .btn.small { height: 26px; padding: 0 9px; font-size: 12px; border-radius: 8px; }" +
    ".iac .iac-keep.on { border-color: var(--violet); color: var(--violet); }" +
    ".iac-use { display: flex; flex-wrap: wrap; gap: 4px 14px; margin-top: 2px; }" +
    ".iac-now { margin-top: 6px; }" +
    ".iac-now div { display: flex; gap: 10px; justify-content: space-between; padding: 6px 0; border-top: 1px solid var(--line); font-size: 13px; }" +
    ".iac-now div span:first-child { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }" +
    ".iac-dir { margin-top: 6px; display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }" +
    ".iac-dir .input { flex: 1; min-width: 220px; }";
  var st = document.createElement("style");
  st.id = "iacStyle"; st.textContent = css;
  document.head.appendChild(st);
})();

var iac = { timer: 0, keepDir: "", panelTimer: 0, info: null };
var IAC_LIVE = { loading: 1, waiting: 1, offline: 1, verifying: 1, keeping: 1, moving: 1 };
var IAC_ACT = { retry: "Try again", restart: "Start over", reload: "Reload" };

function iacBytes(b) {
  if (b == null) return "?";
  if (b >= 1073741824) return (b / 1073741824).toFixed(b >= 10737418240 ? 0 : 1) + " GB";
  if (b >= 1048576) return Math.round(b / 1048576) + " MB";
  return Math.max(0, Math.round(b / 1024)) + " KB";
}

// ---------- badges and Keep buttons on episode rows
function iacSlot(host, key, after, title) {
  if (!host) return null;
  var el = null;
  Array.prototype.forEach.call(host.querySelectorAll(".iac"), function (x) { if (x.getAttribute("data-iac-key") === key) el = x; });
  if (!el) {
    el = document.createElement("span");
    el.className = "iac";
    el.setAttribute("data-iac-key", key);
    if (after && after.parentNode === host) host.insertBefore(el, after.nextSibling); else host.appendChild(el);
  }
  if (title) el.setAttribute("data-iac-title", title);
  return el;
}
function iacSlots(list, opts) {
  var out = [], title = (opts && opts.title) || "";
  if (!list || !list.querySelectorAll) return out;
  var rows = Array.prototype.slice.call(list.querySelectorAll("[data-ia-key]"));
  if (list.matches && list.matches("[data-ia-key]")) rows.unshift(list);
  rows.forEach(function (row) {
    var key = row.getAttribute("data-ia-key"); if (!key) return;
    var host = row.querySelector("[data-ia-cache]") || (row.tagName === "TR" ? row.lastElementChild : row);
    out.push(iacSlot(host, key, null, row.getAttribute("data-ia-title") || title));
  });
  if (typeof ia !== "undefined" && ia.item) {  // an item page: next to each Play button (stream.js)
    Array.prototype.forEach.call(list.querySelectorAll("[data-ia-play]"), function (b) {
      if (b.closest("[data-ia-key]")) return;
      out.push(iacSlot(b.parentNode, "ia:" + ia.item.id + "/" + b.getAttribute("data-ia-play"), b, title));
    });
  }
  return out.filter(Boolean);
}
// Called by the pages after they draw a list of Internet Archive videos.
window.iaCacheDecorate = function (list, opts) {
  var slots = iacSlots(list, opts);
  if (slots.length) iacRefresh(slots);
};
function iacAll() { return Array.prototype.slice.call(document.querySelectorAll(".iac[data-iac-key]")); }
function iacRefresh(slots) {
  var keys = {};
  slots.forEach(function (s) { keys[s.getAttribute("data-iac-key")] = 1; });
  return post("/api/iacache/states", { keys: Object.keys(keys) }).then(function (r) {
    iac.keepDir = r.keepDir || iac.keepDir;
    slots.forEach(function (s) { if (s.isConnected) iacDraw(s, r.states[s.getAttribute("data-iac-key")] || { state: "none" }); });
    iacSchedule();
  }).catch(function () { iacSchedule(); });
}
function iacSchedule() {
  clearTimeout(iac.timer);
  var slots = iacAll();
  if (!slots.length) return;
  var playing = state && state.player && state.player.active && state.player.stream;
  var live = playing || slots.some(function (s) { return IAC_LIVE[s.getAttribute("data-iac-state")]; });
  iac.timer = setTimeout(function () {
    if (document.hidden) return iacSchedule();
    iacRefresh(iacAll());
  }, live ? 2000 : 15000);
}
function iacDraw(el, s) {
  el.setAttribute("data-iac-state", s.state);
  var tip = s.message || (s.state === "preloaded" ? "Loaded ahead, plays straight from this PC" :
    s.state === "loaded" ? "Loaded into the cache on this PC" : s.state === "loading" && s.speed ? iacBytes(s.speed) + "/s" : "");
  var html = s.label ? '<span class="iac-b st-' + esc(s.state) + '" title="' + esc(tip) + '">' + esc(s.label) + "</span>" : "";
  (s.actions || []).forEach(function (a) {
    html += '<button type="button" class="btn small" data-iac-act="' + a + '">' + IAC_ACT[a] + "</button>";
  });
  if (s.state !== "kept" && s.state !== "moving" && s.state !== "gone") {
    html += s.keep ?
      '<button type="button" class="btn small iac-keep on" data-iac-act="unkeep" title="It loads and then moves to your Keep folder. Click to stop that (what\'s loaded stays in the cache).">Don\'t keep</button>' :
      '<button type="button" class="btn small iac-keep" data-iac-act="keep" title="' + esc("Load it fully, check it and move it to your Keep folder" + (iac.keepDir ? " (" + iac.keepDir + ")" : "") +
        " with a readable name. It then plays from there and you can open it without AniBox.") + '">Keep</button>';
  }
  el.innerHTML = html;
}
// Capture: a row may play when clicked; a click on these buttons only does what they say.
document.addEventListener("click", function (e) {
  var b = e.target.closest && e.target.closest("[data-iac-act]");
  if (!b) return;
  e.preventDefault(); e.stopPropagation();
  var el = b.closest(".iac"), key = el.getAttribute("data-iac-key"), act = b.getAttribute("data-iac-act");
  if (act === "restart" && !confirm("Throw away what's loaded of this video and load it again from the start?")) return;
  b.disabled = true;
  var p = act === "keep" || act === "unkeep" ?
    post("/api/iacache/keep", { key: key, keep: act === "keep", title: el.getAttribute("data-iac-title") || "" }) :
    post("/api/iacache/action", { key: key, action: act });
  p.then(function (r) {
    iacDraw(el, r.state);
    if (act === "keep") toast("AniBox loads it fully, checks it and moves it to your Keep folder.");
    iacSchedule();
  }).catch(function (err) { b.disabled = false; fail(err); });
}, true);

// ---------- Settings → Internet Archive streaming
settingsPanels.push(function (box) {
  box.innerHTML = '<section class="panel"><h2>Internet Archive streaming</h2>' +
    '<p class="muted">When you play a video from archive.org, AniBox first loads it into a cache on this PC, with several connections at once, and plays it from there: ' +
    "it doesn't stop to buffer, and when you jump ahead that part loads first. The next episodes load ahead while you watch. " +
    "Only files the cache made itself are ever deleted; anything else in its folder stays.</p>" +
    '<div id="iacBox" class="muted">Loading …</div></section>';
  iacPanel();
});
function iacPanel(full) {
  clearTimeout(iac.panelTimer);
  api("/api/iacache").then(function (d) {
    var box = $("iacBox");
    if (!box || currentPage !== "settings") return;
    iac.info = d;
    if (full !== false || !$("iacGb")) iacForm(box, d);
    iacUsage(d);
    if (d.loading.length || d.busy) iac.panelTimer = setTimeout(function () { iacPanel(false); }, 2000);
  }).catch(function (e) { var box = $("iacBox"); if (box) box.textContent = e.message; });
}
function iacForm(box, d) {
  box.className = "";
  box.innerHTML =
    '<div class="field"><div class="lbl">Use the cache<small>Off: videos play straight from archive.org and nothing is saved. Kept episodes still play from your Keep folder.</small></div>' +
    '<button class="switch' + (d.enabled ? " on" : "") + '" id="iacOn" role="switch" aria-checked="' + d.enabled + '" aria-label="Use the cache"></button></div>' +
    '<div class="field" style="display:block"><div class="lbl">Cache folder<small>' + (d.dirSetting ? "Your choice." : "The standard folder in AniBox's data folder.") + "</small></div>" +
    '<div class="iac-dir"><input class="input" id="iacDir" value="' + esc(d.dir) + '" spellcheck="false" aria-label="Cache folder" title="Type or paste a folder, then press Enter">' +
    '<button class="btn small" id="iacDirPick">Change …</button>' + (d.dirSetting ? '<button class="btn small" id="iacDirStd">Standard folder</button>' : "") +
    '<button class="btn small" data-iac-open="cache">Open folder</button></div>' +
    '<div class="meter" id="iacMeter"><i style="width:0"></i></div><div class="iac-use muted" id="iacUse"></div></div>' +
    '<div class="field"><div class="lbl">Cache size<small>GB. The cache never grows bigger. When it needs room, watched episodes go first (the oldest first), then the ones loaded furthest ahead.</small></div>' +
    '<input class="input num" type="number" min="1" max="100000" id="iacGb" value="' + d.gb + '" aria-label="Cache size in GB"></div>' +
    '<div class="field"><div class="lbl">Connections<small>At the same time to archive.org for one video (1–32). When archive.org is busy, AniBox uses fewer by itself.</small></div>' +
    '<input class="input num" type="number" min="1" max="32" id="iacConn" value="' + d.connections + '" aria-label="Connections"></div>' +
    '<div class="field"><div class="lbl">Episodes to load ahead<small>While one plays, the next ones load (0 = none).</small></div>' +
    '<input class="input num" type="number" min="0" max="10" id="iacAhead" value="' + d.ahead + '" aria-label="Episodes to load ahead"></div>' +
    '<div class="field" style="display:block"><div class="lbl">Keep folder<small>Click <b>Keep</b> next to a video: it loads fully, is checked and moves here with a readable name (<code>Title – file name' +
    "</code>). It then plays from here, doesn't count toward the cache size, and you can open it without AniBox. AniBox never replaces a file in this folder.</small></div>" +
    '<div class="iac-dir"><input class="input" id="iacKeep" value="' + esc(d.keepDir) + '" spellcheck="false" aria-label="Keep folder" title="Type or paste a folder, then press Enter">' +
    '<button class="btn small" id="iacKeepPick">Change …</button>' + (d.keepSetting ? '<button class="btn small" id="iacKeepStd">Standard folder</button>' : "") +
    '<button class="btn small" data-iac-open="keep">Open folder</button></div></div>' +
    '<div class="field"><div class="lbl">Empty the cache<small><span id="iacEmptyInfo"></span>Kept episodes, ones waiting to be kept and the one playing stay. Your watch progress stays.</small></div>' +
    '<button class="btn small danger" id="iacEmpty">Empty the cache</button></div>' +
    '<div class="iac-now" id="iacNow"></div>';
  $("iacOn").onclick = function () { iacSave({ enabled: !iac.info.enabled }); };
  var num = function (id, field) { $(id).onchange = function () { var b = {}; b[field] = Number(this.value); iacSave(b); }; };
  num("iacGb", "gb"); num("iacConn", "connections"); num("iacAhead", "ahead");
  var dir = function (input, pick, std, field) {
    $(input).onkeydown = function (e) { if (e.key === "Enter") this.blur(); };
    $(input).onchange = function () { var b = {}; b[field] = this.value.trim(); iacSave(b); };
    $(pick).onclick = function () {
      toast("A folder window opens (it may be behind this one) …");
      post("/api/pick-folder").then(function (r) { if (r.path) { var b = {}; b[field] = r.path; iacSave(b); } }).catch(fail);
    };
    if ($(std)) $(std).onclick = function () { var b = {}; b[field] = ""; iacSave(b); };
  };
  dir("iacDir", "iacDirPick", "iacDirStd", "dir");
  dir("iacKeep", "iacKeepPick", "iacKeepStd", "keepDir");
  box.querySelectorAll("[data-iac-open]").forEach(function (b) {
    b.onclick = function () { post("/api/iacache/open", { what: b.getAttribute("data-iac-open") }).catch(fail); };
  });
  $("iacEmpty").onclick = function () {
    var i = iac.info;
    if (!confirm("Delete the cache's files (" + plural(i.files, "file") + ", " + iacBytes(i.used) + ")? Kept episodes and your watch progress stay. Videos load again from archive.org when you play them.")) return;
    post("/api/iacache/empty").then(function (r) {
      var inUse = r.inUse ? " " + plural(r.inUse, "file") + " in use stayed." : "";
      toast(r.removed ? "Deleted " + plural(r.removed, "file") + " (" + iacBytes(r.freed) + ")." + inUse : "Nothing to delete." + inUse);
      iacPanel(false);
    }).catch(fail);
  };
}
// The parts that change while videos load (the form itself stays, so typing isn't interrupted)
function iacUsage(d) {
  var pct = d.limit ? Math.min(100, Math.round(100 * d.used / d.limit)) : 0;
  if ($("iacMeter")) { $("iacMeter").title = pct + " % of the cache size"; $("iacMeter").firstChild.style.width = pct + "%"; }
  if ($("iacUse")) $("iacUse").innerHTML = '<span><b style="color:var(--text)">' + iacBytes(d.used) + "</b> used of " + iacBytes(d.limit) + " (" + plural(d.files, "file") + ")</span>" +
    (d.free != null ? "<span>" + iacBytes(d.free) + " free on this drive</span>" : "") +
    (d.kept ? "<span>" + plural(d.kept, "kept episode") + " · " + iacBytes(d.keptBytes) + " (don't count)</span>" : "");
  if ($("iacEmptyInfo")) $("iacEmptyInfo").textContent = d.files ? "Deletes the cache's own files (" + plural(d.files, "file") + ", " + iacBytes(d.used) + "). " : "The cache is empty. ";
  if ($("iacEmpty")) $("iacEmpty").disabled = !d.files;
  if ($("iacNow")) $("iacNow").innerHTML = d.loading.length ? '<div class="muted" style="border:0;padding-bottom:0">Loading now</div>' + d.loading.map(function (j) {
    return '<div><span title="' + esc(j.file) + '">' + esc((j.title ? j.title + " · " : "") + j.file) + '</span><span class="muted">' + esc(j.label) +
      (j.speed ? " · " + iacBytes(j.speed) + "/s" : "") + (j.readers ? " · playing" : "") + "</span></div>";
  }).join("") : "";
}
function iacSave(b) {
  return post("/api/iacache/settings", b).then(function () { toast("Saved"); iacPanel(); }).catch(function (e) { fail(e); iacPanel(); });
}
