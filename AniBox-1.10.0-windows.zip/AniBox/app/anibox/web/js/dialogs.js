/* AniBox window · Dialogs: play on TV, languages, match by hand.
   Plain scripts sharing one page: loaded in order by index.html. */
"use strict";

// ---------- dialog
function openModal(html) {
  $("modalBox").innerHTML = html; $("modal").hidden = false;
  var f = $("modalBox").querySelector("input, button"); if (f) f.focus();
}
function closeModal() { $("modal").hidden = true; $("modalBox").innerHTML = ""; }
$("modal").addEventListener("click", function (e) { if (e.target === $("modal") || e.target.closest("[data-close]")) closeModal(); });
document.addEventListener("keydown", function (e) { if (e.key === "Escape") { if (!$("modal").hidden) closeModal(); if (!$("trackPop").hidden) toggleTracks(false); } });

// Play on TV: pick a TV (CastApp TV on the Shield, DLNA TVs, Kodi), pair if it asks for a code.
function tvDialog(what) {
  openModal('<div class="kicker">Play on TV</div><h2>Which TV?</h2><p class="muted">AniBox streams the episode from this PC to the TV, so keep AniBox open while you watch. The first time, Windows asks whether to allow AniBox in your network: allow it for private networks.</p>' +
    '<div class="tvlist" id="tvList"><div class="muted">…</div></div><div class="row" style="margin-top:16px;justify-content:space-between"><button class="btn small" id="tvSearch">Search again</button><button class="btn small" data-close>Cancel</button></div>' +
    '<details style="margin-top:12px"><summary class="muted">TV not in the list? Type its address</summary><p class="muted">CastApp TV shows its address on the TV (for example 192.168.1.50:49595). AniBox then asks that TV directly.</p><div class="row"><input class="input" id="tvAddr" placeholder="192.168.1.50" style="flex:1"><button class="btn small" id="tvAdd">Add</button></div></details><div id="tvMsg"></div>');
  function list(devs, last) {
    if (!$("tvList")) return;
    $("tvList").innerHTML = devs.length ? devs.map(function (d) {
      return '<button data-tv="' + esc(d.id) + '"><span>' + esc(d.name) + (d.id === last ? ' <small>· last used</small>' : "") + "</span><small>" + esc(d.castapp ? "CastApp TV" : [d.manufacturer, d.model].filter(Boolean).join(" ")) + "</small></button>";
    }).join("") : '<div class="muted">No TV found yet. Is it on, in the same network, and (for the Shield) is CastApp open once?</div>';
  }
  function search() {
    $("tvList").innerHTML = '<div class="muted">Searching your network (3 seconds) …</div>';
    post("/api/tv/discover").then(function (r) { list(r.devices, ""); }).catch(function (e) { list([], ""); fail(e); });
  }
  function start(id) {
    $("tvMsg").innerHTML = '<p style="color:var(--acc)">Starting on the TV …</p>';
    post("/api/tv/play", Object.assign({ device: id }, what)).then(function (r) { closeModal(); toast("Playing on " + r.device); poll(); })
      .catch(function (e) {
        if (!$("tvMsg")) return;
        if (e.reason === "pairing_required" || e.reason === "wrong_code") {
          // CastApp TV in "only paired devices" mode shows a 4-digit code on the TV.
          post("/api/tv/pair", { device: id }).catch(function () {});
          $("tvMsg").innerHTML = '<p>' + esc(e.message) + '</p><div class="row"><input class="input" id="tvCode" placeholder="1234" maxlength="8" style="width:120px"><button class="btn small primary" id="tvPair">Pair</button></div>';
          $("tvPair").onclick = function () {
            post("/api/tv/pair", { device: id, code: $("tvCode").value.trim() }).then(function () { start(id); }).catch(function (x) { $("tvMsg").innerHTML = '<div class="note">' + esc(x.message) + "</div>"; });
          };
        } else $("tvMsg").innerHTML = '<div class="note">' + esc(e.message) + "</div>";
      });
  }
  $("tvList").addEventListener("click", function (e) { var b = e.target.closest("[data-tv]"); if (b) start(b.getAttribute("data-tv")); });
  $("tvSearch").onclick = search;
  $("tvAdd").onclick = function () {
    $("tvMsg").innerHTML = '<p class="muted">Asking that TV …</p>';
    post("/api/tv/add", { address: $("tvAddr").value.trim() }).then(function (r) {
      $("tvMsg").innerHTML = "";
      api("/api/tv").then(function (x) { list(x.devices, ""); toast("Added " + r.device.name); });
    }).catch(function (e) { if ($("tvMsg")) $("tvMsg").innerHTML = '<div class="note">' + esc(e.message) + "</div>"; });
  };
  api("/api/tv").then(function (r) { if (r.devices.length) list(r.devices, r.last); else search(); }).catch(fail);
}

// Languages of a show: what AniBox found (names, files, player) or your own choice.
function langDialog(d, done) {
  api("/api/langs?id=" + encodeURIComponent(d.id)).then(function (r) {
    var codes = ["ja", "de", "en"], src = { manual: "set by you", file: "read from the files", player: "seen while playing", names: "guessed from folder and file names" }[r.langSource] || r.langSource;
    function boxes(kind, have) {
      var extra = have.filter(function (c) { return codes.indexOf(c) < 0; });
      return codes.concat(extra).map(function (c) { return '<label class="check"><input type="checkbox" data-' + kind + '="' + esc(c) + '"' + (have.indexOf(c) >= 0 ? " checked" : "") + "> " + esc(r.names[c] || c) + "</label>"; }).join("");
    }
    openModal('<div class="kicker">Languages</div><h2>' + esc(d.title) + '</h2><p class="muted">Now: ' + esc(src) + ". Change it by hand if it's wrong; AniBox keeps your choice. Nothing in the files changes.</p>" +
      '<div class="lbl" style="margin:12px 0 6px">Audio</div><div class="row">' + boxes("au", r.audio) + "</div>" +
      '<div class="lbl" style="margin:12px 0 6px">Subtitles</div><div class="row">' + boxes("su", r.subs) + "</div>" +
      '<div class="lbl" style="margin:12px 0 6px">Subtitle type</div><div class="row">' + Object.keys(r.typeNames).map(function (t) {
        return '<label class="check"><input type="checkbox" data-ty="' + t + '"' + ((r.subtypes || []).indexOf(t) >= 0 ? " checked" : "") + "> " + esc(r.typeNames[t]) + "</label>"; }).join("") + "</div>" +
      (r.subWarn ? '<div class="note">These subtitles may not show in the Plex app on the Shield or on some TVs as they are. Plex then converts the whole video (slow on the Shield) or shows them without styling. AniBox on the PC shows them fully.</div>' : "") +
      '<details style="margin-top:12px"><summary class="muted">What the subtitle types mean, and where they work</summary><table style="margin-top:8px"><thead><tr><th>Type</th><th>AniBox (PC)</th><th>Plex on the Shield/TV</th><th>CastApp TV</th><th>Note</th></tr></thead><tbody>' +
      r.compat.map(function (c) { return "<tr><td>" + esc(r.typeNames[c.type]) + "</td><td>" + esc(c.pc) + "</td><td>" + esc(c.plex) + "</td><td>" + esc(c.castapp) + "</td><td>" + esc(c.note) + "</td></tr>"; }).join("") +
      '</tbody></table><p class="muted" style="font-size:12px">"Probably": expected from how the players work, still to check on your TV.</p></details>' +
      '<div class="row" style="margin-top:18px;justify-content:space-between"><div class="row"><button class="btn small primary" id="lgSave">Save</button>' +
      (r.manual ? '<button class="btn small" id="lgAuto">Back to automatic</button>' : "") + '<button class="btn small" id="lgProbe">Read from the files again</button></div><button class="btn small" data-close>Cancel</button></div>');
    function picked(kind) { return Array.prototype.filter.call($("modalBox").querySelectorAll("[data-" + kind + "]"), function (x) { return x.checked; }).map(function (x) { return x.getAttribute("data-" + kind); }); }
    $("lgSave").onclick = function () { post("/api/langs", { show: d.id, audio: picked("au"), subs: picked("su"), subtypes: picked("ty") }).then(function () { closeModal(); toast("Saved."); done(); }).catch(fail); };
    if ($("lgAuto")) $("lgAuto").onclick = function () { post("/api/langs", { show: d.id, reset: true }).then(function () { closeModal(); done(); }).catch(fail); };
    $("lgProbe").onclick = function () { post("/api/langs", { show: d.id, probe: true }).then(function () { closeModal(); toast("Reading the files …"); setTimeout(done, 2500); }).catch(fail); };
  }).catch(fail);
}

// Match a folder to a MyAnimeList entry by hand. Saved in AniBox; the folder isn't touched.
function matchDialog(showId, folder, manual, done) {
  openModal('<div class="kicker">Match by hand</div><h2>' + esc(folder) + "</h2>" +
    '<p class="muted">Search MyAnimeList titles (or paste an entry\'s number or link). AniBox remembers your choice; the folder and its files stay exactly as they are.</p>' +
    '<label class="search" style="max-width:none"><input id="mq" type="search" placeholder="Title, alternative title or MAL number" value="' + esc(folder) + '"></label>' +
    '<div class="results" id="mres"></div>' +
    '<div class="row" style="margin-top:18px;justify-content:space-between"><div class="row">' +
    '<button class="btn small" id="mNone">Not on MyAnimeList</button>' + (manual ? '<button class="btn small" id="mAuto">Back to automatic</button>' : "") +
    '</div><button class="btn small" data-close>Cancel</button></div>');
  function send(mal) {
    post("/api/match", { show: showId, mal_id: mal }).then(function (r) {
      closeModal(); toast(mal === null ? "Back to the automatic match." : r.mal_id ? "Matched to " + r.title : "Marked as not on MyAnimeList.");
      if (done) done();
    }).catch(fail);
  }
  function search() {
    var q = $("mq").value.trim(), m = q.match(/myanimelist\.net\/anime\/(\d+)/); if (m) q = m[1];
    if (!q) { $("mres").innerHTML = ""; return; }
    api("/api/search?q=" + encodeURIComponent(q)).then(function (d) {
      if (!$("mres")) return;
      $("mres").innerHTML = d.results.map(function (r) {
        return '<div class="result"><div><div class="t">' + esc(r.title) + '</div><div class="s">' + [TYPE[r.type] || r.type, r.year, r.episodes ? r.episodes + " eps" : "", "MAL " + r.mal_id].filter(Boolean).map(esc).join(" · ") +
          ' · <a href="' + esc(r.url) + '" target="_blank" rel="noopener noreferrer">open ↗</a></div></div><button class="btn small primary" data-mal="' + esc(r.mal_id) + '">Use this</button></div>';
      }).join("") || '<div class="muted">No title found. Try fewer words.</div>';
    }).catch(fail);
  }
  $("mq").addEventListener("input", function () { clearTimeout(search.t); search.t = setTimeout(search, 250); });
  $("mres").addEventListener("click", function (e) { var b = e.target.closest("[data-mal]"); if (b) send(b.getAttribute("data-mal")); });
  $("mNone").onclick = function () { send(""); };
  if ($("mAuto")) $("mAuto").onclick = function () { send(null); };
  search();
}
