/* AniBox window · Internet Archive videos played straight from archive.org, no download first (stream.py):
   the Play buttons on an item page, "Continue watching" on the Internet Archive tab and on Home.
   Playing goes through /api/play with an "ia:<item>/<file>" key, like an episode.
   Plain scripts sharing one page: loaded in order by index.html. */
"use strict";

var stream = { item: "", files: {} };  // the open item's videos you played: file name -> {position, duration, watched}

function streamKey(item, name) { return "ia:" + item + "/" + name; }

// The Play button next to a video's download tick box (archive.js draws the table).
function streamPlayButton(f) {
  var p = ia.item && stream.item === ia.item.id ? stream.files[f.name] : null;
  var label = p && p.watched ? "▶ Again" : p && p.position >= 30 ? "▶ " + fmt(p.position) : "▶ Play";
  var tip = p && p.watched ? "Watched. Play it again from the start." :
    p && p.position >= 30 ? "Go on from " + fmt(p.position) + ", straight from archive.org" : "Watch it now, straight from archive.org (no download)";
  return '<button type="button" class="btn small ia-play' + (p && p.watched ? " seen" : "") + '" data-ia-play="' + esc(f.name) + '" title="' + esc(tip) + '">' + label + "</button>";
}

// Called by archive.js when an item page is shown: where you stopped in its videos.
function streamItemLoaded(id) {
  api("/api/stream/progress?id=" + encodeURIComponent(id)).then(function (r) {
    stream.item = id; stream.files = r.files || {};
    if (currentPage === "archive" && ia.item && ia.item.id === id && $("iaFiles") && Object.keys(stream.files).length) iaDrawFiles();
  }).catch(function () {});
}

view.addEventListener("click", function (e) {
  var b = e.target.closest("[data-ia-play]");
  if (b && ia.item) {
    e.preventDefault();
    var id = ia.item.id;
    play({ key: streamKey(id, b.getAttribute("data-ia-play")), show: "ia:" + id });  // from the item: next follows the item
    setTimeout(function () { if (ia.item && ia.item.id === id) streamItemLoaded(id); }, 4000);
    return;
  }
  var c = e.target.closest("[data-ia-resume]");
  if (c && !e.target.closest("a")) { e.preventDefault(); streamResume(c); }
});
// A card plays from where it belongs: its item, or the series playlist it was last played from (playlists.js)
function streamResume(c) { play({ key: c.getAttribute("data-ia-resume"), show: c.getAttribute("data-ia-show") || "" }); }

// "Continue watching": items you started streaming (and series playlists), with where to go on.
function streamCardHtml(c) {
  var n = c.next, pct = n.duration ? Math.min(100, Math.round(100 * n.position / n.duration)) : 0;
  var sub = (n.position ? "From " + fmt(n.position) + " · " : "") + n.label + (c.files > 1 ? " · " + c.watched + "/" + c.files : "");
  var link = c.playlist ? '<a href="#/archive/series/' + encodeURIComponent(c.id.slice(4)) + '">Series</a>' : '<a href="#/archive/item/' + encodeURIComponent(c.item) + '">Item</a>';
  return '<div class="card ia-cont" role="button" tabindex="0" data-ia-resume="' + esc(n.key) + '" data-ia-show="' + esc(c.id) + '" title="' + esc((n.position ? "Go on with " : "Play ") + n.label) + '">' +
    '<div class="poster ph"><div class="ini">' + esc(c.title) + '</div><img loading="lazy" alt="" src="' + esc(c.img) + '" onerror="this.remove()">' +
    (pct ? '<div class="bar0"><i style="width:' + pct + '%"></i></div>' : "") + "</div>" +
    '<div class="t">' + esc(c.title) + '</div><div class="s">' + esc(sub) + " · " + link + "</div></div>";
}
function streamContinue(box, onHome) {
  if (!box) return;
  api("/api/stream/continue").then(function (r) {
    if (!box.isConnected || !r.items.length) { box.innerHTML = ""; return; }
    box.innerHTML = '<div class="section"' + (onHome ? "" : ' style="margin-top:0"') + "><h2>" + (onHome ? "Internet Archive · Continue watching" : "Continue watching") + "</h2>" +
      (onHome ? '<a href="#/archive">Internet Archive →</a>' : '<span class="muted">Plays straight from archive.org</span>') + "</div>" +
      '<div class="shelf ia-shelf">' + r.items.map(streamCardHtml).join("") + "</div>";
  }).catch(function () { box.innerHTML = ""; });
}
view.addEventListener("keydown", function (e) {
  var c = e.target.closest && e.target.closest("[data-ia-resume]");
  if (c && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); streamResume(c); }
});

homePanels.push(function (box) { streamContinue(box, true); });
