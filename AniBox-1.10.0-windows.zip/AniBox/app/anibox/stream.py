"""Internet Archive videos played straight from archive.org, without downloading them first.

AniBox's player (mpv) opens ``https://archive.org/download/<identifier>/<file>`` like a file on
disk: it reads only what it plays and asks for another part when you jump (HTTP ranges). With the
cache on (iacache.py, a url hook), mpv reads from AniBox's cache on this PC instead, which loads ahead. Requests carry only ``AniBox/<version>`` as their name, like the rest of the
Internet Archive page.

- Every streamed file has the key ``ia:<identifier>/<file>``; the item is its "show"
  ``ia:<identifier>``. Watch progress is kept under these keys in AniBox's database like an
  episode's, so resume, "watched at 95 %", the playing bar and the phone remote work the same.
  The library never sees these keys (``Library.episode`` answers "not found" for them).
- Next/previous are the item's other videos of the same kind, in order: the original files, or
  archive.org's own copies in the same format (an item often has both, e.g. an ``.avi`` and an
  ``.mp4`` copy of every episode, and next should not jump from one to the other). Before anything
  of an item was played, its kind is archive.org's MP4 copy, unless the originals are sharper
  (``default_family``, Frostbox's rule, see iafiles.py).
- Subtitle files of the item with the video's name (``Ep 1.srt``, ``Ep 1.en.srt``) are loaded too.
- The item's title and its list of videos are kept in ``ia-streams.json`` in AniBox's data folder,
  so "Continue watching" and the playing bar work without asking archive.org again.

The idea comes from Frostbox (Martin's archive.org player, used with permission), which streams
archive.org through its own cache; plain mpv streaming is enough here.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from .iafiles import pick_videos
from .iarchive import SUB_EXT, USER_AGENT, ArchiveError, valid_id
from .watching import next_up

log = logging.getLogger("anibox.stream")

PREFIX = "ia:"
LIBRARY = "Internet Archive"
STATE_FILE = "ia-streams.json"
PLAYLIST_PREFIX = PREFIX + "@"  # "ia:@<id>": a show made by a provider (series playlists), not an item
MAX_ITEMS = 300  # items remembered (the oldest one nobody watched lately goes first)
MAX_VIDEOS = 3000  # videos remembered per item


def stream_key(identifier: str, name: str) -> str:
    return f"{PREFIX}{identifier}/{name}"


def split_key(key: str) -> Optional[Tuple[str, str]]:
    """("identifier", "file name") of an ``ia:`` key, or None. A show id gives ("identifier", "")."""
    if not isinstance(key, str) or not key.startswith(PREFIX):
        return None
    ident, _, name = key[len(PREFIX):].partition("/")
    if not valid_id(ident):
        return None
    parts = [p for p in name.split("/") if p]
    if name and (".." in parts or not parts or name.startswith("/") or "\\" in name):
        return None
    return ident, name


def family(video: dict) -> str:
    """Which videos belong together for next/previous: the originals, or archive.org's copies of one format."""
    if (video.get("source") or "original") == "original":
        return "original"
    return "copy:" + (video.get("format") or os.path.splitext(video.get("name") or "")[1]).lower()


def default_family(videos: List[dict]) -> str:
    """The kind an item plays when nothing of it was played yet: the kind of the better copy of each
    episode (archive.org's MP4 copy unless the original is sharper). Mixed: the originals."""
    if not videos:
        return "original"
    kinds = {family(v) for _, v in pick_videos(videos)}
    if len(kinds) == 1:
        return kinds.pop()
    return "original" if "original" in kinds or not kinds else sorted(kinds)[0]


def _mpv_value(text: str) -> str:
    """A value for mpv's "a=b,c=d" option lists, quoted so commas and colons in it are kept."""
    return f"%{len(text.encode('utf-8'))}%{text}"


def _stem(name: str) -> str:
    return os.path.splitext(name.rsplit("/", 1)[-1])[0].casefold()


class IaStreams:
    def __init__(self, client, data_dir: Path, store=None):
        self.client = client  # iarchive.ArchiveClient
        self.store = store
        self.path = data_dir / STATE_FILE
        self._lock = threading.Lock()
        self._items: Dict[str, dict] = {}  # identifier -> {"title", "videos": [...], "subs": [...], "seen"}
        self._family: Dict[str, str] = {}  # identifier -> the kind of video played last (see family())
        # Plug-in points (1.10):
        # - providers: objects with owns(show_id) -> bool, show(show_id) -> show dict or None and
        #   prepare(show_id) (may ask archive.org); their show ids start with PLAYLIST_PREFIX and their
        #   episodes keep the plain "ia:<identifier>/<file>" keys, so progress is shared everywhere.
        # - url_hooks: fn(identifier, name, video dict) -> another address for mpv (e.g. a local cache) or None.
        # - play_hooks: fn(show, index): an episode of a stream show started (e.g. load the next ones ahead).
        # - option_hooks: fn(key) -> extra per-file mpv options ("" for none), e.g. the cache's wait setting.
        # - local_checks: fn(identifier, name) -> True when the whole file is on this PC (kept or fully
        #   cached), so it plays even if archive.org loses it. A url hook alone doesn't mean that.
        self.providers: list = []
        self.url_hooks: list = []
        self.option_hooks: list = []
        self.local_checks: list = []
        self.play_hooks: list = []
        self._context: Dict[str, str] = {}  # episode key -> provider show it was last played from
        self._load()

    # -- what AniBox knows about the items ---------------------------------------------------------

    def _load(self) -> None:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return
        except (OSError, ValueError):
            log.warning("%s couldn't be read; streamed items are asked from archive.org again", self.path.name)
            return
        items = data.get("items") if isinstance(data, dict) else None
        if isinstance(items, dict):
            self._items = {k: v for k, v in items.items() if valid_id(k) and isinstance(v, dict)
                           and isinstance(v.get("videos"), list)}

    def _save(self) -> None:
        tmp = self.path.with_suffix(".part")
        try:
            tmp.write_text(json.dumps({"version": 1, "items": self._items}, ensure_ascii=False), encoding="utf-8")
            os.replace(tmp, self.path)
        except OSError:
            log.warning("%s couldn't be saved", self.path.name, exc_info=True)

    def remember(self, item: dict) -> dict:
        """Keep the title and the videos of an item from ``ArchiveClient.item()``."""
        files = item.get("files") or []
        videos = [{k: f.get(k) for k in ("name", "format", "source", "original", "length", "size", "md5", "width", "height")
                   if f.get(k) not in (None, "")} for f in files if f.get("kind") == "video"][:MAX_VIDEOS]
        for v in videos:
            v.setdefault("format", "")
            v.setdefault("source", "original")
        subs = [f["name"] for f in files if f.get("kind") == "subtitle"][:MAX_VIDEOS]
        entry = {"title": item.get("title") or item["id"], "videos": videos, "subs": subs, "seen": time.time()}
        with self._lock:
            self._items[item["id"]] = entry
            if len(self._items) > MAX_ITEMS:
                for ident in sorted(self._items, key=lambda k: self._items[k].get("seen") or 0)[: len(self._items) - MAX_ITEMS]:
                    self._items.pop(ident, None)
            self._save()
        return entry

    def known(self, identifier: str) -> Optional[dict]:
        with self._lock:
            return self._items.get(identifier)

    def provider_for(self, show_id: str):
        if not isinstance(show_id, str) or not show_id.startswith(PLAYLIST_PREFIX):
            return None
        return next((p for p in self.providers if p.owns(show_id)), None)

    def prepare(self, key_or_show: str, show_id: str = "") -> None:
        """Make sure AniBox knows the item of this key (asks archive.org only if it doesn't yet).

        ``show_id`` is the show the user played it from: a provider's (a series playlist) makes next and
        previous follow that show from now on, for this key and the show's other episodes (autoplay, Next
        and the phone's episode list move on to them). Played from the item itself again: the item's
        videos follow the item again.
        """
        prov = self.provider_for(show_id or key_or_show)
        if prov:
            prov.prepare(show_id or key_or_show)
            if key_or_show == (show_id or key_or_show):
                return  # a playlist without a chosen episode: the player picks its next one
            show = prov.show(show_id) or {}
            with self._lock:
                for e in show.get("episodes") or []:
                    self._context[e["key"]] = show_id
                self._context[key_or_show] = show_id
        elif key_or_show.startswith(PREFIX) and show_id and not self.provider_for(show_id):
            item = split_key(show_id)
            prefix = stream_key(item[0], "") if item and not item[1] else None
            with self._lock:
                self._context.pop(key_or_show, None)  # played from the item itself again
                for k in [k for k in self._context if prefix and k.startswith(prefix)]:
                    del self._context[k]
        parts = split_key(key_or_show)
        if not parts:
            raise RuntimeError("That isn't an Internet Archive video.")
        ident, name = parts
        entry = self.known(ident)
        if entry and entry["videos"] and (not name or any(v["name"] == name for v in entry["videos"])):
            with self._lock:
                entry["seen"] = time.time()
            return
        try:
            item = self.client.cached_item(ident)
        except ArchiveError as exc:
            raise RuntimeError(str(exc)) from exc
        entry = self.remember(item)
        if not entry["videos"]:
            raise RuntimeError("This archive.org item has no videos.")
        if name and not any(v["name"] == name for v in entry["videos"]):
            raise RuntimeError("That video isn't in this archive.org item (any more).")

    # -- shows and episodes, shaped like the library's -------------------------------------------------

    def url_for(self, ident: str, video: dict) -> str:
        """The address mpv opens: a url hook's (the cache) or archive.org's."""
        for hook in self.url_hooks:
            try:
                url = hook(ident, video["name"], video)
            except Exception:
                log.warning("A stream address hook failed", exc_info=True)
                url = None
            if url:
                return url
        return self.client.file_url(ident, video["name"])

    def episode_dict(self, ident: str, video: dict, label: str = "") -> dict:
        """One video as an episode of a show (for providers too)."""
        return {"key": stream_key(ident, video["name"]), "path": self.url_for(ident, video), "file": video["name"],
                "item": ident, "label": label or video["name"].rsplit("/", 1)[-1], "season": None, "number": None,
                "length": video.get("length")}

    def video(self, ident: str, name: str) -> Optional[dict]:
        entry = self.known(ident)
        return next((v for v in entry["videos"] if v["name"] == name), None) if entry else None

    def played(self, show: dict, idx: int) -> None:
        """The player started episode ``idx`` of a stream show: tell the play hooks (they must not block)."""
        for hook in self.play_hooks:
            try:
                hook(show, idx)
            except Exception:
                log.warning("A stream play hook failed", exc_info=True)

    def _show(self, ident: str, entry: dict, fam: str) -> dict:
        videos = [v for v in entry["videos"] if family(v) == fam] or entry["videos"]
        return {
            "id": PREFIX + ident, "library": LIBRARY, "folder": ident, "title": entry.get("title") or ident,
            "stream": True, "item": ident, "art": "/ia/thumb/" + ident, "mal_id": None, "picture": "",
            "episodes": [self.episode_dict(ident, v) for v in videos],
        }

    def episode(self, key: str) -> Tuple[Optional[dict], int]:
        """(item as a show, index of the video) like ``Library.episode``; (None, -1) if unknown."""
        ctx = self._context.get(key)
        prov = self.provider_for(ctx) if ctx else None
        if prov:
            show = prov.show(ctx)
            idx = next((i for i, e in enumerate((show or {}).get("episodes") or []) if e["key"] == key), -1)
            if show and idx >= 0:
                return show, idx
        parts = split_key(key)
        entry = self.known(parts[0]) if parts else None
        if not entry or not entry["videos"]:
            return None, -1
        ident, name = parts
        video = next((v for v in entry["videos"] if v["name"] == name), None)
        if video is None:
            return self._show(ident, entry, self._family.get(ident) or default_family(entry["videos"])), -1
        fam = family(video)
        self._family[ident] = fam
        show = self._show(ident, entry, fam)
        idx = next((i for i, e in enumerate(show["episodes"]) if e["key"] == key), -1)
        return show, idx

    def show(self, show_id: str) -> Optional[dict]:
        """The item as a show (its videos of the kind played last), like ``Library.show``."""
        prov = self.provider_for(show_id)
        if prov:
            return prov.show(show_id)
        parts = split_key(show_id)
        entry = self.known(parts[0]) if parts and not parts[1] else None
        if not entry or not entry["videos"]:
            return None
        ident = parts[0]
        fam = self._family.get(ident)
        if fam is None:
            last = self._last_played(ident)
            video = next((v for v in entry["videos"] if v["name"] == last), None) if last else None
            fam = family(video) if video else default_family(entry["videos"])
            self._family[ident] = fam
        return self._show(ident, entry, fam)

    def _last_played(self, ident: str, progress: Optional[dict] = None) -> str:
        if progress is None:
            progress = self.store.all_progress() if self.store else {}
        best, when = "", -1.0
        for key, p in progress.items():
            parts = split_key(key) if key.startswith(PREFIX) else None
            if parts and parts[0] == ident and parts[1] and float(p.get("updated") or 0) > when:
                best, when = parts[1], float(p.get("updated") or 0)
        return best

    def mpv_options(self, key: str) -> str:
        """Per-file mpv options for a stream: AniBox's name, no web-video helper, the item's subtitles."""
        opts = [f"user-agent={_mpv_value(USER_AGENT)}", "ytdl=no"]
        parts = split_key(key)
        entry = self.known(parts[0]) if parts else None
        if entry and parts[1]:
            stem = _stem(parts[1])
            for sub in entry.get("subs") or []:
                s = _stem(sub)
                if sub.lower().endswith(SUB_EXT) and (s == stem or s.startswith(stem + ".")):
                    opts.append(f"sub-files-append={_mpv_value(self.client.file_url(parts[0], sub))}")
        for hook in self.option_hooks:
            try:
                extra = hook(key)
            except Exception:
                log.warning("A stream option hook failed", exc_info=True)
                extra = ""
            if extra:
                opts.append(extra)
        return ",".join(opts)

    def is_local(self, ident: str, name: str) -> bool:
        """Is the whole file on this PC (kept, or fully in the cache)? See ``local_checks``."""
        for check in self.local_checks:
            try:
                if check(ident, name):
                    return True
            except Exception:
                log.warning("A stream local check failed", exc_info=True)
        return False

    # -- lists for the window ----------------------------------------------------------------------

    def progress_for(self, ident: str) -> Dict[str, dict]:
        """{file name: {"position", "duration", "watched"}} for the videos of one item you played."""
        progress = self.store.all_progress() if self.store else {}
        out = {}
        for key, p in progress.items():
            parts = split_key(key) if key.startswith(PREFIX) else None
            if parts and parts[0] == ident and parts[1]:
                out[parts[1]] = {"position": float(p.get("position") or 0), "duration": float(p.get("duration") or 0),
                                 "watched": bool(p.get("watched"))}
        return out

    def continue_watching(self, limit: int = 12) -> List[dict]:
        """Items you started streaming and haven't finished, newest first, with where to go on.

        A video last played from a provider's show (a series playlist) counts for that show, which
        then has its own entry (``"playlist": True``) instead of the bare item."""
        progress = self.store.all_progress() if self.store else {}
        latest: Dict[str, Tuple[float, str]] = {}  # item identifier or provider show id -> (when, file name)
        for key, p in progress.items():
            parts = split_key(key) if key.startswith(PREFIX) else None
            if parts and parts[1]:
                when = float(p.get("updated") or 0)
                group = p.get("show") or ""
                if not self.provider_for(group):
                    group = parts[0]
                if when > latest.get(group, (-1.0, ""))[0]:
                    latest[group] = (when, parts[1])
        out = []
        for group, (when, name) in sorted(latest.items(), key=lambda kv: kv[1][0], reverse=True):
            prov = self.provider_for(group)
            if prov:
                show = prov.show(group)
                if not show or not show.get("episodes"):
                    continue
                ident = show.get("item") or ""
            else:
                ident = group
                entry = self.known(ident)
                if not entry or not entry["videos"]:
                    continue
                video = next((v for v in entry["videos"] if v["name"] == name), entry["videos"][0])
                show = self._show(ident, entry, family(video))
            nxt, pos = next_up(show, progress)
            if not nxt:
                continue
            eps = show["episodes"]
            watched = sum(1 for e in eps if (progress.get(e["key"]) or {}).get("watched"))
            out.append({"id": show["id"], "item": ident, "title": show["title"], "img": show["art"],
                        "files": len(eps), "watched": watched, "last_played": when, "playlist": bool(prov),
                        "next": {"key": nxt["key"], "label": nxt["label"], "position": pos,
                                 "duration": float((progress.get(nxt["key"]) or {}).get("duration") or 0)}})
            if len(out) >= limit:
                break
        return out

