"""Play on TV: hand an episode to a TV on the home network.

The main target is CastApp TV, the user's own receiver app on the NVIDIA Shield. CastApp TV is a
standard UPnP/DLNA MediaRenderer (it answers SSDP searches on port 1900, serves
``/description.xml`` on port 49595 and handles the AVTransport, RenderingControl and
ConnectionManager SOAP actions), so the same code also works with ordinary DLNA renderers: smart
TVs, Kodi, BubbleUPnP and the like. CastApp TV has no simpler "play this URL" JSON call of its own;
its ``/castapp/...`` extras are only for pairing and for asking what the TV can decode.

How a cast works:

1. :func:`discover` finds renderers (SSDP M-SEARCH), :func:`describe` reads one known address
   again (so the app can remember the last TV), :func:`locate` does both for a remembered TV.
2. :class:`MediaServer` serves the episode file (and a subtitle file next to it) from this PC over
   HTTP, with byte ranges so the TV can seek. URLs carry a random per-session token.
3. :class:`Renderer` tells the TV to play that URL (SetAVTransportURI + Play) and controls it
   (pause, seek, stop, volume, status for resume and "watched").

Nothing listens on the network until :meth:`MediaServer.start` is called, and nothing is sent
until :func:`discover`, :func:`describe` or a :class:`Renderer` method is called. Standard library
only; never goes through a system proxy (all addresses are on the home network).
"""

from __future__ import annotations

import http.client
import io
import ipaddress
import json
import logging
import mimetypes
import os
import re
import secrets
import select
import socket
import socketserver
import sys
import threading
import time
import unicodedata
import urllib.parse
import xml.etree.ElementTree as ET
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

log = logging.getLogger("anibox.tv")

IS_WINDOWS = sys.platform.startswith("win")

MEDIA_RENDERER = "urn:schemas-upnp-org:device:MediaRenderer:1"
AV_TRANSPORT = "urn:schemas-upnp-org:service:AVTransport:1"
RENDERING_CONTROL = "urn:schemas-upnp-org:service:RenderingControl:1"
SEARCH_TARGETS = (MEDIA_RENDERER, AV_TRANSPORT)
SSDP_GROUP = ("239.255.255.250", 1900)

CASTAPP_MODEL = "CastApp TV"
CASTAPP_PORT = 49595  # CastApp TV's renderer: http://<tv>:49595/description.xml
CLIENT_NAME = "AniBox"
# No version number in it: CastApp TV remembers "Allow always" per address and User-Agent.
USER_AGENT = "AniBox UPnP/1.0 DLNADOC/1.50"

STATES = ("PLAYING", "PAUSED_PLAYBACK", "STOPPED", "TRANSITIONING", "NO_MEDIA_PRESENT")

SOAP_TIMEOUT = 5.0
SET_URI_TIMEOUT = 12.0  # CastApp TV in "Ask first" mode waits up to 6 s for the owner's answer
STATUS_TIMEOUT = 3.0
DESCRIBE_TIMEOUT = 2.0
DESCRIBE_GRACE = 2.0  # how long discover() waits for descriptions after the search window
MAX_DEVICES = 64  # descriptions read per search at most (a broken device can't flood us)
MAX_ANSWER = 1_000_000
MAX_SUBTITLE = 20_000_000
CHUNK = 256 * 1024
REQUEST_TIMEOUT = 30.0  # waiting for the TV to send its request
STREAM_TIMEOUT = 3600.0  # a paused TV stops reading; don't drop it too early

VIDEO_FEATURES = "DLNA.ORG_OP=01;DLNA.ORG_CI=0;DLNA.ORG_FLAGS=01700000000000000000000000000000"
TEXT_FEATURES = "DLNA.ORG_OP=01;DLNA.ORG_CI=0;DLNA.ORG_FLAGS=00D00000000000000000000000000000"

MEDIA_TYPES = {
    ".mkv": "video/x-matroska", ".mk3d": "video/x-matroska", ".mp4": "video/mp4", ".m4v": "video/mp4",
    ".avi": "video/x-msvideo", ".webm": "video/webm", ".mov": "video/quicktime", ".ts": "video/mp2t",
    ".m2ts": "video/mp2t", ".mts": "video/mp2t", ".wmv": "video/x-ms-wmv", ".flv": "video/x-flv",
    ".mpg": "video/mpeg", ".mpeg": "video/mpeg", ".ogv": "video/ogg",
    ".mp3": "audio/mpeg", ".flac": "audio/flac", ".m4a": "audio/mp4", ".ogg": "audio/ogg",
    ".srt": "text/srt", ".vtt": "text/vtt", ".ass": "text/x-ssa", ".ssa": "text/x-ssa",
}
VIDEO_EXTS = {e for e, t in MEDIA_TYPES.items() if t.startswith("video/")}
SUBTITLE_EXTS = (".srt", ".vtt", ".ass", ".ssa")

__all__ = [
    "TvError", "discover", "describe", "locate", "lan_ip_for", "mime_for", "find_subtitles", "ass_to_srt",
    "build_didl", "MediaServer", "Renderer", "CASTAPP_PORT",
]


class TvError(Exception):
    """Something went wrong with the TV. ``str(error)`` is a short English sentence for the user.

    ``reason`` says what kind of problem it is, so the app can react (e.g. ask for the pairing code):
    "unreachable", "refused", "unsupported", "bad_answer", "pairing_required", "wrong_code",
    "locked", "waiting", "not_allowed", "blocked", "busy", "file", "server".
    ``code`` is the UPnP error code or HTTP status, if there was one.
    """

    def __init__(self, message: str, reason: str = "refused", code: Optional[int] = None):
        super().__init__(message)
        self.reason = reason
        self.code = code


# ---- small helpers ---------------------------------------------------------------------------------

_XML_INVALID = re.compile("[\x00-\x08\x0b\x0c\x0e-\x1f]")


def _esc(text: str) -> str:
    """XML-escapes text for elements and attributes (named entities only: CastApp TV reads no numeric ones)."""
    text = _XML_INVALID.sub("", str(text))
    return (text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace('"', "&quot;").replace("'", "&apos;"))


def _local(tag) -> str:
    return tag.rsplit("}", 1)[-1] if isinstance(tag, str) else ""


def _child_text(elem: ET.Element, name: str) -> str:
    for child in elem:
        if _local(child.tag) == name:
            return (child.text or "").strip()
    return ""


def _parse_xml(data: bytes) -> ET.Element:
    """Parses a small XML answer. Documents with a DTD are refused (UPnP never needs one)."""
    data = data.lstrip(b"\xef\xbb\xbf \t\r\n")
    if b"<!DOCTYPE" in data or b"<!ENTITY" in data:
        raise ValueError("XML with a DTD")
    try:
        return ET.fromstring(data)
    except ET.ParseError:
        # Some TVs put a bare "&" into their names.
        fixed = re.sub(rb"&(?!(?:[A-Za-z]+|#\d+|#x[0-9A-Fa-f]+);)", b"&amp;", data)
        if fixed != data:
            try:
                return ET.fromstring(fixed)
            except ET.ParseError:
                pass
        raise ValueError("not valid XML")


def _http(method: str, url: str, body: Optional[bytes] = None, headers: Optional[dict] = None,
          timeout: float = SOAP_TIMEOUT, limit: int = MAX_ANSWER) -> Tuple[int, bytes]:
    """One plain HTTP request on the home network (never through a proxy).

    Raises ValueError for a bad address or an oversized answer, OSError / HTTPException otherwise.
    """
    u = urllib.parse.urlsplit(url)
    if u.scheme != "http" or not u.hostname:
        raise ValueError(f"not an http address: {url}")
    conn = http.client.HTTPConnection(u.hostname, u.port or 80, timeout=timeout)
    try:
        path = (u.path or "/") + (f"?{u.query}" if u.query else "")
        conn.request(method, path, body=body, headers=headers or {})
        resp = conn.getresponse()
        data = resp.read(limit + 1)
        if len(data) > limit:
            raise ValueError("answer too large")
        return resp.status, data
    finally:
        conn.close()


def _hms(seconds: float) -> str:
    """3725.9 -> "1:02:05" (UPnP REL_TIME, whole seconds)."""
    total = max(0, int(seconds or 0))
    return f"{total // 3600}:{total % 3600 // 60:02d}:{total % 60:02d}"


_TIME = re.compile(r"^\s*(\d+):(\d{1,2}):(\d{1,2}(?:\.\d+)?)")


def _seconds(text: Optional[str]) -> float:
    """"0:24:00", "00:01:05.500" -> seconds; "NOT_IMPLEMENTED" or empty -> 0.0."""
    m = _TIME.match(text or "")
    if not m:
        return 0.0
    return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))


def _safe_name(text: str, fallback: str = "video") -> str:
    """An ASCII file name for a URL ("Sousou no Frieren 01" -> "Sousou_no_Frieren_01")."""
    ascii_text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
    name = re.sub(r"[^A-Za-z0-9._-]+", "_", ascii_text).strip("._-")[:80]
    return name or fallback


def _is_home_address(ip: str) -> bool:
    """Private, link-local, loopback or carrier-grade NAT (Tailscale) addresses; never the internet."""
    try:
        addr = ipaddress.ip_address(ip.split("%")[0])
    except ValueError:
        return False
    mapped = getattr(addr, "ipv4_mapped", None)
    if mapped:
        addr = mapped
    return not addr.is_global and not addr.is_multicast and not addr.is_unspecified


def lan_ip_for(target_ip: str) -> str:
    """This PC's IPv4 address on the route to ``target_ip`` (the TV), so the TV can reach our URLs.

    Connecting a UDP socket only picks the route; no packet is sent. Falls back to the default
    route's address, then to 127.0.0.1.
    """
    for dest in (target_ip, "10.255.255.255"):
        if not dest:
            continue
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.connect((dest, 9))
                ip = s.getsockname()[0]
            if ip and ip != "0.0.0.0":
                return ip
        except (OSError, UnicodeError):
            continue
    return "127.0.0.1"


def mime_for(path: str) -> str:
    """The MIME type a TV is told for a file ("video/x-matroska" for .mkv, "text/srt" for .srt, ...)."""
    ext = os.path.splitext(path)[1].lower()
    return MEDIA_TYPES.get(ext) or mimetypes.guess_type("x" + ext)[0] or "application/octet-stream"


# ---- discovery -------------------------------------------------------------------------------------

class _NotRenderer(ValueError):
    """The description has no AVTransport service (a media server, a router, ...)."""


def _parse_description(data: bytes, location: str) -> dict:
    root = _parse_xml(data)
    base = location
    url_base = _child_text(root, "URLBase")
    if url_base.startswith("http"):
        base = url_base
    loc = urllib.parse.urlsplit(location)
    for dev in root.iter():
        if _local(dev.tag) != "device":
            continue
        found: Dict[str, Tuple[str, str]] = {}
        for service_list in dev:
            if _local(service_list.tag) != "serviceList":
                continue
            for svc in service_list:
                if _local(svc.tag) != "service":
                    continue
                stype = _child_text(svc, "serviceType")
                control = _child_text(svc, "controlURL")
                if not control:
                    continue
                url = urllib.parse.urljoin(base, control)
                if urllib.parse.urlsplit(url).scheme != "http":
                    continue
                if stype.startswith("urn:schemas-upnp-org:service:AVTransport:"):
                    found.setdefault("avt", (url, stype))
                elif stype.startswith("urn:schemas-upnp-org:service:RenderingControl:"):
                    found.setdefault("rc", (url, stype))
        if "avt" not in found:
            continue
        manufacturer = _child_text(dev, "manufacturer")
        model = _child_text(dev, "modelName")
        rc_url, rc_type = found.get("rc", ("", RENDERING_CONTROL))
        return {
            "id": _child_text(dev, "UDN") or f"{loc.hostname}:{loc.port or 80}",
            "name": _child_text(dev, "friendlyName") or loc.hostname or "TV",
            "location": location,
            "manufacturer": manufacturer,
            "model": model,
            "castapp": CASTAPP_MODEL in f"{manufacturer} {model}",
            "avtransport": found["avt"][0],
            "rendering": rc_url,
            "avtransport_type": found["avt"][1],
            "rendering_type": rc_type,
        }
    raise _NotRenderer("no AVTransport service")


def describe(location: str, timeout: float = 3.0) -> dict:
    """Reads a renderer's description (the address SSDP gave, or one the app remembered).

    Returns ``{"id", "name", "location", "manufacturer", "model", "castapp", "avtransport",
    "rendering", "avtransport_type", "rendering_type"}``; ``rendering`` is "" without volume control.
    Raises :class:`TvError`.
    """
    u = urllib.parse.urlsplit(location or "")
    if u.scheme != "http" or not u.hostname:
        raise TvError(f"\"{location}\" isn't a TV address AniBox can use.", "bad_answer")
    who = f"The TV at {u.hostname}"
    hint = " On the TV, open CastApp once so it says \"Ready to cast\"." if u.port == CASTAPP_PORT else ""
    try:
        status, data = _http("GET", location, headers={"User-Agent": USER_AGENT, "Connection": "close"},
                             timeout=timeout, limit=MAX_ANSWER)
    except ValueError as exc:
        raise TvError(f"{who} sent an answer AniBox doesn't understand.", "bad_answer") from exc
    except (OSError, http.client.HTTPException) as exc:
        raise TvError(f"{who} doesn't answer. Check that it's switched on and on the same network as this PC.{hint}",
                      "unreachable") from exc
    if status != 200:
        raise TvError(f"{who} doesn't answer like a TV (HTTP {status}).", "bad_answer", status)
    try:
        return _parse_description(data, location)
    except _NotRenderer as exc:
        raise TvError(f"{who} can't play videos sent from a PC.", "unsupported") from exc
    except ValueError as exc:
        raise TvError(f"{who} sent a description AniBox doesn't understand.", "bad_answer") from exc


def _ssdp_location(data: bytes, sender_ip: str) -> Optional[str]:
    """The LOCATION of an SSDP search answer, if it points at a device on the home network."""
    text = data.decode("utf-8", "replace")
    lines = text.replace("\r\n", "\n").split("\n")
    first = lines[0].strip().upper() if lines else ""
    if not first.startswith("HTTP/") or " 200" not in first:
        return None
    headers = {}
    for line in lines[1:]:
        key, sep, value = line.partition(":")
        if sep:
            headers[key.strip().lower()] = value.strip()
    location = headers.get("location", "")
    try:
        u = urllib.parse.urlsplit(location)
        u.port  # noqa: B018  (raises ValueError for a bad port)
    except ValueError:
        return None
    if u.scheme != "http" or not u.hostname:
        return None
    host = u.hostname
    if host == sender_ip:
        return location
    try:
        addr = ipaddress.ip_address(host)
        sender_loopback = ipaddress.ip_address(sender_ip).is_loopback
    except ValueError:
        return None  # host names are not followed during a search
    if addr.is_loopback and not sender_loopback:
        return None
    return location if _is_home_address(host) else None


def _local_ipv4s() -> List[str]:
    ips = set()
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except (OSError, UnicodeError):
        pass
    ips.add(lan_ip_for(SSDP_GROUP[0]))
    return sorted(ip for ip in ips if not ip.startswith("127.") and ip != "0.0.0.0")


def _search_sockets(targets) -> List[Tuple[socket.socket, Tuple[str, int]]]:
    """One UDP socket per network adapter for the multicast search, or one for unicast test targets."""
    out = []
    if targets:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.bind(("", 0))
        s.setblocking(False)
        for t in targets:
            out.append((s, (str(t[0]), int(t[1]))))
        return out
    for ip in _local_ipv4s() or ["0.0.0.0"]:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
            s.bind((ip, 0))
            if ip != "0.0.0.0":
                s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_IF, socket.inet_aton(ip))
            s.setblocking(False)
        except OSError:
            s.close()
            continue
        out.append((s, SSDP_GROUP))
    return out


def _msearch(target: str, mx: int) -> bytes:
    return (f"M-SEARCH * HTTP/1.1\r\nHOST: {SSDP_GROUP[0]}:{SSDP_GROUP[1]}\r\nMAN: \"ssdp:discover\"\r\n"
            f"MX: {mx}\r\nST: {target}\r\nUSER-AGENT: {USER_AGENT}\r\n\r\n").encode("ascii")


def discover(timeout: float = 3.0, targets: Optional[Iterable[Tuple[str, int]]] = None) -> List[dict]:
    """Searches the home network for TVs that can play a URL (DLNA MediaRenderers, CastApp TV).

    Sends SSDP M-SEARCH to 239.255.255.250:1900 on every network adapter (``targets``: a list of
    ``(host, port)`` to search by unicast instead, for tests), listens ``timeout`` seconds, reads each
    answering device's description and returns the renderers as :func:`describe` dicts, one per
    device (by UDN), sorted by name. Devices that don't answer or can't play are left out.
    Windows lets the answers in without a firewall rule for about 3 s after the search, which is why
    the default timeout is 3 s.
    """
    timeout = max(0.2, float(timeout))
    targets = list(targets) if targets else None
    socks = _search_sockets(targets)
    if not socks:
        return []
    mx = max(1, min(3, int(timeout) - 1))
    messages = [_msearch(st, mx) for st in SEARCH_TARGETS]
    rounds = [r for r in (0.0, 0.5, 1.5) if r == 0.0 or r < timeout - 0.4]  # again in case a packet got lost
    found: Dict[str, dict] = {}
    lock = threading.Lock()
    seen = set()
    workers: List[threading.Thread] = []

    def fetch(location: str) -> None:
        try:
            dev = describe(location, timeout=DESCRIBE_TIMEOUT)
        except TvError as exc:
            log.info("TV search: skipped %s (%s)", location, exc)
            return
        with lock:
            found.setdefault(dev["id"], dev)

    start = time.monotonic()
    deadline = start + timeout
    sent = 0
    try:
        while True:
            now = time.monotonic()
            while sent < len(rounds) and now >= start + rounds[sent]:
                for s, dest in socks:
                    for msg in messages:
                        try:
                            s.sendto(msg, dest)
                        except OSError:
                            pass
                sent += 1
            if now >= deadline:
                break
            wait = deadline - now
            if sent < len(rounds):
                wait = min(wait, start + rounds[sent] - now)
            readable, _, _ = select.select(list({id(s): s for s, _ in socks}.values()), [], [], max(0.0, wait))
            for s in readable:
                try:
                    data, addr = s.recvfrom(8192)
                except OSError:  # e.g. Windows reports "port unreachable" of an earlier unicast send here
                    continue
                location = _ssdp_location(data, addr[0])
                if location and location not in seen and len(seen) < MAX_DEVICES:
                    seen.add(location)
                    t = threading.Thread(target=fetch, args=(location,), daemon=True, name="anibox-tv-describe")
                    t.start()
                    workers.append(t)
    finally:
        for s in {id(s): s for s, _ in socks}.values():
            s.close()
    grace_end = time.monotonic() + DESCRIBE_GRACE
    for t in workers:
        t.join(max(0.0, grace_end - time.monotonic()))
    with lock:
        devices = list(found.values())
    return sorted(devices, key=lambda d: (d["name"].casefold(), d["id"]))


def address_location(text: str) -> str:
    """The description address for a TV typed in by hand ("192.168.1.50", "shield:49595", a full link).

    Without a port it's CastApp TV's (49595), without a path ``/description.xml``. Only addresses in
    the home network: private, link-local or this PC's IPs, or a plain name like "SHIELD".
    """
    raw = (text or "").strip()
    if not raw:
        raise TvError("Type the TV's address, for example 192.168.1.50.", "bad_answer")
    u = urllib.parse.urlsplit(raw if "://" in raw else "http://" + raw)
    try:
        port = u.port
    except ValueError:
        port = -1
    host = u.hostname or ""
    if u.scheme != "http" or not host or port == -1 or u.username or u.password:
        raise TvError(f"\"{raw}\" isn't a TV address AniBox can use.", "bad_answer")
    try:
        ip = ipaddress.ip_address(host)
        if not (ip.is_private or ip.is_link_local or ip.is_loopback):
            raise TvError(f"{host} isn't in your home network.", "bad_answer")
    except ValueError:  # a name: only local names, nothing on the internet
        if not re.fullmatch(r"[A-Za-z0-9-]{1,63}(\.(local|lan|home|fritz\.box|box))?", host, re.I):
            raise TvError(f"{host} isn't a name in your home network. Use the TV's address (numbers).", "bad_answer")
    netloc = f"[{host}]" if ":" in host else host
    return f"http://{netloc}:{port or CASTAPP_PORT}{u.path if u.path not in ('', '/') else '/description.xml'}"


def locate(device_id: str, location: str = "", timeout: float = 3.0,
           targets: Optional[Iterable[Tuple[str, int]]] = None) -> Optional[dict]:
    """Finds a remembered TV: first at its last address, then (its IP may have changed) by searching.

    Returns its :func:`describe` dict, or None if it isn't on the network right now. ``targets`` as
    in :func:`discover`.
    """
    if location:
        try:
            dev = describe(location, timeout=min(timeout, 3.0))
            if not device_id or dev["id"] == device_id:
                return dev
        except TvError:
            pass
    for dev in discover(timeout, targets):
        if dev["id"] == device_id:
            return dev
    return None


# ---- what to play: DIDL-Lite -------------------------------------------------------------------------

def subtitle_hint(show_sub: str, sub_langs: str, mode: str) -> Optional[str]:
    """CastApp TV's ``castapp:subtrack:`` hint: which subtitle track inside the file to show.

    "off" when subtitles are switched off (setting or this show's last choice); else the show's
    language first, then the preferred ones ("lang=ger&prefer=ger,eng"); None without any language.
    CastApp TV picks the matching track itself (TextTrackHint in CastApp); other TVs ignore it.
    """
    if mode == "off" or show_sub == "no":
        return "off"
    langs = [x for x in re.split(r"[,;\s]+", f"{show_sub},{sub_langs}".lower()) if re.fullmatch(r"[a-z]{2,3}", x)]
    langs = list(dict.fromkeys(langs))
    if not langs:
        return None
    return (f"lang={langs[0]}&" if show_sub and show_sub != "no" else "") + "prefer=" + ",".join(langs)


def build_didl(title: str, url: str, mime: str, subtitle_url: Optional[str] = None,
               castapp_subtrack: Optional[str] = None) -> str:
    """DIDL-Lite metadata for SetAVTransportURI.

    The subtitle goes in the three places renderers look: a second ``res`` (CastApp TV, others),
    ``sec:CaptionInfoEx`` (Samsung; CastApp TV reads this one first) and ``pv:subtitleFileUri``
    (LG and others). CastApp TV takes SRT and WebVTT only.
    """
    if mime.startswith("audio/"):
        upnp_class = "object.item.audioItem.musicTrack"
    elif mime.startswith("image/"):
        upnp_class = "object.item.imageItem.photo"
    else:
        upnp_class = "object.item.videoItem"
    parts = [
        '<DIDL-Lite xmlns="urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/" xmlns:dc="http://purl.org/dc/elements/1.1/" '
        'xmlns:upnp="urn:schemas-upnp-org:metadata-1-0/upnp/" xmlns:sec="http://www.sec.co.kr/" '
        'xmlns:pv="http://www.pv.com/pvns/">',
        '<item id="0" parentID="-1" restricted="1">',
        f"<dc:title>{_esc(title or 'Video')}</dc:title>",
        f"<upnp:class>{upnp_class}</upnp:class>",
    ]
    res = f'<res protocolInfo="http-get:*:{_esc(mime)}:{VIDEO_FEATURES}"'
    kind = ""
    if subtitle_url:
        kind = "vtt" if urllib.parse.urlsplit(subtitle_url).path.lower().endswith(".vtt") else "srt"
        res += f' pv:subtitleFileUri="{_esc(subtitle_url)}" pv:subtitleFileType="{kind}"'
    parts.append(f"{res}>{_esc(url)}</res>")
    if subtitle_url:
        parts.append(f'<res protocolInfo="http-get:*:text/{kind}:*">{_esc(subtitle_url)}</res>')
        parts.append(f'<sec:CaptionInfoEx sec:type="{kind}">{_esc(subtitle_url)}</sec:CaptionInfoEx>')
    if castapp_subtrack:
        parts.append(f'<desc id="castapp-subtrack" nameSpace="urn:castapp">castapp:subtrack:{_esc(castapp_subtrack)}</desc>')
    parts.append("</item></DIDL-Lite>")
    return "".join(parts)


def _envelope(service: str, action: str, args: Sequence[Tuple[str, str]]) -> str:
    inner = "".join(f"<{k}>{_esc(v)}</{k}>" for k, v in args)
    return ('<?xml version="1.0" encoding="utf-8"?>'
            '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" '
            's:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">'
            f'<s:Body><u:{action} xmlns:u="{service}">{inner}</u:{action}></s:Body></s:Envelope>')


def _soap_values(data: bytes) -> Dict[str, str]:
    root = _parse_xml(data)
    body = next((e for e in root.iter() if _local(e.tag) == "Body"), None)
    if body is None or len(body) == 0:
        return {}
    return {_local(c.tag): (c.text or "") for c in body[0]}


def _fault_details(data: bytes) -> Tuple[Optional[int], str]:
    try:
        root = _parse_xml(data)
    except ValueError:
        return None, ""
    code: Optional[int] = None
    desc = fault = ""
    for e in root.iter():
        name = _local(e.tag)
        if name == "errorCode":
            try:
                code = int((e.text or "").strip())
            except ValueError:
                pass
        elif name == "errorDescription":
            desc = (e.text or "").strip()
        elif name == "faultstring":
            fault = (e.text or "").strip()
    return code, desc or ("" if fault == "UPnPError" else fault)


# ---- controlling one TV ---------------------------------------------------------------------------

class Renderer:
    """Controls one TV (a :func:`discover` / :func:`describe` dict) over UPnP AVTransport.

    ``token`` is CastApp TV's pairing token (see :meth:`pair`); keep it per TV id. Every method raises
    :class:`TvError` with a message for the user. Thread-safe: each call is its own HTTP request.
    """

    def __init__(self, device: dict, token: str = "", client_name: str = CLIENT_NAME, timeout: float = SOAP_TIMEOUT):
        avt = str(device.get("avtransport") or "")
        self.name = str(device.get("name") or "The TV")
        if not avt.startswith("http://"):
            raise TvError(f"{self.name} can't play videos sent from a PC.", "unsupported")
        self.device = dict(device)
        self.castapp = bool(device.get("castapp"))
        self.token = token or ""
        self.client_name = client_name
        self.timeout = timeout
        self._avt_url = avt
        self._avt_type = str(device.get("avtransport_type") or AV_TRANSPORT)
        self._rc_url = str(device.get("rendering") or "")
        self._rc_type = str(device.get("rendering_type") or RENDERING_CONTROL)

    @property
    def host(self) -> str:
        """The TV's address (for :func:`lan_ip_for` and :meth:`MediaServer.add`)."""
        return urllib.parse.urlsplit(self._avt_url).hostname or ""

    @property
    def base(self) -> str:
        """"http://host:port" of the renderer (CastApp TV's extras live there too)."""
        u = urllib.parse.urlsplit(self._avt_url)
        return f"{u.scheme}://{u.netloc}"

    # -- plumbing

    def _headers(self) -> dict:
        headers = {"User-Agent": USER_AGENT, "Connection": "close", "X-CastApp-Name": self.client_name}
        if self.token:
            headers["X-CastApp-Token"] = self.token
        return headers

    def _request(self, method: str, url: str, body: Optional[bytes], headers: dict, timeout: Optional[float]) -> Tuple[int, bytes]:
        hint = " On the TV, open CastApp once so it says \"Ready to cast\"." if self.castapp else ""
        try:
            return _http(method, url, body, headers, timeout or self.timeout)
        except socket.timeout as exc:
            raise TvError(f"{self.name} didn't answer in time. Check that it's switched on and on the same network as this PC.{hint}",
                          "unreachable") from exc
        except ValueError as exc:
            raise TvError(f"{self.name} sent an answer AniBox doesn't understand.", "bad_answer") from exc
        except (OSError, http.client.HTTPException) as exc:
            raise TvError(f"{self.name} doesn't answer. Check that it's switched on and on the same network as this PC.{hint}",
                          "unreachable") from exc

    def _call(self, url: str, service: str, action: str, args: Sequence[Tuple[str, str]],
              timeout: Optional[float] = None) -> Dict[str, str]:
        body = _envelope(service, action, args).encode("utf-8")
        headers = self._headers()
        headers["Content-Type"] = 'text/xml; charset="utf-8"'
        headers["SOAPACTION"] = f'"{service}#{action}"'
        status, data = self._request("POST", url, body, headers, timeout)
        if status != 200:
            raise self._fault(action, status, data)
        try:
            return _soap_values(data)
        except ValueError as exc:
            raise TvError(f"{self.name} sent an answer AniBox doesn't understand ({action}).", "bad_answer") from exc

    def _avt(self, action: str, args: Sequence[Tuple[str, str]] = (), timeout: Optional[float] = None) -> Dict[str, str]:
        return self._call(self._avt_url, self._avt_type, action, [("InstanceID", "0"), *args], timeout)

    def _fault(self, action: str, status: int, data: bytes) -> TvError:
        code, desc = _fault_details(data)
        low = desc.lower()
        n = self.name
        if code == 606 or (code is None and status in (401, 403)):
            # CastApp TV's receiver protection (ReceiverGuard) answers with error 606 and these texts.
            if "pairing required" in low:
                return TvError(f"{n} only accepts paired devices. Enter the 4-digit code shown on the TV to pair AniBox.",
                               "pairing_required", code)
            if "waiting for permission" in low:
                return TvError(f"{n} is asking whether to allow AniBox. Choose Allow on the TV, then try again.", "waiting", code)
            if low.startswith("blocked"):
                return TvError(f"{n} has blocked AniBox. You can allow it again in CastApp's receiver settings on the TV.",
                               "blocked", code)
            if low.startswith("not allowed"):
                return TvError(f"{n} hasn't allowed AniBox yet. Start the episode again and choose Allow on the TV.",
                               "not_allowed", code)
            if "busy" in low:
                return TvError(f"{n} is busy asking about other devices. Try again in a moment.", "busy", code)
            return TvError(f"{n} doesn't let AniBox control it" + (f": {desc}" if desc else "."), "refused", code or status)
        if code in (401, 602):
            return TvError(f"{n} doesn't support \"{action}\".", "unsupported", code)
        if code in (714, 716):
            return TvError(f"{n} couldn't open the video.", "refused", code)
        if code == 701:
            return TvError(f"{n} can't do that right now ({action}).", "refused", code)
        if code in (710, 711):
            return TvError(f"{n} can't jump to that position.", "refused", code)
        detail = f": {desc}" if desc else ""
        number = f" (error {code})" if code else f" (HTTP {status})"
        return TvError(f"{n} refused {action}{detail}{number}.", "refused", code or status)

    # -- playback

    def load(self, url: str, title: str, mime: str, subtitle_url: Optional[str] = None,
             start: float = 0.0, wait: float = 10.0, subtrack: Optional[str] = None) -> None:
        """Plays ``url`` on the TV: SetAVTransportURI (with DIDL-Lite metadata) and Play.

        ``start`` > 0 resumes there: most TVs only accept a seek once they play, so this waits up to
        ``wait`` seconds for PLAYING first (a failed resume seek is only logged). Other TVs get a Stop
        first (some refuse a new URL while playing); CastApp TV doesn't, so its player stays open
        and Android doesn't have to let it start from the background again.
        """
        if not self.castapp:
            try:
                self._avt("Stop", timeout=STATUS_TIMEOUT)
            except TvError:
                pass
        meta = build_didl(title, url, mime, subtitle_url, subtrack if self.castapp else None)
        self._avt("SetAVTransportURI", [("CurrentURI", url), ("CurrentURIMetaData", meta)],
                  timeout=max(self.timeout, SET_URI_TIMEOUT))
        self._avt("Play", [("Speed", "1")])
        if start and start > 0:
            self._wait_playing(wait)
            try:
                self.seek(start)
            except TvError as exc:
                log.info("TV: resume at %s s didn't work on %s: %s", start, self.name, exc)

    def _wait_playing(self, wait: float) -> bool:
        deadline = time.monotonic() + max(0.0, wait)
        while True:
            try:
                if self.status()["state"] == "PLAYING":
                    return True
            except TvError:
                pass
            if time.monotonic() >= deadline:
                return False
            time.sleep(0.5)

    def play(self) -> None:
        """Continues after a pause."""
        self._avt("Play", [("Speed", "1")])

    def pause(self) -> None:
        self._avt("Pause")

    def stop(self) -> None:
        """Stops playback (CastApp TV also closes its player screen)."""
        self._avt("Stop")

    def seek(self, seconds: float) -> None:
        """Jumps to ``seconds`` from the start (REL_TIME "H:MM:SS")."""
        self._avt("Seek", [("Unit", "REL_TIME"), ("Target", _hms(seconds))])

    def status(self) -> dict:
        """``{"state", "position", "duration", "uri"}``: state is one of PLAYING, PAUSED_PLAYBACK,
        STOPPED, TRANSITIONING, NO_MEDIA_PRESENT; position and duration in seconds (0 if unknown);
        uri is what the TV plays (empty if it doesn't say), to notice when someone cast something else.
        """
        info = self._avt("GetTransportInfo", timeout=STATUS_TIMEOUT)
        pos = self._avt("GetPositionInfo", timeout=STATUS_TIMEOUT)
        state = (info.get("CurrentTransportState") or "").strip().upper()
        state = {"PAUSED_RECORDING": "PAUSED_PLAYBACK", "RECORDING": "PLAYING"}.get(state, state)
        if state not in STATES:
            state = "STOPPED"
        return {
            "state": state,
            "position": _seconds(pos.get("RelTime")) or _seconds(pos.get("AbsTime")),
            "duration": _seconds(pos.get("TrackDuration")),
            "uri": (pos.get("TrackURI") or "").strip(),
        }

    def volume(self, level: Optional[int] = None) -> int:
        """Sets the TV's volume (0-100) and returns it; without ``level`` just reads it."""
        if not self._rc_url:
            raise TvError(f"AniBox can't change the volume of {self.name}.", "unsupported")
        args = [("InstanceID", "0"), ("Channel", "Master")]
        if level is None:
            value = self._call(self._rc_url, self._rc_type, "GetVolume", args).get("CurrentVolume", "")
            try:
                return int(value.strip())
            except ValueError as exc:
                raise TvError(f"{self.name} sent an answer AniBox doesn't understand (volume).", "bad_answer") from exc
        level = max(0, min(100, int(level)))
        self._call(self._rc_url, self._rc_type, "SetVolume", args + [("DesiredVolume", str(level))])
        return level

    # -- CastApp TV extras

    def pair(self, code: Optional[str] = None) -> dict:
        """CastApp TV in "Only paired phones" mode lets a device in once it typed the TV's 4-digit code.

        Without ``code``: asks whether a code is needed (the TV then shows it for 2 minutes). With the
        right code the TV hands out a token, kept in ``self.token`` and sent with every later request.
        Returns ``{"needed": bool, "paired": bool, "token": str}``. Other TVs (and CastApp TVs in another
        mode) need nothing: ``needed`` is False. Raises :class:`TvError` ("wrong_code", "locked", ...).
        """
        body = {"name": self.client_name}
        if code:
            body["code"] = str(code).strip()
        headers = self._headers()
        headers["Content-Type"] = "application/json"
        status, data = self._request("POST", self.base + "/castapp/pair", json.dumps(body).encode("utf-8"), headers,
                                     max(self.timeout, 8.0))
        try:
            obj = json.loads(data.decode("utf-8") or "{}")
        except ValueError:
            obj = None
        if not isinstance(obj, dict):
            obj = None
        info = obj or {}
        if status == 404:
            return {"needed": False, "paired": False, "token": self.token}
        if status == 200:
            token = info.get("token")
            if isinstance(token, str) and token:
                self.token = token
            return {"needed": info.get("mode") == "paired", "paired": bool(info.get("paired")), "token": self.token}
        error = info.get("error")
        if status == 401 and error == "code_required":
            self.token = ""  # the TV forgot us (or never knew us)
            return {"needed": True, "paired": False, "token": ""}
        if error == "wrong_code":
            left = info.get("attemptsLeft")
            tries = f" ({left} tries left)" if isinstance(left, int) else ""
            raise TvError(f"Wrong code. Look at the code on {self.name} and try again{tries}.", "wrong_code", status)
        if status == 429:
            wait = info.get("retryInSeconds", 60)
            raise TvError(f"Too many wrong codes. Wait {wait} s, then try again with the new code on {self.name}.", "locked", 429)
        text = data.decode("utf-8", "replace").strip()[:200] if obj is None else ""
        raise TvError(f"{self.name} can't pair right now" + (f": {text}" if text else f" (HTTP {status})."),
                      "refused", status)

    def capabilities(self) -> dict:
        """What a CastApp TV can decode (``{"version": 1, "hevc": true, ...}``); {} for other TVs or on errors."""
        try:
            status, data = _http("GET", self.base + "/castapp/capabilities", headers=self._headers(),
                                 timeout=min(self.timeout, 3.0))
            obj = json.loads(data.decode("utf-8")) if status == 200 else {}
        except (OSError, http.client.HTTPException, ValueError):
            return {}
        return obj if isinstance(obj, dict) else {}


# ---- subtitles -------------------------------------------------------------------------------------

def _decode_text(raw: bytes) -> str:
    """UTF-8/UTF-16 with BOM, UTF-8, else Windows-1252 (old German SRTs)."""
    if raw.startswith(b"\xef\xbb\xbf"):
        return raw[3:].decode("utf-8", "replace")
    if raw.startswith(b"\xff\xfe"):
        return raw[2:].decode("utf-16-le", "replace")
    if raw.startswith(b"\xfe\xff"):
        return raw[2:].decode("utf-16-be", "replace")
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return raw.decode("cp1252", "replace")


_ASS_EVENTS = re.compile(r"^\s*\[events\]\s*$", re.I | re.M)
_ASS_FORMAT = ["layer", "start", "end", "style", "name", "marginl", "marginr", "marginv", "effect", "text"]
_ASS_TIME = re.compile(r"^\s*(\d+):(\d{1,2}):(\d{1,2}(?:[.,]\d+)?)\s*$")
_ASS_OVERRIDE = re.compile(r"\{[^}]*\}")
_ASS_DRAWING = re.compile(r"\{[^}]*\\p[1-9]")


def _ass_time(text: str) -> Optional[float]:
    m = _ASS_TIME.match(text)
    if not m:
        return None
    return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3).replace(",", "."))


def _srt_time(seconds: float) -> str:
    ms = int(round(seconds * 1000))
    h, rest = divmod(ms, 3_600_000)
    m, rest = divmod(rest, 60_000)
    s, ms = divmod(rest, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def ass_to_srt(text: str) -> str:
    """Turns ASS/SSA subtitles into SRT (the text of the Dialogue lines, without styling).

    Same rules as CastApp's own converter: override tags dropped, ``\\N`` becomes a line break,
    drawings (``\\p1``) skipped, lines shown at the same time merged into one cue. "" if no lines.
    """
    text = text.replace("\r\n", "\n").replace("\r", "\n").lstrip("﻿")
    sectioned = bool(_ASS_EVENTS.search(text))
    section = ""
    fmt = _ASS_FORMAT
    cues: Dict[Tuple[float, float], List[str]] = {}
    for raw in text.split("\n"):
        line = raw.strip()
        if line.startswith("[") and line.endswith("]"):
            section = line[1:-1].strip().lower()
            continue
        if sectioned and section != "events":
            continue
        key, sep, value = line.partition(":")
        if not sep:
            continue
        key = key.strip().lower()
        if key == "format":
            names = [x.strip().lower() for x in value.split(",")]
            if {"start", "end", "text"} <= set(names):
                fmt = names
        elif key == "dialogue":
            fields = value.split(",", len(fmt) - 1)
            if len(fields) < len(fmt):
                continue
            start, end = _ass_time(fields[fmt.index("start")]), _ass_time(fields[fmt.index("end")])
            body = fields[fmt.index("text")]
            if start is None or end is None or end <= start or _ASS_DRAWING.search(body):
                continue
            body = _ASS_OVERRIDE.sub("", body).replace("\\N", "\n").replace("\\n", "\n").replace("\\h", " ")
            shown = "\n".join(x.strip() for x in body.split("\n") if x.strip())
            if not shown:
                continue
            texts = cues.setdefault((start, end), [])
            if shown not in texts:
                texts.append(shown)
    ordered = sorted(cues.items(), key=lambda kv: kv[0][0])
    return "\n".join(f"{i}\n{_srt_time(s)} --> {_srt_time(e)}\n" + "\n".join(texts) + "\n"
                     for i, ((s, e), texts) in enumerate(ordered, 1))


def _belongs(sub_stem: str, video_stem: str) -> bool:
    """"Ep 1.en" and "Ep 1 [eng]" go with "Ep 1", "Ep 10" doesn't (CastApp's sidecar rule)."""
    if not video_stem or len(sub_stem) < len(video_stem) or sub_stem[:len(video_stem)].casefold() != video_stem.casefold():
        return False
    return len(sub_stem) == len(video_stem) or not sub_stem[len(video_stem)].isalnum()


def _natural(text: str) -> list:
    return [int(p) if p.isdigit() else p.casefold() for p in re.split(r"(\d+)", text)]


def find_subtitles(video_path: str) -> List[str]:
    """Subtitle files next to a video (.srt/.vtt/.ass/.ssa with the video's name), best first.

    One named exactly like the video comes first, then SRT/WebVTT before ASS/SSA, then natural order.
    A subtitle goes with the video of the longest matching name ("Ep 1 extended.srt" belongs to
    "Ep 1 extended.mkv", not to "Ep 1.mkv"). Only lists the folder; never changes anything.
    """
    folder, file_name = os.path.split(video_path)
    video_stem = os.path.splitext(file_name)[0]
    try:
        names = os.listdir(folder or ".")
    except OSError:
        return []
    stems = [os.path.splitext(n)[0] for n in names if os.path.splitext(n)[1].lower() in VIDEO_EXTS]
    picked = []
    for n in names:
        stem, ext = os.path.splitext(n)
        if ext.lower() not in SUBTITLE_EXTS or not _belongs(stem, video_stem):
            continue
        if any(len(v) > len(video_stem) and _belongs(stem, v) for v in stems):
            continue
        picked.append(n)
    picked.sort(key=lambda n: (os.path.splitext(n)[0].casefold() != video_stem.casefold(),
                               os.path.splitext(n)[1].lower() in (".ass", ".ssa"), _natural(n)))
    return [os.path.join(folder, n) for n in picked]


# ---- the media server --------------------------------------------------------------------------------

class _Entry:
    __slots__ = ("path", "name", "mime", "title", "data", "subtitle", "requests", "sent", "last")

    def __init__(self, path: str, name: str, mime: str, title: str = "", data: Optional[bytes] = None):
        self.path = path
        self.name = name
        self.mime = mime
        self.title = title
        self.data = data  # subtitles are kept in memory (converted, UTF-8)
        self.subtitle = ""  # URL of the subtitle that goes with this video (Samsung's CaptionInfo.sec)
        self.requests = 0
        self.sent = 0
        self.last = 0.0


class _BadRange(ValueError):
    pass


def _parse_range(header: Optional[str], size: int) -> Optional[Tuple[int, int]]:
    """A "bytes=" Range header -> (first, last), None for the whole file; raises _BadRange (416).

    Other units and several ranges are ignored (the whole file is sent, as RFC 7233 allows).
    """
    if not header:
        return None
    unit, _, spec = header.partition("=")
    if unit.strip().lower() != "bytes":
        return None
    if "," in spec:
        return None
    m = re.fullmatch(r"\s*(\d*)\s*-\s*(\d*)\s*", spec)
    if not m or (not m.group(1) and not m.group(2)):
        raise _BadRange(header)
    first, last = m.groups()
    if not first:
        count = int(last)
        if count == 0 or size == 0:
            raise _BadRange(header)
        return max(0, size - count), size - 1
    start = int(first)
    if start >= size:
        raise _BadRange(header)
    end = size - 1 if not last else min(int(last), size - 1)
    if end < start:
        raise _BadRange(header)
    return start, end


class _MediaHttpServer(ThreadingHTTPServer):
    daemon_threads = True
    request_queue_size = 16
    allow_reuse_address = not IS_WINDOWS  # on Windows it would let a second program share the port
    owner: "MediaServer"

    def server_bind(self) -> None:
        # HTTPServer.server_bind looks up the host name, which can take seconds on some networks.
        socketserver.TCPServer.server_bind(self)
        host, port = self.server_address[:2]
        self.server_name, self.server_port = str(host), port

    def handle_error(self, request, client_address) -> None:
        log.debug("TV media server: error with %s", client_address, exc_info=True)


class _MediaHandler(BaseHTTPRequestHandler):
    server_version = "AniBox"
    sys_version = ""
    protocol_version = "HTTP/1.1"
    timeout = REQUEST_TIMEOUT
    server: _MediaHttpServer

    def setup(self) -> None:
        super().setup()
        self.server.owner._track(self.connection, True)

    def finish(self) -> None:
        try:
            super().finish()
        except OSError:
            pass
        finally:
            self.server.owner._track(self.connection, False)

    def log_message(self, fmt, *args) -> None:
        log.debug("TV media %s: " + fmt, self.client_address[0], *args)

    def do_GET(self) -> None:
        self._serve(head=False)

    def do_HEAD(self) -> None:
        self._serve(head=True)

    def _plain(self, status: int, extra: Optional[dict] = None) -> None:
        body = f"{status} {self.responses.get(status, ('Error',))[0]}\n".encode("ascii")
        self.send_response(status)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.send_header("Connection", "close")
        self.end_headers()
        self.close_connection = True
        if self.command != "HEAD":
            self.wfile.write(body)

    def _serve(self, head: bool) -> None:
        owner = self.server.owner
        if not _is_home_address(self.client_address[0]):
            self._plain(403)
            return
        entry = owner._find(self.path)
        if entry is None:
            self._plain(404)
            return
        try:
            f = io.BytesIO(entry.data) if entry.data is not None else open(entry.path, "rb", buffering=0)
        except OSError:
            self._plain(404)
            return
        with f:
            size = len(entry.data) if entry.data is not None else os.fstat(f.fileno()).st_size
            try:
                rng = _parse_range(self.headers.get("Range"), size)
            except _BadRange:
                self._plain(416, {"Content-Range": f"bytes */{size}", "Accept-Ranges": "bytes"})
                return
            start, end = rng if rng else (0, size - 1)
            length = max(0, end - start + 1)
            text = entry.data is not None
            self.send_response(206 if rng else 200)
            ctype = entry.mime + ("; charset=utf-8" if text else "")
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(length))
            if rng:
                self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("transferMode.dlna.org", "Interactive" if text else "Streaming")
            self.send_header("contentFeatures.dlna.org", TEXT_FEATURES if text else VIDEO_FEATURES)
            if entry.subtitle and self.headers.get("getCaptionInfo.sec"):
                self.send_header("CaptionInfo.sec", entry.subtitle)
            self.send_header("Cache-Control", "no-store")
            self.send_header("Connection", "close")
            self.end_headers()
            self.close_connection = True
            owner._count(entry, 0)
            if head or length == 0:
                return
            self.connection.settimeout(STREAM_TIMEOUT)
            f.seek(start)
            remaining = length
            try:
                while remaining > 0 and not owner._stopping.is_set():
                    chunk = f.read(min(CHUNK, remaining))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    remaining -= len(chunk)
                    owner._count(entry, len(chunk), request=False)
            except OSError:
                pass  # the TV closed the connection (seeking, stopping): normal


class MediaServer:
    """Serves registered files to the TV over HTTP, so the TV can fetch them from this PC.

    URLs look like ``http://<lan ip>:<port>/m/<token>/<id>/<name>``; the token is random for each
    start, anything else gets 404, and only devices on the home network are answered. GET and HEAD
    with byte ranges (the TV seeks with them); files are streamed in chunks, never read whole.
    One thread per connection, so a slow TV doesn't hold up others. Nothing listens before
    :meth:`start`. Binding to 0.0.0.0 makes Windows ask once whether Python may accept connections.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._entries: Dict[str, _Entry] = {}
        self._next_id = 0
        self._token = secrets.token_hex(16)  # hex: CastApp TV must not find "srt" in a VTT link by chance
        self._httpd: Optional[_MediaHttpServer] = None
        self._conns: set = set()
        self._stopping = threading.Event()
        self.host = ""

    @property
    def running(self) -> bool:
        return self._httpd is not None

    @property
    def port(self) -> Optional[int]:
        httpd = self._httpd
        return httpd.server_address[1] if httpd else None

    def start(self, host: str = "0.0.0.0", port: int = 0) -> int:
        """Starts listening (``port`` 0 = any free port) and returns the port. Raises :class:`TvError`."""
        with self._lock:
            if self._httpd:
                return self._httpd.server_address[1]
            try:
                httpd = _MediaHttpServer((host, port), _MediaHandler)
            except OSError as exc:
                raise TvError(f"AniBox couldn't open port {port} for the TV ({exc}). Another program may be using it.",
                              "server") from exc
            httpd.owner = self
            self._stopping.clear()
            self._token = secrets.token_hex(16)
            self._entries.clear()
            self.host = host
            self._httpd = httpd
        threading.Thread(target=httpd.serve_forever, kwargs={"poll_interval": 0.25}, daemon=True,
                         name="anibox-tv-media").start()
        log.info("TV media server on %s:%s", host, httpd.server_address[1])
        return httpd.server_address[1]

    def stop(self) -> None:
        """Stops listening, ends running transfers and forgets every registered file."""
        with self._lock:
            httpd, self._httpd = self._httpd, None
            self._entries.clear()
        if not httpd:
            return
        self._stopping.set()
        httpd.shutdown()
        httpd.server_close()
        with self._lock:
            conns = list(self._conns)
            self._conns.clear()
        for c in conns:
            try:
                c.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass

    # -- registering files

    def add(self, path: str, title: str = "", tv_ip: Optional[str] = None) -> str:
        """Registers a video (or any media file) and returns its URL for the TV.

        ``tv_ip`` (e.g. ``Renderer.host``) picks this PC's address on the TV's network; without it the
        default route's address is used. Raises :class:`TvError` if the file isn't there.
        """
        if not os.path.isfile(path):
            raise TvError(f"AniBox can't find \"{os.path.basename(path)}\". Is the drive connected?", "file")
        stem, ext = os.path.splitext(os.path.basename(path))
        ext = _safe_name(ext[1:].lower(), "")  # keep the extension: some TVs look at it
        name = _safe_name(title or stem) + (f".{ext}" if ext else "")
        return self._register(_Entry(path, name, mime_for(path), title), tv_ip)

    def add_subtitle(self, path: str, video_url: Optional[str] = None, tv_ip: Optional[str] = None) -> str:
        """Registers a subtitle file and returns its URL (for :meth:`Renderer.load`'s ``subtitle_url``).

        SRT and WebVTT are served as UTF-8; ASS/SSA are converted to SRT first, because CastApp TV
        (and DLNA TVs in general) only take SRT/WebVTT from outside the video. With ``video_url`` the
        video's answers also name the subtitle (Samsung TVs ask that way). Raises :class:`TvError`.
        """
        base = os.path.basename(path)
        stem, ext = os.path.splitext(base)
        ext = ext.lower()
        if ext not in SUBTITLE_EXTS:
            raise TvError(f"\"{base}\" isn't a subtitle file AniBox can send (SRT, VTT, ASS or SSA).", "file")
        try:
            with open(path, "rb") as f:
                raw = f.read(MAX_SUBTITLE + 1)
        except OSError as exc:
            raise TvError(f"AniBox can't read \"{base}\". Is the drive connected?", "file") from exc
        if len(raw) > MAX_SUBTITLE:
            raise TvError(f"\"{base}\" is too large for a subtitle file.", "file")
        text = _decode_text(raw)
        if ext in (".ass", ".ssa"):
            text, ext = ass_to_srt(text), ".srt"
            if not text:
                raise TvError(f"\"{base}\" has no subtitle lines AniBox could convert.", "file")
        else:
            text = text.lstrip("﻿").replace("\r\n", "\n")
        if ext == ".vtt":
            stem = re.sub("(?i)srt", "", stem)  # CastApp TV reads any subtitle link containing "srt" as SRT
        entry = _Entry(path, _safe_name(stem, "subtitles") + ext, MEDIA_TYPES[ext], data=text.encode("utf-8"))
        url = self._register(entry, tv_ip)
        if video_url:
            with self._lock:
                video = self._lookup(video_url)
                if video is not None:
                    video.subtitle = url
        return url

    def remove(self, url: str) -> None:
        """Forgets one registered URL (the TV gets 404 for it from now on)."""
        with self._lock:
            parts = urllib.parse.urlsplit(url).path.split("/")
            if len(parts) == 5 and self._lookup(url) is not None:
                self._entries.pop(parts[3], None)
            for e in self._entries.values():
                if e.subtitle == url:
                    e.subtitle = ""

    def clear(self) -> None:
        """Forgets every registered URL."""
        with self._lock:
            self._entries.clear()

    def activity(self, url: str) -> dict:
        """``{"requests", "bytes", "last"}`` for a URL: did the TV fetch it? (0 requests a few seconds
        after :meth:`Renderer.load` usually means the firewall blocks the TV.)"""
        with self._lock:
            e = self._lookup(url)
            if e is None:
                return {"requests": 0, "bytes": 0, "last": 0.0}
            return {"requests": e.requests, "bytes": e.sent, "last": e.last}

    # -- internals

    def _register(self, entry: _Entry, tv_ip: Optional[str]) -> str:
        with self._lock:
            httpd = self._httpd
            if httpd is None:
                raise TvError("AniBox's media server for the TV isn't running.", "server")
            self._next_id += 1
            eid = str(self._next_id)
            self._entries[eid] = entry
            token = self._token
        host = self.host if self.host not in ("", "0.0.0.0") else lan_ip_for(tv_ip or "")
        return f"http://{host}:{httpd.server_address[1]}/m/{token}/{eid}/{entry.name}"

    def _lookup(self, url_or_path: str) -> Optional[_Entry]:
        """The entry for a URL or request path (call with the lock held)."""
        try:
            path = urllib.parse.urlsplit(url_or_path).path
        except ValueError:
            return None
        parts = path.split("/")
        if len(parts) != 5 or parts[0] != "" or parts[1] != "m":
            return None
        if not secrets.compare_digest(parts[2].encode("utf-8", "replace"), self._token.encode("ascii")):
            return None
        entry = self._entries.get(parts[3])
        if entry is None or parts[4] != entry.name:
            return None
        return entry

    def _find(self, path: str) -> Optional[_Entry]:
        with self._lock:
            return self._lookup(path)

    def _count(self, entry: _Entry, sent: int, request: bool = True) -> None:
        with self._lock:
            if request:
                entry.requests += 1
            entry.sent += sent
            entry.last = time.time()

    def _track(self, conn: socket.socket, add: bool) -> None:
        with self._lock:
            if add:
                self._conns.add(conn)
            else:
                self._conns.discard(conn)
