"""History: every change AniBox made, newest first, gathered from the logs AniBox already keeps.

Sources (all in AniBox's app folder, nothing on the drives is read):

- ``file-log.jsonl`` (fileops.py): Add new videos, Move or rename, one entry per batch. Undo: the last
  batch, or an older one if no later batch touched the same files (``FileOps.undo_batch``).
- ``nfo-undo.jsonl`` (nfo.py) and the ``nfo-undo-done-*.jsonl`` files of earlier undos: info files written.
  Undo: what was written since the last undo (``nfo.undo``).
- ``tidy-log.jsonl`` (cleanup.py): what Tidy up removed. Can't be undone.
- ``logs/update.log`` (update_apply.py): updates with "Update now". Can't be undone here.
- the ``overrides`` table (matches by hand, with the time they were set). Changed on the show's page.
"""

from __future__ import annotations

import json
import os
import re
import time
from pathlib import Path
from typing import Dict, Iterable, List, Optional

from . import cleanup

EXAMPLES = 30  # files listed per entry; the rest is counted
NFO_PENDING = "nfo:pending"


def _lines(path: Path) -> List[dict]:
    try:
        text = Path(path).read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return []
    out = []
    for line in text.splitlines():
        try:
            rec = json.loads(line)
        except ValueError:
            continue
        if isinstance(rec, dict):
            out.append(rec)
    return out


def _stamp(value) -> float:
    """A time from a log: seconds, or nfo.py's "2026-11-23T10:00:00+0100" (read as local time)."""
    if isinstance(value, (int, float)):
        return float(value)
    try:
        return time.mktime(time.strptime(str(value)[:19], "%Y-%m-%dT%H:%M:%S"))
    except (ValueError, OverflowError):
        return 0.0


def _inside(path: str, roots: Iterable[str]) -> bool:
    p = os.path.normcase(os.path.abspath(path))
    for r in roots:
        r = os.path.normcase(os.path.abspath(r)).rstrip("\\/")
        if r and (p == r or p.startswith(r + os.sep)):
            return True
    return False


# -- the sources ---------------------------------------------------------------------------------------

def file_entries(fileops, library_folders: Iterable[str] = ()) -> List[dict]:
    folders = [f for f in library_folders if f]
    batches = fileops.batches()
    last = fileops.last_batch()
    out = []
    for b in batches:
        files = b["files"]
        label = b["label"]
        if label.startswith("Adding"):
            title = "Added new videos"
        elif label.startswith("Moving "):
            title = "Moved or renamed " + label[len("Moving "):]
        elif label:
            title = label
        else:  # logs of AniBox 1.8.0/1.8.1 have no label
            title = ("Moved or renamed files" if folders and all(_inside(e["src"], folders) for e in files)
                     else "Added new videos")
        ops = [e.get("op") for e in files]
        kinds = ((ops.count("rename"), "moved on the same drive"), (ops.count("move"), "moved to another drive"),
                 (ops.count("copy"), "copied"))
        how = ", ".join(f"{n} {word}" for n, word in kinds if n)
        undo = {"can": False, "why": ""}
        if b["undone"]:
            undo["why"] = "Undone already."
        else:
            is_last = bool(last and last["batch"] == b["batch"])
            blocker = None if is_last else fileops.undo_blocker(b["batch"], batches)
            if blocker:
                undo["why"] = ("A later change moved some of the same files "
                               f"({time.strftime('%Y-%m-%d %H:%M', time.localtime(blocker['time']))}). Undo that one first.")
            else:
                undo = {"can": True, "why": "", "last": is_last}
        out.append({
            "id": "files:" + b["batch"], "kind": "files", "time": b["time"], "title": title,
            "detail": f"{len(files)} file(s): {how}." if how else f"{len(files)} file(s).",
            "count": len(files), "undone": b["undone"], "undo": undo,
            "examples": [{"from": e["src"], "to": e["dst"]} for e in files[:EXAMPLES]],
        })
    return out


def _nfo_segments(path: Path) -> List[dict]:
    """Writes between two undos: {"records", "undone": time or None}."""
    segs, cur = [], []
    for rec in _lines(path):
        if "undo" in rec:
            if cur:
                segs.append({"records": cur, "undone": _stamp(rec["undo"]) or time.time(), "summary": rec})
            cur = []
        elif rec.get("path") and rec.get("sha256"):
            cur.append(rec)
    if cur:
        segs.append({"records": cur, "undone": None, "summary": None})
    return segs


def nfo_entries(data_dir: Path) -> List[dict]:
    data_dir = Path(data_dir)
    files = sorted(data_dir.glob("nfo-undo-done-*.jsonl")) + [data_dir / "nfo-undo.jsonl"]
    out = []
    for f in files:
        for i, seg in enumerate(_nfo_segments(f)):
            recs = seg["records"]
            times = [_stamp(r.get("time")) for r in recs]
            new = sum(1 for r in recs if r.get("action") == "new")
            shows = len({r.get("show") for r in recs})
            pending = seg["undone"] is None and f.name == "nfo-undo.jsonl"
            undo = {"can": True, "why": ""} if pending else {"can": False, "why": "Undone already." if seg["undone"] else ""}
            detail = f"{len(recs)} file(s) in {shows} show(s): {new} new, {len(recs) - new} updated."
            if seg["summary"]:
                s = seg["summary"]
                detail += (f" Undo removed {s.get('removed', 0)}, put back {s.get('restored', 0)}, "
                           f"kept {s.get('kept', 0)} that you had changed.")
            out.append({
                "id": NFO_PENDING if pending else f"nfo:{f.name}:{i}", "kind": "nfo", "time": min(times or [0.0]),
                "title": "Wrote info files (.nfo)", "detail": detail, "count": len(recs), "undone": seg["undone"],
                "undo": undo, "examples": [{"to": r.get("path")} for r in recs[:EXAMPLES]],
                "note": "Undo removes the info files of every write since the last undo." if pending else "",
            })
    return out


def tidy_entries(data_dir: Path) -> List[dict]:
    return [{"id": f"tidy:{i}", "kind": "tidy", "time": float(r.get("time") or 0), "title": "Removed with Tidy up",
             "detail": r.get("what") or "", "count": 1, "undone": None,
             "undo": {"can": False, "why": "Removed for good (Tidy up doesn't use the recycle bin)."},
             "examples": [{"to": r.get("path")}]}
            for i, r in enumerate(_lines(Path(data_dir) / cleanup.LOG_FILE)) if r.get("path")]


_LOG_LINE = re.compile(r"^(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d) (.*)$")
_UPDATE = re.compile(r"^Update (\S+) -> (\S+) in ")


def update_entries(data_dir: Path) -> List[dict]:
    """From the update helper's log: one entry per "Update now"."""
    try:
        lines = (Path(data_dir) / "logs" / "update.log").read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return []
    runs: List[dict] = []
    for line in lines:
        m = _LOG_LINE.match(line)
        if not m:
            continue
        when, text = m.groups()
        u = _UPDATE.match(text)
        if u:
            runs.append({"time": time.mktime(time.strptime(when, "%Y-%m-%d %H:%M:%S")), "from": u.group(1),
                         "to": u.group(2), "lines": []})
        elif runs:
            runs[-1]["lines"].append(text)
        elif text.startswith("Update failed"):
            runs.append({"time": time.mktime(time.strptime(when, "%Y-%m-%d %H:%M:%S")), "from": "?", "to": "?",
                         "lines": [text]})
    out = []
    for i, r in enumerate(runs):
        said = " ".join(r["lines"])
        if "going back" in said:
            title, detail = f"Update to {r['to']} went back", f"AniBox {r['to']} didn't start, so AniBox went back to {r['from']}."
        elif "is running" in said or "New files are in place" in said:
            title, detail = f"Updated to AniBox {r['to']}", f"From {r['from']}. The old version was kept in .previous-update."
        else:
            title = f"Update to {r['to']} didn't happen"
            detail = (r["lines"][-1] if r["lines"] else "") + " Nothing was changed."
        out.append({"id": f"update:{i}", "kind": "update", "time": r["time"], "title": title, "detail": detail.strip(),
                    "count": 0, "undone": None, "undo": {"can": False, "why": ""}, "examples": []})
    return out


def match_entries(store, titles: Optional[dict] = None, file_items: Iterable[dict] = ()) -> List[dict]:
    """Matches by hand. A new show's match set by Add new videos (right after the files were added) says so."""
    titles = titles or {}
    added: Dict[str, float] = {}
    for it in file_items:
        if it["title"] != "Added new videos":
            continue
        for ex in it["examples"]:
            parts = [p for p in re.split(r"[\\/]+", ex.get("to") or "") if p]
            if len(parts) >= 3:
                added.setdefault(f"{parts[-3]}\\{parts[-2]}", it["time"])
    out = []
    for show, mal, when in store.override_times():
        name = (titles.get(mal) or {}).get("title") or (f"MyAnimeList {mal}" if mal else "")
        auto = show in added and 0 <= when - added[show] < 600
        out.append({"id": f"match:{show}", "kind": "match", "time": when, "show": show,
                    "title": ("Matched when the videos were added" if auto else "Matched by hand") if mal
                    else "Marked as not on MyAnimeList",
                    "detail": f"{show} → {name}" if mal else show,
                    "count": 0, "undone": None, "examples": [],
                    "undo": {"can": False, "why": "Change it on the show's page (Wrong match? → Back to automatic)."}})
    return out


def collect(data_dir: Path, fileops, store, titles: Optional[dict] = None,
            library_folders: Iterable[str] = ()) -> List[dict]:
    """Everything, newest first."""
    files = file_entries(fileops, library_folders)
    items = files + nfo_entries(data_dir) + tidy_entries(data_dir) + update_entries(data_dir) + \
        match_entries(store, titles, files)
    items.sort(key=lambda it: it["time"] or 0.0, reverse=True)
    return items
