"""Play on TV (CastApp TV and other DLNA TVs).

Part of the App class (see server.py); the methods use the App's attributes.
"""

from __future__ import annotations

from .apierror import ApiError



def _tv_json(d: dict) -> dict:
    return {"id": d.get("id"), "name": d.get("name"), "model": d.get("model") or "",
            "manufacturer": d.get("manufacturer") or "", "castapp": bool(d.get("castapp"))}


class RoutesTvMixin:
    def _tv_post(self, path: str, body: dict) -> dict:
        if path == "/api/tv/discover":
            return {"devices": [_tv_json(d) for d in self.tv.discover(float(body.get("timeout") or 3.0))]}
        if path == "/api/tv/add":
            return {"device": _tv_json(self.tv.add(str(body.get("address") or "")))}
        device = str(body.get("device") or "")
        if not device:
            raise ApiError("Pick a TV first.")
        if path == "/api/tv/pair":
            return self.tv.pair(device, str(body.get("code") or "") or None)
        # Play on TV. "Move" continues what plays on this PC right now.
        show, key, start = str(body.get("show") or ""), str(body.get("key") or ""), None
        if body.get("move") and self.player.running and self.player.key:
            key, start = self.player.key, max(0.0, self.player.pos - 3)
            self.player.stop()
        self.tv.play(device, show_id=show, key=key, from_start=bool(body.get("fromStart")), start=start)
        return {"ok": True, "device": self.tv.renderer.name if self.tv.renderer else ""}
