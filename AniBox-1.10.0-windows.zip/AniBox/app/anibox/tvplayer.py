"""Play on TV: AniBox's episode logic (resume, watched, next episode, sleep timer) for a TV.

The TV side (finding TVs, streaming the file, UPnP commands) is in ``tv.py``. This module keeps
one TV session at a time and looks like the mpv player to the rest of the app: ``play()``,
``command()`` and ``state()`` behave the same, so the playing bar and the phone remote work
unchanged. The file streams from this PC to the TV (it's read from the Shield's share), so AniBox
has to stay open while the TV plays.
"""

from __future__ import annotations

import logging
import threading
import time
from typing import Optional

from . import tv
from .watching import next_up, resume_from

log = logging.getLogger("anibox.tvplayer")

POLL = 2.0  # seconds between status questions to the TV
SAVE_EVERY = 10.0
MAX_FAILURES = 6  # status questions in a row without an answer, then the session ends
END_SLACK = 20.0  # stopped this close to the end = finished


class TvPlayer:
    def __init__(self, store, library, media: Optional[tv.MediaServer] = None):
        self.store = store
        self.library = library
        self.media = media or tv.MediaServer()
        self.devices = []  # from the last search
        self._lock = threading.RLock()
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self.renderer: Optional[tv.Renderer] = None
        self.error = ""
        self._reset()

    def _reset(self) -> None:
        self.key = ""
        self.show_id = ""
        self.url = ""
        self.pos = 0.0
        self.dur = 0.0
        self.tv_state = ""
        self.stage = "idle"  # idle, playing, ended
        self.started = 0.0
        self.played = False  # the TV reported PLAYING for this episode
        self.marked = False
        self.last_saved = 0.0
        self.failures = 0
        self.list_version = getattr(self, "list_version", 0)
        self.sleep_mode = None
        self.sleep_until = 0.0
        self.sleep_label = ""

    @property
    def active(self) -> bool:
        return self.renderer is not None and self.stage != "idle"

    # -- TVs ---------------------------------------------------------------------------------------

    def known(self) -> list:
        """TVs found before (remembered), newest search first."""
        saved = self.store.meta("tv_devices") or {}
        seen = {d["id"] for d in self.devices}
        return list(self.devices) + [d for i, d in saved.items() if i not in seen]

    def discover(self, timeout: float = 3.0) -> list:
        self.devices = tv.discover(timeout)
        log.info("TV search: %s", ", ".join(f"{d['name']}{' (CastApp TV)' if d.get('castapp') else ''}" for d in self.devices) or "none")
        return self.devices

    def add(self, address: str) -> dict:
        """A TV typed in by hand (when the search doesn't find it): read its description, remember it."""
        dev = tv.describe(tv.address_location(address))
        self.devices = [d for d in self.devices if d["id"] != dev["id"]] + [dev]
        saved = self.store.meta("tv_devices") or {}
        saved[dev["id"]] = {k: dev.get(k) for k in ("id", "name", "location", "manufacturer", "model", "castapp",
                                                    "avtransport", "avtransport_type", "rendering", "rendering_type")}
        self.store.set_meta("tv_devices", saved)
        log.info("TV added by address: %s%s", dev["name"], " (CastApp TV)" if dev.get("castapp") else "")
        return dev

    def _device(self, device_id: str) -> dict:
        for d in self.devices:
            if d["id"] == device_id:
                return d
        saved = (self.store.meta("tv_devices") or {}).get(device_id) or {}
        dev = tv.locate(device_id, saved.get("location", ""))
        if not dev:
            raise tv.TvError("That TV isn't on the network right now. Switch it on and search again.", "unreachable")
        return dev

    def _remember(self, dev: dict) -> None:
        saved = self.store.meta("tv_devices") or {}
        saved[dev["id"]] = {k: dev.get(k) for k in ("id", "name", "location", "manufacturer", "model", "castapp",
                                                    "avtransport", "avtransport_type", "rendering", "rendering_type")}
        self.store.set_meta("tv_devices", saved)
        self.store.update_settings({"tv_device": dev["id"]})

    def _token(self, device_id: str) -> str:
        return (self.store.meta("tv_tokens") or {}).get(device_id, "")

    def pair(self, device_id: str, code: Optional[str] = None) -> dict:
        """CastApp TV in "only paired devices" mode: the 4-digit code shown on the TV."""
        r = tv.Renderer(self._device(device_id), token=self._token(device_id))
        result = r.pair(code)
        if result.get("token"):
            tokens = self.store.meta("tv_tokens") or {}
            tokens[device_id] = result["token"]
            self.store.set_meta("tv_tokens", tokens)
        return {k: v for k, v in result.items() if k != "token"}

    # -- playing -------------------------------------------------------------------------------------

    def play(self, device_id: str, show_id: str = "", key: str = "", from_start: bool = False,
             start: Optional[float] = None) -> None:
        settings = self.store.settings()
        if not key:
            show = self.library.show(show_id)
            if not show:
                raise RuntimeError("Show not found. Scan again in Settings.")
            ep, _ = next_up(show, self.store.all_progress())
            key = (ep or show["episodes"][0])["key"]
        if start is None:
            p = self.store.progress(key) or {}
            start = 0.0 if from_start or p.get("watched") else resume_from(
                float(p.get("position") or 0), float(p.get("duration") or 0), int(settings.get("resume_back", 10)))
        dev = self._device(device_id)
        with self._lock:
            if self.renderer and self.renderer.device.get("id") != dev["id"]:
                self._end("switched to another TV")
            self.renderer = tv.Renderer(dev, token=self._token(dev["id"]))
            self._load(key, start)
            self._remember(dev)
        self._ensure_thread()

    def _load(self, key: str, start: float) -> None:
        show, idx = self.library.episode(key)
        if not show or idx < 0:
            raise RuntimeError("That episode isn't in the library any more. Scan again in Settings.")
        ep = show["episodes"][idx]
        if self.key and self.key != key:
            self._save()
        if not self.media.running:
            self.media.start()
        if self.url:
            self.media.remove(self.url)
        r = self.renderer
        title = f"{show['title']} · {ep['label']}"
        url = self.media.add(ep["path"], title, tv_ip=r.host)
        s = self.store.settings()
        hint = tv.subtitle_hint(self.store.show_pref(show["id"])["sub"], s.get("sub_langs", ""), s.get("subs") or "auto")
        sub_url = None
        for sub in (tv.find_subtitles(ep["path"]) if hint != "off" else []):  # subtitles off: send none
            try:
                sub_url = self.media.add_subtitle(sub, video_url=url, tv_ip=r.host)
                break
            except tv.TvError:
                continue
        r.load(url, title, tv.mime_for(ep["path"]), sub_url, start=start, subtrack=hint)
        log.info("Playing on %s: %s", r.name, title)
        self.key, self.show_id, self.url = key, show["id"], url
        self.pos, self.dur, self.tv_state = start, 0.0, "PLAYING"  # load() ended with Play
        self.stage, self.started, self.played, self.marked = "playing", time.time(), False, False
        self.last_saved, self.failures, self.error = time.time(), 0, ""
        self.list_version += 1
        self.store.save_position(key, show["id"], start, 0)

    def _neighbour(self, step: int) -> Optional[str]:
        if not self.key:
            return None
        show, idx = self.library.episode(self.key)
        if not show or idx < 0:
            return None
        j = idx + step
        return show["episodes"][j]["key"] if 0 <= j < len(show["episodes"]) else None

    def command(self, cmd: str, value=None, ident=None) -> None:
        with self._lock:
            if cmd == "play-episode":
                self._need()._load(str(ident or value), 0.0)
                return
            if cmd == "sleep-set":
                minutes = int(value or 0)
                if minutes < 0:
                    self.sleep_mode, self.sleep_label = "episode", "end of this episode"
                else:
                    self.sleep_mode, self.sleep_until, self.sleep_label = "minutes", time.time() + 60 * minutes, f"{minutes} min"
                return
            if cmd == "sleep-stop":
                self.sleep_mode, self.sleep_label = None, ""
                return
            r = self._need().renderer
            if cmd == "play-pause":
                if self.tv_state == "PLAYING":
                    r.pause()
                    self.tv_state = "PAUSED_PLAYBACK"
                else:
                    r.play()
                    self.tv_state = "PLAYING"
            elif cmd in ("seek-rel", "seek-to"):
                target = (self.pos + float(value or 0)) if cmd == "seek-rel" else float(value or 0)
                target = max(0.0, min(target, self.dur - 1 if self.dur else target))
                r.seek(target)
                self.pos = target
            elif cmd in ("next", "prev"):
                key = self._neighbour(1 if cmd == "next" else -1)
                if not key:
                    raise RuntimeError("There's no " + ("next" if cmd == "next" else "previous") + " episode.")
                self._load(key, 0.0)
            elif cmd == "volume":
                r.volume(int(max(0, min(100, float(value or 0)))))
            elif cmd in ("stop", "still-stop"):
                try:
                    r.stop()
                except tv.TvError:
                    pass
                self._end("stopped")
            elif cmd in ("audio", "sub", "skip", "mute"):
                raise RuntimeError("That isn't available while playing on the TV.")
            else:
                raise RuntimeError(f"Unknown command: {cmd}")

    def _need(self) -> "TvPlayer":
        if not self.active:
            raise RuntimeError("Nothing is playing on the TV.")
        return self

    def stop(self) -> None:
        with self._lock:
            if self.renderer:
                try:
                    self.renderer.stop()
                except tv.TvError:
                    pass
            self._end("stopped")

    def shutdown(self) -> None:
        self._stop.set()
        with self._lock:
            self._end("AniBox closed")
        self.media.stop()

    def _end(self, why: str) -> None:
        if self.renderer and self.key:
            self._save()
            log.info("TV session ended (%s)", why)
        if self.url:
            self.media.remove(self.url)
        self.renderer = None
        self._reset()

    def _save(self, watched: Optional[bool] = None) -> None:
        if not self.key:
            return
        at = float(self.store.settings().get("watched_at", 95)) / 100
        if watched is None and self.dur > 0 and self.pos >= self.dur * at:
            watched = True
        self.store.save_position(self.key, self.show_id, self.pos, self.dur, watched)
        self.last_saved = time.time()

    # -- watching the TV -------------------------------------------------------------------------------

    def _ensure_thread(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True, name="anibox-tv")
        self._thread.start()

    def _loop(self) -> None:
        while not self._stop.wait(POLL):
            with self._lock:
                if not self.active:
                    break
                try:
                    self.tick()
                except Exception as exc:
                    log.exception("TV problem")
                    self.error = str(exc)

    def tick(self) -> None:
        r = self.renderer
        try:
            st = r.status()
        except tv.TvError as exc:
            self.failures += 1
            if self.failures >= MAX_FAILURES:
                self.error = str(exc)
                self._end("the TV stopped answering")
            return
        self.failures = 0
        if st.get("uri") and self.url and st["uri"] != self.url and self.played:
            self._end("something else is playing on the TV now")
            return
        self.tv_state = st["state"]
        if st["state"] == "PLAYING":
            self.played = True
        if st["position"]:
            self.pos = st["position"]
        if st["duration"]:
            self.dur = st["duration"]
        at = float(self.store.settings().get("watched_at", 95)) / 100
        if self.dur and self.pos >= self.dur * at and not self.marked:
            self.marked = True
            self._save(True)
        elif time.time() - self.last_saved >= SAVE_EVERY and st["state"] == "PLAYING":
            self._save()
        if self.sleep_mode == "minutes" and time.time() >= self.sleep_until:
            self.sleep_mode, self.sleep_label = None, ""
            try:
                r.pause()
            except tv.TvError:
                pass
        if not self.played and not self.error and time.time() - self.started > 12 \
                and self.url and self.media.activity(self.url)["requests"] == 0:
            # The TV never asked for the file: almost always the Windows firewall.
            self.error = ("The TV couldn't reach this PC. Allow Python (pythonw.exe) in the Windows firewall for "
                          "private networks, and check that your home network is set to Private.")
        finished = st["state"] in ("STOPPED", "NO_MEDIA_PRESENT") and self.played
        if not finished:
            if st["state"] in ("STOPPED", "NO_MEDIA_PRESENT") and time.time() - self.started > 45:
                self.error = "The TV didn't start the video. If it's CastApp TV, open it once on the TV; also allow AniBox in the Windows firewall (private networks)."
                self._end("the TV never played")
            return
        near_end = self.dur and self.pos >= self.dur - END_SLACK
        if not near_end:
            self._end("stopped on the TV")
            return
        self.pos = self.dur
        self._save(True)
        nxt = self._neighbour(1)
        if self.sleep_mode == "episode":
            self.sleep_mode, self.sleep_label = None, ""
            self._end("sleep timer")
        elif nxt and self.store.settings().get("autoplay", True):
            self._load(nxt, 0.0)
        else:
            self._end("last episode finished")

    def state(self) -> dict:
        show = self.library.show(self.show_id) if self.show_id else None
        ep = None
        if show:
            _, idx = self.library.episode(self.key)
            ep = show["episodes"][idx] if idx >= 0 else None
        active = self.active and bool(ep)
        out = {
            "active": active, "target": "tv", "device": self.renderer.name if self.renderer else "",
            "stage": "playing" if active else "idle", "showId": self.show_id,
            "malId": (show or {}).get("mal_id") or "" if (show or {}).get("picture") else "",
            "key": self.key, "title": show["title"] if show else "",
            "kicker": f"On {self.renderer.name}" if active else "", "sub": ep["label"] if ep else "",
            "pos": round(self.pos, 1), "dur": round(self.dur, 1),
            "paused": self.tv_state != "PLAYING", "volume": 100, "muted": False,
            "hasPrev": bool(self._neighbour(-1)) if active else False,
            "hasNext": bool(self._neighbour(1)) if active else False,
            "countdown": 0,
            "sleep": {"active": bool(self.sleep_mode), "label": self.sleep_label,
                      "remaining": max(0, round(self.sleep_until - time.time())) if self.sleep_mode == "minutes" else 0},
            "still": {"stage": "", "next": ""}, "listVersion": self.list_version, "showIdle": "",
            "tracks": {"audio": [], "sub": []}, "subOff": False, "skip": None,
            "error": self.error, "mpv": True, "tvState": self.tv_state,
        }
        if show:
            progress = self.store.all_progress()
            out["count"] = len(show["episodes"])
            out["seen"] = sum(1 for e in show["episodes"] if (progress.get(e["key"]) or {}).get("watched"))
        return out
