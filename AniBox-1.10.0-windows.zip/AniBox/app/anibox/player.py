"""Plays episodes with mpv and keeps track of them (resume, watched, next episode).

mpv runs in its own window and is remote-controlled through its JSON IPC (a named pipe on
Windows, a Unix socket elsewhere). All talking to mpv happens under one lock, one request at a
time, which keeps Windows pipes happy.

Frostbox features carried over:
- resume a little before where you stopped (default 10 s), watched at 95 %
- automatic next episode after a short countdown
- "Still watching?" after a few episodes in a row without touching anything
- sleep timer (minutes, or "end of this episode"), phone remote
"""

from __future__ import annotations

import json
import logging
import os
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path
from typing import List, Optional

from .languages import lang, subtype
from .stream import PREFIX as STREAM_PREFIX
from .watching import next_up, resume_from

log = logging.getLogger("anibox.player")

IS_WINDOWS = sys.platform.startswith("win")
TICK = 0.5
SAVE_EVERY = 5.0
INPUT_CONF = "N script-message anibox-next\nP script-message anibox-prev\nS script-message anibox-skip\n"
# Inside the AniBox window, "full screen" belongs to the window: these keys tell the page instead.
EMBED_INPUT_CONF = "f script-message anibox-zoom\nMBTN_LEFT_DBL script-message anibox-zoom\nESC script-message anibox-esc\n"

# Chapter names used for openings and endings (fansub and Blu-ray releases, English and German).
OPENING_RE = re.compile(r"^\s*(op(ening)?|intro|vorspann)(\b|\s*\d)", re.I)
ENDING_RE = re.compile(r"^\s*(ed|ending|outro|credits|end credits|abspann)(\b|\s*\d)", re.I)
LANG_RE = re.compile(r"^[a-z]{2,3}(-[a-z0-9]{2,8})?$", re.I)


def clean_langs(text: str) -> str:
    """"jpn, ger" -> "jpn,ger"; anything that isn't a language code is dropped."""
    parts = [p.strip().lower() for p in re.split(r"[,;\s]+", text or "") if p.strip()]
    return ",".join(p for p in parts if LANG_RE.match(p))


def skip_segments(chapters: list, duration: float) -> list:
    """[(kind, start, end)] for chapters named like an opening or ending."""
    out = []
    for i, ch in enumerate(chapters or []):
        title = str(ch.get("title") or "")
        start = float(ch.get("time") or 0)
        end = float(chapters[i + 1].get("time") or 0) if i + 1 < len(chapters) else float(duration or 0)
        kind = "opening" if OPENING_RE.match(title) else "ending" if ENDING_RE.match(title) else ""
        if kind and end - start >= 10:  # very short "chapters" are markers, not songs
            out.append((kind, start, end))
    return out


def track_json(t: dict) -> dict:
    bits = [t.get("lang") or "", t.get("title") or ""]
    label = " · ".join(b for b in bits if b) or f"Track {t.get('id')}"
    extra = []
    if t.get("codec"):
        extra.append(str(t["codec"]).upper().replace("SUBRIP", "SRT"))
    if t.get("forced"):
        extra.append("forced")
    if t.get("external"):
        extra.append("file")
    return {"id": t.get("id"), "lang": t.get("lang") or "", "label": label, "info": ", ".join(extra),
            "selected": bool(t.get("selected"))}


class MpvGone(Exception):
    """mpv was closed or stopped answering."""


class _Ipc:
    def __init__(self, address: str):
        self.address = address
        self._buf = b""
        self._id = 0
        self.events: List[dict] = []
        if IS_WINDOWS:
            self._f = open(address, "r+b", buffering=0)
            self._sock = None
        else:
            self._sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            self._sock.settimeout(5)
            try:
                self._sock.connect(address)
            except OSError:
                self._sock.close()
                raise
            self._f = None

    def close(self) -> None:
        try:
            if self._sock:
                self._sock.close()
            if self._f:
                self._f.close()
        except OSError:
            pass

    def _write(self, data: bytes) -> None:
        try:
            if self._sock:
                self._sock.sendall(data)
            else:
                self._f.write(data)
        except OSError as exc:
            raise MpvGone(str(exc)) from exc

    def _readline(self) -> bytes:
        while b"\n" not in self._buf:
            try:
                chunk = self._sock.recv(65536) if self._sock else self._f.read(65536)
            except (OSError, socket.timeout) as exc:
                raise MpvGone(str(exc)) from exc
            if not chunk:
                raise MpvGone("mpv closed the connection")
            self._buf += chunk
        line, self._buf = self._buf.split(b"\n", 1)
        return line

    def request(self, command) -> dict:
        self._id += 1
        rid = self._id
        self._write(json.dumps({"command": command, "request_id": rid}).encode("utf-8") + b"\n")
        while True:
            line = self._readline()
            if not line.strip():
                continue
            try:
                obj = json.loads(line.decode("utf-8", "replace"))
            except ValueError:
                continue
            if obj.get("request_id") == rid:
                return obj
            if "event" in obj:
                self.events.append(obj)


def find_mpv(configured: str, data_dir: Path) -> Optional[str]:
    """mpv from the settings, the one AniBox downloaded, the PATH, or a usual install folder."""
    candidates = [configured] if configured else []
    candidates.append(str(data_dir.parent / "mpv" / ("mpv.exe" if IS_WINDOWS else "mpv")))
    for name in ("mpv.exe", "mpv") if IS_WINDOWS else ("mpv",):
        found = shutil.which(name)
        if found:
            candidates.append(found)
    if IS_WINDOWS:
        for base in (os.environ.get("ProgramFiles", r"C:\Program Files"), os.environ.get("LOCALAPPDATA", "")):
            if base:
                candidates += [os.path.join(base, "mpv", "mpv.exe"), os.path.join(base, "Programs", "mpv", "mpv.exe")]
    for c in candidates:
        if c and os.path.isfile(c):
            return c
    return None


class Player:
    def __init__(self, store, library, data_dir: Path, mpv_args: Optional[List[str]] = None):
        self.store = store
        self.library = library
        self.data_dir = data_dir
        self.extra_args = list(mpv_args or [])
        self._io = threading.RLock()
        self._ipc: Optional[_Ipc] = None
        self._proc: Optional[subprocess.Popen] = None
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self.error = ""
        self._reset_playback()
        self.sleep_mode = None  # None, "minutes" or "episode"
        self.sleep_until = 0.0
        self.sleep_label = ""
        self.embed_wid = lambda: None  # set by the App: the place in the AniBox window for mpv (embed.py)
        self.streams = None  # set by the App: Internet Archive videos played from archive.org (stream.py)

    def _reset_playback(self) -> None:
        self.show_id = ""
        self.key = ""
        self.pos = 0.0
        self.dur = 0.0
        self.paused = False
        self.volume = 100.0
        self.muted = False
        self.stage = "idle"  # idle, playing, countdown, still, ended
        self.countdown_until = 0.0
        self.auto_count = 0
        self.last_saved = 0.0
        self.expected_pos = None
        self.list_version = 0
        self.tracks_for = ""  # the episode whose tracks/chapters were read
        self.tracks = {"audio": [], "sub": []}
        self.aid = None
        self.sid = None
        self.segments = []  # (kind, start, end) of openings/endings
        self.skipped = set()  # segment starts already skipped automatically
        self.skip = None  # {"kind", "to"} while inside an opening/ending
        self.embedded_wid = None  # where the running mpv draws (None = its own window)
        self.ui_event = {"n": 0, "kind": ""}  # zoom/esc pressed inside the video, for the page

    # -- mpv process -------------------------------------------------------------------------------

    @property
    def running(self) -> bool:
        return self._proc is not None and self._proc.poll() is None and self._ipc is not None

    def mpv_path(self) -> Optional[str]:
        return find_mpv(self.store.settings().get("mpv_path", ""), self.data_dir)

    def _start_mpv(self) -> None:
        exe = self.mpv_path()
        if not exe:
            raise RuntimeError("mpv isn't installed yet. Open Settings → Player and click \"Download mpv\".")
        tag = f"anibox-mpv-{os.getpid()}-{int(time.time() * 1000) % 100000}"
        address = rf"\\.\pipe\{tag}" if IS_WINDOWS else os.path.join(tempfile.gettempdir(), tag + ".sock")
        conf = self.data_dir / "mpv-input.conf"
        wid = self.embed_wid()
        conf.write_text(INPUT_CONF + (EMBED_INPUT_CONF if wid else ""), encoding="utf-8")
        args = [exe, "--idle=yes", "--force-window=yes", "--keep-open=yes", f"--input-ipc-server={address}",
                f"--input-conf={conf}", "--title=AniBox"]
        if wid:
            args.append(f"--wid={wid}")  # draw inside the AniBox window
        elif self.store.settings().get("fullscreen"):
            args.append("--fullscreen")
        args += self.extra_args
        flags = subprocess.CREATE_NO_WINDOW if IS_WINDOWS else 0
        log.info("Starting mpv: %s", exe)
        if self.store.settings().get("mpv_log"):  # detailed player log, for hunting problems
            mpv_log = self.data_dir / "logs" / "mpv.log"
            mpv_log.parent.mkdir(exist_ok=True)
            args.append(f"--log-file={mpv_log}")
        self._proc = subprocess.Popen(args, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                      stderr=subprocess.DEVNULL, creationflags=flags)
        deadline = time.time() + 15
        while time.time() < deadline:
            if self._proc.poll() is not None:
                log.error("mpv closed right after starting (exit code %s)", self._proc.returncode)
                raise RuntimeError("mpv closed right after starting. Check the mpv path in Settings.")
            try:
                self._ipc = _Ipc(address)
                self.embedded_wid = wid
                try:
                    log.info("mpv is ready (%s)%s", self._get("mpv-version"), " inside the AniBox window" if wid else "")
                except MpvGone:
                    pass
                return
            except OSError:
                time.sleep(0.15)
        self._kill()
        log.error("mpv didn't open its control connection within 15 s (%s)", address)
        raise RuntimeError("mpv didn't answer. Try again, or check the mpv path in Settings.")

    def _kill(self) -> None:
        if self._ipc:
            self._ipc.close()
        self._ipc = None
        self.embedded_wid = None
        if self._proc and self._proc.poll() is None:
            try:
                self._proc.terminate()
                self._proc.wait(3)
            except (OSError, subprocess.TimeoutExpired):
                try:
                    self._proc.kill()
                except OSError:
                    pass
        self._proc = None

    def _req(self, *command):
        if not self._ipc:
            raise MpvGone("not running")
        return self._ipc.request(list(command) if len(command) != 1 or not isinstance(command[0], dict) else command[0])

    def _get(self, prop: str):
        r = self._req("get_property", prop)
        return r.get("data") if r.get("error") == "success" else None

    def _set(self, prop: str, value) -> None:
        self._req("set_property", prop, value)

    def _osd(self, text: str, ms: int = 3000) -> None:
        self._req("show-text", text, ms)

    # -- playing -----------------------------------------------------------------------------------

    def lookup(self, key: str):
        """(show, index) of an episode key: the library's, or for "ia:" keys an Internet Archive item's."""
        if key.startswith(STREAM_PREFIX) and self.streams:
            return self.streams.episode(key)
        return self.library.episode(key)

    def show_of(self, show_id: str):
        if show_id.startswith(STREAM_PREFIX) and self.streams:
            return self.streams.show(show_id)
        return self.library.show(show_id)

    def _episode(self, key: str):
        show, idx = self.lookup(key)
        if not show or idx < 0:
            raise RuntimeError("That episode isn't in the library any more. Scan again in Settings.")
        return show, idx

    def _load(self, key: str, start: float, paused: bool = False) -> None:
        show, idx = self._episode(key)
        ep = show["episodes"][idx]
        if self.key and self.key != key:
            self._save()
        self._apply_track_prefs(show["id"])
        options = f"start={start:.1f}" if start > 0 else ""
        if show.get("stream"):  # straight from archive.org (stream.py)
            options = ",".join(x for x in (options, self.streams.mpv_options(key)) if x)
        cmd = {"name": "loadfile", "url": ep["path"], "flags": "replace"}
        if options:
            cmd["options"] = options
        r = self._req(cmd)
        if r.get("error") not in ("success", None):
            raise RuntimeError(f"mpv couldn't open the file ({r.get('error')}).")
        if show.get("stream") and self.streams:
            self.streams.played(show, idx)  # e.g. the cache loads the next episodes ahead
        title = f"{show['title']} · {ep['label']}"
        self._set("force-media-title", title)
        self._set("pause", bool(paused))
        self.show_id, self.key = show["id"], key
        self.pos, self.dur = start, 0.0
        self.paused = paused
        self.last_saved = time.time()
        self.expected_pos = None
        self.stage = "still" if paused else "playing"
        self.list_version += 1
        self.tracks_for, self.tracks, self.segments, self.skipped, self.skip = "", {"audio": [], "sub": []}, [], set(), None
        self.store.save_position(key, show["id"], start, 0)
        log.info("Playing %s · %s", show["title"], ep["label"])

    def _apply_track_prefs(self, show_id: str) -> None:
        """Preferred languages (this show's last choice first), set before the file opens."""
        s = self.store.settings()
        pref = self.store.show_pref(show_id)
        alang = clean_langs(",".join(x for x in (pref["audio"], s.get("audio_langs", "")) if x))
        sub_pref = pref["sub"]
        slang = clean_langs(",".join(x for x in ("" if sub_pref == "no" else sub_pref, s.get("sub_langs", "")) if x))
        mode = s.get("subs") or "auto"
        for prop, value in (("alang", alang), ("slang", slang),
                            ("sid", "no" if mode == "off" or sub_pref == "no" else "auto"),
                            ("subs-fallback", "yes" if mode == "on" else "default")):
            try:
                self._req("set_property", prop, value)
            except MpvGone:
                raise
            except Exception:  # an older mpv without this option: keep going
                pass

    def _read_tracks(self) -> None:
        tracks = self._get("track-list") or []
        self.tracks = {
            "audio": [track_json(t) for t in tracks if t.get("type") == "audio"],
            "sub": [track_json(t) for t in tracks if t.get("type") == "sub"],
        }
        self.segments = skip_segments(self._get("chapter-list") or [], self.dur)
        self.tracks_for = self.key
        audio = {lang(t["lang"]) for t in self.tracks["audio"]} - {""}
        subs = {lang(t.get("lang") or "") for t in tracks if t.get("type") == "sub" and not t.get("forced")} - {""}
        types = {subtype(t.get("codec") or "") for t in tracks if t.get("type") == "sub"} - {""}
        if audio or subs or types:
            known = (self.store.all_show_langs().get(self.show_id) or {}).get("subtypes") or []
            if not types and "hard" in known:
                types = {"hard"}  # no subtitle tracks: keep "burned in" if that was found before
            self.store.set_show_langs(self.show_id, audio, subs, "player", types)
        if self.segments:
            log.info("Chapters to skip: %s", ", ".join(f"{k} {a:.0f}-{b:.0f}s" for k, a, b in self.segments))

    def _set_track(self, kind: str, value) -> None:
        """Pick an audio or subtitle track (or "no" subtitles) and remember the language for this show."""
        prop = "aid" if kind == "audio" else "sid"
        if value in ("no", None, "", False):
            if kind == "audio":
                raise RuntimeError("Pick an audio track.")
            self._set("sid", "no")
            self.store.set_show_pref(self.show_id, sub="no")
            return
        tid = int(value)
        track = next((t for t in self.tracks[kind] if t["id"] == tid), None)
        if track is None:
            raise RuntimeError("That track isn't in this episode.")
        self._set(prop, tid)
        if track["lang"]:
            self.store.set_show_pref(self.show_id, **({"audio": track["lang"]} if kind == "audio" else {"sub": track["lang"]}))

    def play(self, show_id: str = "", key: str = "", from_start: bool = False) -> None:
        """Play an episode (or the show's next episode) and remember it as user activity."""
        settings = self.store.settings()
        if (key or show_id).startswith(STREAM_PREFIX) and self.streams:
            self.streams.prepare(key or show_id, show_id=show_id)  # the item's videos from archive.org (once)
        if not key:
            show = self.show_of(show_id)
            if not show:
                raise RuntimeError("Show not found. Scan again in Settings.")
            ep, _ = next_up(show, self.store.all_progress())
            if not ep:
                ep = show["episodes"][0]
            key = ep["key"]
            if show.get("stream") and self.streams:
                self.streams.prepare(key, show_id=show_id)  # a playlist: next/previous follow it
        p = self.store.progress(key) or {}
        start = 0.0 if from_start or p.get("watched") else resume_from(
            float(p.get("position") or 0), float(p.get("duration") or 0), int(settings.get("resume_back", 10)))
        with self._io:
            self.error = ""
            if self.running and self.embed_wid() != self.embedded_wid:
                # Inside the window now, or not anymore: start mpv again in the right place.
                if self.key:
                    self._save()
                self._kill()
            if not self.running:
                self._kill()
                self._start_mpv()
            self._load(key, start)
            self.auto_count = 0
            self.touch()
        self._ensure_thread()

    def _neighbour(self, step: int) -> Optional[str]:
        if not self.key:
            return None
        show, idx = self.lookup(self.key)
        if not show or idx < 0:
            return None
        j = idx + step
        return show["episodes"][j]["key"] if 0 <= j < len(show["episodes"]) else None

    def touch(self) -> None:
        """Someone used AniBox (window, phone, mpv keys): reset the "still watching" counter."""
        self.auto_count = 0

    def command(self, cmd: str, value=None, ident=None) -> None:
        if cmd == "play-episode":
            self.play(key=str(ident or value))
            return
        if cmd == "resume":
            recent = self.store.recent_shows(1)
            if not recent:
                raise RuntimeError("Nothing to continue yet.")
            self.play(show_id=recent[0])
            return
        if cmd == "sleep-set":
            minutes = int(value or 0)
            if minutes < 0:
                self.sleep_mode, self.sleep_until, self.sleep_label = "episode", 0.0, "end of this episode"
            else:
                self.sleep_mode, self.sleep_until, self.sleep_label = "minutes", time.time() + 60 * minutes, f"{minutes} min"
            self.touch()
            return
        if cmd == "sleep-stop":
            self.sleep_mode, self.sleep_label = None, ""
            return
        with self._io:
            if not self.running:
                raise RuntimeError("Nothing is playing.")
            self.touch()
            if cmd == "play-pause":
                self._set("pause", not self.paused)
                self.paused = not self.paused
                if self.stage == "still" and not self.paused:
                    self.stage = "playing"
            elif cmd == "seek-rel":
                self._req("seek", float(value or 0), "relative")
                self.expected_pos = None
            elif cmd == "seek-to":
                self._req("seek", float(value or 0), "absolute")
                self.expected_pos = None
            elif cmd in ("next", "prev"):
                key = self._neighbour(1 if cmd == "next" else -1)
                if not key:
                    raise RuntimeError("There's no " + ("next" if cmd == "next" else "previous") + " episode.")
                self._load(key, 0.0)
            elif cmd == "volume":
                self._set("volume", max(0, min(130, float(value or 0))))
            elif cmd == "mute":
                self._set("mute", not self.muted)
            elif cmd in ("audio", "sub"):
                if self.tracks_for != self.key:
                    self._read_tracks()
                self._set_track(cmd, value if value is not None else ident)
            elif cmd == "skip":
                if not self.skip:
                    raise RuntimeError("There's no opening or ending to skip right now.")
                self._skip_to(self.skip["to"], self.skip["kind"])
            elif cmd == "still-continue":
                self._set("pause", False)
                self.paused = False
                self.stage = "playing"
            elif cmd in ("still-stop", "stop"):
                self.stop_locked()
            else:
                raise RuntimeError(f"Unknown command: {cmd}")

    def _skip_to(self, to: float, kind: str) -> None:
        self._req("seek", max(0.0, float(to)), "absolute")
        self.expected_pos = None
        self.skip = None
        self._osd(f"Skipped the {kind}", 1500)

    def stop(self) -> None:
        with self._io:
            self.stop_locked()

    def stop_locked(self) -> None:
        self._save()
        try:
            if self._ipc:
                self._req("quit")
        except MpvGone:
            pass
        self._kill()
        self._reset_playback()

    def shutdown(self) -> None:
        self._stop.set()
        self.stop()

    # -- background loop -------------------------------------------------------------------------

    def _ensure_thread(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True, name="anibox-player")
        self._thread.start()

    def _loop(self) -> None:
        while not self._stop.is_set():
            with self._io:
                if self._proc is None:
                    break
                try:
                    self.tick()
                except MpvGone as exc:
                    code = self._proc.poll() if self._proc else None
                    log.info("mpv closed (%s, exit code %s)", exc, code)
                    self._save()
                    self._kill()
                    self._reset_playback()
                    break
                except Exception as exc:  # keep the loop alive, show the problem
                    if str(exc) != self.error:
                        log.exception("Player problem")
                    self.error = str(exc)
            time.sleep(TICK)

    def _save(self) -> None:
        if not self.key:
            return
        settings = self.store.settings()
        watched = None
        if self.dur > 0 and self.pos >= self.dur * float(settings.get("watched_at", 95)) / 100:
            watched = True
        self.store.save_position(self.key, self.show_id, self.pos, self.dur, watched)
        self.last_saved = time.time()

    def tick(self) -> None:
        """One look at mpv: position, end of episode, next episode, timers."""
        if self._proc is not None and self._proc.poll() is not None:
            raise MpvGone("mpv closed")
        settings = self.store.settings()
        pos = self._get("time-pos")
        dur = self._get("duration")
        paused = bool(self._get("pause"))
        eof = bool(self._get("eof-reached"))
        vol = self._get("volume")
        mute = self._get("mute")
        for ev in self._ipc.events:
            if ev.get("event") == "client-message":
                args = ev.get("args") or []
                if args[:1] in (["anibox-zoom"], ["anibox-esc"]):
                    self.ui_event = {"n": self.ui_event["n"] + 1, "kind": args[0][len("anibox-"):]}
                    continue
                if args[:1] == ["anibox-skip"]:
                    self.touch()
                    if self.skip:
                        self._skip_to(self.skip["to"], self.skip["kind"])
                    else:
                        self._osd("Nothing to skip here")
                    continue
                if args[:1] == ["anibox-next"] or args[:1] == ["anibox-prev"]:
                    step = 1 if args[0] == "anibox-next" else -1
                    key = self._neighbour(step)
                    self.touch()
                    if key:
                        self._load(key, 0.0)
                        self._ipc.events.clear()
                        return
                    self._osd("No " + ("next" if step == 1 else "previous") + " episode")
            if ev.get("event") == "end-file" and ev.get("reason") == "error" and self.key.startswith(STREAM_PREFIX):
                self.error = "The video didn't load from archive.org. Try again in a minute."
                log.info("Stream didn't load: %s (%s)", self.key, ev.get("file_error") or "?")
        self._ipc.events.clear()
        if vol is not None:
            self.volume = float(vol)
        if mute is not None:
            self.muted = bool(mute)
        if pos is not None:
            # A jump that playback alone can't explain means someone seeked in mpv.
            if self.expected_pos is not None and abs(pos - self.expected_pos) > 4:
                self.touch()
            self.pos = float(pos)
            self.expected_pos = self.pos + (0 if paused else TICK)
        if dur:
            self.dur = float(dur)
        if paused != self.paused and self.stage == "playing" and not eof:
            self.touch()  # paused or unpaused in the mpv window (mpv also pauses itself at the end)
        self.paused = paused
        if self.stage == "still" and not paused:
            self.stage = "playing"
            self.touch()
        if self.stage == "ended" and not eof and not paused:
            self.stage = "playing"  # seeked back and played again after the end

        if self.key and time.time() - self.last_saved >= SAVE_EVERY and not paused:
            self._save()

        # Tracks and chapters, once per episode (as soon as the file is open)
        if self.key and self.tracks_for != self.key and self.dur > 0:
            self._read_tracks()
        if self.tracks_for == self.key:
            aid, sid = self._get("aid"), self._get("sid")
            if aid != self.aid or sid != self.sid:
                self.aid, self.sid = aid, sid
                for kind, cur in (("audio", aid), ("sub", sid)):
                    for t in self.tracks[kind]:
                        t["selected"] = t["id"] == cur

        # Opening/ending: show "Skip", or skip by itself if that's switched on
        self.skip = None
        if self.segments and self.stage == "playing" and pos is not None:
            for kind, start, end in self.segments:
                if start <= self.pos < end - 2:
                    mode = settings.get("skip_openings" if kind == "opening" else "skip_endings") or "button"
                    if mode == "auto" and start not in self.skipped and not paused:
                        self.skipped.add(start)
                        self._skip_to(end, kind)
                    elif mode != "off":
                        self.skip = {"kind": kind, "to": end}
                    break

        # Sleep timer
        if self.sleep_mode == "minutes" and time.time() >= self.sleep_until:
            self.sleep_mode, self.sleep_label = None, ""
            self._set("pause", True)
            self._osd("Sleep timer: paused. Good night!", 8000)

        if eof and self.stage == "playing":
            self.pos = self.dur or self.pos
            self._save()
            self.store.save_position(self.key, self.show_id, 0, self.dur, True)
            nxt = self._neighbour(1)
            if self.sleep_mode == "episode":
                self.sleep_mode, self.sleep_label = None, ""
                self.stage = "ended"
                self._osd("Sleep timer: stopped after this episode.", 8000)
            elif nxt and settings.get("autoplay", True):
                self.stage = "countdown"
                self.countdown_until = time.time() + max(0, int(settings.get("countdown", 8)))
            else:
                self.stage = "ended"
                self._osd("That was the last episode." if not nxt else "Finished.", 5000)
        if self.stage == "countdown":
            nxt = self._neighbour(1)
            left = self.countdown_until - time.time()
            if not nxt:
                self.stage = "ended"
            elif left > 0:
                show, idx = self.lookup(nxt)
                label = show["episodes"][idx]["label"] if show and idx >= 0 else "next episode"
                self._osd(f"Next: {label} in {int(left) + 1} s   ·   Q closes the player", 1200)
            else:
                limit = int(settings.get("still_watching_after", 3))
                self.auto_count += 1
                ask = limit > 0 and self.auto_count >= limit
                self._load(nxt, 0.0, paused=ask)
                if ask:
                    self._osd("Still watching?  Press Space to continue.", 600000)
                else:
                    self.stage = "playing"

    # -- state for the window and the phone ----------------------------------------------------------

    def state(self) -> dict:
        show = self.show_of(self.show_id) if self.show_id else None
        ep = None
        if show:
            _, idx = self.lookup(self.key)
            ep = show["episodes"][idx] if idx >= 0 else None
        active = self.running and bool(ep)
        recent = self.store.recent_shows(1)
        idle_show = self.show_of(recent[0]) if recent else None
        out = {
            "active": active,
            "stage": self.stage if active else "idle",
            "showId": self.show_id,
            "malId": (show or idle_show or {}).get("mal_id") or "" if (show or idle_show or {}).get("picture") else "",
            "key": self.key,
            "title": show["title"] if show else (idle_show["title"] if idle_show else ""),
            "kicker": (show["library"] if show else ""),
            "art": (show or idle_show or {}).get("art") or "",  # Internet Archive streams: the item's picture
            "stream": bool(show and show.get("stream")),
            "sub": ep["label"] if ep else "",
            "pos": round(self.pos, 1),
            "dur": round(self.dur, 1),
            "paused": self.paused,
            "volume": round(self.volume),
            "muted": self.muted,
            "hasPrev": bool(self._neighbour(-1)) if active else False,
            "hasNext": bool(self._neighbour(1)) if active else False,
            "countdown": max(0, round(self.countdown_until - time.time())) if self.stage == "countdown" else 0,
            "embedded": bool(active and self.embedded_wid),
            "uiEvent": self.ui_event,
            "sleep": {
                "active": bool(self.sleep_mode),
                "label": self.sleep_label,
                "remaining": max(0, round(self.sleep_until - time.time())) if self.sleep_mode == "minutes" else 0,
            },
            "still": {"stage": "paused" if active and self.stage == "still" else "", "next": ep["label"] if ep else ""},
            "listVersion": self.list_version,
            "tracks": self.tracks if active else {"audio": [], "sub": []},
            "subOff": active and self.sid in (False, "no", None) and bool(self.tracks["sub"]),
            "skip": self.skip if active else None,
            "showIdle": idle_show["id"] if idle_show else "",
            "error": self.error,
            "mpv": bool(self.mpv_path()),
        }
        if show:
            progress = self.store.all_progress()
            out["count"] = len(show["episodes"])
            out["seen"] = sum(1 for e in show["episodes"] if (progress.get(e["key"]) or {}).get("watched"))
        return out
