"""Download and cache the public anime datasets the report is built from.

No account or API key is needed. Three files are used:

- Fribb/anime-lists ``anime-list-full.json``: links MyAnimeList, AniDB, TVDB, TMDB and IMDb IDs,
  including which TVDB/TMDB season (0 = Specials) and episode offset an entry sits at.
- anime-offline-database (cedya77 fork, weekly, ODbL): titles, type, episode count, year, status,
  and "related anime" links, which the report turns into franchises.

The offline database is about 60 MB, so after downloading it is reduced to a small
``titles-v4.json`` with only the fields the report needs (v3 added alternative titles, which the
folder check uses to recognise folder names; v4 adds the large poster picture for the AniBox app).
"""

from __future__ import annotations

import json
import os
import re
import time
import urllib.request
from pathlib import Path
from typing import Callable, Optional

MAPPING_URL = "https://raw.githubusercontent.com/Fribb/anime-lists/master/anime-list-full.json"
OFFLINE_DB_URL = (
    "https://github.com/cedya77/anime-offline-database/releases/download/latest/"
    "anime-offline-database-minified.json"
)

MAPPING_FILE = "anime-list-full.json"
TITLES_FILE = "titles-v4.json"

MAX_AGE_SECONDS = 7 * 24 * 3600
USER_AGENT = "AniBox-LibraryCheck/0.3"

_MAL_URL_RE = re.compile(r"myanimelist\.net/anime/(\d+)")
_ANIDB_URL_RE = re.compile(r"anidb\.net/anime/(\d+)")


def default_data_dir() -> Path:
    """``<AniBox data folder>/data`` (see home.py)."""
    from .home import home_dir
    return home_dir() / "data"


class DataError(RuntimeError):
    """A dataset is missing, incomplete or not what we expected."""


def _check_mapping(data) -> None:
    if not isinstance(data, list) or not data or not isinstance(data[0], dict):
        raise DataError("anime-list-full.json doesn't look like the anime-lists mapping")


def _check_offline_db(data) -> None:
    if not isinstance(data, dict) or not isinstance(data.get("data"), list) or not data["data"]:
        raise DataError("the anime-offline-database download doesn't look right")


def _download(url: str, dest: Path, log: Callable[[str], None], check: Callable[[object], None]) -> None:
    """Download to ``dest.part``; only replace ``dest`` once the file is complete and valid JSON."""
    log(f"Downloading {url.rsplit('/', 1)[-1]} ...")
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    tmp = dest.with_suffix(dest.suffix + ".part")
    try:
        received = 0
        with urllib.request.urlopen(req, timeout=300) as resp, open(tmp, "wb") as out:
            expected = resp.headers.get("Content-Length")
            while True:
                chunk = resp.read(1 << 20)
                if not chunk:
                    break
                out.write(chunk)
                received += len(chunk)
        if expected and expected.isdigit() and received != int(expected):
            raise DataError(f"download incomplete ({received} of {expected} bytes)")
        try:
            with open(tmp, encoding="utf-8") as fh:
                check(json.load(fh))
        except ValueError as exc:
            raise DataError(f"downloaded file is not valid JSON ({exc})") from exc
        os.replace(tmp, dest)
    finally:
        if tmp.exists():
            tmp.unlink()


def _is_fresh(path: Path) -> bool:
    return path.exists() and (time.time() - path.stat().st_mtime) < MAX_AGE_SECONDS


def reduce_offline_db(raw_path: Path, out_path: Path) -> int:
    """Keep only the fields the report needs, keyed by MAL ID. Returns the number of entries kept."""
    with open(raw_path, encoding="utf-8") as fh:
        raw = json.load(fh)
    titles = {}
    for entry in raw.get("data", []):
        mal_id = anidb_id = None
        for src in entry.get("sources", []):
            m = _MAL_URL_RE.search(src)
            if m:
                mal_id = m.group(1)
            m = _ANIDB_URL_RE.search(src)
            if m:
                anidb_id = m.group(1)
        if not mal_id:
            continue
        related = sorted({m.group(1) for r in entry.get("relatedAnime", []) for m in [_MAL_URL_RE.search(r)] if m})
        duration = (entry.get("duration") or {}).get("value")
        season = entry.get("animeSeason") or {}
        titles[mal_id] = {
            "title": entry.get("title"),
            "type": entry.get("type"),
            "episodes": entry.get("episodes"),
            "status": entry.get("status"),
            "year": season.get("year"),
            "season": season.get("season"),
            "duration": duration,
            "thumbnail": entry.get("thumbnail"),
            "picture": entry.get("picture"),
            "anidb": anidb_id,
            "rel": related,
            "syn": sorted(set(entry.get("synonyms") or []))[:40],
        }
    payload = {
        "source": raw.get("repository"),
        "license": (raw.get("license") or {}).get("name"),
        "lastUpdate": raw.get("lastUpdate"),
        "titles": titles,
    }
    tmp = out_path.with_suffix(".part")
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, ensure_ascii=False, separators=(",", ":"))
    os.replace(tmp, out_path)
    return len(titles)


class Datasets:
    """The datasets, loaded into memory."""

    def __init__(self, mapping: list, titles: dict, titles_meta: Optional[dict] = None):
        self.mapping = mapping
        self.titles = titles
        self.titles_meta = titles_meta or {}

    @classmethod
    def load(cls, data_dir: Path) -> "Datasets":
        try:
            with open(data_dir / MAPPING_FILE, encoding="utf-8") as fh:
                mapping = json.load(fh)
            _check_mapping(mapping)
            with open(data_dir / TITLES_FILE, encoding="utf-8") as fh:
                titles_payload = json.load(fh)
            if not isinstance(titles_payload, dict) or not isinstance(titles_payload.get("titles"), dict):
                raise DataError(f"{TITLES_FILE} doesn't look right")
        except ValueError as exc:
            raise DataError(f"a cached anime list in {data_dir} is damaged ({exc})") from exc
        meta = {k: v for k, v in titles_payload.items() if k != "titles"}
        return cls(mapping, titles_payload["titles"], meta)


def ensure_datasets(
    data_dir: Path,
    refresh: bool = False,
    offline: bool = False,
    log: Callable[[str], None] = print,
) -> Datasets:
    """Make sure all datasets are present and reasonably fresh, then load them.

    Downloads happen only when a file is missing, older than a week, or ``refresh`` is set.
    If a download fails but an older copy exists, the older copy is used. If the cached copy
    turns out to be damaged, everything is downloaded once more.
    """
    data_dir.mkdir(parents=True, exist_ok=True)
    _fetch(data_dir, refresh, offline, log)
    try:
        return Datasets.load(data_dir)
    except (DataError, OSError) as exc:
        if offline:
            raise DataError(f"{exc}. Run once without --offline to download the lists again.") from exc
        log(f"  {exc}; downloading again ...")
        _fetch(data_dir, True, False, log, keep_old=False)
        return Datasets.load(data_dir)


def _fetch(data_dir: Path, refresh: bool, offline: bool, log: Callable[[str], None], keep_old: bool = True) -> None:
    jobs = [
        (MAPPING_URL, data_dir / MAPPING_FILE, None, _check_mapping),
        (OFFLINE_DB_URL, data_dir / "anime-offline-database-minified.json", data_dir / TITLES_FILE, _check_offline_db),
    ]
    for url, raw_path, reduced_path, check in jobs:
        final_path = reduced_path or raw_path
        if offline:
            if not final_path.exists():
                raise FileNotFoundError(
                    f"{final_path.name} is not in {data_dir}. Run once without --offline to download it."
                )
            continue
        if final_path.exists() and _is_fresh(final_path) and not refresh:
            continue
        try:
            _download(url, raw_path, log, check)
            if reduced_path:
                count = reduce_offline_db(raw_path, reduced_path)
                raw_path.unlink(missing_ok=True)
                log(f"  kept {count} titles")
        except Exception as exc:  # network problems, GitHub down, cut-off download ...
            if keep_old and final_path.exists():
                log(f"  download failed ({exc}); using the copy from {time.ctime(final_path.stat().st_mtime)}")
            else:
                raise DataError(f"Could not download {url}: {exc}") from exc
