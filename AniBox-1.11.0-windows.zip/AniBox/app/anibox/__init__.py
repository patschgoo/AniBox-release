"""AniBox: a private player for the anime on your own drives.

Shows your anime folders as a library (matched to MyAnimeList), plays them with mpv, remembers
where you stopped, and tells you which seasons, OVAs, specials and movies are missing. The look
and many features come from Frostbox, Martin's archive.org player (used with permission).
"""

import sys
from pathlib import Path

__version__ = "1.11.0"

# The library matching lives in the Library Check tool next to this app (library-check/).
_CHECK = Path(__file__).resolve().parents[2] / "library-check"
if _CHECK.is_dir() and str(_CHECK) not in sys.path:
    sys.path.append(str(_CHECK))
