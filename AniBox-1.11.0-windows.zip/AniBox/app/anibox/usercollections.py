"""Your own collections of shows: hand-picked ones in your order, and smart ones that fill themselves.

- **Hand-picked:** a name, an optional description and the shows in the order you put them (from any
  library, and Internet Archive series playlists, ``ia:@<id>``). Each entry keeps the show's
  MyAnimeList number, folder and title as well, so a show that moved to another library under the
  same folder name is found again, and one that's gone (a drive that isn't connected) still has a
  name on the page.
- **Smart:** a saved filter, like the Library page's (section, anime type, library, watched state,
  language, title words), plus genres and tags from AniList (only for shows whose AniList extras
  are on this PC, see anilistinfo.py) and a year range, sorted by title, year, recently added or
  recently watched.
- **Cover:** the first show's poster, or a chosen show's poster or AniList banner.

Everything is kept in ``collections.json`` in AniBox's data folder (written as a whole, atomically).
A damaged file is copied aside (``collections.damaged.json``) and AniBox starts with an empty list.
Deleting a collection only deletes the list: never a show, a file or watch progress.
"""

from __future__ import annotations

import copy
import json
import logging
import os
import re
import secrets
import threading
import time
from pathlib import Path
from typing import Callable, List, Optional, Tuple

log = logging.getLogger("anibox.collections")

STATE_FILE = "collections.json"
DAMAGED_FILE = "collections.damaged.json"
KINDS = ("hand", "smart")
SORTS = ("title", "year", "added", "watched")
SORT_LABELS = {"title": "Title", "year": "Year", "added": "Recently added", "watched": "Recently watched"}
SECTIONS = ("", "anime", "series", "movies")
ATYPES = ("", "tv", "movie", "ova", "special", "ona", "music")
WATCHED = ("", "unwatched", "watching", "finished")
LANGS = ("", "ja", "dub-de", "dub-en", "sub-de", "sub-en")
MATCH = ("all", "any")
ID_RE = re.compile(r"^c[0-9a-f]{8}$")
MAX_COLLECTIONS = 500
MAX_ITEMS = 5000
MAX_NAME = 120
MAX_DESCRIPTION = 1000
MAX_WORDS = 20  # genres / tags in one rule


class CollectionError(Exception):
    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.status = status


# -- cleaning what comes from the window (and from the file) ------------------------------------------------

def _text(v, limit: int) -> str:
    return re.sub(r"\s+", " ", str(v or "")).strip()[:limit]


def _year(v) -> Optional[int]:
    try:
        y = int(v)
    except (TypeError, ValueError):
        return None
    return y if 1900 <= y <= 2100 else None


def _words(v) -> List[str]:
    out: List[str] = []
    for w in v if isinstance(v, list) else []:
        w = _text(w, 60)
        if w and w.casefold() not in (x.casefold() for x in out):
            out.append(w)
    return out[:MAX_WORDS]


def clean_rules(r) -> dict:
    """A smart collection's rules with every value checked; unknown values become "any"."""
    r = r if isinstance(r, dict) else {}

    def pick(key, allowed):
        v = str(r.get(key) or "")
        return v if v in allowed else ""

    out = {"kind": pick("kind", SECTIONS), "atype": pick("atype", ATYPES), "library": _text(r.get("library"), 200),
           "watched": pick("watched", WATCHED), "lang": pick("lang", LANGS), "text": _text(r.get("text"), 100),
           "genres": _words(r.get("genres")), "tags": _words(r.get("tags")),
           "match": r.get("match") if r.get("match") in MATCH else "all",
           "yearFrom": _year(r.get("yearFrom")), "yearTo": _year(r.get("yearTo"))}
    if out["atype"] and out["kind"] not in ("", "anime"):
        out["atype"] = ""  # anime types only mean something for anime
    if out["yearFrom"] and out["yearTo"] and out["yearFrom"] > out["yearTo"]:
        out["yearFrom"], out["yearTo"] = out["yearTo"], out["yearFrom"]
    return out


def clean_item(it) -> Optional[dict]:
    """{"id", "mal", "folder", "title"} of a hand-picked entry."""
    if isinstance(it, str):
        it = {"id": it}
    if not isinstance(it, dict):
        return None
    sid = str(it.get("id") or "").strip()
    if not sid or len(sid) > 600:
        return None
    return {"id": sid, "mal": _text(it.get("mal"), 12), "folder": _text(it.get("folder"), 300), "title": _text(it.get("title"), 300)}


def clean_cover(c) -> Optional[dict]:
    if not isinstance(c, dict) or not str(c.get("show") or "").strip():
        return None
    return {"show": str(c["show"]).strip()[:600], "kind": "banner" if c.get("kind") == "banner" else "poster"}


def _clean_collection(d) -> Optional[dict]:
    if not isinstance(d, dict) or not ID_RE.match(str(d.get("id") or "")) or d.get("kind") not in KINDS:
        return None
    name = _text(d.get("name"), MAX_NAME)
    if not name:
        return None
    items, seen = [], set()
    for it in d.get("items") or [] if isinstance(d.get("items"), list) else []:
        it = clean_item(it)
        if it and it["id"] not in seen:
            seen.add(it["id"])
            items.append(it)
    now = time.time()
    return {"id": d["id"], "name": name, "description": _text(d.get("description"), MAX_DESCRIPTION), "kind": d["kind"],
            "items": items[:MAX_ITEMS] if d["kind"] == "hand" else [],
            "rules": clean_rules(d.get("rules")) if d["kind"] == "smart" else {},
            "sort": d.get("sort") if d.get("sort") in SORTS else "title",
            "cover": clean_cover(d.get("cover")), "pinned": bool(d.get("pinned")),
            "created": float(d.get("created") or now) if isinstance(d.get("created"), (int, float)) else now,
            "changed": float(d.get("changed") or now) if isinstance(d.get("changed"), (int, float)) else now}


# -- smart rules ------------------------------------------------------------------------------------------

def _in_section(card: dict, kind: str) -> bool:
    if not kind:
        return True
    return card.get("kind") == kind or (kind == "movies" and card.get("kind") == "movie")


def needs_info(rules: dict) -> bool:
    return bool(rules.get("genres") or rules.get("tags"))


def matches(card: dict, rules: dict, info: Optional[dict]) -> bool:
    """Does a library card (routes_library ``_library()``: kind, atype, library, year, started, finished,
    audio, subs …) fit the rules? ``info``: the show's AniList summary (genres, tags) or None."""
    if not _in_section(card, rules.get("kind", "")):
        return False
    if rules.get("atype") and (card.get("kind") != "anime" or card.get("atype") != rules["atype"]):
        return False
    lib = rules.get("library")
    if lib and card.get("library") != lib and lib not in (card.get("libraries") or []):
        return False
    w = rules.get("watched")
    if w == "unwatched" and card.get("started"):
        return False
    if w == "watching" and not (card.get("started") and not card.get("finished")):
        return False
    if w == "finished" and not card.get("finished"):
        return False
    lang, audio, subs = rules.get("lang"), card.get("audio") or [], card.get("subs") or []
    if lang == "ja" and "ja" not in audio or lang == "dub-de" and "de" not in audio or lang == "dub-en" and "en" not in audio:
        return False
    if lang == "sub-de" and "de" not in subs or lang == "sub-en" and "en" not in subs:
        return False
    y0, y1, year = rules.get("yearFrom"), rules.get("yearTo"), card.get("year")
    if (y0 or y1) and not isinstance(year, int):
        return False
    if y0 and year < y0 or y1 and year > y1:
        return False
    words = [x for x in (rules.get("text") or "").casefold().split() if x]
    if words:
        hay = f"{card.get('title') or ''} {card.get('folder') or ''}".casefold()
        if not all(x in hay for x in words):
            return False
    if needs_info(rules):
        if not info:
            return False
        have = {g.casefold() for g in info.get("genres") or []} | {t.casefold() for t in info.get("tags") or []}
        want = [x.casefold() for x in (rules.get("genres") or []) + (rules.get("tags") or [])]
        hits = [x in have for x in want]
        if not (any(hits) if rules.get("match") == "any" else all(hits)):
            return False
    return True


def sort_cards(cards: List[dict], sort: str) -> List[dict]:
    def title(c):
        return (c.get("title") or "").casefold()

    if sort == "year":
        return sorted(cards, key=lambda c: (not isinstance(c.get("year"), int), c.get("year") or 0, title(c)))
    if sort == "added":
        return sorted(cards, key=lambda c: (-(c.get("added") or 0), title(c)))
    if sort == "watched":
        return sorted(cards, key=lambda c: (not c.get("last_played"), -(c.get("last_played") or 0), title(c)))
    return sorted(cards, key=title)


def apply_rules(cards: List[dict], rules: dict, sort: str, info_for: Callable[[dict], Optional[dict]]) -> Tuple[List[dict], int]:
    """(the cards that fit, sorted; how many cards couldn't be judged because AniBox has no AniList
    extras for them yet and the rules ask for genres or tags)."""
    rules = clean_rules(rules)
    out, unknown = [], 0
    for c in cards:
        info = info_for(c) if needs_info(rules) else None
        if needs_info(rules) and not info:
            # count only anime that would otherwise fit: those are the ones a "Load all" may add
            if c.get("mal_id") and matches(c, dict(rules, genres=[], tags=[]), None):
                unknown += 1
            continue
        if matches(c, rules, info):
            out.append(c)
    return sort_cards(out, sort), unknown


# -- the file ------------------------------------------------------------------------------------------------

class Collections:
    """The collections, kept in ``collections.json``. Methods return copies."""

    def __init__(self, data_dir: Path):
        self.path = Path(data_dir) / STATE_FILE
        self._lock = threading.RLock()
        self._list: List[dict] = []
        self.notice = ""  # for the window: the file was damaged
        self._readonly = False
        self._load()

    def _load(self) -> None:
        try:
            raw = self.path.read_bytes()
        except FileNotFoundError:
            return
        except OSError as exc:
            log.warning("%s couldn't be read (%s)", self.path.name, exc)
            self.notice = "AniBox couldn't read your collections just now. Restart AniBox to try again."
            self._readonly = True
            return
        try:
            data = json.loads(raw.decode("utf-8"))
            lists = data.get("collections") if isinstance(data, dict) else None
            if not isinstance(lists, list):
                raise ValueError("no collections")
        except (ValueError, UnicodeDecodeError) as exc:
            self._keep_damaged(raw, exc)
            return
        bad, seen = 0, set()
        for d in lists:
            c = _clean_collection(d)
            if c and c["id"] not in seen:
                seen.add(c["id"])
                self._list.append(c)
            else:
                bad += 1
        if bad:
            log.warning("%s: %d damaged collection(s) left out", self.path.name, bad)
            self._keep_damaged(raw, None)

    def _keep_damaged(self, raw: bytes, exc) -> None:
        """Copy the damaged file aside, then write what could be read. If the copy fails, the file is left
        alone and nothing is written over it."""
        target = self.path.with_name(DAMAGED_FILE)
        if target.exists():
            target = self.path.with_name(time.strftime("collections.damaged-%Y%m%d-%H%M%S.json"))
        try:
            target.write_bytes(raw)
        except OSError:
            log.warning("The damaged %s couldn't be copied aside; AniBox won't change it", self.path.name, exc_info=True)
            self._readonly = True
            self.notice = ("Your collections file is damaged and AniBox couldn't keep a copy of it, so it doesn't "
                           "change it. Look at collections.json in AniBox's data folder.")
            return
        try:
            self._save()
        except CollectionError:
            pass
        if exc is not None:
            log.warning("%s is damaged (%s); a copy is in %s, starting with no collections", self.path.name, exc, target.name)
            self.notice = (f"Your collections couldn't be read (the file was damaged). AniBox kept a copy as "
                           f"{target.name} in its data folder and started a new list.")
        else:
            self.notice = (f"Some collections were damaged and left out. AniBox kept a copy of the old file as "
                           f"{target.name} in its data folder.")

    def _save(self) -> None:
        if self._readonly:
            raise CollectionError("AniBox couldn't read your collections, so it doesn't change them now. Restart AniBox.")
        data = {"version": 1, "collections": self._list}
        tmp = self.path.with_name(self.path.name + ".tmp")
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
            os.replace(tmp, self.path)
        except OSError as exc:
            log.warning("%s couldn't be saved", self.path.name, exc_info=True)
            raise CollectionError(f"AniBox couldn't save the collections ({exc}).", 500)

    def _get(self, cid: str) -> dict:
        for c in self._list:
            if c["id"] == cid:
                return c
        raise CollectionError("That collection doesn't exist (anymore).", 404)

    def _changed(self, c: dict) -> dict:
        c["changed"] = time.time()
        self._save()
        return copy.deepcopy(c)

    # -- reading ------------------------------------------------------------------------------------------

    def all(self) -> List[dict]:
        with self._lock:
            return copy.deepcopy(self._list)

    def get(self, cid: str) -> dict:
        with self._lock:
            return copy.deepcopy(self._get(cid))

    def containing(self, show_id: str) -> List[dict]:
        with self._lock:
            return [{"id": c["id"], "name": c["name"]} for c in self._list
                    if c["kind"] == "hand" and any(it["id"] == show_id for it in c["items"])]

    # -- changing -------------------------------------------------------------------------------------------

    def create(self, name: str, kind: str = "hand", description: str = "", rules=None, sort: str = "title",
               items=None) -> dict:
        name = _text(name, MAX_NAME)
        if not name:
            raise CollectionError("Give the collection a name.")
        if kind not in KINDS:
            raise CollectionError("A collection is hand-picked or smart.")
        with self._lock:
            if len(self._list) >= MAX_COLLECTIONS:
                raise CollectionError(f"That's {MAX_COLLECTIONS} collections already.")
            cid = "c" + secrets.token_hex(4)
            while any(c["id"] == cid for c in self._list):
                cid = "c" + secrets.token_hex(4)
            now = time.time()
            c = _clean_collection({"id": cid, "name": name, "description": description, "kind": kind,
                                   "items": items or [], "rules": rules, "sort": sort, "created": now, "changed": now})
            self._list.append(c)
            try:
                self._save()
            except CollectionError:
                self._list.remove(c)
                raise
            log.info("Collection made: %s (%s)", c["id"], kind)
            return copy.deepcopy(c)

    def update(self, cid: str, name=None, description=None, rules=None, sort=None, cover=False, pinned=None) -> dict:
        """Change what's given (``cover=None`` goes back to the first show's poster; leave it out to keep it)."""
        with self._lock:
            c = self._get(cid)
            if name is not None:
                name = _text(name, MAX_NAME)
                if not name:
                    raise CollectionError("Give the collection a name.")
                c["name"] = name
            if description is not None:
                c["description"] = _text(description, MAX_DESCRIPTION)
            if rules is not None and c["kind"] == "smart":
                c["rules"] = clean_rules(rules)
            if sort is not None:
                if sort not in SORTS:
                    raise CollectionError("Sort by title, year, recently added or recently watched.")
                c["sort"] = sort
            if cover is not False:
                c["cover"] = clean_cover(cover)
            if pinned is not None:
                c["pinned"] = bool(pinned)
            return self._changed(c)

    def delete(self, cid: str) -> None:
        """Deletes the list only; the shows, files and watch progress stay as they are."""
        with self._lock:
            c = self._get(cid)
            self._list.remove(c)
            try:
                self._save()
            except CollectionError:
                self._list.append(c)
                raise
            log.info("Collection deleted: %s", cid)

    def _hand(self, cid: str) -> dict:
        c = self._get(cid)
        if c["kind"] != "hand":
            raise CollectionError("A smart collection fills itself; change its rules instead.")
        return c

    def add(self, cid: str, item) -> bool:
        """Add a show at the end. False when it's in the collection already."""
        it = clean_item(item)
        if not it:
            raise CollectionError("Pick a show.")
        with self._lock:
            c = self._hand(cid)
            if any(x["id"] == it["id"] for x in c["items"]):
                return False
            if len(c["items"]) >= MAX_ITEMS:
                raise CollectionError(f"A collection holds up to {MAX_ITEMS} shows.")
            c["items"].append(it)
            self._changed(c)
            return True

    def remove(self, cid: str, show_id: str) -> bool:
        with self._lock:
            c = self._hand(cid)
            keep = [x for x in c["items"] if x["id"] != show_id]
            if len(keep) == len(c["items"]):
                return False
            c["items"] = keep
            if c.get("cover") and c["cover"]["show"] == show_id:
                c["cover"] = None
            self._changed(c)
            return True

    def set_order(self, cid: str, ids: list) -> dict:
        """Put the shows in this order. Shows the list doesn't name keep their place after the named ones;
        names that aren't in the collection are ignored."""
        if not isinstance(ids, list) or not all(isinstance(x, str) for x in ids):
            raise CollectionError("Send the shows in their new order.")
        with self._lock:
            c = self._hand(cid)
            by_id = {x["id"]: x for x in c["items"]}
            first = [by_id[i] for i in dict.fromkeys(ids) if i in by_id]
            named = {x["id"] for x in first}
            c["items"] = first + [x for x in c["items"] if x["id"] not in named]
            return self._changed(c)
