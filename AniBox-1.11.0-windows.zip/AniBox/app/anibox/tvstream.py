"""Play on TV for Internet Archive videos and series playlists (stream.py, iaplaylists.py).

Which file the TV gets, and how it reaches the TV, is decided for each video when it starts
(:func:`plan`):

(a) **The whole file is on this PC** (kept, or fully loaded and checked in the cache): AniBox's media
    server (``tv.MediaServer``) serves it like a library episode. Works with every TV, needs no
    internet, and nothing is loaded twice.
(b) **The cache is on** (Settings → Internet Archive streaming): the TV gets an address on this PC
    that relays to the cache's own little server. That server listens on 127.0.0.1 only, which a TV
    can't reach, so this PC passes the TV's byte ranges on (:class:`Relay`). The TV then gets what mpv
    gets: parallel loading, loading ahead, seeks that jump the queue, and the file stays in the cache
    for the next time. Plain http in the home network, so it works with every TV.
(c) **The cache is off** (or the file is bigger than the whole cache): CastApp TV gets archive.org's
    own https address and follows archive.org's redirect itself, as mpv does; nothing goes through
    this PC. Other TVs (the LG TVs, most DLNA TVs) often can't do https, so they get the relay pointed
    at archive.org: http from this PC, https from this PC to archive.org.

The relay passes the Range header on, and status, Content-Range and Content-Length back, nothing
else. It only ever connects to the one address it was made for (the cache's own address, or
archive.org's address of that file) and to archive.org's redirects (the cache sends one when it
can't take a file, e.g. a full disk), never to an address that comes from the TV.

**File type** (:func:`choose_file`), from the file's extension and archive.org's "format": CastApp TV
plays with Media3, which can't open WMV/ASF, Ogg video (Theora) or Blu-ray .m2ts; its
``/castapp/capabilities`` (version 3) say what it decodes and which file types it opens
(``container_mkv`` …; a missing key means "not known", then a built-in table counts). For other TVs
MP4 with H.264 is the safest. When the file won't play (for other TVs: when it isn't the safest kind),
archive.org's MP4 copy of the same episode goes instead (the better-copy rules of iafiles.py link a
copy to its original); progress, watched and next stay with the episode the user played. Without such
a copy AniBox refuses with a sentence that says why.
"""

from __future__ import annotations

import http.client
import logging
import os
import re
import select
import socket
import threading
import urllib.error
import urllib.parse
from typing import Callable, List, Optional, Sequence, Tuple

from . import iafiles, tv
from .iacache import _Conn  # archive.org connections: keep-alive, through a system proxy when one is set up
from .iarchive import USER_AGENT
from .stream import split_key, stream_key

log = logging.getLogger("anibox.tvstream")

LOCAL_TIMEOUT = 120.0  # the cache answers once the part is there (a jump into an unloaded part waits)
REMOTE_TIMEOUT = 30.0
MAX_HOPS = 5
CHUNK = 256 * 1024
SUB_TIMEOUT = 8.0
_RANGE = re.compile(r"\s*bytes\s*=\s*\d*\s*-\s*\d*\s*")
_LOOPBACK = ("127.0.0.1", "localhost", "::1")

# -- what a TV plays -------------------------------------------------------------------------------------

# CastApp TV's capability key for a file type (capabilities version 3, CastApp main 001889a)
_FILE_KEYS = {".mkv": "container_mkv", ".mk3d": "container_mkv", ".webm": "container_webm", ".mp4": "container_mp4",
              ".m4v": "container_mp4", ".mov": "container_mp4", ".avi": "container_avi", ".ts": "container_ts",
              ".m2ts": "container_m2ts", ".mts": "container_m2ts", ".flv": "container_flv",
              ".mpg": "container_mpeg_ps", ".mpeg": "container_mpeg_ps", ".vob": "container_mpeg_ps",
              ".ogv": "container_ogg_video", ".ogg": "container_ogg_video", ".wmv": "container_asf", ".asf": "container_asf"}
# CastApp TV when it doesn't say (older versions): what its player (Media3) reads. It has no reader for
# ASF/WMV, its Ogg reader is for sound only (no Theora video), and its TS reader takes 188-byte packets
# only (Blu-ray .m2ts has 192). The same as CastApp TV 3 answers.
CASTAPP_FILES = {"container_mp4": True, "container_mkv": True, "container_webm": True, "container_ts": True,
                 "container_avi": True, "container_flv": True, "container_mpeg_ps": True,
                 "container_m2ts": False, "container_ogg_video": False, "container_asf": False}
# The video codec from archive.org's "format" (its own words for a file). "MPEG4" alone says nothing
# about the codec (uploaded MP4 files are called that); "512Kb MPEG4" is its old MPEG-4 Part 2 copy.
_FORMAT_CODECS = ((r"h\.?264|\bavc\b", "h264"), (r"h\.?265|\bhevc\b", "hevc"), (r"\bav1\b", "av1"),
                  (r"\bvp9\b", "vp9"), (r"\bvp8\b", "vp8"), (r"512kb mpeg4|divx|xvid|mpeg-?4 part 2", "mpeg4"),
                  (r"mpeg-?2", "mpeg2"), (r"ogg video|theora", "theora"), (r"windows media|\bwmv\b", "wmv"),
                  (r"cinepa", "cinepak"))
# Codecs CastApp TV has no decoder for (none of them is in its capabilities list)
CASTAPP_NO_CODECS = {"theora", "wmv", "cinepak"}
# Other TVs: what most of them can't open at all
OTHER_NO_FILES = {".ogv", ".ogg"}
OTHER_NO_CODECS = {"theora", "cinepak"}


def file_ext(name: str) -> str:
    return os.path.splitext(iafiles.base_name(name))[1].lower()


def video_codec(video: dict) -> str:
    """"h264", "mpeg4", "theora" … from archive.org's format, "" when it doesn't say."""
    fmt = str(video.get("format") or "").lower()
    return next((codec for rx, codec in _FORMAT_CODECS if re.search(rx, fmt)), "")


def verdict(video: dict, castapp: bool, caps: Optional[dict] = None) -> Optional[bool]:
    """Does this TV play the file? True, False, or None (not known: it's sent and tried)."""
    caps = caps or {}
    ext = file_ext(video.get("name") or "")
    codec = video_codec(video)
    if not castapp:
        if ext in OTHER_NO_FILES or codec in OTHER_NO_CODECS:
            return False
        return True if ext in (".mp4", ".m4v") and codec in ("h264", "") else None
    key = _FILE_KEYS.get(ext, "")
    answer = caps.get(key) if isinstance(caps.get(key), bool) else CASTAPP_FILES.get(key)
    if answer is False:
        return False
    if codec:
        hw, sw = caps.get(codec), caps.get(codec + "_sw")
        if hw is False and sw is not True:
            return False
        if not isinstance(hw, bool) and not isinstance(sw, bool) and codec in CASTAPP_NO_CODECS:
            return False
    return answer


def describe(video: dict) -> str:
    """A short name for the kind of file: archive.org's format, else the extension ("WMV file")."""
    fmt = str(video.get("format") or "").strip()
    return fmt or (file_ext(video.get("name") or "")[1:].upper() or "this kind of") + " file"


def _copy_rank(video: dict):
    pixels = int(video.get("width") or 0) * int(video.get("height") or 0)
    return (video_codec(video) != "h264", file_ext(video["name"]) not in (".mp4", ".m4v"), -pixels,
            -int(video.get("size") or 0))


def choose_file(videos: Sequence[dict], video: dict, castapp: bool, caps: Optional[dict] = None,
                tv_name: str = "The TV") -> Tuple[Optional[dict], str]:
    """The file of this episode to send: ``(file, "")``, or ``(None, why)`` when none of its files plays.

    CastApp TV gets the file itself unless it surely can't play it. Other TVs get archive.org's MP4
    (H.264) copy of the episode when there is one, else the file itself unless it surely won't play.
    A replacement is always a copy of the same episode (``iafiles.episode_of``)."""
    own = verdict(video, castapp, caps)
    if own is True or (own is None and castapp):
        return video, ""
    ep = iafiles.episode_of(video)
    others = [v for v in videos if v.get("name") and v["name"] != video.get("name") and iafiles.is_video(v)
              and iafiles.episode_of(v) == ep]
    rated = sorted(((verdict(v, castapp, caps), v) for v in others), key=lambda x: _copy_rank(x[1]))
    best = next((v for ok, v in rated if ok is True), None)
    if best is None and own is None:
        return video, ""  # nothing safer: try the file itself
    if best is None:
        best = next((v for ok, v in rated if ok is None), None)
    if best is not None:
        return best, ""
    name = iafiles.base_name(video.get("name") or "")
    return None, (f"{tv_name} can't play “{name}” ({describe(video)}), and archive.org has no other copy of this "
                  "episode that it can play. Play it on this PC instead.")


# -- how the file reaches the TV ---------------------------------------------------------------------------

def is_cache_address(url: str) -> bool:
    """An address on this PC itself (the cache's server): http to 127.0.0.1, never anywhere else."""
    try:
        u = urllib.parse.urlsplit(url or "")
        return u.scheme == "http" and (u.hostname or "") in _LOOPBACK and u.port is not None and not u.username
    except ValueError:
        return False


def _archive_address(url: str, base: str) -> bool:
    """archive.org (https, its own hosts, the usual port), or the archive address AniBox is set to
    (``ArchiveClient.base``; tests and ANIBOX_IA_BASE use a made-up one)."""
    try:
        u = urllib.parse.urlsplit(url or "")
        b = urllib.parse.urlsplit(base or "")
        if u.username or u.password or not u.hostname:
            return False
        host = u.hostname.lower()
        if u.scheme == "https" and u.port in (None, 443) and (host == "archive.org" or host.endswith(".archive.org")):
            return True
        return bool(b.hostname) and (u.scheme, host, u.port) == (b.scheme, b.hostname.lower(), b.port)
    except ValueError:
        return False


def plan(streams, key: str, castapp: bool, caps: Optional[dict] = None, tv_name: str = "The TV") -> dict:
    """How the Internet Archive video ``key`` goes to the TV.

    Returns ``{"how": "file"|"relay"|"direct", "item", "name" (the file sent), "key" (its key), "video",
    "swapped" (archive.org's copy instead of the file played), "path" (file) or "url" (relay, direct),
    "cache" (relay through the cache)}``. Raises :class:`tv.TvError` ("format") when no file of the
    episode plays on this TV."""
    parts = split_key(key)
    if not parts or not parts[1]:
        raise RuntimeError("That isn't an Internet Archive video.")
    ident, name = parts
    entry = streams.known(ident) or {}
    video = streams.video(ident, name) or {"name": name}
    pick, why = choose_file(entry.get("videos") or [], video, castapp, caps, tv_name)
    if pick is None:
        raise tv.TvError(why, "format")
    chosen = pick["name"]
    out = {"item": ident, "name": chosen, "key": stream_key(ident, chosen), "video": pick, "swapped": chosen != name,
           "cache": False}
    path = streams.local_file(ident, chosen)
    if path:
        # (a) The whole file is on this PC: served from there, like a library episode. Every TV can
        # fetch it (plain http in the home network), and it plays even if archive.org is slow or gone.
        out.update(how="file", path=path)
        return out
    url = streams.url_for(ident, pick)
    if url != streams.client.file_url(ident, chosen) and is_cache_address(url):
        # (b) Through the cache: the TV gets its parallel loading, loading ahead and quick seeks. The
        # cache only answers this PC (127.0.0.1), so AniBox relays it to the TV over plain http.
        out.update(how="relay", url=url, cache=True)
    elif castapp:
        # (c) No cache: CastApp TV plays https and follows archive.org's redirect itself (every jump asks
        # archive.org again, so it never holds a storage server's address that went stale).
        out.update(how="direct", url=url)
    else:
        # (c) No cache, another TV: many can't do https (or archive.org's redirect), so this PC relays
        # archive.org to them over plain http, byte ranges and all.
        out.update(how="relay", url=url)
    return out


def tv_key(streams, key: str, castapp: bool, caps: Optional[dict] = None) -> Optional[str]:
    """The key of the file the TV gets for episode ``key`` (itself, or archive.org's copy), None if none plays."""
    parts = split_key(key)
    if not parts or not parts[1]:
        return None
    entry = streams.known(parts[0]) or {}
    pick, _ = choose_file(entry.get("videos") or [], streams.video(*parts) or {"name": parts[1]}, castapp, caps)
    return stream_key(parts[0], pick["name"]) if pick else None


def tv_view(streams, show: dict, idx: int, castapp: bool, caps: Optional[dict] = None, ahead: int = 4) -> dict:
    """The show as the TV plays it, for the cache's play hook: the episode at ``idx`` and the next few
    carry the key of the file the TV gets (archive.org's copy instead of a file the TV can't play), so
    the cache loads those ahead, not files the TV won't ask for."""
    eps = list(show.get("episodes") or [])
    for i in range(max(0, idx), min(len(eps), idx + 1 + ahead)):
        other = tv_key(streams, eps[i]["key"], castapp, caps)
        if other and other != eps[i]["key"]:
            eps[i] = dict(eps[i], key=other)
    return dict(show, episodes=eps)


# -- subtitle files of an item -------------------------------------------------------------------------------

def item_subtitles(streams, ident: str, names: Sequence[str], langs: Optional[Sequence[str]] = None,
                   prefer_ass: bool = False) -> List[str]:
    """The item's subtitle files that go with the first of ``names`` that has any ("Ep 1.srt",
    "Ep 1.en.srt" for "Ep 1.mkv" or its copy "Ep 1.ia.mp4"), best first like files next to a video
    (``prefer_ass`` as in ``tv.order_subtitles``)."""
    entry = streams.known(ident) or {}
    subs = [s for s in entry.get("subs") or [] if file_ext(s) in tv.SUBTITLE_EXTS]
    for name in names:
        video_stem = iafiles.stem(iafiles.base_name(name))
        mine = {}
        for s in subs:
            base = iafiles.base_name(s)
            if tv._belongs(os.path.splitext(base)[0], video_stem):
                mine.setdefault(base, s)
        if mine:
            return [mine[b] for b in tv.order_subtitles(list(mine), video_stem, langs, prefer_ass)]
    return []


def fetch_subtitle(client, ident: str, name: str) -> bytes:
    """A subtitle file of an item, from archive.org (small; raises OSError/ValueError when it can't)."""
    try:
        with client.open(client.file_url(ident, name), timeout=SUB_TIMEOUT) as resp:
            data = resp.read(tv.MAX_SUBTITLE + 1)
    except (urllib.error.URLError, http.client.HTTPException) as exc:
        raise OSError(str(exc)) from exc
    if len(data) > tv.MAX_SUBTITLE:
        raise ValueError("subtitle file too large")
    return data


# -- the relay --------------------------------------------------------------------------------------------------

class _Upstream:
    """One request to the cache's server (straight, never through a proxy) or to archive.org."""

    def __init__(self, timeout: float):
        self.timeout = timeout
        self.local: Optional[http.client.HTTPConnection] = None
        self.remote: Optional[_Conn] = None

    def get(self, url: str, headers: dict, method: str, local: bool = False):
        self.close()
        if local and is_cache_address(url):
            u = urllib.parse.urlsplit(url)
            self.local = http.client.HTTPConnection(u.hostname, u.port, timeout=self.timeout)
            self.local.request(method, (u.path or "/") + (f"?{u.query}" if u.query else ""), headers=headers)
            resp = self.local.getresponse()
            return resp.status, resp.headers, resp
        self.remote = _Conn(self.timeout)
        return self.remote.get(url, headers, method)

    def abort(self) -> None:
        """From another thread: the TV went away, so a read that waits (for the cache) ends now."""
        sock = getattr(self.local, "sock", None)
        if sock is not None:
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
        if self.remote is not None:
            self.remote.abort()

    def close(self) -> None:
        local, self.local = self.local, None
        remote, self.remote = self.remote, None
        if local is not None:
            try:
                local.close()
            except Exception:
                pass
        if remote is not None:
            remote.close()


def _watch_tv(conn: socket.socket, done: threading.Event, abort: Callable[[], None]) -> None:
    """Ends the upstream read as soon as the TV closes its connection (it jumped elsewhere or stopped),
    so the cache stops waiting for a part nobody wants any more."""
    while not done.is_set():
        try:
            readable, _, _ = select.select([conn], [], [], 0.5)
        except (OSError, ValueError):
            return
        if not readable:
            continue
        try:
            gone = conn.recv(1, socket.MSG_PEEK) == b""
        except BlockingIOError:
            continue
        except (OSError, ValueError):
            gone = True
        if gone and not done.is_set():
            abort()
        return  # gone, or the TV sent something more: nothing left to watch


class Relay:
    """Answers the TV's requests for one video by asking ``url`` for the same bytes (see the module text).

    ``url``: the cache's own address (127.0.0.1) or archive.org's address of the file. ``archive_base``:
    ``ArchiveClient.base``. ``mime``: the type the TV was told. Raises ValueError for any other address."""

    def __init__(self, url: str, archive_base: str, mime: str):
        self.url = url
        self.archive_base = archive_base
        self.mime = mime
        self.local = is_cache_address(url) and not _archive_address(url, archive_base)
        if not self.local and not _archive_address(url, archive_base):
            raise ValueError("The relay only fetches from AniBox's cache or archive.org.")

    def allowed(self, url: str) -> bool:
        """The address it was made for, or archive.org (a redirect). Nothing else, ever."""
        return url == self.url or _archive_address(url, self.archive_base)

    def serve(self, handler, head: bool, count: Callable[[int], None], stopping: threading.Event) -> None:
        rng = (handler.headers.get("Range") or "").strip()
        if rng and not _RANGE.fullmatch(rng):
            rng = ""  # several ranges or another unit: the whole file (as RFC 7233 allows)
        headers = {"User-Agent": USER_AGENT, "Accept-Encoding": "identity"}
        if rng:
            headers["Range"] = rng
        up = _Upstream(LOCAL_TIMEOUT if self.local else REMOTE_TIMEOUT)
        started = False
        url = self.url
        try:
            for _ in range(MAX_HOPS):
                status, rh, resp = up.get(url, headers, "HEAD" if head else "GET", self.local and url == self.url)
                loc = rh.get("Location")
                if not (300 <= status < 400 and loc):
                    break
                nxt = urllib.parse.urljoin(url, loc)
                if not self.allowed(nxt):
                    log.warning("TV relay: not following a redirect to %s", urllib.parse.urlsplit(nxt).hostname)
                    return handler._plain(502)
                url = nxt
            else:
                return handler._plain(502)
            if status in (404, 410):
                return handler._plain(404)
            if status in (429, 503):
                return handler._plain(503, {"Retry-After": rh.get("Retry-After") or "5"})
            if status == 416:
                extra = {"Accept-Ranges": "bytes"}
                if rh.get("Content-Range"):
                    extra["Content-Range"] = rh["Content-Range"]
                return handler._plain(416, extra)
            if status not in (200, 206):
                log.info("TV relay: %s answered %s", urllib.parse.urlsplit(url).hostname, status)
                return handler._plain(502)
            length = (rh.get("Content-Length") or "").strip()
            handler.send_response(status)
            handler.send_header("Content-Type", self.mime)
            if length.isdigit():
                handler.send_header("Content-Length", length)
            if status == 206 and rh.get("Content-Range"):
                handler.send_header("Content-Range", rh["Content-Range"])
            handler.send_header("Accept-Ranges", "bytes")
            handler.send_header("transferMode.dlna.org", "Streaming")
            handler.send_header("contentFeatures.dlna.org", tv.VIDEO_FEATURES)
            handler.send_header("Cache-Control", "no-store")
            handler.send_header("Connection", "close")
            handler.end_headers()
            handler.close_connection = True
            started = True
            if head:
                return
            self._copy(handler, resp, up, int(length) if length.isdigit() else None, count, stopping)
        except (OSError, http.client.HTTPException) as exc:
            if not started:
                log.info("TV relay: %s didn't answer (%s)", urllib.parse.urlsplit(url).hostname, exc)
                try:
                    handler._plain(502)
                except OSError:
                    pass
        finally:
            up.close()

    @staticmethod
    def _copy(handler, resp, up: _Upstream, remaining: Optional[int], count, stopping: threading.Event) -> None:
        handler.connection.settimeout(tv.STREAM_TIMEOUT)
        done = threading.Event()
        threading.Thread(target=_watch_tv, args=(handler.connection, done, up.abort), daemon=True,
                         name="anibox-tv-relay-watch").start()
        try:
            while not stopping.is_set() and (remaining is None or remaining > 0):
                data = resp.read1(CHUNK if remaining is None else min(CHUNK, remaining))
                if not data:
                    break
                handler.wfile.write(data)
                count(len(data))
                if remaining is not None:
                    remaining -= len(data)
        except (OSError, http.client.HTTPException, ValueError):
            pass  # the TV closed the connection (a jump, stop), or the source went away: normal
        finally:
            done.set()
