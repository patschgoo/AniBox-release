/* AniBox window · Settings page: folders, player, languages, MyAnimeList, data, Plex, info files, updates.
   Plain scripts sharing one page: loaded in order by index.html. */
"use strict";

// ---------- Settings
var settingsData = null;
function settings() {
  api("/api/settings").then(function (d) {
    settingsData = d;
    var s = d.settings;
    var libs = Object.keys(d.libraries).sort();
    var chosen = s.libraries.length ? s.libraries : libs;
    var html = '<div class="settings">' +
      '<section class="panel"><h2>Folders</h2><p class="muted">Any folder with videos: a Shield drive (<code>\\\\SHIELD\\…\\NVIDIA_SHIELD</code>), a NAS, a USB disk or a folder on this PC. Choose it with Browse or paste the address from File Explorer. AniBox only reads them.</p>' +
      '<div id="folders">' + s.folders.map(function (f, i) { return '<div class="folder"><span title="' + esc(f) + '">' + esc(f) + '</span><button class="btn small danger" data-rm="' + i + '">Remove</button></div>'; }).join("") + "</div>" +
      '<div class="row" style="margin-top:10px"><input class="input wide" id="newFolder" placeholder="\\\\SHIELD\\…\\NVIDIA_SHIELD" aria-label="Folder to add"><button class="btn" id="browseFolder">Browse …</button><button class="btn" id="addFolder">Add</button>' +
      '<button class="btn primary" id="scanNow"' + (s.folders.length ? "" : " disabled") + ">Scan now</button>" +
      '<button class="btn" id="scanFull" title="Reads every folder again instead of only the ones that changed. Use it when an episode you added doesn\'t show up."' + (s.folders.length ? "" : " disabled") + ">Full rescan</button></div>" +
      '<div id="scanInfo" class="muted" style="margin-top:10px"></div></section>' +
      (libs.length ? '<section class="panel"><h2>Libraries to show</h2><p class="muted">Folders that hold shows. AniBox picked the ones that look like anime; change it here.</p>' +
        libs.map(function (l) {
          var x = d.libraries[l], set = (s.library_kinds || {})[l] || "";
          var names = { anime: "Anime", series: "Series", movies: "Movies" };
          return '<div class="librow"><label class="check"><input type="checkbox" data-lib="' + esc(l) + '"' + (chosen.indexOf(l) >= 0 ? " checked" : "") + "> " + esc(l) + ' <span class="muted">· ' + x.folders + " folders, " + x.matched + " recognized</span></label>" +
            '<select class="input small" data-kind="' + esc(l) + '" title="What this folder holds: decides where it shows in the library (Anime, Series or Movies)">' +
            '<option value=""' + (set ? "" : " selected") + ">Auto (" + names[x.autoKind] + ")</option>" +
            ["anime", "series", "movies"].map(function (k) { return '<option value="' + k + '"' + (set === k ? " selected" : "") + ">" + names[k] + "</option>"; }).join("") + "</select></div>";
        }).join("") + "</section>" : "") +
      '<section class="panel"><h2>Player</h2><div id="mpvBox"></div>' +
      field("Play inside the AniBox window", "Windows: the video plays in the AniBox window (big, small in a corner, filling the window, or full screen) instead of a window of its own. If AniBox can't place it there, it opens in its own window as before." +
        (state && state.embed && state.embed.enabled && state.embed.reason ? " Right now: " + state.embed.reason : ""), sw("embed_player", s.embed_player)) +
      field("Full screen", "Start the player in full screen.", sw("fullscreen", s.fullscreen)) +
      field("Next episode automatically", "After an episode ends, the next one starts by itself.", sw("autoplay", s.autoplay)) +
      field("Countdown before the next episode", "Seconds.", num("countdown", s.countdown)) +
      field("Go back when resuming", "Seconds before the point where you stopped.", num("resume_back", s.resume_back)) +
      field("Counts as watched at", "Percent of an episode.", num("watched_at", s.watched_at)) +
      field("“Still watching?”", "Ask after this many episodes in a row without touching anything (0 = never).", num("still_watching_after", s.still_watching_after)) +
      '<div class="field"><div class="lbl">mpv program<small>Leave empty to use the one AniBox downloads.</small></div><input class="input wide" data-text="mpv_path" value="' + esc(s.mpv_path) + '" placeholder="C:\\…\\mpv.exe"></div>' +
      field("Detailed player log", "Writes mpv's own log to logs\\mpv.log. Only needed when something doesn't play.", sw("mpv_log", s.mpv_log)) +
      field("Chromecasts in Play on TV", "Play on TV also lists Chromecasts and TVs with Google Cast (the Shield has it built in). What they can't play as it is gets repackaged or converted on this PC with ffmpeg.", sw("chromecast", s.chromecast)) +
      "</section>" +
      '<section class="panel"><h2>Audio and subtitles</h2><p class="muted">Language codes like <code>jpn</code> (Japanese), <code>ger</code> or <code>deu</code> (German), <code>eng</code> (English), first choice first. When you pick a track while watching, AniBox remembers it for that show.</p>' +
      field("Audio languages", "For example: jpn,ger", txt("audio_langs", s.audio_langs, "jpn,ger")) +
      field("Subtitle languages", "For example: ger,eng", txt("sub_langs", s.sub_langs, "ger,eng")) +
      field("Subtitles", "Automatic follows the file; On always picks one; Off hides them.", sel("subs", s.subs, [["auto", "Automatic"], ["on", "Always on"], ["off", "Off"]])) +
      field("Openings", "Needs chapters called Opening or OP in the file (most fansub and Blu-ray releases have them).", sel("skip_openings", s.skip_openings, [["button", "Show a Skip button"], ["auto", "Skip by itself"], ["off", "Don't skip"]])) +
      field("Endings", "Skipping the ending goes straight to the next episode.", sel("skip_endings", s.skip_endings, [["button", "Show a Skip button"], ["auto", "Skip by itself"], ["off", "Don't skip"]])) +
      "</section>" +
      '<section class="panel"><h2>MyAnimeList</h2><p class="muted">Optional: descriptions, scores, genres and studios on each show page. Make a free Client ID on myanimelist.net: Profile → Account settings → API → Create ID (App type “other”, any name; App Redirect URL e.g. <code>http://localhost</code>). Copy the Client ID here. AniBox only reads public information with it.</p>' +
      field("Client ID", d.settings.mal_client_id ? "Saved." : "Not set.", '<input class="input wide" data-text="mal_client_id" value="' + esc(s.mal_client_id) + '" placeholder="Client ID" autocomplete="off" spellcheck="false">') +
      "</section>" +
      '<section class="panel"><h2>Phone remote</h2><p class="muted">Control AniBox from your phone over Wi-Fi: play, pause, skip, volume, sleep timer and the episode list. Scan the code with the phone\'s camera. The first time, Windows asks whether Python may use the network; allow it for private networks.</p>' +
      field("Phone remote", "Only works in your home network, only with the secret link.", sw("remote_enabled", s.remote_enabled)) +
      '<div id="remoteBox"></div></section>' +
      '<section class="panel"><h2>Posters</h2>' + field("Show posters", "Loaded once from MyAnimeList's image server and kept on this PC.", sw("posters", s.posters)) + "</section>" +
      '<section class="panel"><h2>Your data</h2>' +
      '<p class="paths">AniBox keeps your settings, watch progress and downloads in <code>' + esc(d.folders.home) + "</code>" + (d.folders.portable ? " (portable mode: next to AniBox.bat)" : "") +
      ". It's a separate folder so that a new AniBox version can replace the program folder without losing anything. Your video files are never changed.</p>" +
      '<div class="row"><button class="btn small" data-open="data">Open data folder</button><button class="btn small" data-open="logs">Open log files</button>' +
      '<a class="btn small" href="/api/backup" download>Back up watch progress</a><label class="btn small" style="cursor:pointer">Restore a backup …<input type="file" id="restore" accept=".json,application/json" hidden></label></div>' +
      '<p class="muted" style="margin-top:12px">AniBox also keeps a copy of your watch progress every day (last 7 days)' + (d.folders.lastBackup ? ", the newest is " + esc(d.folders.lastBackup) : "") + '. <a href="#" data-open="backups">Show them</a></p>' +
      (d.folders.portable ? "" : '<div class="field"><div class="lbl">Portable mode<small>Copies everything into a “data” folder next to AniBox.bat (' + esc(d.folders.portableDir) + "). After a restart AniBox uses that folder. Handy on a USB stick; when you update, copy the data folder over to the new version.</small></div>" +
        '<button class="btn small" id="portable">Copy to the program folder</button></div>') +
      '<div class="field"><div class="lbl">Desktop shortcut<small>Puts an AniBox icon on your desktop (Windows).</small></div><button class="btn small" id="shortcut">Add to desktop</button></div>' +
      '<div class="field" style="display:block"><div class="lbl">Tidy up<small>AniBox\'s own leftovers that aren\'t needed anymore (old launchers, the previous version after an update, old update zips). Your videos, library, progress and settings are never in this list.</small></div><div id="tidy" class="muted">Looking …</div></div>' +
      "</section>" +
      '<section class="panel"><h2>Your Plex library</h2><p class="muted">Copies what you watched in Plex (and where you stopped), and what Plex knows about your shows, into AniBox, matched by file. Plex itself is only read, never changed. AniBox never un-marks anything.</p><div id="plexBox"></div></section>' +
      '<section class="panel"><h2>Protection and episode titles</h2>' +
      field("Lock what's already there", "Episodes that were in your folders before stay locked: AniBox writes nothing for them (no info files) until you unlock a show on its page. New episodes are open. Your video files are never changed either way.", sw("protect_existing", s.protect_existing)) +
      '<div class="row" style="margin:4px 0 14px"><button class="btn small" id="lockNow">Lock everything that\'s there now</button></div>' +
      field("Episode titles and pictures", "Titles you typed into your file names always come first. Otherwise from Kitsu (free, no account) and, for One Piece, pictures from the One Piece Wiki. Only shown in AniBox; files are never renamed.", sw("episode_info", s.episode_info)) +
      "</section>" +
      '<section class="panel"><h2>Info files for Plex and Jellyfin (NFO)</h2><p class="muted">Writes small <code>.nfo</code> files with the MyAnimeList title, description and IDs next to your videos, for Plex\'s new “Plex NFO Series” agent (and Jellyfin/Kodi). Check under Plex Web → Settings → Metadata Agents that your server has it, and try it with a <b>copy of a few folders in a new test library</b> first. AniBox never replaces a file it didn\'t write, never touches protected folders, and Undo removes exactly what it wrote.</p><div id="nfoBox"></div></section>' +
      '<section class="panel"><h2>Updates</h2>' + field("Look for new versions", "Once a day AniBox looks at the release page on GitHub (" + esc(s.release_repo || "") + "). It never downloads or installs anything without a click.", sw("update_check", s.update_check)) +
      '<div class="row"><button class="btn small" id="checkNow">Check now</button><span class="muted" id="updInfo"></span></div>' +
      '<div class="field"><div class="lbl">Update from a file<small>Put the new AniBox zip (AniBox-…-windows.zip) in your Downloads folder, don\'t unpack it, and click Update now. AniBox closes, puts the new version in place and opens again. Your library, progress and settings stay. If the new version doesn\'t start, the old one comes back by itself.</small></div><div id="localUpd" class="muted">Looking …</div></div></section>' +
      '<div id="settingsExtra"></div>' +
      '<section class="panel"><h2>About</h2><p><b>AniBox</b> <span class="muted" id="ver"></span></p>' +
      '<p class="muted">Look and many features come from <b>Frostbox</b> by Martin (used with permission). Anime data: Fribb/anime-lists and anime-offline-database (ODbL). Player: mpv. Fonts: Sora and Inter (SIL Open Font License).</p>' +
      '<button class="btn danger" id="quit">Close AniBox</button></section></div>';
    render(html);
    $("ver").textContent = state ? "version " + state.version : "";
    drawUpdate(d.update);
    drawLocalUpdate();
    drawTidy();
    runPanels(settingsPanels, "settingsExtra");
    drawPlex();
    drawNfo();
    view.querySelectorAll("[data-sel]").forEach(function (x) { x.onchange = function () { save(x.getAttribute("data-sel"), x.value); }; });
    view.querySelectorAll("[data-open]").forEach(function (b) {
      b.onclick = function (e) { e.preventDefault(); post("/api/open", { what: b.getAttribute("data-open") }).catch(fail); };
    });
    $("restore").onchange = function () {
      var f = this.files[0]; if (!f) return;
      f.text().then(function (t) { return post("/api/restore", { backup: JSON.parse(t) }); })
        .then(function (r) { toast("Restored: " + r.episodes + " episodes, " + r.overrides + " matches by hand."); settings(); })
        .catch(function (e) { fail(e.name === "SyntaxError" ? new Error("That file isn't an AniBox backup.") : e); });
    };
    if ($("portable")) $("portable").onclick = function () {
      post("/api/portable").then(function (r) { toast("Copied to " + r.dest + ". Close and start AniBox again to use it."); }).catch(fail);
    };
    $("lockNow").onclick = function () {
      if (!confirm("Lock every episode that is in your folders right now? (Shows you unlocked stay unlocked.)")) return;
      post("/api/lock/now").then(function (r) { toast(r.locked.toLocaleString() + " episodes are locked."); }).catch(fail);
    };
    $("shortcut").onclick = function () { post("/api/shortcut").then(function () { toast("AniBox is on your desktop now."); }).catch(fail); };
    $("checkNow").onclick = function () { $("updInfo").textContent = "Checking …"; post("/api/update/check").then(drawUpdate).catch(fail); };
    drawRemote(d.remote);
    drawMpv();
    drawScan();
    view.querySelectorAll("[data-kind]").forEach(function (sel) {
      sel.onchange = function () {
        var kinds = Object.assign({}, s.library_kinds || {});
        if (this.value) kinds[this.getAttribute("data-kind")] = this.value; else delete kinds[this.getAttribute("data-kind")];
        save("library_kinds", kinds).then(function (r) { s.library_kinds = r.settings.library_kinds; });
      };
    });
    view.querySelectorAll("[data-sw]").forEach(function (b) {
      b.onclick = function () { var k = b.getAttribute("data-sw"), v = !b.classList.contains("on"); save(k, v).then(function () { b.classList.toggle("on", v); }); };
    });
    view.querySelectorAll("[data-num]").forEach(function (inp) { inp.onchange = function () { save(inp.getAttribute("data-num"), Number(inp.value)); }; });
    view.querySelectorAll("[data-text]").forEach(function (inp) { inp.onchange = function () { save(inp.getAttribute("data-text"), inp.value).then(drawMpv); }; });
    view.querySelectorAll("[data-lib]").forEach(function (c) {
      c.onchange = function () {
        var picked = Array.prototype.filter.call(view.querySelectorAll("[data-lib]"), function (x) { return x.checked; }).map(function (x) { return x.getAttribute("data-lib"); });
        save("libraries", picked);
      };
    });
    $("folders").addEventListener("click", function (e) {
      var b = e.target.closest("[data-rm]"); if (!b) return;
      var list = s.folders.slice(); list.splice(Number(b.getAttribute("data-rm")), 1);
      save("folders", list).then(settings);
    });
    $("addFolder").onclick = function () {
      var v = $("newFolder").value.trim().replace(/^"|"$/g, ""); if (!v) return;
      save("folders", s.folders.concat([v])).then(function () { settings(); toast("Folder added. Click “Scan now”."); });
    };
    $("browseFolder").onclick = function () {
      toast("A folder window opens (it may be behind this one) …");
      post("/api/pick-folder").then(function (r) { if (r.path) { $("newFolder").value = r.path; $("addFolder").click(); } }).catch(fail);
    };
    $("newFolder").addEventListener("keydown", function (e) { if (e.key === "Enter") $("addFolder").click(); });
    $("scanNow").onclick = function () { post("/api/scan").then(function () { toast("Scanning your folders …"); poll(); }).catch(fail); };
    $("scanFull").onclick = function () { post("/api/scan", { full: true }).then(function () { toast("Reading every folder again …"); poll(); }).catch(fail); };
    $("quit").onclick = function () { post("/api/quit").then(function () { document.body.innerHTML = '<div class="welcome"><h1>AniBox is closed.</h1><p class="muted">You can close this window.</p></div>'; }).catch(fail); };
  }).catch(fail);
}
function field(label, small, control) { return '<div class="field"><div class="lbl">' + esc(label) + "<small>" + esc(small) + "</small></div>" + control + "</div>"; }
function sw(key, on) { return '<button class="switch' + (on ? " on" : "") + '" data-sw="' + key + '" role="switch" aria-checked="' + (on ? "true" : "false") + '" aria-label="' + key + '"></button>'; }
function txt(key, v, ph) { return '<input class="input" data-text="' + key + '" value="' + esc(v) + '" placeholder="' + esc(ph || "") + '" spellcheck="false">'; }
function sel(key, v, opts) {
  return '<select class="select" data-sel="' + key + '">' + opts.map(function (o) { return '<option value="' + o[0] + '"' + (o[0] === v ? " selected" : "") + ">" + esc(o[1]) + "</option>"; }).join("") + "</select>";
}
function drawPlex() {
  api("/api/plex").then(function (d) {
    var box = $("plexBox"); if (!box) return;
    var im = d.import || {}, html = "";
    if (d.saved) {
      html += '<div class="field"><div class="lbl">Signed in<small>Plex server: ' + esc(d.saved.name) + "</small></div>" +
        '<div class="row"><button class="btn small primary" id="plexImport"' + (im.state === "running" ? " disabled" : "") + ">Import watched episodes</button>" +
        '<button class="btn small" id="plexSign" title="Use another server or account, or fix a sign-in Plex no longer accepts">Sign in again</button></div></div><div id="plexCode"></div>';
    } else {
      html += '<p class="note">' + esc(d.note) + '</p><button class="btn small primary" id="plexSign">Sign in with a code</button><div id="plexCode"></div>';
    }
    if (d.saved) {
      var cp = d.copy || {}, sn = d.snapshot || {};
      html += '<div class="field"><div class="lbl">Copy Plex\'s details into AniBox<small>Titles, descriptions, the MyAnimeList match from the old agent, episode titles and posters, linked to your folders. Only reads from Plex. A backup in case the Shield\'s SD card fails; locked shows keep what was copied.' +
        (sn.fetched ? " Last copy: " + esc(ago(sn.fetched)) + " · " + plural((sn.counts || {}).linked_shows || 0, "show") + ", " + plural((sn.counts || {}).linked_episodes || 0, "episode") + " linked" + (sn.unlinked ? ", " + sn.unlinked + " not linked" : "") + "." : "") +
        '</small></div><button class="btn small" id="plexCopy"' + (cp.state === "running" ? " disabled" : "") + ">" + (sn.fetched ? "Copy again" : "Copy now") + "</button></div>";
      if (cp.state === "running") html += '<p style="color:var(--acc)">' + esc(cp.message || "Working …") + "</p>";
      if (cp.state === "error") html += '<div class="note">' + esc(cp.message) + "</div>";
      if (sn.fetched) html += '<p><a href="#" id="plexDiff">Shows where Plex\'s old match and AniBox\'s match differ</a></p><div id="plexDiffList"></div>';
    }
    if (im.state === "running") html += '<p style="color:var(--acc)">' + esc(im.message || "Working …") + "</p>";
    if (im.state === "error") html += '<div class="note">' + esc(im.message) + "</div>";
    if (im.state === "done") {
      html += "<p>Done: <b>" + im.watched + "</b> episodes newly marked as watched, <b>" + im.positions + "</b> resume points, " + im.already + " already known in AniBox. " +
        im.matched + " of " + im.plex + " Plex files found in your folders.</p>" +
        (im.unmatched ? '<details><summary class="muted">' + im.unmatched + " Plex files not found in the folders AniBox reads</summary><p class=\"muted\">" + im.unmatchedShows.map(esc).join("<br>") + "</p></details>" : "");
    }
    box.innerHTML = html;
    if ($("plexImport")) $("plexImport").onclick = function () { post("/api/plex/import").then(drawPlex).catch(fail); };
    if ($("plexSign")) $("plexSign").onclick = plexSignIn;
    if ($("plexCopy")) $("plexCopy").onclick = function () { post("/api/plex/copy").then(drawPlex).catch(fail); };
    if ($("plexDiff")) $("plexDiff").onclick = function (e) {
      e.preventDefault();
      api("/api/plex/diff").then(function (r) {
        $("plexDiffList").innerHTML = r.items.length ? '<table><thead><tr><th>Folder</th><th>Plex had</th><th>AniBox has</th></tr></thead><tbody>' + r.items.map(function (it) {
          return '<tr><td><a href="#/show/' + encodeURIComponent(it.show) + '">' + esc(it.folder) + "</a></td><td>" + esc(it.plex_mal_title || ("MAL " + it.plex_mal_id)) + "</td><td>" + esc(it.anibox_mal_id ? "MAL " + it.anibox_mal_id : "nothing") + (it.manual ? " (by hand)" : "") + "</td></tr>";
        }).join("") + "</tbody></table>" : '<p class="muted">None: Plex and AniBox agree everywhere.</p>';
      }).catch(fail);
    };
    if (im.state === "running" || (d.copy && d.copy.state === "running")) { clearTimeout(drawPlex.t); drawPlex.t = setTimeout(function () { if (currentPage === "settings") drawPlex(); }, 1500); }
  }).catch(fail);
}
function plexSignIn() {
  post("/api/plex/signin").then(function (r) {
    function show(st) {
      var box = $("plexCode"); if (!box) return;
      if (st.state === "waiting") {
        box.innerHTML = st.step === "server" ? '<p style="color:var(--acc)">' + esc(st.message) + "</p>" :
          '<p>Open <a href="' + esc(st.url) + '" target="_blank" rel="noopener noreferrer">' + esc(st.url) + '</a> and enter this code:</p><div class="score" style="letter-spacing:.2em">' + esc(st.code) + "</div>";
        setTimeout(function () { if (currentPage === "settings") api("/api/plex/poll").then(show).catch(fail); }, 1500);
      } else if (st.state === "done") { toast("Signed in to " + st.server); drawPlex(); }
      else box.innerHTML = '<div class="note">' + esc(st.message || "Sign-in failed.") + "</div>";
    }
    show(r);
  }).catch(fail);
}
function drawNfo() {
  api("/api/nfo").then(function (d) {
    var box = $("nfoBox"); if (!box) return;
    var libs = Object.keys(d.libraries).sort();
    box.innerHTML = '<div class="field"><div class="lbl">Does your Plex have the NFO agent?<small>AniBox asks your Plex server which metadata agents it offers (only reads; needs the Plex sign-in below).</small><div id="agentsOut"></div></div><button class="btn small" id="agentsBtn">Check my Plex</button></div>' +
      '<details class="guide"><summary>Step by step: a safe test library in Plex</summary><ol>' +
      "<li>Make sure your latest Plex database backup is on the USB drive.</li>" +
      "<li>In File Explorer, make a new folder on the same drive, for example <code>NVIDIA_SHIELD\\AniBox NFO test</code>, and <b>copy</b> (don't move) 3 to 5 show folders into it: a normal series, one with season folders, a movie.</li>" +
      "<li>Here in AniBox: Settings → Folders → <b>Scan now</b>. The test folder shows up as its own library; everything in it is new, so nothing is locked.</li>" +
      "<li>Below: tick only the test library → <b>Preview</b> → <b>Write</b>.</li>" +
      "<li>In Plex Web: Add Library → TV Shows → choose the test folder → Advanced: agent <b>Plex NFO Series</b> (or a custom agent with the NFO provider first) and the <b>Plex TV Series</b> scanner.</li>" +
      "<li>Look at titles, descriptions and episode numbers in Plex, and tell Claude what you see.</li>" +
      "<li>If it's good: the same later for a new library over your real anime folder; the old library stays as your backup. If not: delete the test library in Plex and the test folder.</li>" +
      "</ol></details>" +
      field("Protected folders", "Never written into at all, not even for new episodes (any library or folder whose name contains one of these). Separate with commas. Old episodes are locked anyway.",
        '<input class="input wide" id="nfoProt" value="' + esc(d.protected.join(", ")) + '">') +
      '<div class="lbl" style="margin:14px 0 6px">Write for these libraries</div>' +
      libs.map(function (l) { return '<label class="check"><input type="checkbox" data-nfolib="' + esc(l) + '"> ' + esc(l) + ' <span class="muted">· ' + d.libraries[l].folders + " folders</span></label>"; }).join("") +
      '<label class="check" style="margin-top:8px"><input type="checkbox" id="nfoPosters"> Also save the MyAnimeList poster as poster.jpg (only where a folder has none)</label>' +
      '<div class="row" style="margin-top:14px"><button class="btn small" id="nfoPreview">Preview</button><button class="btn small primary" id="nfoWrite" hidden>Write</button>' +
      (d.canUndo ? '<button class="btn small danger" id="nfoUndo">Undo the last writing</button>' : "") + "</div>" +
      '<div id="nfoOut"></div>';
    var token = "";
    $("agentsBtn").onclick = function () {
      $("agentsOut").innerHTML = '<span class="muted">Asking your Plex …</span>';
      api("/api/plex/agents").then(function (r) {
        var verdict = r.nfo ? "Yes: your Plex lists an NFO agent. The test library below is the way to go." :
          r.custom ? "No NFO agent found, but your Plex lists extra metadata providers: AniBox as a provider would be the route." :
          "No NFO agent found in what Plex reports. Please also look in Plex Web → Settings → your server → Metadata Agents.";
        var names = r.agents.concat(r.providers).map(function (x) { return x.name; }).filter(function (v, i, a) { return v && a.indexOf(v) === i; });
        $("agentsOut").innerHTML = '<p style="margin:6px 0">' + esc(verdict) + '</p><p class="muted" style="font-size:12px">Plex reports: ' + esc(names.join(", ") || "nothing") + (r.errors.length ? " · " + esc(r.errors.join("; ")) : "") + "</p>";
      }).catch(function (e) { $("agentsOut").innerHTML = '<span class="muted">' + esc(e.message) + "</span>"; });
    };
    $("nfoProt").onchange = function () {
      var list = this.value.split(",").map(function (x) { return x.trim(); }).filter(Boolean);
      save("protected", list);
    };
    $("nfoPreview").onclick = function () {
      var picked = Array.prototype.filter.call(view.querySelectorAll("[data-nfolib]"), function (x) { return x.checked; }).map(function (x) { return x.getAttribute("data-nfolib"); });
      $("nfoOut").innerHTML = '<p class="muted">Looking at the folders …</p>';
      post("/api/nfo/preview", { libraries: picked, posters: $("nfoPosters").checked }).then(function (r) {
        token = r.token;
        var c = r.counts, todo = (c["new"] || 0) + (c.update || 0);
        $("nfoOut").innerHTML = "<p>" + r.shows + " shows · <b>" + (c["new"] || 0) + "</b> new files, <b>" + (c.update || 0) + "</b> updates of AniBox files, " + (c.same || 0) + " unchanged, " +
          Object.keys(c).filter(function (k) { return k.indexOf("skip") === 0; }).reduce(function (n, k) { return n + c[k]; }, 0) + " skipped (your own or edited files, protected or unmatched folders, files without a number; see the list).</p>" +
          '<pre class="preview">' + esc(r.text) + "</pre>";
        $("nfoWrite").hidden = !todo; $("nfoWrite").textContent = "Write " + todo + " files";
      }).catch(function (e) { $("nfoOut").innerHTML = ""; fail(e); });
    };
    $("nfoWrite").onclick = function () {
      if (!confirm("Write these files onto your drives now? Only new .nfo files (and files AniBox wrote before) are written. You can undo it.")) return;
      post("/api/nfo/write", { token: token }).then(function (r) {
        toast("Written: " + (r.written || 0) + " files" + ((r.errors || []).length ? ", " + r.errors.length + " problems" : "") + ".");
        drawNfo();
      }).catch(fail);
    };
    if ($("nfoUndo")) $("nfoUndo").onclick = function () {
      if (!confirm("Remove the .nfo files AniBox wrote last time? Files changed since then are kept.")) return;
      post("/api/nfo/undo").then(function (r) { toast("Undone: " + (r.removed || 0) + " removed, " + (r.restored || 0) + " restored, " + (r.kept || 0) + " kept because they changed since."); drawNfo(); }).catch(fail);
    };
  }).catch(fail);
}
function drawTidy(items) {
  if (!items) return api("/api/tidy").then(function (r) { drawTidy(r.items); }).catch(function (e) { if ($("tidy")) $("tidy").textContent = e.message; });
  var box = $("tidy"); if (!box) return;
  box.innerHTML = items.length ? items.map(function (it) {
    return '<div class="librow"><div><div>' + esc(it.what) + '</div><div class="muted" style="font-size:12px;overflow-wrap:anywhere">' + esc(it.path) + " · " + fmtSize(it.size) + '</div></div><button class="btn small danger" data-tidy="' + esc(it.id) + '">Remove</button></div>';
  }).join("") : "Nothing to tidy up.";
  box.querySelectorAll("[data-tidy]").forEach(function (b) {
    b.onclick = function () {
      if (!confirm("Remove it for good? It doesn't go to the recycle bin.")) return;
      post("/api/tidy/remove", { id: b.getAttribute("data-tidy") }).then(function (r) { toast("Removed."); drawTidy(r.items); }).catch(fail);
    };
  });
}
function fmtSize(n) { return n >= 1073741824 ? (n / 1073741824).toFixed(1) + " GB" : n >= 1048576 ? Math.round(n / 1048576) + " MB" : Math.max(1, Math.round(n / 1024)) + " KB"; }
function drawLocalUpdate() {
  api("/api/update/local").then(function (u) {
    var box = $("localUpd"); if (!box) return;
    if (u.why_not) { box.textContent = u.why_not; return; }
    var skipped = u.skipped && u.skipped.length ? '<div style="font-size:12px;margin-top:6px">Not used: ' + u.skipped.map(function (x) { return esc(x.name) + " (" + esc(x.why) + ")"; }).join("; ") + "</div>" : "";
    box.innerHTML = (u.found ? '<button class="btn small primary" data-update-now="' + esc(u.found.version) + '">Update now to ' + esc(u.found.version) + "</button> " :
      'No newer AniBox zip in <span title="' + esc(u.folder) + '">your Downloads folder</span>. <button class="btn small" id="lookAgain">Look again</button>') + skipped;
    if ($("lookAgain")) $("lookAgain").onclick = function () { box.textContent = "Looking …"; drawLocalUpdate(); };
    wireUpdateButtons();
  }).catch(function (e) { var box = $("localUpd"); if (box) box.textContent = e.message; });
}
function drawUpdate(u) {
  var el = $("updInfo"); if (!el || !u) return;
  el.innerHTML = u.newer ? "AniBox <b>" + esc(u.latest) + "</b> is out. " + (u.canDownload ? '<button class="btn small primary" data-update-download>Download</button>' : '<a href="' + esc(u.page) + '" target="_blank" rel="noopener noreferrer">Release page ↗</a>') :
    (u.error ? esc(u.error) : u.latest ? "You have the newest version (" + esc(u.current) + ")." : "") + (u.checked ? " · checked " + ago(u.checked) : "");
  wireUpdateButtons();
}
function num(key, v) { return '<input class="input num" type="number" data-num="' + key + '" value="' + esc(v) + '">'; }
function save(key, value) {
  var b = {}; b[key] = value;
  return post("/api/settings", b).then(function (d) { settingsData.settings = d.settings; if (d.remote) drawRemote(d.remote); toast("Saved"); return d; }).catch(function (e) { fail(e); throw e; });
}
function drawRemote(r) {
  var box = $("remoteBox"); if (!box) return;
  if (!r.enabled) { box.innerHTML = r.error ? '<div class="note">' + esc(r.error) + "</div>" : ""; return; }
  var qr = qrcode(0, "M"); qr.addData(r.url); qr.make();
  box.innerHTML = '<div class="row" style="align-items:flex-start;gap:22px;margin-top:10px"><div class="qr">' + qr.createSvgTag({ cellSize: 4, margin: 0, scalable: true }) + "</div>" +
    '<div><p>Scan this with your phone, or open:<br><code style="word-break:break-all">' + esc(r.url) + "</code></p>" +
    (r.tailscale ? '<p class="muted">Away from home with Tailscale on your phone and this PC: <code style="word-break:break-all">' + esc(r.tailscale) + "</code></p>" : "") +
    '<p class="muted">Phone and PC must be in the same Wi-Fi. Anyone with this link can control AniBox, so don\'t share it.</p>' +
    '<button class="btn small" id="newKey">Make a new link</button></div></div>';
  $("newKey").onclick = function () { post("/api/remote/newkey").then(drawRemote).then(function () { toast("New link made. The old one stopped working."); }).catch(fail); };
}
function drawMpv() {
  var box = $("mpvBox"); if (!box || !state) return;
  var m = state.mpv, st = m.setup;
  if (st.state === "running") {
    var pct = st.total ? Math.round(100 * st.received / st.total) : 0;
    box.innerHTML = '<div class="field"><div class="lbl">Downloading mpv …<small>' + pct + "% of " + Math.round(st.total / 1048576) + ' MB</small><div class="meter"><i style="width:' + pct + '%"></i></div></div></div>';
  } else if (m.path) {
    box.innerHTML = '<div class="field"><div class="lbl">mpv is ready<small>' + esc(m.path) + "</small></div></div>";
  } else {
    box.innerHTML = '<div class="field"><div class="lbl">mpv isn\'t installed yet<small>' + (st.state === "error" ? esc(st.message) : "AniBox plays your episodes with mpv, the player Frostbox uses. One-time download, about 34 MB.") +
      '</small></div><button class="btn primary" id="getMpv">Download mpv</button></div>';
    $("getMpv").onclick = function () { post("/api/mpv/install").then(function () { poll(); }).catch(fail); };
  }
}
function drawScan() {
  var box = $("scanInfo"); if (!box || !state) return;
  var sc = state.scan;
  if (sc.state === "running") box.innerHTML = '<span style="color:var(--acc)">' + esc(sc.phase) + "</span> · " + sc.found.toLocaleString() + " video files found";
  else if (sc.state === "error") box.innerHTML = '<span style="color:var(--red)">' + esc(sc.message) + "</span>";
  else box.textContent = "Last scan: " + ago(state.scannedAt) + "." + (sc.state === "done" && sc.listed != null ?
    " " + sc.listed.toLocaleString() + " folders read" + (sc.reused ? ", " + sc.reused.toLocaleString() + " unchanged ones skipped" : "") + (sc.full ? " (full rescan)" : "") + "." : "");
}
