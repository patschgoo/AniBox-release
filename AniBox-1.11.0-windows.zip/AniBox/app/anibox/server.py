"""AniBox's small built-in web server: the app window talks to it, and (if switched on) the phone remote.

- The app window is served on 127.0.0.1 only. Requests that change something need the
  ``X-AniBox`` header, which other websites can't send, and the Host header must be local.
- The phone remote is a second server on the home network, only while it's switched on in
  Settings, and only under a secret link (the QR code).
"""

from __future__ import annotations

import hmac
import json
import logging
import mimetypes
import os
import re
import secrets
import socket
import threading
import time
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Optional

from . import __version__
from .apierror import ApiError
from .routes_langs import RoutesLangsMixin as LangsMixin
from .routes_files import RoutesFilesMixin as FilesMixin
from .routes_library import RoutesLibraryMixin as LibraryMixin
from .routes_missing import RoutesMissingMixin as MissingMixin
from .routes_nfo import RoutesNfoMixin as NfoMixin
from .routes_plex import RoutesPlexMixin as PlexMixin
from .routes_settings import RoutesSettingsMixin as SettingsMixin
from .routes_tv import RoutesTvMixin as TvMixin, _tv_json
from .routes_ia import RoutesIaMixin as IaMixin
from .routes_insights import RoutesInsightsMixin as InsightsMixin
from .routes_health import RoutesHealthMixin as HealthMixin
from .routes_lists import RoutesListsMixin as ListsMixin
from .routes_stream import RoutesStreamMixin as StreamMixin
from .routes_iaplaylists import RoutesIaPlaylistsMixin as IaPlaylistsMixin
from .routes_tmdb import RoutesTmdbMixin as TmdbMixin
from .routes_media import RoutesMediaMixin as MediaMixin
from .routes_iacache import RoutesIaCacheMixin as IaCacheMixin
from .routes_rewatch import RoutesRewatchMixin as RewatchMixin
from .routes_setupcheck import RoutesSetupCheckMixin as SetupCheckMixin
from .routes_anilistinfo import RoutesAniListInfoMixin as AniListInfoMixin
from .routes_collections import RoutesCollectionsMixin as CollectionsMixin
from .routes_tvcopy import RoutesTvCopyMixin as TvCopyMixin
from .routes_watchfolders import RoutesWatchFoldersMixin as WatchFoldersMixin
from .routes_profiles import RoutesProfilesMixin as ProfilesMixin
from .routes_introdetect import RoutesIntroMixin as IntroMixin
from .library import Library
from .episodes import EpisodeInfo
from .malapi import MalApi
from .mpvsetup import MpvSetup
from .embed import Embedder
from .fileops import FileOps
from .paths import PROGRAM_DIR, web_dir
from .selfupdate import SelfUpdate, UpdateError
from .player import Player
from .tvplayer import TvPlayer
from . import tv as tvlib
from . import plexhistory
from .shortcut import create_desktop_shortcut, open_folder, pick_folder
from .store import Store
from .updates import UpdateCheck

log = logging.getLogger("anibox.server")

IDLE_EXIT_SECONDS = 120
# Fixed types: on some Windows PCs the registry says .js is text/plain, which browsers then refuse to run.
CONTENT_TYPES = {
    ".html": "text/html; charset=utf-8", ".js": "application/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8", ".svg": "image/svg+xml", ".ttf": "font/ttf", ".woff2": "font/woff2",
    ".json": "application/json; charset=utf-8", ".png": "image/png", ".jpg": "image/jpeg", ".ico": "image/x-icon",
    ".txt": "text/plain; charset=utf-8",
}
BIG_BODY_PATHS = ("/api/restore",)  # a backup of a big library can be a few MB


def lan_address() -> str:
    """This PC's address in the home network (no data is sent anywhere)."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("10.255.255.255", 1))
            return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"


def tailscale_address() -> str:
    """This PC's Tailscale address (100.64.0.0/10), if Tailscale is running here; else "". """
    import ipaddress
    cgnat = ipaddress.ip_network("100.64.0.0/10")
    try:
        infos = socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET)
    except OSError:
        return ""
    for info in infos:
        ip = info[4][0]
        try:
            if ipaddress.ip_address(ip) in cgnat:
                return ip
        except ValueError:
            continue
    return ""


class App(MediaMixin, ProfilesMixin, SettingsMixin, LibraryMixin, MissingMixin, FilesMixin, LangsMixin, PlexMixin, NfoMixin, TvMixin, IaMixin, InsightsMixin, HealthMixin, ListsMixin, StreamMixin, IaPlaylistsMixin, TmdbMixin, IaCacheMixin, RewatchMixin, SetupCheckMixin, AniListInfoMixin, CollectionsMixin, TvCopyMixin, WatchFoldersMixin, IntroMixin):
    def __init__(self, data_dir: Path, port: int = 0, datasets_dir: Optional[Path] = None,
                 mpv_args=None, idle_exit: bool = True, remote_host: str = "0.0.0.0"):
        self.data_dir = data_dir
        data_dir.mkdir(parents=True, exist_ok=True)
        self.store = Store(data_dir / "anibox.db")
        self.library = Library(self.store, data_dir, datasets_dir)
        self.player = Player(self.store, self.library, data_dir, mpv_args)
        self.tv = TvPlayer(self.store, self.library)
        self.fileops = FileOps(data_dir / "file-log.jsonl")  # Add new videos, Move or rename (routes_files.py)
        self._inbox, self._import_matches, self._inbox_count = {}, {}, (0, 0.0)
        self.embed = Embedder()  # mpv's picture inside the AniBox window (embed.py)
        self.embed.on_gone = self._embed_gone
        self.player.embed_wid = self._embed_wid
        self.mpv_setup = MpvSetup(data_dir)
        self.poster_dir = data_dir / "posters"
        self.poster_dir.mkdir(exist_ok=True)
        self.backup_dir = data_dir / "backups"
        self.mal = MalApi(data_dir / "mal")
        self.episodes = EpisodeInfo(data_dir / "episodes")
        self._kitsu_ids = None
        self.updates = UpdateCheck(self.store)
        self.plex_signin = plexhistory.SignIn()
        self.plex_import = {"state": "idle"}
        self.plex_copy = {"state": "idle"}
        self.plex_details_path = data_dir / "plex-details.json"
        self.plex_posters_dir = data_dir / "plexposters"
        self._plex_snapshot = None
        self.plex_check = {"state": "idle"}  # the Missing page's Plex check (routes_missing.py)
        self.plex_check_path = data_dir / "plex-check.json"
        self._plex_report = None
        self._plex_report_meta = {}
        self.nfo_plan = None  # the last preview, written only after "Write"
        self._lang_busy = {}  # show id -> "loading" while AniBox reads a file's track list
        self.nfo_undo = data_dir / "nfo-undo.jsonl"
        self._ia_init()  # Internet Archive search and downloads (routes_ia.py, iarchive.py)
        self._lists_init()  # MyAnimeList / AniList lists and sync (routes_lists.py, listsync.py)
        self._stream_init()  # Internet Archive videos played straight from archive.org (routes_stream.py, stream.py)
        self._playlists_init()  # series playlists of those videos (routes_iaplaylists.py, iaplaylists.py)
        self._tvcopy_init()  # TV copies of videos the TV can't play (routes_tvcopy.py, tvcopy.py)
        try:
            if self.store.auto_backup(self.backup_dir):
                log.info("Daily copy of the watch progress saved in %s", self.backup_dir)
        except Exception:
            log.exception("Daily copy of the watch progress failed")
        self.idle_exit = idle_exit
        self.remote_host = remote_host
        self.last_seen = time.time()
        self.ui = ThreadingHTTPServer(("127.0.0.1", port), make_handler(self, remote=False))
        self.ui.daemon_threads = True
        self.remote: Optional[ThreadingHTTPServer] = None
        self.remote_error = ""
        self._stopping = threading.Event()
        self.sync_remote()
        self._iacache_init()  # Internet Archive streams through a cache on this PC (routes_iacache.py, iacache.py)
        self.selfupdate = SelfUpdate(PROGRAM_DIR, data_dir, self.port)  # "Update now" (selfupdate.py)
        self.update_result = self.selfupdate.take_result()  # shown once on Home after an update
        self._update_result_checked_late = False

    @property
    def port(self) -> int:
        return self.ui.server_address[1]

    @property
    def url(self) -> str:
        return f"http://127.0.0.1:{self.port}/"

    # -- life cycle ----------------------------------------------------------------------------

    def serve_forever(self) -> None:
        threading.Thread(target=self._watchdog, daemon=True, name="anibox-watchdog").start()
        self.updates.check_later()
        self.ia.start()  # Internet Archive downloads from last time go on
        self._watch_start()  # new videos in the inbox, automatic rescans (routes_watchfolders.py)
        try:
            self.ui.serve_forever(poll_interval=0.3)
        finally:
            self.close()

    def _watchdog(self) -> None:
        while not self._stopping.wait(5):
            if self.idle_exit and time.time() - self.last_seen > IDLE_EXIT_SECONDS and not self.player.running \
                    and not self.tv.active and not self.ia.busy() and not self.iacache.busy() \
                    and not self._tvcopy_busy():  # the TV streams from this PC; downloads, Keep and TV copies finish first
                self.shutdown()

    def _embed_wid(self):
        if not self.store.settings().get("embed_player", True):
            return None
        return self.embed.wid()

    def _embed_gone(self) -> None:
        """The AniBox window closed while mpv was drawing inside it: stop (and save) instead of
        playing on without a picture."""
        if self.player.embedded_wid:
            log.info("Stopping playback: the AniBox window it was shown in was closed")
            self.player.stop()

    def _close_for_update(self) -> None:
        log.info("Closing for the update")
        try:
            self.player.stop()
        except Exception:
            pass
        self.shutdown()

    def shutdown(self) -> None:
        if self._stopping.is_set():
            return
        self._stopping.set()
        threading.Thread(target=self.ui.shutdown, daemon=True).start()

    def close(self) -> None:
        self._stopping.set()
        try:
            self.player.shutdown()
        except Exception:
            pass
        try:
            self.tv.shutdown()
        except Exception:
            pass
        try:
            self.ia.shutdown()  # downloads stop here and go on next time
        except Exception:
            pass
        cache = getattr(self, "iacache", None)
        if cache is not None:
            try:
                cache.shutdown()  # loading stops here (it goes on next time); maps and index are saved
            except Exception:
                log.warning("Closing the Internet Archive cache failed", exc_info=True)
        try:
            self._tvcopy_close()  # the copy being made stops (its .part is deleted) and waits for next time
        except Exception:
            log.warning("Stopping the TV copies failed", exc_info=True)
        self._stop_remote()
        self.ui.server_close()
        self.store.close()

    # -- phone remote -------------------------------------------------------------------------------

    def _stop_remote(self) -> None:
        if self.remote:
            log.info("Phone remote off")
            srv, self.remote = self.remote, None
            threading.Thread(target=lambda: (srv.shutdown(), srv.server_close()), daemon=True).start()

    def sync_remote(self) -> None:
        s = self.store.settings()
        want = bool(s.get("remote_enabled"))
        port = int(s.get("remote_port") or 43211)
        if self.remote and (not want or self.remote.server_address[1] != port):
            self._stop_remote()
        if want and not self.remote:
            try:
                self.remote = ThreadingHTTPServer((self.remote_host, port), make_handler(self, remote=True))
                self.remote.daemon_threads = True
                threading.Thread(target=self.remote.serve_forever, daemon=True, name="anibox-remote").start()
                self.remote_error = ""
                log.info("Phone remote on port %s", self.remote.server_address[1])
            except OSError as exc:
                self.remote_error = f"The phone remote couldn't start on port {port} ({exc})."
                log.warning(self.remote_error)

    def remote_info(self) -> dict:
        s = self.store.settings()
        port = self.remote.server_address[1] if self.remote else int(s.get("remote_port") or 43211)
        return {
            "enabled": bool(self.remote),
            "url": f"http://{lan_address()}:{port}/r/{s['remote_key']}/",
            "tailscale": (f"http://{ts}:{port}/r/{s['remote_key']}/" if (ts := tailscale_address()) else ""),
            "error": self.remote_error,
        }

    # -- posters --------------------------------------------------------------------------------------

    def poster(self, mal_id: str) -> Optional[bytes]:
        if not mal_id.isdigit():
            return None
        path = self.poster_dir / f"{mal_id}.jpg"
        if path.is_file():
            return path.read_bytes()
        if not self.store.settings().get("posters", True):
            return None
        info = self.library.datasets().titles.get(mal_id) or {}
        url = info.get("picture") or info.get("thumbnail")
        if not url or not url.startswith("https://"):
            return None
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "AniBox"})
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = resp.read(5_000_000)
        except Exception:
            return None
        tmp = path.with_suffix(".part")
        tmp.write_bytes(data)
        os.replace(tmp, path)
        return data

    # -- API ------------------------------------------------------------------------------------------

    def _routes(self, attr: str) -> dict:
        """Routes declared by the mixins: ``GET_ROUTES = {"/api/x": "_method"}`` (called with the query)
        and ``POST_ROUTES`` (called with the body). Only for the AniBox window, never the phone remote."""
        cache = self.__dict__.setdefault("_route_cache", {})
        if attr not in cache:
            routes = {}
            for klass in reversed(type(self).__mro__):
                routes.update(klass.__dict__.get(attr) or {})
            cache[attr] = routes
        return cache[attr]

    def api_get(self, path: str, query: dict, remote: bool):
        self.last_seen = time.time()
        if not remote and path in self._routes("GET_ROUTES"):
            return getattr(self, self._routes("GET_ROUTES")[path])(query)
        if path == "/api/ping":
            return {"app": "AniBox", "version": __version__}
        if path == "/api/state":
            out = {"player": self.tv.state() if self.tv.active else self.player.state(), "version": __version__}
            if remote:
                return out["player"]
            out["embed"] = {"available": self.embed.available, "attached": self.embed.attached,
                            "enabled": bool(self.store.settings().get("embed_player", True)), "reason": self.embed.reason,
                            "startFull": bool(self.store.settings().get("fullscreen"))}
            out.update(scan=self.library.status, scannedAt=self.library.scanned_at,
                       mpv={"path": self.player.mpv_path() or "", "setup": self.mpv_setup.status},
                       hasFolders=bool(self.store.settings().get("folders")))
            return out
        if path == "/api/episodes":  # phone remote: episodes of the current show
            state = self.tv.state() if self.tv.active else self.player.state()
            show = self.player.show_of(state["showId"] or state["showIdle"])  # also Internet Archive items
            if not show:
                return []
            progress = self.store.all_progress()
            return [{"id": e["key"], "nr": e["number"] if e["number"] is not None else "·", "label": e["label"],
                     "watched": bool((progress.get(e["key"]) or {}).get("watched")), "current": e["key"] == state["key"]}
                    for e in show["episodes"]]
        if remote:
            raise ApiError("Not found", 404)
        if path.startswith("/api/ia/"):
            return self._ia_get(path, query)
        if path == "/api/home":
            return self._home()
        if path == "/api/import":
            return self._import_view()
        if path == "/api/import/count":
            return {"count": self._import_count()}
        if path == "/api/tidy":
            return {"items": self._tidy_list()}
        if path == "/api/files/state":
            return {"job": self.fileops.state, "undo": self.fileops.last_batch()}
        if path == "/api/update/local":
            return self.selfupdate.status()
        if path == "/api/library":
            return self._library()
        if path == "/api/show":
            return self._show(query.get("id", ""))
        if path == "/api/missing":
            return self._missing(query.get("source", "folders"))
        if path == "/api/missing/plex/sections":
            return self._plex_sections()
        if path == "/api/settings":
            libs = {n: {**v, "kind": self.library.library_kind(n), "autoKind": self.library.auto_kind(n)}
                    for n, v in self.library.libraries().items()}
            return {"settings": self._public_settings(), "libraries": libs,
                    "remote": self.remote_info(), "dataDir": str(self.data_dir), "folders": self._folders_info(),
                    "update": self.updates.info()}
        if path == "/api/search":
            return {"results": self.library.search_titles(query.get("q", ""))}
        if path == "/api/langs":
            return self._langs_info(query.get("id", ""))
        if path == "/api/episode-info":
            return self._episode_info(query.get("id", ""))
        if path == "/api/details":
            return self._details(query.get("id", ""), refresh=query.get("refresh") == "1")
        if path == "/api/franchises":
            return self._franchises()
        if path == "/api/franchise":
            return self._franchise(query.get("key", ""))
        if path == "/api/update":
            return self.updates.info()
        if path == "/api/plex":
            return {"saved": self.plex_signin.saved(), "import": self.plex_import, "note": plexhistory.SIGN_IN_NOTE,
                    "copy": self.plex_copy, "snapshot": self._plex_summary()}
        if path == "/api/plex/diff":
            return self._plex_diff()
        if path == "/api/plex/poll":
            return self.plex_signin.poll()
        if path == "/api/plex/agents":
            return self._plex_agents()
        if path == "/api/tv":
            return {"devices": [_tv_json(d) for d in self.tv.known()], "last": self.store.settings().get("tv_device") or ""}
        if path == "/api/nfo":
            return {"protected": self.store.settings().get("protected") or [],
                    "libraries": self.library.libraries(), "canUndo": self.nfo_undo.is_file()}
        raise ApiError("Not found", 404)

    def api_post(self, path: str, body: dict, remote: bool):
        self.last_seen = time.time()
        if path == "/api/cmd":
            target = self.tv if self.tv.active else self.player
            try:
                target.command(str(body.get("cmd") or ""), body.get("value"), body.get("id"))
            except tvlib.TvError as exc:
                raise ApiError(str(exc), 400, exc.reason)
            return {"ok": True}
        if remote:
            raise ApiError("Not found", 404)
        if path in self._routes("POST_ROUTES"):
            return getattr(self, self._routes("POST_ROUTES")[path])(body)
        if path.startswith("/api/ia/"):
            return self._ia_post(path, body)
        if path == "/api/play":
            if self.tv.active:
                self.tv.stop()
            self.player.play(show_id=str(body.get("show") or ""), key=str(body.get("key") or ""),
                             from_start=bool(body.get("fromStart")), once=bool(body.get("once")))
            return {"ok": True}
        if path == "/api/watched":
            return self._set_watched(body)
        if path == "/api/settings":
            return self._save_settings(body)
        if path == "/api/scan":
            folders = self.store.settings().get("folders") or []
            if not folders:
                raise ApiError("Add a folder first.")
            self.library.scan_async(folders, full=bool(body.get("full")))
            return {"ok": True}
        if path == "/api/mpv/install":
            self.mpv_setup.start()
            return {"ok": True, "status": self.mpv_setup.status}
        if path == "/api/missing/plex":
            return self._plex_check_start(body)
        if path == "/api/ignore":
            return self._ignore(str(body.get("key") or ""), bool(body.get("ignore", True)))
        if path == "/api/remote/newkey":
            self.store.update_settings({"remote_key": secrets.token_urlsafe(9)})
            return self.remote_info()
        if path == "/api/pick-folder":
            return {"path": pick_folder()}
        if path == "/api/langs":
            return self._langs_post(body)
        if path == "/api/lock":
            show_id = str(body.get("show") or "")
            if not self.library.show(show_id):
                raise ApiError("Show not found", 404)
            self.store.set_unlocked(show_id, bool(body.get("unlock")))
            log.info("Show %s %s", show_id, "unlocked" if body.get("unlock") else "locked again")
            return {"ok": True}
        if path == "/api/lock/now":
            return {"ok": True, "locked": self.library.lock_everything_now()}
        if path == "/api/match":
            mal = body.get("mal_id")
            show = self.library.set_match(str(body.get("show") or ""), None if mal is None else str(mal))
            return {"ok": True, "title": show["title"], "mal_id": show["mal_id"]}
        if path == "/api/restore":
            result = self.store.import_data(body.get("backup") or {})
            self.library.reapply_matches()
            log.info("Backup restored: %s", result)
            return {"ok": True, **result}
        if path == "/api/open":
            folders = self._folders_info()
            what = str(body.get("what") or "data")
            target = {"data": folders["home"], "logs": folders["logs"], "backups": folders["backups"]}.get(what)
            if not target:
                raise ApiError("Unknown folder")
            Path(target).mkdir(parents=True, exist_ok=True)
            open_folder(Path(target))
            return {"ok": True}
        if path == "/api/portable":
            return self._make_portable()
        if path == "/api/shortcut":
            return {"ok": True, "path": create_desktop_shortcut()}
        if path == "/api/update/check":
            return self.updates.check()
        if path == "/api/update/download":
            try:
                return self.updates.download()
            except ValueError as exc:
                raise ApiError(str(exc))
        if path == "/api/update/install":
            try:
                out = self.selfupdate.install()
            except UpdateError as exc:
                raise ApiError(str(exc))
            threading.Timer(1.5, self._close_for_update).start()  # let the window get the answer first
            return out
        if path == "/api/import/match":
            return self._import_match(body)
        if path == "/api/import/apply":
            return self._import_apply(body)
        if path == "/api/tidy/remove":
            return self._tidy_remove(body)
        if path == "/api/files/undo":
            return self._files_undo()
        if path == "/api/reveal":
            return self._reveal(body)
        if path == "/api/move/preview":
            return self._move_preview(body)
        if path == "/api/move/apply":
            return self._move_apply(body)
        if path == "/api/embed/attach":
            return self.embed.attach(str(body.get("marker") or ""))
        if path == "/api/embed/place":
            def num(k, d=0.0):
                try:
                    return float(body.get(k, d))
                except (TypeError, ValueError):
                    return d
            self.embed.place(num("x"), num("y"), num("w", 1), num("h", 1), num("dpr", 1), num("iw", 1), num("ih", 1),
                             bool(body.get("visible")))
            return {"ok": True}
        if path == "/api/update/dismiss":
            self.update_result = None
            return {"ok": True}
        if path == "/api/plex/signin":
            log.info("Plex sign-in started")
            return self.plex_signin.start()
        if path == "/api/plex/import":
            return self._plex_import()
        if path == "/api/plex/copy":
            return self._plex_copy()
        if path in ("/api/tv/discover", "/api/tv/play", "/api/tv/pair", "/api/tv/add"):
            try:
                return self._tv_post(path, body)
            except tvlib.TvError as exc:
                log.info("TV: %s (%s)", exc, exc.reason)
                raise ApiError(str(exc), 400, exc.reason)
        if path == "/api/nfo/preview":
            return self._nfo_preview([str(x) for x in body.get("libraries") or []], bool(body.get("posters")))
        if path == "/api/nfo/write":
            return self._nfo_write(str(body.get("token") or ""))
        if path == "/api/nfo/undo":
            return self._nfo_undo()
        if path == "/api/quit":
            self.player.stop()
            self.shutdown()
            return {"ok": True}
        raise ApiError("Not found", 404)

    # -- API helpers ----------------------------------------------------------------------------------

    # -- NFO info files (see nfo.py): preview first, write only on request, undo -------------------

    # -- languages: dub/sub badges --------------------------------------------------------------------

def make_handler(app: App, remote: bool):
    root = web_dir()

    class Handler(BaseHTTPRequestHandler):
        server_version = "AniBox"
        protocol_version = "HTTP/1.1"

        def log_message(self, *args):
            pass

        # -- helpers
        def _send(self, status: int, body: bytes, ctype: str, cache: bool = False) -> None:
            self.send_response(status)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "max-age=86400" if cache else "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.end_headers()
            self.wfile.write(body)

        def _json(self, obj, status: int = 200) -> None:
            self._send(status, json.dumps(obj, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")

        def _file(self, rel: str) -> None:
            path = (root / rel).resolve()
            if root.resolve() not in path.parents or not path.is_file():
                self._send(404, b"Not found", "text/plain")
                return
            ctype = CONTENT_TYPES.get(path.suffix.lower()) or mimetypes.guess_type(str(path))[0] or "application/octet-stream"
            self._send(200, path.read_bytes(), ctype, cache=rel.startswith(("fonts/", "vendor/")))

        def _route(self) -> Optional[str]:
            """The path inside the app, or None if the request isn't allowed."""
            url = urllib.parse.urlsplit(self.path)
            path = urllib.parse.unquote(url.path)
            if not remote:
                host = (self.headers.get("Host") or "").split(":")[0]
                if host not in ("127.0.0.1", "localhost"):
                    return None
                return path
            key = app.store.settings().get("remote_key") or ""
            prefix = f"/r/{key}"
            if not key or not hmac.compare_digest(path[: len(prefix)].encode(), prefix.encode()):
                return None
            rest = path[len(prefix):]
            if rest and not rest.startswith("/"):
                return None
            return rest or ""

        # -- methods
        def do_GET(self):
            path = self._route()
            if path is None:
                self._send(403 if not remote else 404, b"Not found", "text/plain")
                return
            if remote and path == "":
                self.send_response(301)
                self.send_header("Location", urllib.parse.urlsplit(self.path).path + "/")
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
            query = dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(self.path).query))
            try:
                if path == "/api/backup" and not remote:
                    data = json.dumps(app.store.export_data(), ensure_ascii=False, indent=1).encode("utf-8")
                    name = time.strftime("AniBox-backup-%Y-%m-%d.json")
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json; charset=utf-8")
                    self.send_header("Content-Disposition", f'attachment; filename="{name}"')
                    self.send_header("Content-Length", str(len(data)))
                    self.send_header("Cache-Control", "no-store")
                    self.end_headers()
                    self.wfile.write(data)
                    return
                if path == "/api/missing/export" and not remote:
                    data, name, ctype = app._missing_export(query.get("source", "folders"), query.get("format", "html"))
                    self.send_response(200)
                    self.send_header("Content-Type", ctype)
                    self.send_header("Content-Disposition", f'attachment; filename="{name}"')
                    self.send_header("Content-Length", str(len(data)))
                    self.send_header("Cache-Control", "no-store")
                    self.end_headers()
                    self.wfile.write(data)
                    return
                if path.startswith("/api/"):
                    self._json(app.api_get(path, query, remote))
                elif remote:
                    if path in ("/", "/index.html"):
                        self._file("remote.html")
                    elif path == "/icon.svg":
                        self._file("icon.svg")
                    elif path.startswith("/fonts/"):
                        self._file(path[1:])
                    elif path.startswith("/img/"):
                        data = app.poster(path[5:])
                        self._send(200 if data else 404, data or b"", "image/jpeg", cache=bool(data))
                    else:
                        self._send(404, b"Not found", "text/plain")
                elif path == "/":
                    self._file("index.html")
                elif path.startswith("/img/"):
                    data = app.poster(path[5:])
                    if data:
                        self._send(200, data, "image/jpeg", cache=True)
                    else:
                        self._send(404, b"", "image/jpeg")
                elif path.startswith("/ia/thumb/"):  # Internet Archive pictures, fetched and kept by AniBox
                    data, ctype = app._ia_thumb(path[len("/ia/thumb/"):])
                    self._send(200 if data else 404, data or b"", ctype, cache=bool(data))
                elif path in app._routes("PAGE_FILES"):  # fixed pages of a feature (the OAuth sign-in returns)
                    self._file(app._routes("PAGE_FILES")[path])
                elif path.startswith("/tmdb/poster/"):  # series and movie posters from TMDB, kept by AniBox
                    data = app._tmdb_poster(path[len("/tmdb/poster/"):])
                    self._send(200 if data else 404, data or b"", "image/jpeg", cache=bool(data))
                elif path.startswith("/plexposter/"):
                    name = path[len("/plexposter/"):]
                    f = app.plex_posters_dir / name
                    ok = bool(re.fullmatch(r"[\w.-]+\.(jpg|png|webp|gif)", name)) and f.is_file()
                    ctype = CONTENT_TYPES.get(f.suffix.lower()) or "image/jpeg"
                    self._send(200 if ok else 404, f.read_bytes() if ok else b"", ctype, cache=ok)
                else:
                    self._file(path.lstrip("/"))
            except ApiError as exc:
                self._json({"ok": False, "error": str(exc), "reason": exc.reason}, exc.status)
            except Exception as exc:
                log.exception("GET %s failed", path)
                self._json({"ok": False, "error": str(exc)}, 500)

        def do_POST(self):
            try:
                length = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                length = 0
            limit = 50_000_000 if urllib.parse.urlsplit(self.path).path in BIG_BODY_PATHS else 1_000_000
            if length > limit:
                self.close_connection = True
                self._send(413, b"Too large", "text/plain")
                return
            raw = self.rfile.read(length) if length else b"{}"  # always read it, so the connection stays clean
            path = self._route()
            if path is None or (not remote and self.headers.get("X-AniBox") != "1"):
                self._send(403, b"Forbidden", "text/plain")
                return
            try:
                body = json.loads(raw.decode("utf-8") or "{}")
                if not isinstance(body, dict):
                    raise ApiError("Bad request")
                self._json(app.api_post(path, body, remote))
            except ApiError as exc:
                self._json({"ok": False, "error": str(exc), "reason": exc.reason}, exc.status)
            except (ValueError, RuntimeError) as exc:
                log.info("POST %s: %s", path, exc)
                self._json({"ok": False, "error": str(exc)}, 400)
            except Exception as exc:
                log.exception("POST %s failed", path)
                self._json({"ok": False, "error": str(exc)}, 500)

    return Handler
