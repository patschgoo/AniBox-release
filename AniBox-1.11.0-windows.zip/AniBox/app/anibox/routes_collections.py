"""Your own collections (usercollections.py): the routes for the window.

All of them are for the AniBox window only (the phone remote can't reach them); changes are POSTs
with the ``X-AniBox: 1`` header like everywhere else. Cards are the Library page's cards (same
progress, posters, language badges), so a collection page looks and filters like the library.

Part of the App class (see server.py); the methods use the App's attributes.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

from . import usercollections as col
from . import stream
from .apierror import ApiError
from .watching import show_card

HOME_CARDS = 14  # cards in a pinned collection's row on Home
PREVIEW_CARDS = 12


def _playlist_card(s: dict) -> dict:
    """A series playlist (iaplaylists.py summary) as a card like a show's."""
    return {"id": s["show"], "title": s["name"], "folder": s["name"], "library": "Internet Archive", "kind": "playlist",
            "playlist": s["id"], "poster": s.get("img") or "", "files": s.get("episodes") or 0,
            "watched": s.get("watched") or 0, "finished": bool(s.get("episodes")) and s["watched"] >= s["episodes"],
            "started": bool(s.get("lastPlayed")), "last_played": s.get("lastPlayed") or 0.0, "added": s.get("created") or 0.0,
            "next": s.get("next"), "year": None, "mal_id": None, "badges": []}


class RoutesCollectionsMixin:
    GET_ROUTES = {
        "/api/collections": "_col_list",
        "/api/collections/one": "_col_one",
        "/api/collections/options": "_col_options",
        "/api/collections/candidates": "_col_candidates",
        "/api/collections/for-show": "_col_for_show",
        "/api/collections/home": "_col_home",
    }
    POST_ROUTES = {
        "/api/collections/create": "_col_create",
        "/api/collections/update": "_col_update",
        "/api/collections/delete": "_col_delete",
        "/api/collections/add": "_col_add",
        "/api/collections/remove": "_col_remove",
        "/api/collections/order": "_col_order",
        "/api/collections/preview": "_col_preview",
    }

    def _collections(self) -> col.Collections:
        c = self.__dict__.get("_collections_obj")
        if c is None:  # made on first use, so App.__init__ needs nothing for it
            c = self.__dict__.setdefault("_collections_obj", col.Collections(self.data_dir))
        return c

    def _col(self, fn, *args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except col.CollectionError as exc:
            raise ApiError(str(exc), exc.status)

    # -- cards ---------------------------------------------------------------------------------------------

    def _col_show_cards(self, shows: List[dict]) -> List[dict]:
        """Library cards (progress, poster, language badges, section) for these shows, in this order."""
        if not shows:
            return []
        settings = self.store.settings()
        progress = self.store.all_progress()
        posters = bool(settings.get("posters", True))
        cards = self._cards_with_langs([(s, show_card(s, progress, posters)) for s in shows])
        for c, s in zip(cards, shows):
            c["kind"], c["atype"] = self.library.show_kind(s)
        return self._tmdb_cards(cards)

    def _col_info_for(self):
        """card -> its AniList summary (genres, tags) from the cache on this PC, or None."""
        by_mal = self._anilist_summaries_by_mal()
        return lambda c: by_mal.get(str(c.get("mal_id"))) if c.get("mal_id") else None

    def _col_resolve(self, c: dict) -> Tuple[List[dict], List[dict]]:
        """(cards of a hand-picked collection in its order, entries not found right now)."""
        order: List[Tuple[str, object]] = []
        missing, seen = [], set()
        everything: Optional[List[dict]] = None
        playlists: Optional[Dict[str, dict]] = None
        for it in c["items"]:
            if it["id"].startswith(stream.PLAYLIST_PREFIX):
                if playlists is None:
                    playlists = {s["show"]: _playlist_card(s) for s in self.playlists.summaries()}
                card = playlists.get(it["id"])
                if card and card["id"] not in seen:
                    seen.add(card["id"])
                    order.append(("card", card))
                elif not card:
                    missing.append(it)
                continue
            show = self.library.show(it["id"])
            if not show and it.get("mal") and it.get("folder"):  # moved to another library, same folder name
                if everything is None:
                    everything = self.library.shows(all_libraries=True)
                show = next((s for s in everything if str(s.get("mal_id") or "") == it["mal"] and s["folder"] == it["folder"]
                             and s["id"] not in seen), None)
            if show and show["id"] not in seen:
                seen.add(show["id"])
                order.append(("show", show))
            elif not show:
                missing.append(it)
        shows = [x for k, x in order if k == "show"]
        cards = iter(self._col_show_cards(shows))
        return [next(cards) if k == "show" else x for k, x in order], missing

    def _col_shared(self, ctx: dict, key: str):
        """What one request shares between its collections, made once: the library's cards ("lib") and the
        AniList lookup ("info")."""
        if key not in ctx:
            ctx[key] = self._library()["shows"] if key == "lib" else self._col_info_for()
        return ctx[key]

    def _col_cards(self, c: dict, ctx: Optional[dict] = None) -> Tuple[List[dict], List[dict], int]:
        """(cards, missing entries, anime without AniList extras that a genre/tag rule couldn't judge)."""
        if c["kind"] == "hand":
            cards, missing = self._col_resolve(c)
            return cards, missing, 0
        ctx = {} if ctx is None else ctx
        cards, unknown = col.apply_rules(self._col_shared(ctx, "lib"), c["rules"], c["sort"], self._col_shared(ctx, "info"))
        return cards, [], unknown

    def _col_cover(self, c: dict, cards: List[dict]) -> Tuple[str, str]:
        """(picture address, "poster" | "banner"): the chosen one, else the first show's poster."""
        cov = c.get("cover")
        if cov:
            card = next((x for x in cards if x["id"] == cov["show"]), None)
            if card:
                if cov["kind"] == "banner" and self._al_enabled():
                    info = self._anilist_summary_for_mal(card.get("mal_id"))
                    if info and info.get("banner"):
                        return info["banner"], "banner"
                if card.get("poster"):
                    return card["poster"], "poster"
        first = next((x for x in cards if x.get("poster")), None)
        return (first["poster"], "poster") if first else ("", "")

    def _col_summary(self, c: dict, cards: List[dict], missing: List[dict], unknown: int) -> dict:
        cover, cover_kind = self._col_cover(c, cards)
        return {"id": c["id"], "name": c["name"], "description": c["description"], "kind": c["kind"], "sort": c["sort"],
                "pinned": c["pinned"], "count": len(cards), "finished": sum(1 for x in cards if x.get("finished")),
                "started": sum(1 for x in cards if x.get("started")), "missing": len(missing), "unknown": unknown,
                "cover": cover, "coverKind": cover_kind, "changed": c["changed"]}

    # -- GET -------------------------------------------------------------------------------------------------

    def _col_list(self, query: dict) -> dict:
        store = self._collections()
        ctx: dict = {}
        out = []
        for c in store.all():
            cards, missing, unknown = self._col_cards(c, ctx)
            out.append(self._col_summary(c, cards, missing, unknown))
        return {"collections": out, "notice": store.notice}

    def _col_one(self, query: dict) -> dict:
        c = self._col(self._collections().get, query.get("id", ""))
        cards, missing, unknown = self._col_cards(c)
        out = self._col_summary(c, cards, missing, unknown)
        out.update(cards=cards, missingItems=missing, rules=c["rules"], coverChoice=c.get("cover"),
                   sorts=[{"id": s, "label": col.SORT_LABELS[s]} for s in col.SORTS],
                   infoEnabled=self._al_enabled(),
                   banners=self._col_banners(cards) if self._al_enabled() else {})
        return out

    def _col_banners(self, cards: List[dict]) -> Dict[str, str]:
        """show id -> AniList banner, for the cover choice (only what's cached on this PC)."""
        out = {}
        for x in cards:
            info = self._anilist_summary_for_mal(x.get("mal_id")) if x.get("mal_id") else None
            if info and info.get("banner"):
                out[x["id"]] = info["banner"]
        return out

    def _col_options(self, query: dict) -> dict:
        """What the smart-collection editor offers: libraries, genres and tags (from the AniList extras on
        this PC, with how many of your shows have each), years."""
        cards = self._library()["shows"]
        info_for = self._col_info_for()
        genres: Dict[str, int] = {}
        tags: Dict[str, int] = {}
        known = 0
        for c in cards:
            info = info_for(c)
            if not info:
                continue
            known += 1
            for g in info.get("genres") or []:
                genres[g] = genres.get(g, 0) + 1
            for t in info.get("tags") or []:
                tags[t] = tags.get(t, 0) + 1
        years = [c["year"] for c in cards if isinstance(c.get("year"), int)]
        return {"libraries": self.library.selected_libraries(),
                "genres": sorted(genres.items(), key=lambda g: (-g[1], g[0].casefold())),
                "tags": sorted(tags.items(), key=lambda t: (-t[1], t[0].casefold())),
                "years": [min(years), max(years)] if years else [], "known": known,
                "anime": sum(1 for c in cards if c.get("mal_id")), "infoEnabled": self._al_enabled(),
                "sorts": [{"id": s, "label": col.SORT_LABELS[s]} for s in col.SORTS]}

    def _col_candidates(self, query: dict) -> dict:
        """Everything a hand-picked collection can hold: the library's shows and the series playlists."""
        settings = self.store.settings()
        posters = bool(settings.get("posters", True))
        shows = sorted(self.library.shows(), key=lambda s: (s.get("title") or s["folder"]).casefold())
        cards = self._tmdb_cards([dict(show_card(s, {}, posters), kind=self.library.show_kind(s)[0]) for s in shows])
        out = [{"id": c["id"], "title": c["title"], "library": c["library"], "year": c.get("year"), "poster": c.get("poster") or "",
                "folder": c["folder"]} for c in cards]
        out += [{"id": s["show"], "title": s["name"], "library": "Internet Archive", "year": None, "poster": s.get("img") or "",
                 "folder": ""} for s in sorted(self.playlists.summaries(), key=lambda s: s["name"].casefold())]
        return {"shows": out}

    def _col_for_show(self, query: dict) -> dict:
        show_id = query.get("id", "")
        mine = {c["id"] for c in self._collections().containing(show_id)}
        return {"collections": [{"id": c["id"], "name": c["name"], "count": len(c["items"]), "in": c["id"] in mine}
                                for c in self._collections().all() if c["kind"] == "hand"]}

    def _col_home(self, query: dict) -> dict:
        ctx: dict = {}
        rows = []
        for c in self._collections().all():
            if not c["pinned"]:
                continue
            cards, _missing, _unknown = self._col_cards(c, ctx)
            if cards:
                rows.append({"id": c["id"], "name": c["name"], "kind": c["kind"], "count": len(cards), "cards": cards[:HOME_CARDS]})
        return {"rows": rows}

    # -- POST -----------------------------------------------------------------------------------------------

    def _col_item(self, show_id: str) -> dict:
        """The entry a show (or series playlist) gets in a hand-picked collection."""
        show_id = str(show_id or "")
        if show_id.startswith(stream.PLAYLIST_PREFIX):
            s = next((s for s in self.playlists.summaries() if s["show"] == show_id), None)
            if not s:
                raise ApiError("That series playlist doesn't exist (anymore).", 404)
            return {"id": show_id, "title": s["name"]}
        show = self.library.show(show_id)
        if not show:
            raise ApiError("Show not found", 404)
        return {"id": show["id"], "mal": str(show.get("mal_id") or ""), "folder": show["folder"],
                "title": show.get("title") or show["folder"]}

    def _col_create(self, body: dict) -> dict:
        kind = str(body.get("kind") or "hand")
        items = [self._col_item(body["show"])] if body.get("show") and kind == "hand" else []
        c = self._col(self._collections().create, body.get("name") or "", kind, str(body.get("description") or ""),
                      body.get("rules"), str(body.get("sort") or "title"), items)
        return {"ok": True, "collection": c}

    def _col_update(self, body: dict) -> dict:
        def opt(key):
            return body[key] if key in body and body[key] is not None else None
        c = self._col(self._collections().update, str(body.get("id") or ""),
                      name=opt("name"), description=opt("description"), rules=opt("rules"),
                      sort=str(body["sort"]) if body.get("sort") else None,
                      cover=body.get("cover") if "cover" in body else False,
                      pinned=bool(body["pinned"]) if "pinned" in body else None)
        return {"ok": True, "collection": c}

    def _col_delete(self, body: dict) -> dict:
        self._col(self._collections().delete, str(body.get("id") or ""))
        return {"ok": True}

    def _col_add(self, body: dict) -> dict:
        added = self._col(self._collections().add, str(body.get("id") or ""), self._col_item(body.get("show")))
        return {"ok": True, "added": added}

    def _col_remove(self, body: dict) -> dict:
        removed = self._col(self._collections().remove, str(body.get("id") or ""), str(body.get("show") or ""))
        return {"ok": True, "removed": removed}

    def _col_order(self, body: dict) -> dict:
        c = self._col(self._collections().set_order, str(body.get("id") or ""), body.get("items"))
        return {"ok": True, "collection": c}

    def _col_preview(self, body: dict) -> dict:
        """How many shows smart rules find (for the editor, before saving)."""
        sort = str(body.get("sort") or "title")
        cards, unknown = col.apply_rules(self._library()["shows"], body.get("rules"), sort if sort in col.SORTS else "title",
                                         self._col_info_for())
        return {"count": len(cards), "unknown": unknown, "cards": cards[:PREVIEW_CARDS]}
